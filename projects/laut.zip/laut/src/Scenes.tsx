import React from "react";
import {
  AbsoluteFill,
  Easing,
  Img,
  interpolate,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

const SANS = "'Helvetica Neue', Arial, 'DejaVu Sans', sans-serif";
const SERIF = "Georgia, 'DejaVu Serif', serif";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/* ---------- Helper ---------- */

const Fade: React.FC<{children: React.ReactNode}> = ({children}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const opacity = interpolate(
    frame,
    [0, 18, durationInFrames - 18, durationInFrames],
    [0, 1, 1, 0],
    clamp
  );
  return <AbsoluteFill style={{opacity}}>{children}</AbsoluteFill>;
};

const Background: React.FC<{hue: number; image?: string}> = ({hue, image}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const x = Math.sin(frame / 90) * 220;
  const y = Math.cos(frame / 110) * 160;
  const zoom = interpolate(frame, [0, durationInFrames], [1, 1.15], clamp);

  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(160deg, hsl(${hue},60%,7%), hsl(${hue + 30},55%,16%))`,
      }}
    >
      {image ? (
        <AbsoluteFill style={{transform: `scale(${zoom})`}}>
          <Img src={staticFile(image)} style={{width: "100%", height: "100%", objectFit: "cover"}} />
        </AbsoluteFill>
      ) : (
        <>
          <div
            style={{
              position: "absolute",
              width: 1100,
              height: 1100,
              left: 100 + x,
              top: -300 + y,
              background: `radial-gradient(circle, hsla(${hue},80%,50%,0.35), transparent 65%)`,
            }}
          />
          <div
            style={{
              position: "absolute",
              width: 900,
              height: 900,
              right: -100 - x,
              bottom: -300 - y,
              background: `radial-gradient(circle, hsla(${hue + 40},80%,55%,0.28), transparent 65%)`,
            }}
          />
        </>
      )}
      {/* Vignette */}
      <AbsoluteFill
        style={{
          background: "radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.75) 100%)",
        }}
      />
    </AbsoluteFill>
  );
};

/* ---------- Scenes ---------- */

export const Title: React.FC<{title: string; subtitle: string}> = ({title, subtitle}) => {
  const frame = useCurrentFrame();
  const spacing = interpolate(frame, [0, 120], [10, 28], {...clamp, easing: Easing.out(Easing.cubic)});
  const lineW = interpolate(frame, [20, 60], [0, 420], {...clamp, easing: Easing.out(Easing.cubic)});
  const subOpacity = interpolate(frame, [45, 75], [0, 1], clamp);

  return (
    <Fade>
      <Background hue={210} />
      <AbsoluteFill style={{justifyContent: "center", alignItems: "center"}}>
        <div
          style={{
            fontFamily: SERIF,
            fontSize: 190,
            color: "white",
            letterSpacing: spacing,
            paddingLeft: spacing,
          }}
        >
          {title}
        </div>
        <div style={{height: 3, width: lineW, background: "rgba(255,255,255,0.8)", margin: "30px 0"}} />
        <div
          style={{
            fontFamily: SANS,
            fontSize: 44,
            letterSpacing: 8,
            textTransform: "uppercase",
            color: "rgba(255,255,255,0.85)",
            opacity: subOpacity,
          }}
        >
          {subtitle}
        </div>
      </AbsoluteFill>
    </Fade>
  );
};

export const Chapter: React.FC<{
  number: number;
  heading: string;
  lines: string[];
  hue: number;
  image?: string;
}> = ({number, heading, lines, hue, image}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  // Heading
  const headX = interpolate(frame, [10, 40], [-60, 0], {...clamp, easing: Easing.out(Easing.cubic)});
  const headOpacity = interpolate(frame, [10, 40], [0, 1], clamp);

  // Subtitle bergantian
  const seg = durationInFrames / lines.length;
  const idx = Math.min(Math.floor(frame / seg), lines.length - 1);
  const local = frame - idx * seg;
  const lineOpacity = interpolate(local, [0, 12, seg - 12, seg], [0, 1, 1, 0], clamp);
  const lineY = interpolate(local, [0, 14], [18, 0], {...clamp, easing: Easing.out(Easing.cubic)});

  return (
    <Fade>
      <Background hue={hue} image={image} />

      <div
        style={{
          position: "absolute",
          left: 140,
          top: 200,
          opacity: headOpacity,
          transform: `translateX(${headX}px)`,
        }}
      >
        <div style={{fontFamily: SANS, fontSize: 30, letterSpacing: 10, color: `hsl(${hue},80%,70%)`}}>
          BAB {String(number).padStart(2, "0")}
        </div>
        <div style={{fontFamily: SERIF, fontSize: 96, color: "white", marginTop: 12, maxWidth: 1200}}>
          {heading}
        </div>
        <div style={{height: 4, width: 140, background: `hsl(${hue},80%,60%)`, marginTop: 24}} />
      </div>

      <AbsoluteFill style={{justifyContent: "flex-end", alignItems: "center", paddingBottom: 170}}>
        <div
          style={{
            opacity: lineOpacity,
            transform: `translateY(${lineY}px)`,
            fontFamily: SANS,
            fontSize: 48,
            lineHeight: 1.35,
            color: "white",
            textAlign: "center",
            maxWidth: 1400,
            padding: "18px 40px",
            background: "rgba(0,0,0,0.45)",
            borderRadius: 8,
            textShadow: "0 2px 10px rgba(0,0,0,0.8)",
          }}
        >
          {lines[idx]}
        </div>
      </AbsoluteFill>
    </Fade>
  );
};

export const Stat: React.FC<{value: number; suffix?: string; label: string; hue: number}> = ({
  value,
  suffix = "",
  label,
  hue,
}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const current = Math.round(
    interpolate(frame, [10, durationInFrames * 0.65], [0, value], {
      ...clamp,
      easing: Easing.out(Easing.cubic),
    })
  );
  const labelOpacity = interpolate(frame, [30, 55], [0, 1], clamp);

  return (
    <Fade>
      <Background hue={hue} />
      <AbsoluteFill style={{justifyContent: "center", alignItems: "center"}}>
        <div
          style={{
            fontFamily: SERIF,
            fontSize: 260,
            color: `hsl(${hue},85%,72%)`,
            textShadow: `0 0 60px hsla(${hue},90%,60%,0.5)`,
          }}
        >
          {current.toLocaleString("id-ID")}
          {suffix}
        </div>
        <div
          style={{
            fontFamily: SANS,
            fontSize: 44,
            color: "rgba(255,255,255,0.9)",
            opacity: labelOpacity,
            maxWidth: 1300,
            textAlign: "center",
            marginTop: 10,
          }}
        >
          {label}
        </div>
      </AbsoluteFill>
    </Fade>
  );
};

export const Quote: React.FC<{text: string; author: string; hue: number}> = ({text, author, hue}) => {
  const frame = useCurrentFrame();
  const textOpacity = interpolate(frame, [15, 45], [0, 1], clamp);
  const authorOpacity = interpolate(frame, [70, 100], [0, 1], clamp);

  return (
    <Fade>
      <Background hue={hue} />
      <AbsoluteFill style={{justifyContent: "center", alignItems: "center", padding: "0 260px"}}>
        <div
          style={{
            fontFamily: SERIF,
            fontStyle: "italic",
            fontSize: 70,
            lineHeight: 1.35,
            color: "white",
            textAlign: "center",
            opacity: textOpacity,
          }}
        >
          “{text}”
        </div>
        <div
          style={{
            fontFamily: SANS,
            fontSize: 36,
            letterSpacing: 6,
            textTransform: "uppercase",
            color: `hsl(${hue},80%,70%)`,
            marginTop: 50,
            opacity: authorOpacity,
          }}
        >
          — {author}
        </div>
      </AbsoluteFill>
    </Fade>
  );
};

export const Outro: React.FC<{text: string}> = ({text}) => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [15, 50], [0, 1], clamp);

  return (
    <Fade>
      <Background hue={210} />
      <AbsoluteFill style={{justifyContent: "center", alignItems: "center"}}>
        <div style={{fontFamily: SERIF, fontSize: 90, color: "white", opacity}}>{text}</div>
      </AbsoluteFill>
    </Fade>
  );
};
