export const FPS = 30;

export type Scene =
  | {type: "title"; title: string; subtitle: string; duration: number}
  | {
      type: "chapter";
      number: number;
      heading: string;
      lines: string[];
      duration: number;
      hue: number;
      image?: string; // opsional: nama file di folder public/, mis. "karang.jpg"
    }
  | {type: "stat"; value: number; suffix?: string; label: string; duration: number; hue: number}
  | {type: "quote"; text: string; author: string; duration: number; hue: number}
  | {type: "outro"; text: string; duration: number};

// duration dalam DETIK
export const scenes: Scene[] = [
  {
    type: "title",
    title: "SAMUDRA",
    subtitle: "Dunia di Bawah Permukaan",
    duration: 6,
  },
  {
    type: "chapter",
    number: 1,
    heading: "Planet Biru",
    hue: 205,
    duration: 12,
    lines: [
      "Lebih dari 70% permukaan Bumi tertutup lautan.",
      "Namun sebagian besar dasarnya belum dipetakan secara rinci.",
      "Peta permukaan Bulan sering lebih detail daripada peta dasar laut kita.",
    ],
  },
  {
    type: "stat",
    value: 71,
    suffix: "%",
    label: "permukaan Bumi adalah lautan",
    hue: 200,
    duration: 6,
  },
  {
    type: "chapter",
    number: 2,
    heading: "Zona Gelap",
    hue: 230,
    duration: 12,
    lines: [
      "Di bawah kedalaman 200 meter, cahaya matahari mulai lenyap.",
      "Banyak makhluk di sini menghasilkan cahayanya sendiri.",
      "Fenomena ini disebut bioluminesensi.",
    ],
  },
  {
    type: "stat",
    value: 10935,
    suffix: " m",
    label: "kedalaman Challenger Deep, titik terdalam di lautan",
    hue: 250,
    duration: 6,
  },
  {
    type: "quote",
    text: "Laut, sekali ia memikat, akan menjerat kita dalam jaring keajaibannya selamanya.",
    author: "Jacques Cousteau",
    hue: 190,
    duration: 8,
  },
  {
    type: "chapter",
    number: 3,
    heading: "Segitiga Terumbu Karang",
    hue: 175,
    duration: 12,
    lines: [
      "Perairan Indonesia adalah bagian jantung Coral Triangle.",
      "Kawasan ini punya keanekaragaman hayati laut tertinggi di dunia.",
      "Menjaganya berarti menjaga masa depan kita sendiri.",
    ],
  },
  {
    type: "outro",
    text: "Terima kasih telah menonton",
    duration: 7,
  },
];

export const totalFrames = scenes.reduce((sum, s) => sum + Math.round(s.duration * FPS), 0);
