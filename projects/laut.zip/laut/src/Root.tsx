import React from "react";
import {Composition} from "remotion";
import {Dokumenter} from "./Dokumenter";
import {FPS, totalFrames} from "./script";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Dokumenter"
      component={Dokumenter}
      durationInFrames={totalFrames}
      fps={FPS}
      width={1920}
      height={1080}
    />
  );
};
