import React from "react";
import {AbsoluteFill, Sequence} from "remotion";
import {FPS, scenes} from "./script";
import {Chapter, Outro, Quote, Stat, Title} from "./Scenes";

export const Dokumenter: React.FC = () => {
  let from = 0;

  return (
    <AbsoluteFill style={{backgroundColor: "black"}}>
      {scenes.map((scene, i) => {
        const dur = Math.round(scene.duration * FPS);
        const start = from;
        from += dur;

        return (
          <Sequence key={i} from={start} durationInFrames={dur}>
            {scene.type === "title" && <Title {...scene} />}
            {scene.type === "chapter" && <Chapter {...scene} />}
            {scene.type === "stat" && <Stat {...scene} />}
            {scene.type === "quote" && <Quote {...scene} />}
            {scene.type === "outro" && <Outro {...scene} />}
          </Sequence>
        );
      })}

      {/* Letterbox sinematik */}
      <div style={{position: "absolute", top: 0, left: 0, right: 0, height: 90, background: "black"}} />
      <div style={{position: "absolute", bottom: 0, left: 0, right: 0, height: 90, background: "black"}} />

      {/*
        Musik latar (opsional): taruh music.mp3 di public/, lalu aktifkan:
        import {Audio, staticFile} from "remotion";
        <Audio src={staticFile("music.mp3")} volume={0.4} />
      */}
    </AbsoluteFill>
  );
};
