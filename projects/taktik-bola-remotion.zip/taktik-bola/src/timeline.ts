// Fungsi murni (tanpa React) - menghitung kamera, waktu sumber, dan kotak tracking.
import { BOXES, CUES, Cam, LINKS, SEGMENTS } from './data';

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const easeOut = (p: number) => 1 - Math.pow(1 - p, 3);
const easeOutBack = (x: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};

export const isFrozen = (i: number) => SEGMENTS[i].src[0] === SEGMENTS[i].src[1];

export const segIndexAt = (t: number): number => {
  for (let i = 0; i < SEGMENTS.length; i++) {
    if (t >= SEGMENTS[i].out[0] && t < SEGMENTS[i].out[1]) return i;
  }
  return SEGMENTS.length - 1;
};

export const camAt = (t: number): Cam => {
  const i = segIndexAt(t);
  const seg = SEGMENTS[i];
  const p = clamp((t - seg.out[0]) / (seg.out[1] - seg.out[0]), 0, 1);
  const e = isFrozen(i) ? easeOut(p) : p;
  const [a, b] = seg.cam;
  return { cx: lerp(a.cx, b.cx, e), cy: lerp(a.cy, b.cy, e), s: lerp(a.s, b.s, e) };
};

export const srcAt = (t: number): number => {
  const i = segIndexAt(t);
  const seg = SEGMENTS[i];
  const p = clamp((t - seg.out[0]) / (seg.out[1] - seg.out[0]), 0, 1);
  return lerp(seg.src[0], seg.src[1], p);
};

export type DrawBox = {
  id: string;
  cx: number;
  cy: number;
  w: number;
  h: number;
  opacity: number;
  label?: string;
  space: boolean;
  labelOpacity: number;
};
export type DrawLine = { x1: number; y1: number; x2: number; y2: number; opacity: number };

export const overlayAt = (t: number): { boxes: DrawBox[]; lines: DrawLine[] } => {
  const active: Record<string, { b: (typeof BOXES)[number]; opacity: number }> = {};
  const boxes: DrawBox[] = [];
  for (const b of BOXES) {
    const segEnd = SEGMENTS[b.seg].out[1];
    if (t < b.at || t > segEnd) continue;
    const p = clamp((t - b.at) / 0.3, 0, 1);
    const fade = clamp((segEnd - t) / 0.25, 0, 1);
    const sc = 0.55 + 0.45 * easeOutBack(p);
    const opacity = clamp(p * 1.6, 0, 1) * fade;
    active[b.id] = { b, opacity };
    boxes.push({
      id: b.id,
      cx: b.cx,
      cy: b.cy,
      w: b.w * sc,
      h: b.h * sc,
      opacity,
      label: b.label,
      space: b.kind === 'space',
      labelOpacity: clamp((t - b.at - 0.15) / 0.25, 0, 1) * fade,
    });
  }
  const lines: DrawLine[] = [];
  for (const [ia, ib] of LINKS) {
    const A = active[ia];
    const B = active[ib];
    if (!A || !B) continue;
    const start = Math.max(A.b.at, B.b.at) + 0.1;
    const q = easeOut(clamp((t - start) / 0.35, 0, 1));
    if (q <= 0) continue;
    // garis tumbuh dari kotak yang muncul lebih dulu
    const [from, to] = A.b.at <= B.b.at ? [A.b, B.b] : [B.b, A.b];
    lines.push({
      x1: from.cx,
      y1: from.cy,
      x2: lerp(from.cx, to.cx, q),
      y2: lerp(from.cy, to.cy, q),
      opacity: Math.min(A.opacity, B.opacity),
    });
  }
  return { boxes, lines };
};

export const cueAt = (t: number) => CUES.find((c) => t >= c.from && t < c.to) ?? null;
