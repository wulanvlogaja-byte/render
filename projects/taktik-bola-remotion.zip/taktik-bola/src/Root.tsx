import React from 'react';
import { Composition } from 'remotion';
import { TaktikBola } from './TaktikBola';
import { DURATION_FRAMES, FPS, H, W } from './data';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="TaktikBola"
      component={TaktikBola}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={W}
      height={H}
    />
  );
};
