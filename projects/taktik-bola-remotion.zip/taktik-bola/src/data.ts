// ============================================================
//  DATA UTAMA - semua timing, kamera, kotak tracking & caption
//  ada di sini. Ubah angka di sini kalau mau fine-tuning.
//  Semua koordinat kotak = piksel di video sumber (1280x720).
// ============================================================

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const SRC_W = 1280;
export const SRC_H = 720;

export const VIDEO_FILE = 'taktik.mp4';
export const AUDIO_FILE = 'narasi.mp3';

export const AUDIO_SEC = 52.271; // durasi narasi
export const TAIL_SEC = 2.2; // ekor setelah narasi (end card)
export const TOTAL_SEC = AUDIO_SEC + TAIL_SEC;
export const DURATION_FRAMES = Math.ceil(TOTAL_SEC * FPS);
export const END_CARD_AT = 52.35; // end card mulai muncul (detik)

// Area video (band) di tengah kanvas 9:16, sisanya background blur
export const BAND_H = 1152;
export const BAND_TOP = (H - BAND_H) / 2;

export const BRAND = {
  ig: '@idin_iskndr',
  yt: 'idintacticalfootball',
};

// ---------------- Kamera ----------------
// cx,cy = titik tengah (px video sumber), s = skala (px layar per px sumber)
export type Cam = { cx: number; cy: number; s: number };

// ---------------- Segmen timeline ----------------
// out = [mulai, selesai] di video hasil (detik)
// src = [mulai, selesai] di video mentah (detik). Kalau sama = FREEZE.
export type Seg = { out: [number, number]; src: [number, number]; cam: [Cam, Cam]; note: string };

export const SEGMENTS: Seg[] = [
  // 0
  { note: 'A play', out: [0, 0.9], src: [0, 0.9], cam: [{ cx: 640, cy: 360, s: 0.95 }, { cx: 760, cy: 330, s: 1.05 }] },
  // 1 FREEZE: garis belakang Sevilla + transisi Madrid
  { note: 'A freeze', out: [0.9, 6.258], src: [0.9, 0.9], cam: [{ cx: 760, cy: 330, s: 1.05 }, { cx: 850, cy: 330, s: 1.75 }] },
  // 2
  { note: 'B1 play', out: [6.258, 11.236], src: [1.37, 5.6], cam: [{ cx: 640, cy: 360, s: 1.3 }, { cx: 640, cy: 360, s: 1.3 }] },
  // 3
  { note: 'B2 play', out: [11.236, 11.95], src: [5.6, 6.2], cam: [{ cx: 640, cy: 360, s: 1.3 }, { cx: 640, cy: 360, s: 1.3 }] },
  // 4 FREEZE: bek nomor 2 keluar posisi
  { note: 'B2 freeze', out: [11.95, 14.934], src: [6.2, 6.2], cam: [{ cx: 640, cy: 360, s: 1.3 }, { cx: 640, cy: 360, s: 1.4 }] },
  // 5
  { note: 'B3 play', out: [14.934, 16.6], src: [6.2, 7.2], cam: [{ cx: 640, cy: 360, s: 1.4 }, { cx: 700, cy: 370, s: 1.25 }] },
  // 6 FREEZE: bek nomor 2 tertinggal + ruang kosong
  { note: 'B3 freeze', out: [16.6, 21.263], src: [7.2, 7.2], cam: [{ cx: 700, cy: 370, s: 1.25 }, { cx: 740, cy: 375, s: 1.3 }] },
  // 7
  { note: 'C1 play', out: [21.263, 23.6], src: [7.5, 8.9], cam: [{ cx: 640, cy: 360, s: 1.0 }, { cx: 640, cy: 370, s: 1.3 }] },
  // 8 FREEZE: Madrid menumpuk, sisi lain kosong
  { note: 'C1 freeze', out: [23.6, 29.869], src: [8.9, 8.9], cam: [{ cx: 640, cy: 370, s: 1.3 }, { cx: 660, cy: 380, s: 1.55 }] },
  // 9
  { note: 'C2 play', out: [29.869, 31.87], src: [8.9, 10.0], cam: [{ cx: 660, cy: 380, s: 1.55 }, { cx: 620, cy: 360, s: 1.45 }] },
  // 10 FREEZE: menyerbu kotak penalti
  { note: 'C2 freeze', out: [31.87, 34.136], src: [10.0, 10.0], cam: [{ cx: 620, cy: 360, s: 1.45 }, { cx: 600, cy: 360, s: 1.5 }] },
  // 11
  { note: 'C3 play', out: [34.136, 35.04], src: [10.0, 10.9], cam: [{ cx: 600, cy: 360, s: 1.5 }, { cx: 620, cy: 330, s: 1.5 }] },
  // 12 FREEZE: bek menatap bola, ruang di depan kiper
  { note: 'C3 freeze', out: [35.04, 38.26], src: [10.9, 10.9], cam: [{ cx: 620, cy: 330, s: 1.5 }, { cx: 640, cy: 330, s: 1.6 }] },
  // 13
  { note: 'C4 play', out: [38.26, 39.83], src: [10.9, 12.0], cam: [{ cx: 640, cy: 330, s: 1.6 }, { cx: 880, cy: 360, s: 1.5 }] },
  // 14 FREEZE: penyelesaian akhir
  { note: 'C4 freeze', out: [39.83, 44.732], src: [12.0, 12.0], cam: [{ cx: 880, cy: 360, s: 1.5 }, { cx: 900, cy: 360, s: 1.5 }] },
  // 15
  { note: 'C5 play', out: [44.732, 45.95], src: [12.0, 12.7], cam: [{ cx: 900, cy: 360, s: 1.5 }, { cx: 900, cy: 360, s: 1.5 }] },
  // 16 selebrasi slow-mo
  { note: 'D play', out: [45.95, 50.9], src: [12.76, 15.1], cam: [{ cx: 680, cy: 400, s: 1.45 }, { cx: 680, cy: 400, s: 1.3 }] },
  // 17 tahan frame terakhir + end card
  { note: 'End freeze', out: [50.9, TOTAL_SEC], src: [15.1, 15.1], cam: [{ cx: 680, cy: 400, s: 1.3 }, { cx: 680, cy: 400, s: 1.3 }] },
];

// ---------------- Kotak tracking ----------------
export type Box = {
  id: string;
  seg: number; // index segmen FREEZE tempat kotak ini hidup
  at: number; // detik (video hasil) kotak muncul
  cx: number;
  cy: number;
  w: number;
  h: number;
  label?: string;
  kind?: 'player' | 'space';
};

const P = (id: string, seg: number, at: number, cx: number, cy: number, w = 60, h = 88): Box => ({ id, seg, at, cx, cy, w, h, kind: 'player' });

export const BOXES: Box[] = [
  // --- seg 1: garis belakang Sevilla (merah), lalu transisi Madrid (putih) ---
  P('A-r1', 1, 1.0, 1009, 271, 72, 92),
  P('A-r2', 1, 1.3, 1077, 318, 72, 92),
  P('A-r3', 1, 1.6, 985, 437, 72, 92),
  P('A-w1', 1, 2.5, 982, 302, 72, 92),
  P('A-w2', 1, 3.3, 821, 203, 72, 92),
  P('A-w3', 1, 4.1, 603, 486, 84, 124),

  // --- seg 4: bek nomor 2 keluar posisi ---
  P('B-d2', 4, 12.1, 892, 458, 250, 470),
  P('B-dr', 4, 13.0, 394, 286, 280, 424),

  // --- seg 6: bek nomor 2 tertinggal + ruang kosong ---
  P('C-dr', 6, 16.7, 440, 330, 190, 430),
  P('C-d2', 6, 17.2, 763, 458, 330, 480),
  P('C-ball', 6, 17.6, 560, 522, 84, 84),
  { id: 'C-space', seg: 6, at: 18.0, cx: 1005, cy: 430, w: 220, h: 330, label: 'RUANG KOSONG', kind: 'space' },

  // --- seg 8: Madrid menumpuk di sisi bola, Sevilla bergeser, sisi lain kosong ---
  P('D-m1', 8, 23.9, 538, 219),
  P('D-m2', 8, 24.6, 674, 332),
  P('D-m3', 8, 25.2, 538, 388),
  P('D-m4', 8, 25.8, 427, 437),
  P('D-s4', 8, 26.6, 529, 341),
  P('D-s1', 8, 27.0, 785, 311),
  P('D-s2', 8, 27.4, 866, 332),
  P('D-s3', 8, 27.8, 796, 398),
  { id: 'D-space', seg: 8, at: 28.5, cx: 700, cy: 575, w: 300, h: 170, label: 'SISI KOSONG', kind: 'space' },

  // --- seg 10: pemain Madrid menyerbu kotak penalti ---
  P('E-a1', 10, 32.0, 673, 326),
  P('E-a2', 10, 32.3, 668, 372),
  P('E-a3', 10, 32.6, 428, 289),
  P('E-a4', 10, 32.9, 415, 425),

  // --- seg 12: bek menatap bola, ruang di depan kiper terbuka ---
  P('F-b1', 12, 35.1, 575, 277),
  P('F-b2', 12, 35.4, 426, 295),
  P('F-b3', 12, 35.7, 450, 366),
  P('F-b4', 12, 36.0, 812, 320),
  { id: 'F-space', seg: 12, at: 36.5, cx: 700, cy: 280, w: 150, h: 110, label: 'RUANG KOSONG', kind: 'space' },
  P('F-kp', 12, 37.2, 938, 268, 64, 88),

  // --- seg 14: penyelesaian akhir ---
  P('G-fin', 14, 40.0, 770, 385, 60, 96),
  P('G-kp', 14, 40.9, 890, 378, 124, 74),
  { id: 'G-ball', seg: 14, at: 42.2, cx: 1153, cy: 351, w: 70, h: 70, label: 'GOL', kind: 'player' },
];

// garis penghubung antar kotak (id, id)
export const LINKS: [string, string][] = [
  ['A-r1', 'A-r2'], ['A-r2', 'A-r3'], ['A-w1', 'A-w2'], ['A-w2', 'A-w3'], ['A-w1', 'A-r1'],
  ['B-d2', 'B-dr'],
  ['C-dr', 'C-d2'], ['C-d2', 'C-space'], ['C-dr', 'C-ball'],
  ['D-m1', 'D-m2'], ['D-m2', 'D-m3'], ['D-m3', 'D-m4'], ['D-s4', 'D-s1'], ['D-s1', 'D-s2'], ['D-s2', 'D-s3'], ['D-m3', 'D-s4'],
  ['E-a1', 'E-a2'], ['E-a2', 'E-a3'], ['E-a3', 'E-a4'],
  ['F-b1', 'F-b2'], ['F-b2', 'F-b3'], ['F-b3', 'F-b4'], ['F-space', 'F-kp'],
  ['G-fin', 'G-kp'], ['G-kp', 'G-ball'],
];

// ---------------- Caption (sudut kiri atas) ----------------
// Teks sudah dikoreksi dari SRT (Sevia -> Sevilla, back -> bek).
export type Cue = { from: number; to: number; text: string };
export const CUES: Cue[] = [
  { from: 0, to: 2.275, text: 'Perhatikan garis belakang Sevilla.' },
  { from: 2.275, to: 6.258, text: 'Madrid mulai transisi cepat, dan lawan belum sempat rapi.' },
  { from: 6.258, to: 11.236, text: 'Pemain Madrid membawa bola lewat tepi lapangan dengan kecepatan penuh.' },
  { from: 11.236, to: 14.934, text: 'Bek nomor 2 terpaksa keluar posisi untuk menutup.' },
  { from: 14.934, to: 17.921, text: 'Satu tipuan, dan bek nomor 2 tertinggal.' },
  { from: 17.921, to: 21.263, text: 'Kotak ini menandai ruang kosong di belakangnya.' },
  { from: 21.263, to: 25.9, text: 'Dari atas terlihat jelas: beberapa pemain Madrid menumpuk di sisi bola,' },
  { from: 25.9, to: 28.233, text: 'menarik bek Sevilla bergeser.' },
  { from: 28.233, to: 29.869, text: 'Sisi lain mulai kosong.' },
  { from: 29.869, to: 34.136, text: 'Lalu pemain Madrid menyerbu kotak penalti dari arah berbeda.' },
  { from: 34.136, to: 36.198, text: 'Para bek hanya menatap bola.' },
  { from: 36.198, to: 38.26, text: 'Ruang di depan kiper terbuka.' },
  { from: 38.26, to: 39.612, text: 'Penyelesaian akhir.' },
  { from: 39.612, to: 41.816, text: 'Kiper sudah terlambat bergerak.' },
  { from: 41.816, to: 44.732, text: 'Di titik inilah peluang berubah jadi gol.' },
  { from: 44.732, to: 47.0, text: 'Ruang dibuka satu per satu,' },
  { from: 47.0, to: 50.066, text: 'dan satu kesalahan posisi cukup untuk menghukum.' },
  { from: 50.066, to: 52.271, text: 'Itulah taktik di balik gol ini.' },
];
