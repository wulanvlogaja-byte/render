# Taktik Bola - Madrid vs Sevilla (Remotion, 9:16)

Composition ID : TaktikBola  |  1080x1920 @ 30fps  |  ±54,5 detik
Media          : public/taktik.mp4 (mentahan), public/narasi.mp3 (narasi)

## Render
- GitHub Actions: jalankan workflow `render-remotion.yml` (workflow_dispatch), hasil ada di Artifacts (taktik-bola.mp4).
- Lokal: `npm install` lalu `npm run render` (atau `npm run studio` untuk preview).

## Fine-tuning
Semua ada di `src/data.ts`:
- SEGMENTS : kapan video jalan / freeze (src = detik di mentahan, out = detik di hasil) + gerak kamera
- BOXES / LINKS : posisi kotak tracking (piksel video 1280x720), waktu muncul, label
- CUES : teks narasi di kiri atas
- BRAND : nama akun IG & YouTube
