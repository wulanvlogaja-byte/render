# POV Ilmu Gaib (Remotion, 9:16 1080x1920, 30 fps, ±31 dtk)

```
src/Video.jsx   komponen murni Video({ t }); cue visual dari kata di timing.json
src/Root.tsx    pembungkus Remotion: frame -> t, <Audio>, durationInFrames dari timing.json
src/index.ts    registerRoot
src/timing.json hasil timing.cjs (durasi, fps, kalimat + waktu tiap kata)
timing.cjs      silencedetect (-35dB, d=0.25) + DP monoton -> timing.json (butuh ffmpeg)
public/narasi.mp3   audio narasi
assets/narasi.srt   teks narasi (hanya teksnya yang dipakai)
render-remotion.example.yml  contoh workflow
```

## Menjalankan
- Lokal: `npm install && npm run render` -> `out/video.mp4` (`npm start` untuk Studio).
- GitHub Actions: commit folder ini, buka tab Actions -> **render-remotion** -> *Run workflow*
  (isi input folder bila workflow Anda memintanya). Hasil ada di artifact.
- Ganti audio/teks: timpa `public/narasi.mp3` dan `assets/narasi.srt`, jalankan `node timing.cjs`.
  Cue di `Video.jsx` memakai `C(indeksKalimat, 'kata')`, jadi ikut bergeser otomatis.
