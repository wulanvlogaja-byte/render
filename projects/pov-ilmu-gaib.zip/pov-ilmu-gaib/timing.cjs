// Membuat src/timing.json dari public/narasi.mp3 + assets/narasi.srt (hanya teksnya dipakai).
// Pakai: node timing.cjs   (butuh ffmpeg di PATH; tanpa dependensi npm)
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const FPS = 30;
const TAIL = 0.7; // detik hening di akhir video setelah narasi selesai
const AUDIO = path.join(__dirname, 'public/narasi.mp3');
const SRT = path.join(__dirname, 'assets/narasi.srt');
const OUT = path.join(__dirname, 'src/timing.json');

// 1) teks kalimat dari SRT (timestamp SRT diabaikan)
const sentences = fs.readFileSync(SRT, 'utf8').replace(/\r/g, '').split(/\n\s*\n/)
  .map((b) => b.trim().split('\n').slice(2).join(' ').trim()).filter(Boolean);

// 2) durasi audio + silencedetect
const dur = parseFloat(spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', AUDIO], { encoding: 'utf8' }).stdout);
const sd = spawnSync('ffmpeg', ['-hide_banner', '-i', AUDIO, '-af', 'silencedetect=noise=-35dB:d=0.25', '-f', 'null', '-'], { encoding: 'utf8' }).stderr;
const sil = [];
for (const m of sd.matchAll(/silence_start: ([\d.]+)/g)) sil.push({ s: +m[1] });
let k = 0;
for (const m of sd.matchAll(/silence_end: ([\d.]+)/g)) { if (sil[k]) sil[k].e = +m[1]; k++; }
// segmen bicara = ruang di antara hening
const segs = [];
let cur = 0;
for (const x of sil) { if (x.s > cur + 0.05) segs.push([cur, x.s]); cur = x.e ?? dur; }
if (dur > cur + 0.05) segs.push([cur, dur]);
console.log(`audio ${dur.toFixed(3)}s, ${sil.length} hening, ${segs.length} segmen bicara, ${sentences.length} kalimat`);

// 3) DP monoton: tiap kalimat dapat >=1 segmen berurutan; biaya = simpangan log laju (huruf/detik bicara) dari laju global
const letters = (s) => s.replace(/[^\p{L}\p{N}]/gu, '').length;
const N = sentences.length, M = segs.length;
if (M < N) throw new Error('Segmen bicara < jumlah kalimat; turunkan d= pada silencedetect');
const L = sentences.map(letters);
const ref = L.reduce((a, b) => a + b, 0) / segs.reduce((a, [s, e]) => a + (e - s), 0);
const spDur = (a, b) => { let d = 0; for (let i = a; i < b; i++) d += segs[i][1] - segs[i][0]; return d; };
const cost = (i, a, b) => Math.log(L[i] / spDur(a, b) / ref) ** 2;
const INF = 1e18;
const dp = Array.from({ length: N + 1 }, () => new Array(M + 1).fill(INF));
const bk = Array.from({ length: N + 1 }, () => new Array(M + 1).fill(-1));
dp[0][0] = 0;
for (let i = 1; i <= N; i++) for (let b = i; b <= M; b++) for (let a = i - 1; a < b; a++) {
  if (dp[i - 1][a] >= INF) continue;
  const c = dp[i - 1][a] + cost(i - 1, a, b);
  if (c < dp[i][b]) { dp[i][b] = c; bk[i][b] = a; }
}
const groups = []; // [a,b) per kalimat
for (let i = N, b = M; i >= 1; i--) { const a = bk[i][b]; groups.unshift([a, b]); b = a; }

// 4) waktu tiap kata: proporsional bobot huruf pada "waktu bicara" kalimat (hening dilewati)
const out = [];
groups.forEach(([a, b], i) => {
  const sg = segs.slice(a, b);
  const D = sg.reduce((x, [s, e]) => x + e - s, 0);
  const at = (p) => { let r = p; for (const [s, e] of sg) { if (r <= e - s + 1e-9) return s + r; r -= e - s; } return sg[sg.length - 1][1]; };
  const toks = sentences[i].split(/\s+/);
  const wt = toks.map((w) => Math.max(1, letters(w)) + (/[.,!?]$/.test(w) ? 0.8 : 0));
  const T = wt.reduce((x, y) => x + y, 0);
  // jangkar: tiap hening di dalam kalimat dipaksa jatuh tepat di batas kata terdekat (hindari kata "bergeser" melewati jeda)
  const cum = [0]; wt.forEach((x, j) => cum.push(cum[j] + x));
  const anchors = [[0, 0]];
  let off = 0, lastJ = 0;
  for (let g = 0; g < sg.length - 1; g++) {
    off += sg[g][1] - sg[g][0];
    let bj = -1, bd = 1e9;
    for (let j = lastJ + 1; j < toks.length; j++) { const d = Math.abs((cum[j] / T) * D - off); if (d < bd) { bd = d; bj = j; } }
    if (bj > 0) { anchors.push([cum[bj], off]); lastJ = bj; }
  }
  anchors.push([T, D]);
  const posOf = (w) => { for (let q = 1; q < anchors.length; q++) if (w <= anchors[q][0] + 1e-9) { const [w0, p0] = anchors[q - 1], [w1, p1] = anchors[q]; return w1 === w0 ? p1 : p0 + ((w - w0) / (w1 - w0)) * (p1 - p0); } return D; };
  const words = toks.map((w, j) => ({ w, start: +at(posOf(cum[j]) + 2e-6).toFixed(3), end: +at(Math.max(0, posOf(cum[j + 1]) - 1e-6)).toFixed(3) }));
  const rate = L[i] / D;
  console.log(`#${i + 1} ${sg[0][0].toFixed(2)}-${sg[sg.length - 1][1].toFixed(2)}s  ${rate.toFixed(1)} huruf/s (${(rate / ref).toFixed(2)}x)  ${sentences[i]}`);
  if (rate / ref < 0.6 || rate / ref > 1.6) console.warn(`  ! laju kalimat #${i + 1} janggal, cek segmentasi`);
  out.push({ i, text: sentences[i], start: sg[0][0], end: sg[sg.length - 1][1], words });
});

const duration = +(dur + TAIL).toFixed(3);
fs.writeFileSync(OUT, JSON.stringify({ fps: FPS, audioDuration: +dur.toFixed(3), duration, durationInFrames: Math.ceil(duration * FPS), sentences: out }, null, 1));
console.log('tulis', OUT);
