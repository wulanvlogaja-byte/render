// Komposisi inti: komponen React murni Video({ t }).
// Semua animasi = fungsi dari t (detik). Tanpa state, timer, atau Math.random.
// Cue visual diambil dari kata di timing.json via C(kalimat, kata, urutan).
import React from 'react';
import timing from './timing.json';

export const W = 1080;
export const H = 1920;
const DISPLAY = "'Lilita One', 'Inter', 'Arial Black', sans-serif";
const BODY = "'Inter', 'Helvetica Neue', Arial, sans-serif";
const INK = '#0d0820';

/* ---------- util murni ---------- */
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, k) => a + (b - a) * k;
const prog = (t, a, b) => clamp((t - a) / (b - a));
const eOut = (k) => 1 - Math.pow(1 - k, 3);
const eInOut = (k) => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2);
const eBack = (k) => { const c = 1.70158; return 1 + (c + 1) * Math.pow(k - 1, 3) + c * Math.pow(k - 1, 2); };
const pop = (t, a, d = 0.35) => (t < a ? 0 : eBack(prog(t, a, a + d)));
const fadeIn = (t, a, d = 0.25) => prog(t, a, a + d);
const hash = (n) => { // deterministik, 0..1
  let x = Math.imul(n | 0, 374761393) + 668265263 | 0;
  x = Math.imul(x ^ (x >>> 13), 1274126177);
  x ^= x >>> 16;
  return (x >>> 0) % 100000 / 100000;
};
const norm = (s) => s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
// waktu mulai kata (detik) dari timing.json
export const C = (si, word, nth = 0) => {
  const ws = timing.sentences[si].words.filter((x) => norm(x.w).startsWith(norm(word)));
  if (!ws[nth]) throw new Error(`cue tidak ketemu: kalimat ${si} kata "${word}" #${nth}`);
  return ws[nth].start;
};
const shake = (t, times, amp = 14) => {
  let dx = 0, dy = 0;
  for (const ti of times) if (t >= ti && t < ti + 0.6) {
    const d = t - ti, a = amp * Math.exp(-d * 9);
    dx += a * Math.sin(d * 70); dy += a * Math.cos(d * 63);
  }
  return [dx, dy];
};

/* ---------- batas adegan (satu adegan per kalimat) ---------- */
const S = timing.sentences;
const DUR = timing.duration;
const bounds = S.map((s, i) => {
  const a = i === 0 ? 0 : (S[i - 1].end + s.start) / 2;
  const b = i === S.length - 1 ? DUR : (s.end + S[i + 1].start) / 2;
  return [a, b];
});
const BG = [
  ['#1a0b3b', '#5a208f'], ['#0b2a3a', '#1f7a76'], ['#151a3a', '#2f46a8'], ['#3a0b2a', '#b03466'],
  ['#3a260b', '#a8701f'], ['#0b1a3a', '#6a22a0'], ['#161a1f', '#35495c'], ['#3a0b0b', '#b32f2f'],
];

/* ---------- komponen gambar kecil (SVG) ---------- */
const Heart = ({ x, y, s = 1, rot = 0, fill = '#ff3d7f', o = 1 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`} opacity={o}>
    <path d="M0 30 C-60 -10 -40 -55 0 -25 C40 -55 60 -10 0 30Z" fill={fill} stroke={INK} strokeWidth="6" strokeLinejoin="round" />
    <ellipse cx="-16" cy="-18" rx="7" ry="4" fill="#fff" opacity=".6" transform="rotate(-30 -16 -18)" />
  </g>
);
const Star = ({ x, y, r = 20, rot = 0, fill = '#ffd23f', o = 1 }) => (
  <path transform={`translate(${x} ${y}) rotate(${rot}) scale(${r / 20})`} opacity={o} fill={fill}
    d="M0 -22 L5 -6 L22 0 L5 6 L0 22 L-5 6 L-22 0 L-5 -6Z" />
);
const Flower = ({ x, y, s = 1, rot = 0, color = '#ff6fa8' }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    {[0, 72, 144, 216, 288].map((a) => (
      <ellipse key={a} cx="0" cy="-20" rx="13" ry="20" fill={color} stroke={INK} strokeWidth="4" transform={`rotate(${a})`} />
    ))}
    <circle r="10" fill="#ffd23f" stroke={INK} strokeWidth="4" />
  </g>
);
const Person = ({ x, y, s = 1, skin = '#f2b98f', shirt = '#4fb3ff', hair = '#1b1b1b', mood = 'neutral', o = 1, cap = false, vest = false, dashed = false }) => {
  const mouth = mood === 'sad' ? 'M-18 52 Q0 36 18 52' : mood === 'smile' ? 'M-20 42 Q0 66 20 42' : 'M-16 48 L16 48';
  const sk = dashed ? { fill: 'none', stroke: '#fff', strokeWidth: 6, strokeDasharray: '10 12' } : null;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
      <path d="M-95 150 Q-95 70 0 70 Q95 70 95 150 L95 190 L-95 190Z" {...(sk || { fill: shirt, stroke: INK, strokeWidth: 6 })} />
      {vest && <path d="M-60 80 L-20 76 L-20 190 L-95 190 L-95 150Z M60 80 L20 76 L20 190 L95 190 L95 150Z" fill="#ff8a1f" stroke={INK} strokeWidth="5" />}
      {vest && <path d="M-80 130 H-30 M30 130 H80 M-80 160 H-30 M30 160 H80" stroke="#e6ff4d" strokeWidth="9" />}
      <circle r="62" cx="0" cy="0" {...(sk || { fill: skin, stroke: INK, strokeWidth: 6 })} />
      {!dashed && <>
        <path d="M-64 -8 Q-60 -70 0 -68 Q60 -70 64 -8 Q40 -38 0 -34 Q-40 -38 -64 -8Z" fill={hair} stroke={INK} strokeWidth="5" />
        <circle cx="-22" cy="8" r="7" fill={INK} /><circle cx="22" cy="8" r="7" fill={INK} />
        <path d={mouth} stroke={INK} strokeWidth="6" fill="none" strokeLinecap="round" />
      </>}
      {cap && !dashed && <g><path d="M-68 -22 Q0 -92 68 -22Z" fill="#2b5fff" stroke={INK} strokeWidth="5" /><rect x="-10" y="-34" width="95" height="14" rx="6" fill="#2b5fff" stroke={INK} strokeWidth="5" /></g>}
    </g>
  );
};
const Bubble = ({ x, y, w, h, text, size = 40, o = 1, s = 1, tail = 'left' }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx="26" fill="#fff" stroke={INK} strokeWidth="6" />
    <path d={tail === 'left' ? `M${-w / 2 + 40} ${h / 2 - 2} l-24 40 l60 -40Z` : `M${w / 2 - 40} ${h / 2 - 2} l24 40 l-60 -40Z`} fill="#fff" stroke={INK} strokeWidth="6" strokeLinejoin="round" />
    <rect x={-w / 2 + 6} y={h / 2 - 8} width="80" height="12" fill="#fff" transform={tail === 'left' ? 'translate(34 0)' : `translate(${w - 120} 0)`} />
    <text textAnchor="middle" y={size * 0.35} fontFamily={DISPLAY} fontSize={size} fill={INK}>{text}</text>
  </g>
);
const Sticker = ({ x, y, rot = 0, s = 1, o = 1, text, size = 70, fill = '#ffd23f', color = INK, padX = 40, w }) => {
  const width = w || text.length * size * 0.6 + padX * 2;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`} opacity={o}>
      <rect x={-width / 2 + 8} y={-size * 0.8 + 10} width={width} height={size * 1.6} rx="18" fill={INK} />
      <rect x={-width / 2} y={-size * 0.8} width={width} height={size * 1.6} rx="18" fill={fill} stroke={INK} strokeWidth="6" />
      <text textAnchor="middle" y={size * 0.34} fontFamily={DISPLAY} fontSize={size} fill={color}>{text}</text>
    </g>
  );
};

/* ---------- latar adegan ---------- */
function Background({ i, t }) {
  const [c1, c2] = BG[i];
  const orbs = Array.from({ length: 14 }, (_, k) => {
    const ph = (t * (0.03 + hash(k + i * 31) * 0.05) + hash(k * 7 + i)) % 1;
    return { x: hash(k * 13 + i * 5) * W + Math.sin(t * 0.6 + k) * 30, y: H - ph * (H + 200) + 100, r: 14 + hash(k + 99) * 46, o: Math.sin(ph * Math.PI) * 0.16 };
  });
  return (
    <g>
      <rect width={W} height={H} fill={`url(#bg${i})`} />
      <defs><linearGradient id={`bg${i}`} x1="0" y1="0" x2="0.6" y2="1"><stop offset="0" stopColor={c1} /><stop offset="1" stopColor={c2} /></linearGradient></defs>
      {orbs.map((o, k) => <circle key={k} cx={o.x} cy={o.y} r={o.r} fill="#fff" opacity={o.o} />)}
      {Array.from({ length: 9 }, (_, r) => Array.from({ length: 6 }, (_, c) => (
        <circle key={`${r}-${c}`} cx={90 + c * 180 + (r % 2) * 90} cy={120 + r * 150} r={5 + 3 * Math.sin(t * 2 + r + c)} fill="#fff" opacity=".06" />
      )))}
    </g>
  );
}

/* ---------- ADEGAN 0: POV lo punya ilmu gaib ---------- */
function Scene0({ t }) {
  const tPOV = C(0, 'POV'), tIlmu = C(0, 'ilmu'), tGaib = C(0, 'gaib');
  const puffs = Array.from({ length: 16 }, (_, i) => {
    const ph = (t * 0.14 + hash(i)) % 1;
    return { x: 540 + (hash(i + 50) - 0.5) * 560 + Math.sin(ph * 6 + i) * 70, y: 1300 - ph * 1150, r: 40 + ph * 120, o: Math.sin(ph * Math.PI) * 0.22 };
  });
  const eyeP = pop(t, tPOV + 0.05, 0.5);
  const blinkT = (t % 2.4) - 2.2;
  const blink = 1 - 0.92 * clamp(1 - Math.abs(blinkT) / 0.09);
  const pulse = 1 + 0.14 * clamp(1 - (t - tGaib) / 0.35) * (t >= tGaib ? 1 : 0);
  const rays = Array.from({ length: 28 }, (_, k) => k);
  return (
    <g>
      {puffs.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r={p.r} fill="#d2b3ff" opacity={p.o} />)}
      <g transform={`translate(540 700) scale(${eyeP * pulse})`}>
        <g transform={`rotate(${t * 9})`} opacity={fadeIn(t, tIlmu, 0.4) * 0.9}>
          {rays.map((k) => <path key={k} d="M0 -330 L16 -440 L-16 -440Z" fill={k % 2 ? '#ffd23f' : '#ff3da6'} transform={`rotate(${k * (360 / 28)})`} />)}
        </g>
        <circle r="330" fill="#2a0f52" stroke={INK} strokeWidth="8" opacity=".85" />
        <g transform={`scale(1 ${blink})`}>
          <path d="M-290 0 Q0 -230 290 0 Q0 230 -290 0Z" fill="#fff" stroke={INK} strokeWidth="9" />
          <circle cx={Math.sin(t * 1.3) * 46} cy={Math.cos(t * 0.9) * 14} r="118" fill="#22d3c5" stroke={INK} strokeWidth="8" />
          <circle cx={Math.sin(t * 1.3) * 46} cy={Math.cos(t * 0.9) * 14} r="58" fill={INK} />
          <circle cx={Math.sin(t * 1.3) * 46 - 34} cy={Math.cos(t * 0.9) * 14 - 34} r="20" fill="#fff" />
        </g>
      </g>
      <Sticker x={540} y={250} rot={-5} s={pop(t, tPOV, 0.4)} text="POV" size={150} fill="#ff3da6" color="#fff" />
      <g transform={`translate(540 1180) scale(${pop(t, tIlmu, 0.45) * pulse})`}>
        <text textAnchor="middle" fontFamily={DISPLAY} fontSize="170" fill="#ffd23f" stroke={INK} strokeWidth="18" paintOrder="stroke fill" strokeLinejoin="round" filter="url(#glow)">ILMU GAIB</text>
      </g>
    </g>
  );
}

/* ---------- ADEGAN 1: puasa 3 hari, mandi kembang, ngilang ---------- */
function Scene1({ t }) {
  const tPuasa = C(1, 'puasa'), tTiga = C(1, 'tiga'), tHari = C(1, 'hari'), tMandi = C(1, 'mandi');
  const tKemb = C(1, 'kembang'), tRupa = C(1, 'rupa'), tAkhir = C(1, 'akhirnya'), tNgilang = C(1, 'ngilang');
  const aOut = 1 - prog(t, tMandi - 0.05, tMandi + 0.2);
  const bIn = fadeIn(t, tMandi, 0.25), bOut = 1 - prog(t, tAkhir - 0.05, tAkhir + 0.25);
  const cIn = fadeIn(t, tAkhir, 0.3);
  const cards = [tPuasa, tTiga, tHari];
  const flowerCols = ['#ff6fa8', '#ffd23f', '#ff8a3d', '#c77dff', '#ffffff', '#ff4d4d', '#5eead4'];
  const landed = flowerCols.filter((_, k) => t >= lerp(tKemb, tRupa, k / 6) + 0.5).length;
  const v = prog(t, tNgilang, tNgilang + 0.7);
  return (
    <g>
      {/* A: puasa 3 hari */}
      <g opacity={aOut}>
        {cards.map((ta, k) => (
          <g key={k} transform={`translate(${190 + k * 350} 640) scale(${pop(t, ta, 0.4)}) rotate(${(k - 1) * 4})`}>
            <rect x="-150" y="-240" width="300" height="480" rx="30" fill="#fff6dd" stroke={INK} strokeWidth="7" />
            <rect x="-150" y="-240" width="300" height="100" rx="30" fill="#ff4d4d" stroke={INK} strokeWidth="7" />
            <text textAnchor="middle" y="-168" fontFamily={DISPLAY} fontSize="56" fill="#fff">HARI</text>
            <text textAnchor="middle" y="50" fontFamily={DISPLAY} fontSize="220" fill={INK}>{k + 1}</text>
            <circle cx="0" cy="150" r="50" fill="none" stroke={INK} strokeWidth="6" /><circle cx="0" cy="150" r="30" fill="none" stroke={INK} strokeWidth="4" />
          </g>
        ))}
        <Sticker x={540} y={1060} rot={-3} s={pop(t, tPuasa + 0.1, 0.4)} text="PUASA: PERUT KOSONG" size={58} fill="#ffd23f" />
        <text x="540" y={1170 + Math.sin(t * 20) * 3} textAnchor="middle" fontFamily={DISPLAY} fontSize="70" fill="#fff" opacity={fadeIn(t, tTiga, 0.3)}>grrruuukk...</text>
      </g>
      {/* B: mandi kembang tujuh rupa */}
      <g opacity={bIn * bOut}>
        <Sticker x={540} y={300} rot={2} s={pop(t, tMandi, 0.4)} text={`KEMBANG ${landed}/7 RUPA`} size={64} fill="#ff6fa8" color="#fff" />
        <g transform="translate(540 940)">
          <path d="M-350 -60 H350 V80 Q350 250 160 250 H-160 Q-350 250 -350 80Z" fill="#f3f0ff" stroke={INK} strokeWidth="8" />
          <path d={`M-330 -10 ${Array.from({ length: 13 }, (_, k) => `L${-330 + k * 55} ${-10 + Math.sin(t * 3 + k) * 9}`).join(' ')} V80 Q330 230 160 230 H-160 Q-330 230 -330 80Z`} fill="#4fd1ff" opacity=".85" />
          <circle cx="-120" cy="-120" r="70" fill="#f2b98f" stroke={INK} strokeWidth="6" />
          <path d="M-190 -140 Q-120 -230 -50 -140Z" fill="#fff" stroke={INK} strokeWidth="5" />
          <circle cx="-142" cy="-120" r="7" fill={INK} /><circle cx="-98" cy="-120" r="7" fill={INK} />
          <path d="M-140 -92 Q-120 -72 -100 -92" stroke={INK} strokeWidth="5" fill="none" strokeLinecap="round" />
          <rect x="-350" y="240" width="40" height="40" rx="8" fill="#c0b6e8" stroke={INK} strokeWidth="6" /><rect x="310" y="240" width="40" height="40" rx="8" fill="#c0b6e8" stroke={INK} strokeWidth="6" />
        </g>
        {flowerCols.map((c, k) => {
          const t0 = lerp(tKemb, tRupa, k / 6), u = prog(t, t0, t0 + 0.5);
          if (t < t0) return null;
          const x = 300 + k * 80 + Math.sin(k * 3) * 20;
          const y = u < 1 ? lerp(300, 880, eOut(u)) : 880 + Math.sin(t * 2.4 + k * 1.7) * 10;
          return <Flower key={k} x={x + (u >= 1 ? Math.sin(t * 1.5 + k) * 8 : 0)} y={y + (hash(k) - 0.5) * 30} s={1.3} rot={u * 240 + k * 20} color={c} />;
        })}
      </g>
      {/* C: ngilang */}
      <g opacity={cIn}>
        <g opacity={1 - v}><Person x={540} y={720} s={2.6} shirt="#4fb3ff" mood="smile" /></g>
        <g opacity={fadeIn(t, tNgilang, 0.2) * 0.9}><Person x={540} y={720} s={2.6} dashed /></g>
        {t >= tNgilang && Array.from({ length: 46 }, (_, k) => {
          const a = hash(k) * Math.PI * 2, d = eOut(v) * (120 + hash(k + 9) * 480);
          return <rect key={k} x={540 + Math.cos(a) * d - 10 + (hash(k + 3) - 0.5) * 240} y={720 + 60 + Math.sin(a) * d * 0.9 - 10 + (hash(k + 5) - 0.5) * 360} width="20" height="20" fill={k % 3 ? '#fff' : '#4fb3ff'} opacity={(1 - v) * 0.95} transform={`rotate(${k * 17 + v * 200} 540 720)`} />;
        })}
        {[0, 1, 2, 3, 4, 5].map((k) => <Star key={k} x={540 + Math.cos(k * 1.05 + t * 2) * 330} y={720 + Math.sin(k * 1.05 + t * 2) * 330} r={22 + 8 * Math.sin(t * 6 + k)} rot={t * 90} o={1 - 0.7 * v} />)}
        <Sticker x={540} y={1180} rot={-3} s={pop(t, tNgilang, 0.4)} text="BERHASIL NGILANG!" size={74} fill="#5eead4" />
      </g>
    </g>
  );
}

/* ---------- ADEGAN 2: sinyal HP & duit di dompet ---------- */
function Scene2({ t }) {
  const tMasal = C(2, 'masalahnya'), tSinyal = C(2, 'sinyal'), tHP = C(2, 'HP'), tDuit = C(2, 'duit'), tDompet = C(2, 'dompet');
  const barsOn = [0, 1, 2, 3].map((k) => t < tSinyal + (3 - k) * 0.13 + 0.05);
  const gone = !barsOn.some(Boolean);
  const notes = Array.from({ length: 7 }, (_, k) => k);
  return (
    <g>
      <g transform={`translate(540 630) scale(${pop(t, tMasal, 0.5)})`}>
        <rect x="-210" y="-390" width="420" height="780" rx="60" fill="#222a44" stroke={INK} strokeWidth="9" />
        <rect x="-185" y="-360" width="370" height="720" rx="38" fill="#0f1530" />
        <rect x="-60" y="-376" width="120" height="14" rx="7" fill={INK} />
        {[0, 1, 2, 3].map((k) => <rect key={k} x={-160 + k * 30} y={-300 - k * 14 + 30} width="20" height={20 + k * 14} rx="4" fill={barsOn[k] ? '#5eead4' : '#3a4366'} />)}
        <text x="140" y="-285" textAnchor="end" fontFamily={BODY} fontWeight="800" fontSize="30" fill="#fff">{gone ? 'SOS' : '5G'}</text>
        <text textAnchor="middle" y="0" fontFamily={DISPLAY} fontSize="68" fill="#fff" opacity={gone ? fadeIn(t, tSinyal + 0.5, 0.2) : 0.2}>Tidak ada</text>
        <text textAnchor="middle" y="75" fontFamily={DISPLAY} fontSize="68" fill="#ff5d5d" opacity={gone ? fadeIn(t, tSinyal + 0.5, 0.2) : 0.2}>layanan</text>
        <g opacity={gone ? pop(t, tSinyal + 0.55, 0.3) : 0} transform="translate(0 -150)">
          <circle r="62" fill="none" stroke="#ff5d5d" strokeWidth="14" /><path d="M-30 -30 L30 30 M30 -30 L-30 30" stroke="#ff5d5d" strokeWidth="14" strokeLinecap="round" />
        </g>
        <text textAnchor="middle" y="200" fontFamily={BODY} fontWeight="800" fontSize="34" fill="#8da0d6">Mencari jaringan{'.'.repeat(1 + Math.floor(t * 3) % 3)}</text>
      </g>
      <Sticker x={540} y={190} rot={-2} s={pop(t, tHP, 0.35)} text="SINYAL HP: ILANG" size={52} fill="#5eead4" />
      <g transform={`translate(540 1180) scale(${pop(t, tDuit, 0.45)})`}>
        {notes.map((k) => {
          const u = prog(t, tDuit + 0.1 + k * 0.08, tDuit + 1.3 + k * 0.08);
          if (u <= 0 || u >= 1) return null;
          return (
            <g key={k} transform={`translate(${(hash(k + 4) - 0.5) * 360 * u} ${-260 * eOut(u) - 40}) rotate(${(hash(k) - 0.5) * 80 + u * 120})`} opacity={1 - u}>
              <rect x="-70" y="-36" width="140" height="72" rx="8" fill="#7ee07e" stroke={INK} strokeWidth="5" /><circle r="22" fill="#4fb84f" stroke={INK} strokeWidth="4" />
              <text textAnchor="middle" y="9" fontFamily={DISPLAY} fontSize="28" fill={INK}>Rp</text>
            </g>
          );
        })}
        <rect x="-260" y="-110" width="520" height="260" rx="34" fill="#8a5a33" stroke={INK} strokeWidth="8" />
        <path d="M-260 -40 H260" stroke={INK} strokeWidth="6" /><rect x="170" y="-20" width="100" height="90" rx="22" fill="#b8844f" stroke={INK} strokeWidth="7" /><circle cx="215" cy="25" r="12" fill="#ffd23f" stroke={INK} strokeWidth="4" />
        <text x="-30" y="75" textAnchor="middle" fontFamily={DISPLAY} fontSize="90" fill="#fff" opacity={fadeIn(t, tDompet, 0.25)} stroke={INK} strokeWidth="10" paintOrder="stroke fill">Rp 0</text>
      </g>
      <Sticker x={540} y={1400 - 20} rot={2} s={pop(t, tDuit + 0.2, 0.4)} text="DUIT DOMPET: KOSONG" size={52} fill="#ffd23f" />
    </g>
  );
}

/* ---------- ADEGAN 3: bikin orang kangen -> tukang parkir ---------- */
function Scene3({ t }) {
  const tBikin = C(3, 'bikin'), tKangen = C(3, 'kangen'), tMalah = C(3, 'malah'), tTukang = C(3, 'tukang'), tParkir = C(3, 'parkir');
  const e = eInOut(prog(t, tMalah - 0.05, tMalah + 0.5));
  const dest = [lerp(830, 800, e), lerp(480, 1000, e)];
  const hearts = Array.from({ length: 7 }, (_, k) => {
    const tl = lerp(tBikin, tMalah + 0.4, k / 6);
    const u = prog(t, tl, tl + 1.1);
    if (t < tl) return null;
    const p0 = [280, 760], p1 = [560, 360 + k * 20], p2 = dest;
    const x = (1 - u) ** 2 * p0[0] + 2 * (1 - u) * u * p1[0] + u * u * p2[0];
    const y = (1 - u) ** 2 * p0[1] + 2 * (1 - u) * u * p1[1] + u * u * p2[1];
    const o = u < 1 ? 1 : clamp(1 - (t - tl - 1.1) / 0.3);
    return <Heart key={k} x={x} y={y} s={0.9 + 0.2 * Math.sin(t * 9 + k)} rot={Math.sin(t * 5 + k) * 15} o={o} fill={k % 2 ? '#ff3d7f' : '#ff7ab5'} />;
  });
  return (
    <g>
      <Person x={200} y={700} s={1.5} shirt="#4fb3ff" mood="sad" o={fadeIn(t, tBikin - 0.4, 0.3)} />
      <Sticker x={200} y={1000} s={pop(t, tBikin - 0.3, 0.3)} text="LO" size={48} fill="#4fb3ff" color="#fff" />
      <g opacity={fadeIn(t, tKangen, 0.3) * (1 - 0.55 * e)}>
        <Person x={830} y={400} s={1.2} shirt="#9aa4c4" skin="#c9c9d6" hair="#555" mood="neutral" />
        <Sticker x={830} y={680} s={pop(t, tKangen, 0.3)} text="DIA" size={44} fill="#e5e5f0" />
        <text x="830" y="378" textAnchor="middle" fontFamily={DISPLAY} fontSize="80" fill="#fff" opacity={1 - e}>?</text>
        <text x="900" y="300" fontFamily={DISPLAY} fontSize={44 + e * 6} fill="#fff" opacity={e * 0.9}>zzz</text>
      </g>
      {hearts}
      <g opacity={fadeIn(t, tMalah, 0.3)}>
        <Person x={800} y={980} s={1.5} shirt="#ffd23f" cap vest mood="smile" />
        <circle cx="750" cy="1170" r="12" fill="#ddd" stroke={INK} strokeWidth="4" />
        <g transform="translate(940 1200)"><rect x="-6" y="-170" width="12" height="170" fill="#666" /><rect x="-90" y="-250" width="180" height="90" rx="12" fill="#2b5fff" stroke={INK} strokeWidth="6" /><text textAnchor="middle" y="-185" fontFamily={DISPLAY} fontSize="62" fill="#fff">P</text></g>
      </g>
      <Bubble x={430} y={1150} w={560} h={110} text="KIRI... KIRI... TERUS!" size={46} s={pop(t, tTukang, 0.4)} tail="right" />
      <Sticker x={540} y={170} rot={-2} s={pop(t, tKangen - 0.1, 0.4)} text="MAU BIKIN KANGEN" size={62} fill="#ff7ab5" color={INK} />
      <Sticker x={540} y={1340} rot={2} s={pop(t, tParkir, 0.4)} text="YANG KANGEN: TUKANG PARKIR" size={50} fill="#ffd23f" />
    </g>
  );
}

/* ---------- ADEGAN 4: narik rezeki -> benang layangan ---------- */
function Scene4({ t }) {
  const tNarik = C(4, 'narik'), tRezeki = C(4, 'rezeki'), tKetarik = C(4, 'ketarik'), tMalah = C(4, 'malah'), tBenang = C(4, 'benang');
  const pull = eInOut(prog(t, tNarik, tMalah + 0.2));
  const y = lerp(1180, 600, pull);
  const sway = Math.sin(t * 3) * 14 * (1 - pull * 0.5);
  const isKite = t >= tMalah + 0.1;
  const coinS = isKite ? 0 : 1, kiteS = pop(t, tMalah + 0.1, 0.5);
  const tail = Array.from({ length: 6 }, (_, k) => k);
  return (
    <g>
      <Sticker x={540} y={160} rot={-2} s={pop(t, tNarik, 0.35)} text="MAU NARIK REZEKI" size={64} fill="#ffd23f" />
      <path d={`M540 230 Q${540 + sway * 2} ${(230 + y) / 2} ${540 + sway} ${y - (isKite ? 150 : 70)}`} stroke="#fff" strokeWidth="8" fill="none" strokeLinecap="round" />
      <g transform={`translate(${540 + sway} ${y})`}>
        <g transform={`scale(${coinS})`}>
          <circle r="130" fill="#ffd23f" stroke={INK} strokeWidth="9" /><circle r="100" fill="none" stroke="#e0a800" strokeWidth="8" />
          <text textAnchor="middle" y="24" fontFamily={DISPLAY} fontSize="78" fill={INK}>Rp</text>
          {[0, 1, 2].map((k) => <Star key={k} x={Math.cos(t * 3 + k * 2.1) * 190} y={Math.sin(t * 3 + k * 2.1) * 190} r={22} rot={t * 120} />)}
        </g>
        <g transform={`scale(${kiteS}) rotate(${Math.sin(t * 2.5) * 8})`}>
          <path d="M0 -170 L115 0 L0 190 L-115 0Z" fill="#ff4d6d" stroke={INK} strokeWidth="8" strokeLinejoin="round" />
          <path d="M0 -170 L0 190 M-115 0 H115" stroke={INK} strokeWidth="6" /><path d="M0 -170 L115 0 L0 0Z M0 190 L-115 0 L0 0Z" fill="#ffd23f" opacity=".9" />
          {tail.map((k) => <g key={k} transform={`translate(${Math.sin(t * 4 + k * 0.9) * 34} ${210 + k * 56})`}><path d="M-22 -14 L22 14 M22 -14 L-22 14" stroke={INK} strokeWidth="6" /><path d="M-22 -14 L22 14 L22 -14 L-22 14Z" fill={k % 2 ? '#5eead4' : '#fff'} stroke={INK} strokeWidth="5" /></g>)}
          <path d={`M-60 -60 ${Array.from({ length: 22 }, (_, k) => `L${Math.cos(k * 1.1 + t * 3) * (40 + k * 5)} ${Math.sin(k * 1.1 + t * 3) * (30 + k * 4)}`).join(' ')}`} stroke="#fff" strokeWidth="5" fill="none" opacity=".85" />
        </g>
      </g>
      <Sticker x={540} y={1370} rot={2} s={pop(t, tMalah + 0.05, 0.4)} text="MALAH KETARIK..." size={58} fill="#ff4d6d" color="#fff" />
      <Sticker x={540} y={1215} rot={-3} s={pop(t, tBenang, 0.4)} text="BENANG LAYANGAN" size={60} fill="#fff" />
      <text x="540" y={y + 210} textAnchor="middle" fontFamily={DISPLAY} fontSize="64" fill="#fff" opacity={fadeIn(t, tRezeki, 0.2) * (1 - prog(t, tMalah, tMalah + 0.2))}>REZEKI...</text>
    </g>
  );
}

/* ---------- ADEGAN 5: khodam harimau putih -> intern magang ---------- */
function Scene5({ t }) {
  const tKhodam = C(5, 'khodam'), tTapi = C(5, 'tapi'), tMagang = C(5, 'magang');
  const glitch = t > tTapi - 0.05 && t < tTapi + 0.5;
  const g = glitch ? 1 : 0;
  const j = Math.floor(t * 30);
  const gx = g * (hash(j) - 0.5) * 50, gy = g * (hash(j + 7) - 0.5) * 16;
  const swap = t >= tTapi + 0.2;
  const slide = eOut(prog(t, tKhodam - 0.1, tKhodam + 0.5));
  const aura = 0.5 + 0.5 * Math.sin(t * 4);
  return (
    <g transform={`translate(0 ${(1 - slide) * 900})`}>
      <g transform="translate(540 740)">
        <rect x="-350" y="-520" width="700" height="1040" rx="44" fill="#2a1055" stroke="#ffd23f" strokeWidth="14" />
        <rect x="-320" y="-490" width="640" height="980" rx="30" fill="#3d1a7a" stroke={INK} strokeWidth="6" />
        <rect x="-290" y="-455" width="580" height="90" rx="20" fill="#ffd23f" stroke={INK} strokeWidth="6" />
        <text textAnchor="middle" y="-390" fontFamily={DISPLAY} fontSize="52" fill={INK}>{swap ? 'INTERN MAGANG' : 'HARIMAU PUTIH'}</text>
        <rect x="-290" y="-340" width="580" height="620" rx="24" fill={swap ? '#bcd7f5' : '#1a0b3b'} stroke={INK} strokeWidth="6" />
        <g transform={`translate(${gx} ${gy + 20})`}>
          {!swap ? (
            <g>
              <circle r={190 + aura * 20} fill="#5eead4" opacity=".16" /><circle r="150" fill="#22d3c5" opacity=".2" />
              <circle cx="-110" cy="-110" r="52" fill="#fff" stroke={INK} strokeWidth="7" /><circle cx="110" cy="-110" r="52" fill="#fff" stroke={INK} strokeWidth="7" />
              <circle cx="-110" cy="-110" r="26" fill="#ff9ec4" /><circle cx="110" cy="-110" r="26" fill="#ff9ec4" />
              <ellipse cx="0" cy="0" rx="160" ry="140" fill="#fff" stroke={INK} strokeWidth="8" />
              {[-1, 1].map((s) => <g key={s}><path d={`M${s * 40} -135 L${s * 55} -70 M${s * 85} -120 L${s * 98} -60 M${s * 130} -80 L${s * 130} -35`} stroke={INK} strokeWidth="12" strokeLinecap="round" /><path d={`M${s * 150} 10 L${s * 105} 22 M${s * 148} 55 L${s * 100} 52`} stroke={INK} strokeWidth="10" strokeLinecap="round" /></g>)}
              <ellipse cx="-62" cy="-18" rx="24" ry="18" fill="#22d3c5" stroke={INK} strokeWidth="6" /><ellipse cx="62" cy="-18" rx="24" ry="18" fill="#22d3c5" stroke={INK} strokeWidth="6" />
              <rect x="-4" y="-30" width="8" height="26" fill={INK} transform="translate(-62 0)" /><rect x="-4" y="-30" width="8" height="26" fill={INK} transform="translate(62 0)" />
              <path d="M-26 30 L26 30 L0 58Z" fill="#ff7ab5" stroke={INK} strokeWidth="6" strokeLinejoin="round" />
              <path d="M0 58 V80 M-50 100 Q-25 84 0 80 Q25 84 50 100" stroke={INK} strokeWidth="6" fill="none" strokeLinecap="round" />
              <text textAnchor="middle" y="215" fontFamily={DISPLAY} fontSize="40" fill="#5eead4">ATK 9999   DEF 9999</text>
            </g>
          ) : (
            <g>
              <Person x={-20} y={-125} s={1.25} shirt="#fff" skin="#f2b98f" mood="sad" />
              <path d="M-40 52 L0 150 L40 52" stroke="#ff4d4d" strokeWidth="10" fill="none" transform="translate(-20 -125) scale(1.25)" />
              <g transform="translate(-20 25) rotate(-4) scale(.62)"><rect x="-70" y="0" width="140" height="170" rx="14" fill="#fff" stroke={INK} strokeWidth="6" /><rect x="-70" y="0" width="140" height="42" fill="#ff4d4d" stroke={INK} strokeWidth="6" /><text textAnchor="middle" y="32" fontFamily={DISPLAY} fontSize="30" fill="#fff">INTERN</text><circle cx="0" cy="88" r="24" fill="#f2b98f" stroke={INK} strokeWidth="4" /><rect x="-44" y="128" width="88" height="10" fill="#bbb" /></g>
              <g transform="translate(170 60) scale(.8)"><path d="M-40 0 H40 V90 Q40 120 0 120 Q-40 120 -40 90Z" fill="#fff" stroke={INK} strokeWidth="6" /><path d="M40 20 Q75 25 60 70 Q50 80 40 75" stroke={INK} strokeWidth="6" fill="none" /><text textAnchor="middle" y="60" fontFamily={DISPLAY} fontSize="28" fill={INK}>KOPI</text></g>
              <text textAnchor="middle" y="245" fontFamily={DISPLAY} fontSize="38" fill="#1a3a6a">ATK 0   DEF 0   KOPI 99</text>
            </g>
          )}
        </g>
        {g > 0 && <g opacity=".5" transform={`translate(${-gx * 1.5} 0)`}><rect x="-290" y="-340" width="580" height="620" fill="#ff3da6" opacity=".25" /></g>}
        <rect x="-290" y="320" width="580" height="120" rx="20" fill="#fff6dd" stroke={INK} strokeWidth="6" />
        <text textAnchor="middle" y="396" fontFamily={DISPLAY} fontSize="36" fill={INK}>{swap ? 'Skill: Fotokopi, Ngopi' : 'Skill: Basmi Musuh'}</text>
      </g>
      <Bubble x={800} y={520} w={340} h={100} text="Siap, Kak!" size={52} s={pop(t, tMagang, 0.4)} tail="left" o={swap ? 1 : 0} />
      <Sticker x={540} y={1330 + 0} rot={0} s={pop(t, tTapi + 0.1, 0.4)} text="PLOT TWIST" size={50} fill="#ff3da6" color="#fff" o={swap ? 1 : 0} />
    </g>
  );
}

/* ---------- ADEGAN 6: belum di-training, masih loading ---------- */
function Scene6({ t }) {
  const tBelum = C(6, 'belum'), tTrain = C(6, 'di-training'), tMasih = C(6, 'masih'), tLoad = C(6, 'loading');
  const p = t < tMasih ? eOut(prog(t, tBelum, tMasih)) * 0.99 : 0.99;
  const stuck = t >= tMasih;
  const pct = Math.floor(p * 100);
  return (
    <g>
      <g transform={`translate(540 600) scale(${pop(t, tBelum, 0.45)})`}>
        <rect x="-460" y="-300" width="920" height="600" rx="22" fill="#e9edf2" stroke={INK} strokeWidth="8" />
        <path d="M-460 -240 V-278 Q-460 -300 -438 -300 H438 Q460 -300 460 -278 V-240Z" fill="#2b5fff" stroke={INK} strokeWidth="8" />
        <rect x="-460" y="-300" width="920" height="60" rx="22" fill="#2b5fff" stroke={INK} strokeWidth="8" />
        <text x="-430" y="-258" fontFamily={BODY} fontWeight="800" fontSize="30" fill="#fff">khodam_training.exe {stuck ? '(Tidak Merespons)' : ''}</text>
        {[0, 1, 2].map((k) => <rect key={k} x={290 + k * 52} y="-286" width="36" height="32" rx="6" fill={k === 2 ? '#ff5d5d' : '#cfd8ff'} stroke={INK} strokeWidth="4" />)}
        <text textAnchor="middle" y="-130" fontFamily={DISPLAY} fontSize="64" fill={INK}>{stuck ? 'Masih loading' + '.'.repeat(1 + Math.floor(t * 3) % 3) : 'Menginstal ilmu gaib...'}</text>
        <rect x="-380" y="-40" width="760" height="90" rx="20" fill="#fff" stroke={INK} strokeWidth="7" />
        <rect x="-374" y="-34" width={Math.max(0, 748 * p)} height="78" rx="16" fill={stuck ? '#ffb020' : '#34d399'} />
        <text textAnchor="middle" y="140" fontFamily={DISPLAY} fontSize="100" fill={INK}>{pct}%</text>
        {stuck && <g transform="translate(330 120)" opacity={fadeIn(t, tMasih, 0.2)}><circle r="46" fill="none" stroke="#c9d2de" strokeWidth="12" /><path d="M0 -46 A46 46 0 0 1 46 0" stroke={INK} strokeWidth="12" fill="none" strokeLinecap="round" transform={`rotate(${t * 360})`} /></g>}
        <text textAnchor="middle" y="250" fontFamily={BODY} fontWeight="700" fontSize="32" fill="#6b7a8c">{stuck ? 'Server: lagi ngopi' : 'Estimasi: 3 abad'}</text>
      </g>
      <Sticker x={540} y={190} rot={-2} s={pop(t, tTrain, 0.4)} text="BELUM DI-TRAINING" size={64} fill="#ffd23f" />
      <g transform="translate(540 1130)">
        <Person x={0} y={-70} s={1.3} shirt="#fff" mood="sad" />
        {stuck && [0, 1, 2].map((k) => <circle key={k} cx={150 + k * 40} cy={-60 - k * 45 - (1 + Math.sin(t * 5 - k)) * 4} r={12 + k * 8} fill="#fff" stroke={INK} strokeWidth="5" opacity={fadeIn(t, tMasih + k * 0.1, 0.2)} />)}
        <path d="M70 -30 Q86 0 70 10 Q54 0 70 -30Z" fill="#5ec8ff" stroke={INK} strokeWidth="4" transform={`translate(0 ${((t * 40) % 40) * (stuck ? 1 : 0)})`} opacity={stuck ? 1 : 0} />
      </g>
      <Sticker x={540} y={1400} rot={2} s={pop(t, tLoad, 0.4)} text="LOADING..." size={60} fill="#34d399" />
    </g>
  );
}

/* ---------- ADEGAN 7: bukan dukun sakti, korban magang ---------- */
function Scene7({ t }) {
  const tDukun = C(7, 'dukun'), tSakti = C(7, 'sakti'), tKorban = C(7, 'korban'), tMagang = C(7, 'magang'), tDibayar = C(7, 'dibayar');
  const strike = prog(t, tSakti + 0.1, tSakti + 0.35);
  const slam = (ta, d = 0.22) => (t < ta ? 0 : 1 + 1.2 * (1 - eOut(prog(t, ta, ta + d))));
  const stampT = tDibayar - 0.15;
  return (
    <g>
      <g transform={`translate(540 340) rotate(-3) scale(${pop(t, tDukun - 0.2, 0.4)})`}>
        <rect x="-420" y="-100" width="840" height="200" rx="28" fill="#6b2fb3" stroke={INK} strokeWidth="9" />
        <text textAnchor="middle" y="38" fontFamily={DISPLAY} fontSize="110" fill="#ffd23f">DUKUN SAKTI</text>
        <path d={`M-400 0 L${-400 + 800 * strike} ${-0 + 0}`} stroke="#ff3030" strokeWidth="20" strokeLinecap="round" />
        <g opacity={strike >= 1 ? 1 : 0} transform={`scale(${pop(t, tSakti + 0.35, 0.3)})`}><circle cx="400" cy="-100" r="52" fill="#ff3030" stroke={INK} strokeWidth="7" /><path d="M378 -122 L422 -78 M422 -122 L378 -78" stroke="#fff" strokeWidth="12" strokeLinecap="round" /></g>
      </g>
      <g transform={`translate(540 640) rotate(2) scale(${slam(tKorban)})`} opacity={t >= tKorban ? 1 : 0}>
        <rect x="-440" y="-110" width="880" height="220" rx="28" fill="#ffd23f" stroke={INK} strokeWidth="10" />
        <text textAnchor="middle" y="-5" fontFamily={DISPLAY} fontSize="100" fill={INK}>KORBAN</text>
        <text textAnchor="middle" y="82" fontFamily={DISPLAY} fontSize="86" fill="#c01a1a">MAGANG</text>
      </g>
      <g transform={`translate(540 1040) rotate(-2) scale(${pop(t, tMagang, 0.4) * 1.3})`}>
        <rect x="-330" y="-150" width="660" height="330" rx="14" fill="#fffdf4" stroke={INK} strokeWidth="7" />
        <text textAnchor="middle" y="-95" fontFamily={DISPLAY} fontSize="54" fill={INK}>SLIP GAJI</text>
        <path d="M-290 -70 H290" stroke={INK} strokeWidth="4" strokeDasharray="10 8" />
        {[['Gaji pokok', 'Rp 0'], ['Uang makan', 'Rp 0'], ['Ilmu & pengalaman', 'Banyak']].map(([a, b], k) => (
          <g key={k}><text x="-290" y={-20 + k * 62} fontFamily={BODY} fontWeight="700" fontSize="36" fill={INK}>{a}</text><text x="290" y={-20 + k * 62} textAnchor="end" fontFamily={BODY} fontWeight="800" fontSize="36" fill={k === 2 ? '#1a8a4a' : '#c01a1a'}>{b}</text></g>
        ))}
      </g>
      <g transform={`translate(540 1330) rotate(-8) scale(${slam(stampT, 0.2)})`} opacity={t >= stampT ? 0.95 : 0}>
        <rect x="-330" y="-70" width="660" height="140" rx="14" fill="#fffdf4" fillOpacity=".85" stroke="#e01919" strokeWidth="14" />
        <text textAnchor="middle" y="30" fontFamily={DISPLAY} fontSize="80" fill="#e01919">TIDAK DIBAYAR</text>
      </g>
    </g>
  );
}

const SCENES = [Scene0, Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7];
const IMPACTS = (() => [
  C(0, 'gaib'), C(1, 'ngilang'), C(2, 'duit'), C(3, 'malah'), C(4, 'malah'), C(5, 'tapi'), C(7, 'korban'), C(7, 'dibayar') - 0.15,
])();

/* ---------- caption per kata ---------- */
function Captions({ t }) {
  const si = S.findIndex((s) => t >= s.start - 0.12 && t <= s.end + 0.45);
  if (si < 0) return null;
  const s = S[si];
  const k = pop(t, s.start - 0.12, 0.3);
  return (
    <div style={{ position: 'absolute', left: 60, right: 60, top: 1480, height: 330, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignContent: 'center', gap: '2px 30px', transform: `scale(${0.85 + 0.15 * k})`, opacity: clamp(k) }}>
      {s.words.map((w, i) => {
        const act = t >= w.start && t < w.end + 0.04;
        const past = t >= w.end + 0.04;
        return (
          <span key={i} style={{
            fontFamily: DISPLAY, fontSize: 74, lineHeight: 1.12, color: act ? '#ffd23f' : '#fff', opacity: past || act ? 1 : 0.62,
            WebkitTextStroke: `12px ${INK}`, paintOrder: 'stroke fill', textShadow: `0 6px 0 ${INK}`,
            display: 'inline-block', transform: `scale(${act ? 1.14 : 1}) translateY(${act ? -4 : 0}px)`,
          }}>{w.w}</span>
        );
      })}
    </div>
  );
}

/* ---------- HUD kamera POV ---------- */
function Hud({ t }) {
  const mm = String(Math.floor(t / 60)).padStart(2, '0'), ss = String(Math.floor(t % 60)).padStart(2, '0');
  const corner = (x, y, sx, sy) => <path d={`M${x} ${y + sy * 70} V${y} H${x + sx * 70}`} stroke="#fff" strokeWidth="8" fill="none" opacity=".75" strokeLinecap="round" />;
  return (
    <g>
      {corner(40, 40, 1, 1)}{corner(W - 40, 40, -1, 1)}{corner(40, H - 40, 1, -1)}{corner(W - 40, H - 40, -1, -1)}
      <g opacity={Math.floor(t * 1.6) % 2 === 0 ? 1 : 0.2}><circle cx="86" cy="96" r="14" fill="#ff2d2d" /></g>
      <text x="112" y="108" fontFamily={BODY} fontWeight="800" fontSize="34" fill="#fff">REC {mm}:{ss}</text>
      <rect x="0" y={H - 14} width={W} height="14" fill="#000" opacity=".35" />
      <rect x="0" y={H - 14} width={W * clamp(t / DUR)} height="14" fill="#ffd23f" />
    </g>
  );
}

/* ---------- komponen utama ---------- */
export function Video({ t }) {
  const [sx, sy] = shake(t, IMPACTS);
  return (
    <div style={{ position: 'relative', width: W, height: H, overflow: 'hidden', background: '#000' }}>
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{ position: 'absolute', left: 0, top: 0 }}>
        <defs>
          <filter id="glow" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="9" result="b" /><feMerge><feMergeNode in="b" /><feMergeNode in="SourceGraphic" /></feMerge>
          </filter>
        </defs>
        <g transform={`translate(${sx} ${sy})`}>
          {SCENES.map((Sc, i) => {
            const [a, b] = bounds[i];
            if (t < a || t > b + 0.25) return null;
            const o = fadeIn(t, a, 0.2); // adegan baru memudar masuk di atas adegan lama
            return (
              <g key={i} opacity={i === 0 ? 1 : o} transform={`translate(0 ${(1 - fadeIn(t, a, 0.2)) * 30})`}>
                <Background i={i} t={t} />
                <Sc t={t} />
              </g>
            );
          })}
        </g>
        <Hud t={t} />
      </svg>
      <Captions t={t} />
    </div>
  );
}

export default Video;
