import React from 'react';
import { AbsoluteFill, Audio, Composition, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont as loadLilita } from '@remotion/google-fonts/LilitaOne';
import { loadFont as loadInter } from '@remotion/google-fonts/Inter';
import timing from './timing.json';
// @ts-ignore - komponen murni (JSX)
import { Video, W, H } from './Video';

loadLilita();
loadInter('normal', { weights: ['700', '800'], subsets: ['latin'] });

const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  return (
    <AbsoluteFill style={{ backgroundColor: '#000' }}>
      <Video t={t} />
      <Audio src={staticFile('narasi.mp3')} />
    </AbsoluteFill>
  );
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={timing.durationInFrames}
    fps={timing.fps}
    width={W}
    height={H}
  />
);
