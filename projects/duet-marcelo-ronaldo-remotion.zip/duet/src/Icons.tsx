import React from 'react';

export const IgIcon: React.FC<{ size: number; gid?: string }> = ({ size, gid = 'igg' }) => (
  <svg width={size} height={size} viewBox="0 0 48 48">
    <defs>
      <linearGradient id={gid} x1="0" y1="1" x2="1" y2="0">
        <stop offset="0" stopColor="#FEDA75" />
        <stop offset="0.35" stopColor="#FA7E1E" />
        <stop offset="0.6" stopColor="#D62976" />
        <stop offset="0.85" stopColor="#962FBF" />
        <stop offset="1" stopColor="#4F5BD5" />
      </linearGradient>
    </defs>
    <rect x="2" y="2" width="44" height="44" rx="13" fill={`url(#${gid})`} />
    <rect x="10" y="10" width="28" height="28" rx="9" fill="none" stroke="#fff" strokeWidth="3.4" />
    <circle cx="24" cy="24" r="6.8" fill="none" stroke="#fff" strokeWidth="3.4" />
    <circle cx="33" cy="15" r="2.3" fill="#fff" />
  </svg>
);

export const YtIcon: React.FC<{ size: number }> = ({ size }) => (
  <svg width={size * 1.42} height={size} viewBox="0 0 48 34">
    <rect width="48" height="34" rx="9" fill="#FF0000" />
    <path d="M19 9.5 L19 24.5 L32 17 Z" fill="#fff" />
  </svg>
);
