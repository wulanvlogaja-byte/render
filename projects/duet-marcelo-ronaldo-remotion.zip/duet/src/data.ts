// ============================================================
//  DATA UTAMA - semua timing, kamera, kotak tracking, caption
//  dan mixing audio ada di sini. Ubah angka di sini kalau mau
//  fine-tuning. Koordinat kotak = piksel video sumber (720x1280).
// ============================================================

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const SRC_W = 720;
export const SRC_H = 1280;

export const VIDEO_FILE = 'duet.mp4';
export const AUDIO_FILE = 'narasi.mp3';
export const MUSIC_FILE = 'sfx/backsound.mp3';

export const AUDIO_SEC = 53.159; // durasi narasi
export const TAIL_SEC = 2.2; // ekor setelah narasi (end card)
export const TOTAL_SEC = AUDIO_SEC + TAIL_SEC;
export const DURATION_FRAMES = Math.ceil(TOTAL_SEC * FPS);
export const END_CARD_AT = 53.25; // end card mulai muncul (detik)

export const BRAND = {
  ig: '@idin_iskndr',
  yt: 'idintacticalfootball',
};

// ---------------- Mixing audio ----------------
export const MIX = {
  narasi: 1.0,
  music: 0.17, // backsound saat narasi jalan
  musicTail: 0.42, // backsound saat ekor (setelah narasi)
  whoosh: 0.4,
  swish: 0.3,
  impact: 0.55,
  pop: 0.25,
};
// durasi file sfx (detik) - dipakai untuk memotong <Sequence>
export const SFX_LEN: Record<string, number> = { whoosh: 1.0, swish: 0.42, impact: 1.44, pop: 0.24 };

// ---------------- Kamera ----------------
// cx,cy = titik tengah (px video sumber), s = skala (px layar per px sumber).
// s minimal 1.5 (video vertikal pas satu layar penuh).
export type Cam = { cx: number; cy: number; s: number };

// ---------------- Segmen timeline ----------------
// out = [mulai, selesai] di video hasil (detik)
// src = [mulai, selesai] di video mentah (detik). Kalau sama = FREEZE.
export type Seg = { out: [number, number]; src: [number, number]; cam: [Cam, Cam]; note: string };

const c = (cx: number, cy: number, s: number): Cam => ({ cx, cy, s });

export const SEGMENTS: Seg[] = [
  // ===== KLIP 1 (lawan jersey biru tua) =====
  /* 0  */ { note: 'k1 hook play', out: [0, 2.6], src: [0, 1.5], cam: [c(360, 500, 1.8), c(310, 430, 2.4)] },
  /* 1  */ { note: 'k1 FREEZE Marcelo+Ronaldo', out: [2.6, 4.784], src: [1.5, 1.5], cam: [c(310, 430, 2.4), c(310, 420, 2.8)] },
  /* 2  */ { note: 'k1 play', out: [4.784, 6.8], src: [1.5, 3.0], cam: [c(310, 420, 2.8), c(335, 430, 1.8)] },
  /* 3  */ { note: 'k1 FREEZE Ronaldo tarik bek', out: [6.8, 11.0], src: [3.0, 3.0], cam: [c(335, 430, 1.8), c(335, 430, 1.7)] },
  /* 4  */ { note: 'k1 play finishing', out: [11.0, 15.615], src: [3.0, 6.9], cam: [c(335, 430, 1.7), c(360, 560, 1.55)] },

  // ===== KLIP 2 (Juventus) =====
  /* 5  */ { note: 'k2 play', out: [15.615, 19.0], src: [7.1, 10.5], cam: [c(360, 720, 1.6), c(430, 720, 1.8)] },
  /* 6  */ { note: 'k2 FREEZE Marcelo vs bek', out: [19.0, 20.6], src: [10.5, 10.5], cam: [c(430, 720, 1.8), c(382, 720, 1.6)] },
  /* 7  */ { note: 'k2 play', out: [20.6, 22.1], src: [10.5, 12.0], cam: [c(382, 720, 1.6), c(400, 600, 1.7)] },
  /* 8  */ { note: 'k2 FREEZE Ronaldo sisi jauh', out: [22.1, 25.3], src: [12.0, 12.0], cam: [c(400, 600, 1.7), c(400, 580, 1.8)] },
  /* 9  */ { note: 'k2 play Marcelo menyelesaikan', out: [25.3, 29.702], src: [12.0, 16.25], cam: [c(400, 580, 1.8), c(330, 640, 1.55)] },

  // ===== KLIP 3 (Bayern) =====
  /* 10 */ { note: 'k3 play', out: [29.702, 33.2], src: [16.4, 20.5], cam: [c(330, 640, 1.55), c(300, 700, 1.6)] },
  /* 11 */ { note: 'k3 FREEZE Marcelo lewati lawan', out: [33.2, 35.7], src: [20.5, 20.5], cam: [c(300, 700, 1.6), c(380, 760, 1.7)] },
  /* 12 */ { note: 'k3 play', out: [35.7, 36.9], src: [20.5, 21.4], cam: [c(380, 760, 1.7), c(380, 780, 1.7)] },
  /* 13 */ { note: 'k3 play (lompat)', out: [36.9, 37.8], src: [23.0, 24.0], cam: [c(370, 690, 1.6), c(370, 690, 1.7)] },
  /* 14 */ { note: 'k3 FREEZE Ronaldo ruang kosong', out: [37.8, 40.3], src: [24.0, 24.0], cam: [c(370, 690, 1.7), c(370, 700, 1.7)] },
  /* 15 */ { note: 'k3 play', out: [40.3, 41.2], src: [24.0, 25.0], cam: [c(370, 700, 1.7), c(380, 760, 1.6)] },
  /* 16 */ { note: 'k3 play (lompat)', out: [41.2, 42.0], src: [26.5, 27.3], cam: [c(380, 760, 1.6), c(400, 640, 1.6)] },
  /* 17 */ { note: 'k3 FREEZE Ronaldo vs kiper', out: [42.0, 45.0], src: [27.3, 27.3], cam: [c(400, 640, 1.6), c(380, 640, 1.6)] },
  /* 18 */ { note: 'k3 play akhir', out: [45.0, 47.2], src: [27.3, 29.0], cam: [c(382, 640, 1.55), c(360, 640, 1.55)] },

  // ===== RECAP (replay slow-mo selama outro) =====
  /* 19 */ { note: 'recap k1', out: [47.2, 48.9], src: [4.6, 6.0], cam: [c(360, 560, 1.55), c(360, 560, 1.55)] },
  /* 20 */ { note: 'recap k2', out: [48.9, 50.6], src: [13.2, 14.6], cam: [c(330, 640, 1.55), c(330, 640, 1.55)] },
  /* 21 */ { note: 'recap k3', out: [50.6, 52.0], src: [19.4, 20.5], cam: [c(330, 700, 1.6), c(380, 760, 1.7)] },
  /* 22 */ { note: 'END FREEZE + end card', out: [52.0, TOTAL_SEC], src: [20.5, 20.5], cam: [c(380, 760, 1.7), c(380, 760, 1.7)] },
];

// ---------------- Kotak tracking ----------------
export type Box = {
  id: string;
  seg: number; // index segmen FREEZE tempat kotak ini hidup
  at: number; // detik (video hasil) kotak muncul
  cx: number;
  cy: number;
  w: number;
  h: number;
  label?: string;
  kind?: 'player' | 'space';
};

const P = (id: string, seg: number, at: number, cx: number, cy: number, w: number, h: number, label?: string): Box => ({
  id,
  seg,
  at,
  cx,
  cy,
  w,
  h,
  label,
  kind: 'player',
});

export const BOXES: Box[] = [
  // --- seg 1: hook, sebut Marcelo dan Ronaldo ---
  P('A-m', 1, 3.5, 235, 376, 64, 104),
  P('A-r', 1, 4.0, 377, 407, 66, 116),

  // --- seg 3: Marcelo bawa bola, Ronaldo tarik perhatian bek ---
  P('B-m', 3, 7.0, 468, 410, 76, 130),
  P('B-r', 3, 8.4, 62, 420, 70, 125),
  P('B-d1', 3, 9.4, 237, 395, 62, 110),
  P('B-d2', 3, 9.9, 293, 383, 62, 110),

  // --- seg 6: Marcelo menusuk melewati bek ---
  P('C-m', 6, 19.1, 459, 740, 60, 175),
  P('C-d1', 6, 19.5, 326, 633, 64, 142),
  P('C-d2', 6, 19.8, 156, 688, 120, 130),
  P('C-d3', 6, 20.2, 690, 768, 52, 165),

  // --- seg 8: Ronaldo di sisi jauh menyita perhatian bek ---
  P('D-r', 8, 22.4, 626, 552, 70, 165),
  P('D-d1', 8, 23.0, 442, 463, 64, 136),
  P('D-d2', 8, 23.5, 169, 568, 74, 100),
  P('D-d3', 8, 24.0, 185, 663, 70, 170),

  // --- seg 11: Marcelo melewati pemain lawan ---
  P('E-m', 11, 33.4, 225, 704, 70, 140),
  P('E-d1', 11, 34.0, 111, 765, 100, 135),
  P('E-d2', 11, 34.5, 290, 728, 90, 90),

  // --- seg 14: Ronaldo berlari ke ruang kosong di belakang pertahanan ---
  P('F-r', 14, 38.0, 385, 904, 110, 210),
  P('F-ball', 14, 38.5, 127, 720, 70, 70),
  P('F-d1', 14, 38.9, 333, 516, 70, 130),
  P('F-d2', 14, 39.3, 434, 595, 100, 120),
  { id: 'F-space', seg: 14, at: 39.5, cx: 300, cy: 415, w: 300, h: 110, label: 'RUANG KOSONG', kind: 'space' },

  // --- seg 17: Ronaldo berhadapan dengan kiper ---
  P('G-r', 17, 42.2, 550, 787, 115, 170),
  P('G-kp', 17, 42.7, 281, 534, 115, 175, 'KIPER'),
];

// garis penghubung antar kotak (id, id)
export const LINKS: [string, string][] = [
  ['A-m', 'A-r'],
  ['B-m', 'B-r'], ['B-r', 'B-d1'], ['B-d1', 'B-d2'],
  ['C-m', 'C-d1'], ['C-d1', 'C-d2'], ['C-m', 'C-d3'],
  ['D-r', 'D-d1'], ['D-d1', 'D-d2'], ['D-d2', 'D-d3'],
  ['E-m', 'E-d1'], ['E-m', 'E-d2'],
  ['F-r', 'F-ball'], ['F-r', 'F-d2'], ['F-d1', 'F-d2'], ['F-d1', 'F-space'],
  ['G-r', 'G-kp'],
];

// ---------------- Caption (sudut kiri atas) ----------------
// Teks sudah dikoreksi dari SRT (back -> bek).
export type Cue = { from: number; to: number; text: string };
export const CUES: Cue[] = [
  { from: 0, to: 4.784, text: 'Satu kombinasi yang selalu bikin bek lawan pusing, Marcelo dan Ronaldo.' },
  { from: 4.784, to: 8.3, text: 'Lihat bagaimana Marcelo naik dari sisi kiri membawa bola,' },
  { from: 8.3, to: 11.894, text: 'sementara Ronaldo bergerak menarik perhatian bek.' },
  { from: 11.894, to: 15.615, text: 'Satu operan cepat dan pertahanan lawan langsung terbuka.' },
  { from: 15.615, to: 18.6, text: 'Di laga lain Marcelo menusuk ke dalam kotak penalti' },
  { from: 18.6, to: 21.197, text: 'dan melewati bek satu per satu.' },
  { from: 21.197, to: 23.4, text: 'Perhatikan Ronaldo di sisi jauh,' },
  { from: 23.4, to: 26.446, text: 'dia terus bergerak dan menyita perhatian bek.' },
  { from: 26.446, to: 29.702, text: 'Sehingga Marcelo punya ruang untuk menyelesaikan.' },
  { from: 29.702, to: 32.8, text: 'Lalu di laga berikutnya Marcelo membawa bola dari tengah lapangan' },
  { from: 32.8, to: 35.55, text: 'melewati pemain lawan.' },
  { from: 35.55, to: 39.869, text: 'Sementara Ronaldo berlari ke ruang kosong di belakang pertahanan.' },
  { from: 39.869, to: 43.989, text: 'Satu umpan dan Ronaldo sudah berhadapan langsung dengan kiper.' },
  { from: 43.989, to: 46.35, text: 'Pola yang sama, lawan yang berbeda:' },
  { from: 46.35, to: 50.9, text: 'satu pemain membawa bola dan menarik bek, satu lagi menyerang ruang,' },
  { from: 50.9, to: 53.159, text: 'itulah duet yang sulit dihentikan.' },
];
