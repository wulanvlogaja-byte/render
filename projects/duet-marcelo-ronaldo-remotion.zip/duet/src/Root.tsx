import React from 'react';
import { Composition } from 'remotion';
import { DuetVideo } from './DuetVideo';
import { DURATION_FRAMES, FPS, H, W } from './data';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="DuetMarceloRonaldo"
      component={DuetVideo}
      durationInFrames={DURATION_FRAMES}
      fps={FPS}
      width={W}
      height={H}
    />
  );
};
