import React from 'react';
import { AbsoluteFill, Audio, Freeze, OffthreadVideo, Sequence, staticFile, useCurrentFrame } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Oswald';
import {
  AUDIO_FILE,
  BRAND,
  END_CARD_AT,
  FPS,
  H,
  MIX,
  MUSIC_FILE,
  SEGMENTS,
  SFX_LEN,
  SRC_H,
  SRC_W,
  VIDEO_FILE,
  W,
} from './data';
import { SFX, camAt, cueAt, musicVolAt, overlayAt } from './timeline';
import { IgIcon, YtIcon } from './Icons';

const { fontFamily: oswald } = loadFont('normal', { weights: ['500', '700'], subsets: ['latin'] });
const FONT = `${oswald}, 'Arial Narrow', Arial, sans-serif`;
const YELLOW = '#FFEB3B';
const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));

// Semua segmen video mentah (play / freeze) sebagai deretan <Sequence>.
// Suara bawaan video di-mute (muted); audio diganti narasi + backsound + SFX.
const SourceSegments: React.FC<{ style: React.CSSProperties }> = ({ style }) => (
  <>
    {SEGMENTS.map((seg, i) => {
      const from = Math.round(seg.out[0] * FPS);
      const dur = Math.max(1, Math.round(seg.out[1] * FPS) - from);
      const startFrom = Math.round(seg.src[0] * FPS);
      const frozen = seg.src[0] === seg.src[1];
      const rate = frozen ? 1 : (seg.src[1] - seg.src[0]) / (seg.out[1] - seg.out[0]);
      const video = (
        <OffthreadVideo src={staticFile(VIDEO_FILE)} startFrom={startFrom} playbackRate={rate} muted style={style} />
      );
      return (
        <Sequence key={i} from={from} durationInFrames={dur} layout="none">
          {frozen ? <Freeze frame={0}>{video}</Freeze> : video}
        </Sequence>
      );
    })}
  </>
);

// Kotak tracking + garis penghubung, digambar di koordinat video sumber.
const BoxLayer: React.FC<{ t: number; s: number }> = ({ t, s }) => {
  const { boxes, lines } = overlayAt(t);
  return (
    <svg
      width={SRC_W}
      height={SRC_H}
      viewBox={`0 0 ${SRC_W} ${SRC_H}`}
      style={{ position: 'absolute', left: 0, top: 0, overflow: 'visible' }}
    >
      {lines.map((l, i) => (
        <line
          key={i}
          x1={l.x1}
          y1={l.y1}
          x2={l.x2}
          y2={l.y2}
          stroke={YELLOW}
          strokeWidth={2 / s}
          opacity={l.opacity * 0.95}
        />
      ))}
      {boxes.map((b) => (
        <g key={b.id} opacity={b.opacity}>
          <rect
            x={b.cx - b.w / 2}
            y={b.cy - b.h / 2}
            width={b.w}
            height={b.h}
            fill={YELLOW}
            fillOpacity={b.space ? 0.14 : 0.22}
            stroke={YELLOW}
            strokeWidth={3.4 / s}
            strokeDasharray={b.space ? `${14 / s} ${9 / s}` : undefined}
          />
          <circle cx={b.cx} cy={b.cy} r={6 / s} fill="#fff" />
          {b.label ? (
            <text
              x={b.cx - b.w / 2 + (b.space ? 14 / s : 0)}
              y={b.space ? b.cy - b.h / 2 + 46 / s : b.cy - b.h / 2 - 12 / s}
              fill={YELLOW}
              opacity={b.labelOpacity}
              fontFamily={FONT}
              fontWeight={700}
              fontSize={36 / s}
              stroke="#000"
              strokeWidth={5 / s}
              paintOrder="stroke"
              style={{ letterSpacing: 1 }}
            >
              {b.label}
            </text>
          ) : null}
        </g>
      ))}
    </svg>
  );
};

// Narasi di sudut kiri atas.
const Caption: React.FC<{ t: number }> = ({ t }) => {
  const cue = cueAt(t);
  if (!cue) return null;
  const inP = clamp((t - cue.from) / 0.18, 0, 1);
  const outP = clamp((cue.to - t) / 0.12, 0, 1);
  return (
    <div
      style={{
        position: 'absolute',
        left: 48,
        top: 150,
        maxWidth: 600,
        padding: '14px 22px 16px 20px',
        background: 'rgba(0,0,0,0.62)',
        borderLeft: `8px solid ${YELLOW}`,
        borderRadius: 14,
        color: '#fff',
        fontFamily: FONT,
        fontWeight: 700,
        fontSize: 46,
        lineHeight: 1.18,
        opacity: inP * outP,
        transform: `translateY(${(1 - inP) * 14}px)`,
        textShadow: '0 2px 8px rgba(0,0,0,0.6)',
      }}
    >
      {cue.text}
    </div>
  );
};

const Watermark: React.FC<{ opacity: number }> = ({ opacity }) => {
  const row: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 12, justifyContent: 'flex-end' };
  const txt: React.CSSProperties = {
    color: '#fff',
    fontFamily: FONT,
    fontWeight: 500,
    fontSize: 31,
    textShadow: '0 2px 8px rgba(0,0,0,0.75)',
  };
  return (
    <div
      style={{
        position: 'absolute',
        right: 48,
        top: 150,
        display: 'flex',
        flexDirection: 'column',
        gap: 16,
        opacity,
      }}
    >
      <div style={row}>
        <span style={txt}>{BRAND.ig}</span>
        <IgIcon size={46} gid="ig-wm" />
      </div>
      <div style={row}>
        <span style={txt}>{BRAND.yt}</span>
        <YtIcon size={34} />
      </div>
    </div>
  );
};

const EndCard: React.FC<{ p: number }> = ({ p }) => {
  if (p <= 0) return null;
  const txt: React.CSSProperties = { color: '#fff', fontFamily: FONT, fontWeight: 700, fontSize: 52 };
  const row: React.CSSProperties = { display: 'flex', alignItems: 'center', gap: 22 };
  return (
    <AbsoluteFill
      style={{
        background: `rgba(0,0,0,${0.78 * p})`,
        justifyContent: 'center',
        alignItems: 'center',
        gap: 44,
      }}
    >
      <div style={{ ...row, opacity: p, transform: `translateY(${(1 - p) * 20}px)` }}>
        <IgIcon size={84} gid="ig-end" />
        <span style={txt}>{BRAND.ig}</span>
      </div>
      <div style={{ ...row, opacity: p, transform: `translateY(${(1 - p) * 20}px)` }}>
        <YtIcon size={70} />
        <span style={txt}>{BRAND.yt}</span>
      </div>
    </AbsoluteFill>
  );
};

export const DuetVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const cam = camAt(t);
  const endP = clamp((t - END_CARD_AT) / 0.5, 0, 1);

  return (
    <AbsoluteFill style={{ backgroundColor: '#05070a' }}>
      {/* ===== AUDIO: narasi + backsound + SFX (suara video asli di-mute) ===== */}
      <Audio src={staticFile(AUDIO_FILE)} volume={MIX.narasi} />
      <Audio src={staticFile(MUSIC_FILE)} volume={(f) => musicVolAt(f / FPS)} />
      {SFX.map((s, i) => (
        <Sequence
          key={i}
          from={Math.round(s.t * FPS)}
          durationInFrames={Math.ceil(SFX_LEN[s.name] * FPS) + 2}
          layout="none"
        >
          <Audio src={staticFile(`sfx/${s.name}.mp3`)} volume={s.vol} />
        </Sequence>
      ))}

      {/* ===== VIDEO: full-bleed 9:16 + kamera (pan/zoom) + kotak tracking ===== */}
      <div style={{ position: 'absolute', left: 0, top: 0, width: W, height: H, overflow: 'hidden' }}>
        <div
          style={{
            position: 'absolute',
            left: W / 2 - cam.cx * cam.s,
            top: H / 2 - cam.cy * cam.s,
            width: SRC_W,
            height: SRC_H,
            transformOrigin: '0 0',
            transform: `scale(${cam.s})`,
          }}
        >
          <SourceSegments style={{ position: 'absolute', left: 0, top: 0, width: SRC_W, height: SRC_H }} />
          <BoxLayer t={t} s={cam.s} />
        </div>
      </div>

      {/* gradien tipis di atas supaya caption + watermark terbaca */}
      <div
        style={{
          position: 'absolute',
          left: 0,
          top: 0,
          width: W,
          height: 520,
          background: 'linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0))',
        }}
      />

      <Caption t={t} />
      <Watermark opacity={1 - endP} />
      <EndCard p={endP} />
    </AbsoluteFill>
  );
};
