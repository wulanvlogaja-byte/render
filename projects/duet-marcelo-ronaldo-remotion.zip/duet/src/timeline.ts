// Fungsi murni (tanpa React): kamera, waktu sumber, kotak tracking, SFX, volume musik.
import { AUDIO_SEC, BOXES, CUES, Cam, END_CARD_AT, H, LINKS, MIX, SEGMENTS, SRC_H, SRC_W, TOTAL_SEC, W } from './data';

const clamp = (v: number, a: number, b: number) => Math.min(b, Math.max(a, v));
const lerp = (a: number, b: number, p: number) => a + (b - a) * p;
const easeOut = (p: number) => 1 - Math.pow(1 - p, 3);
const easeOutBack = (x: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};

export const isFrozen = (i: number) => SEGMENTS[i].src[0] === SEGMENTS[i].src[1];

export const segIndexAt = (t: number): number => {
  for (let i = 0; i < SEGMENTS.length; i++) {
    if (t >= SEGMENTS[i].out[0] && t < SEGMENTS[i].out[1]) return i;
  }
  return SEGMENTS.length - 1;
};

// Kamera selalu di-clamp supaya tepi video tidak pernah kelihatan.
export const camAt = (t: number): Cam => {
  const i = segIndexAt(t);
  const seg = SEGMENTS[i];
  const p = clamp((t - seg.out[0]) / (seg.out[1] - seg.out[0]), 0, 1);
  const e = isFrozen(i) ? easeOut(p) : p;
  const [a, b] = seg.cam;
  const s = Math.max(1.5, lerp(a.s, b.s, e));
  const halfW = W / (2 * s);
  const halfH = H / (2 * s);
  return {
    s,
    cx: clamp(lerp(a.cx, b.cx, e), halfW, SRC_W - halfW),
    cy: clamp(lerp(a.cy, b.cy, e), halfH, SRC_H - halfH),
  };
};

export const srcAt = (t: number): number => {
  const i = segIndexAt(t);
  const seg = SEGMENTS[i];
  const p = clamp((t - seg.out[0]) / (seg.out[1] - seg.out[0]), 0, 1);
  return lerp(seg.src[0], seg.src[1], p);
};

export type DrawBox = {
  id: string;
  cx: number;
  cy: number;
  w: number;
  h: number;
  opacity: number;
  label?: string;
  space: boolean;
  labelOpacity: number;
};
export type DrawLine = { x1: number; y1: number; x2: number; y2: number; opacity: number };

export const overlayAt = (t: number): { boxes: DrawBox[]; lines: DrawLine[] } => {
  const active: Record<string, { b: (typeof BOXES)[number]; opacity: number }> = {};
  const boxes: DrawBox[] = [];
  for (const b of BOXES) {
    const segEnd = SEGMENTS[b.seg].out[1];
    if (t < b.at || t > segEnd) continue;
    const p = clamp((t - b.at) / 0.3, 0, 1);
    const fade = clamp((segEnd - t) / 0.25, 0, 1);
    const sc = 0.55 + 0.45 * easeOutBack(p);
    const opacity = clamp(p * 1.6, 0, 1) * fade;
    active[b.id] = { b, opacity };
    boxes.push({
      id: b.id,
      cx: b.cx,
      cy: b.cy,
      w: b.w * sc,
      h: b.h * sc,
      opacity,
      label: b.label,
      space: b.kind === 'space',
      labelOpacity: clamp((t - b.at - 0.15) / 0.25, 0, 1) * fade,
    });
  }
  const lines: DrawLine[] = [];
  for (const [ia, ib] of LINKS) {
    const A = active[ia];
    const B = active[ib];
    if (!A || !B) continue;
    const start = Math.max(A.b.at, B.b.at) + 0.1;
    const q = easeOut(clamp((t - start) / 0.35, 0, 1));
    if (q <= 0) continue;
    // garis tumbuh dari kotak yang muncul lebih dulu
    const [from, to] = A.b.at <= B.b.at ? [A.b, B.b] : [B.b, A.b];
    lines.push({
      x1: from.cx,
      y1: from.cy,
      x2: lerp(from.cx, to.cx, q),
      y2: lerp(from.cy, to.cy, q),
      opacity: Math.min(A.opacity, B.opacity),
    });
  }
  return { boxes, lines };
};

export const cueAt = (t: number) => CUES.find((c) => t >= c.from && t < c.to) ?? null;

// ---------------- SFX otomatis dari timeline ----------------
export type Sfx = { t: number; name: 'whoosh' | 'swish' | 'impact' | 'pop'; vol: number };

const buildSfx = (): Sfx[] => {
  const list: Sfx[] = [];
  const last = SEGMENTS.length - 1;
  SEGMENTS.forEach((seg, i) => {
    const start = seg.out[0];
    if (isFrozen(i) && i !== last) {
      // whoosh naik lalu hantaman tepat saat video freeze
      list.push({ t: Math.max(0, start - 0.5), name: 'whoosh', vol: MIX.whoosh });
      list.push({ t: start, name: 'impact', vol: MIX.impact });
    } else if (i > 0 && !isFrozen(i)) {
      const prev = SEGMENTS[i - 1];
      const prevFrozen = isFrozen(i - 1);
      const jump = Math.abs(prev.src[1] - seg.src[0]) > 0.3; // potongan klip / lompat
      if (prevFrozen || jump) list.push({ t: Math.max(0, start - 0.04), name: 'swish', vol: MIX.swish });
    }
  });
  for (const b of BOXES) list.push({ t: b.at, name: 'pop', vol: MIX.pop });
  list.push({ t: END_CARD_AT, name: 'whoosh', vol: MIX.whoosh });
  return list.sort((a, b) => a.t - b.t);
};
export const SFX: Sfx[] = buildSfx();

// ---------------- Volume backsound (detik -> 0..1) ----------------
export const musicVolAt = (t: number): number => {
  const tailStart = AUDIO_SEC - 1.5;
  const base = t < tailStart ? MIX.music : lerp(MIX.music, MIX.musicTail, clamp((t - tailStart) / 2.1, 0, 1));
  const fadeIn = clamp(t / 1.0, 0, 1);
  const fadeOut = clamp((TOTAL_SEC - t) / 1.4, 0, 1);
  return base * fadeIn * fadeOut;
};
