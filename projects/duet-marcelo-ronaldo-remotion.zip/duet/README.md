# Duet Marcelo x Ronaldo (Remotion, 9:16)

Composition ID : DuetMarceloRonaldo  |  1080x1920 @ 30fps  |  ±55,4 detik
Media          : public/duet.mp4 (mentahan), public/narasi.mp3 (narasi)
Audio          : suara bawaan video di-mute. Yang terdengar = narasi + backsound + SFX
                 (public/sfx/*.mp3 dibuat sendiri, bebas hak cipta)

## Render
- GitHub Actions: jalankan workflow `render-remotion.yml` (workflow_dispatch), hasil ada di Artifacts.
- Lokal: `npm install` lalu `npm run render` (atau `npm run studio` untuk preview).

## Fine-tuning (semua di src/data.ts)
- SEGMENTS : kapan video jalan / freeze (src = detik di mentahan, out = detik di hasil) + gerak kamera
- BOXES / LINKS : posisi kotak tracking (piksel video 720x1280), waktu muncul, label
- CUES : teks narasi di kiri atas
- MIX : volume narasi / backsound / SFX
- BRAND : nama akun IG & YouTube
