import React from 'react';
import timing from './timing.json';

// ============ Komposisi murni: semua animasi = fungsi dari t (detik) ============
export const W = 1080;
export const H = 1920;
type Word = { w: string; start: number; end: number };
type Sent = { i: number; text: string; start: number; end: number; words: Word[] };
const SENT = timing.sentences as Sent[];
const DUR = timing.duration;

// ---------- util ----------
const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const prog = (t: number, a: number, d: number) => clamp((t - a) / d);
const eo = (x: number) => 1 - Math.pow(1 - x, 3);
const eb = (x: number) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
const hash = (n: number) => { // deterministik, 0..1
  let h = Math.imul(Math.floor(n) + 1, 0x9e3779b1) >>> 0;
  h ^= h >>> 15; h = Math.imul(h, 0x85ebca6b) >>> 0; h ^= h >>> 13; h = Math.imul(h, 0xc2b2ae35) >>> 0; h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
};
const mixHex = (a: string, b: string, k: number) => {
  const p = (s: string) => [1, 3, 5].map((i) => parseInt(s.slice(i, i + 2), 16));
  const A = p(a), B = p(b);
  return '#' + A.map((v, i) => Math.round(v + (B[i] - v) * clamp(k)).toString(16).padStart(2, '0')).join('');
};
const norm = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}-]/gu, '');
// cue visual dari kata di timing.json (nth = kemunculan ke-n kata itu dalam kalimat)
const cue = (si: number, word: string, nth = 0) => {
  const k = norm(word); let n = 0;
  for (const w of SENT[si].words) if (norm(w.w) === k) { if (n === nth) return w.start; n++; }
  return SENT[si].start;
};
const S = (i: number) => SENT[i].start;
const E = (i: number) => SENT[i].end;
const shake = (t: number, amp: number, f = 28) => ({
  x: (hash(Math.floor(t * f)) - 0.5) * amp, y: (hash(Math.floor(t * f) + 777) - 0.5) * amp,
});

const FONT = "'Poppins','DejaVu Sans',sans-serif";
const C = { yellow: '#ffd23f', cyan: '#22d3ee', pink: '#ff4d8d', green: '#34d399', red: '#ef4444', blue: '#3b82f6', navy: '#0b1020', white: '#ffffff', ink: '#0b1020' };

// ---------- primitif SVG ----------
const T: React.FC<{ x: number; y: number; size: number; fill?: string; anchor?: 'middle' | 'start' | 'end'; stroke?: string; sw?: number; rot?: number; children: React.ReactNode; opacity?: number; weight?: number }> =
  ({ x, y, size, fill = '#fff', anchor = 'middle', stroke = C.ink, sw, rot = 0, children, opacity = 1, weight = 800 }) => (
    <text x={x} y={y} fontSize={size} fontWeight={weight} fill={fill} textAnchor={anchor} opacity={opacity}
      stroke={stroke} strokeWidth={sw ?? Math.max(2, size * 0.09)} paintOrder="stroke" strokeLinejoin="round"
      transform={rot ? `rotate(${rot} ${x} ${y})` : undefined} style={{ fontFamily: FONT }}>{children}</text>
  );

const Pop: React.FC<{ t: number; at: number; x: number; y: number; s?: number; rot?: number; children: React.ReactNode }> = ({ t, at, x, y, s = 1, rot = 0, children }) => {
  if (t < at) return null;
  const p = eb(prog(t, at, 0.4)); const o = clamp((t - at) / 0.1);
  return <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${Math.max(0.0001, p * s)})`} opacity={o}>{children}</g>;
};

const Stamp: React.FC<{ t: number; at: number; x: number; y: number; text: string; color: string; size?: number; rot?: number }> = ({ t, at, x, y, text, color, size = 90, rot = -10 }) => {
  if (t < at) return null;
  const k = clamp((t - at) / 0.18); const sc = 1 + (1 - eo(k)) * 1.2;
  const w = text.length * size * 0.62 + 60;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${sc})`} opacity={k}>
      <rect x={-w / 2} y={-size * 0.85} width={w} height={size * 1.25} rx={18} fill="rgba(0,0,0,0.35)" stroke={color} strokeWidth={10} />
      <T x={0} y={0} size={size} fill={color} stroke="none" sw={0}>{text}</T>
    </g>
  );
};

const Cross: React.FC<{ t: number; at: number; x: number; y: number; r?: number }> = ({ t, at, x, y, r = 42 }) => {
  const a = eo(prog(t, at, 0.2)), b = eo(prog(t, at + 0.15, 0.2));
  if (t < at) return null;
  return (
    <g stroke={C.red} strokeWidth={16} strokeLinecap="round">
      <line x1={x - r} y1={y - r} x2={x - r + 2 * r * a} y2={y - r + 2 * r * a} />
      {b > 0 && <line x1={x + r} y1={y - r} x2={x + r - 2 * r * b} y2={y - r + 2 * r * b} />}
    </g>
  );
};

const WifiArcs: React.FC<{ t: number; x: number; y: number; s?: number; color?: string; speed?: number }> = ({ t, x, y, s = 1, color = C.cyan, speed = 0.9 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill="none" stroke={color} strokeWidth={12} strokeLinecap="round">
    {[0, 1, 2].map((k) => {
      const ph = (t * speed + k / 3) % 1; const r = 50 + ph * 190;
      const a0 = (-135 * Math.PI) / 180, a1 = (-45 * Math.PI) / 180;
      return <path key={k} opacity={(1 - ph) * 0.95} d={`M ${r * Math.cos(a0)} ${r * Math.sin(a0)} A ${r} ${r} 0 0 1 ${r * Math.cos(a1)} ${r * Math.sin(a1)}`} />;
    })}
  </g>
);

type Mood = 'happy' | 'tired' | 'panic' | 'dead' | 'smile';
const Router: React.FC<{ t: number; x: number; y: number; s?: number; mood?: Mood; heat?: number; body?: string; ledRate?: number }> = ({ t, x, y, s = 1, mood = 'happy', heat = 0, body = C.blue, ledRate = 6 }) => {
  const col = mixHex(body, '#ff2a1a', heat);
  const dark = mixHex(col, '#000000', 0.35);
  const sway = Math.sin(t * 2.2) * 3 + (heat > 0.5 ? (hash(Math.floor(t * 30)) - 0.5) * 8 * heat : 0);
  const blink = mood !== 'dead' && (t % 3.1) < 0.12;
  const ey = blink ? 0.12 : 1;
  const eye = (cx: number) => {
    if (mood === 'dead') return (
      <g stroke="#fff" strokeWidth={9} strokeLinecap="round"><line x1={cx - 16} y1={-30} x2={cx + 16} y2={2} /><line x1={cx + 16} y1={-30} x2={cx - 16} y2={2} /></g>);
    const big = mood === 'panic' ? 27 : 22;
    const px = Math.sin(t * 1.3) * 5;
    return (
      <g transform={`translate(${cx} -14) scale(1 ${ey})`}>
        <circle r={big} fill="#fff" />
        <circle cx={px} cy={mood === 'tired' ? 7 : 0} r={mood === 'panic' ? 6 : 11} fill={C.ink} />
        {mood === 'tired' && <rect x={-big - 2} y={-big - 2} width={big * 2 + 4} height={big + 2} fill={col} />}
      </g>);
  };
  const mouth = mood === 'happy' || mood === 'smile' ? 'M -34 34 Q 0 70 34 34'
    : mood === 'tired' ? 'M -30 52 Q 0 36 30 52' : mood === 'panic' ? 'M -28 40 Q 0 74 28 40 Q 0 52 -28 40' : 'M -30 50 L 30 50';
  const sweat = (mood === 'tired' || mood === 'panic') ? ((t * 0.9) % 1) : -1;
  return (
    <g transform={`translate(${x} ${y}) scale(${s}) rotate(${sway * 0.3})`}>
      <g stroke={dark} strokeWidth={16} strokeLinecap="round">
        <line x1={-120} y1={-80} x2={-150 + sway} y2={-230} /><line x1={120} y1={-80} x2={150 - sway} y2={-230} />
      </g>
      <circle cx={-150 + sway} cy={-236} r={13} fill={C.yellow} /><circle cx={150 - sway} cy={-236} r={13} fill={C.yellow} />
      <rect x={-190} y={-90} width={380} height={190} rx={42} fill={col} stroke={C.ink} strokeWidth={8} />
      <rect x={-190} y={52} width={380} height={48} rx={24} fill={dark} />
      {[0, 1, 2, 3].map((k) => {
        const on = mood === 'dead' ? false : hash(Math.floor(t * ledRate) + k * 13) > (heat > 0.5 ? 0.15 : 0.4);
        return <circle key={k} cx={-110 + k * 44} cy={76} r={9} fill={on ? (heat > 0.5 ? '#ff5a3c' : C.green) : '#334155'} />;
      })}
      {eye(-54)}{eye(54)}
      <path d={mouth} fill={mood === 'panic' ? '#7f1d1d' : 'none'} stroke="#fff" strokeWidth={9} strokeLinecap="round" transform="translate(0 0)" />
      {sweat >= 0 && <path d={`M 118 ${-60 + sweat * 80} q 14 22 0 34 q -14 -12 0 -34`} fill={C.cyan} opacity={1 - sweat} />}
    </g>
  );
};

const Person: React.FC<{ t: number; x: number; y: number; s?: number; color?: string; seed?: number; sign?: string; jump?: boolean }> = ({ t, x, y, s = 1, color = C.pink, seed = 0, sign, jump }) => {
  const bob = jump ? -Math.abs(Math.sin(t * 7 + seed)) * 26 : Math.sin(t * 4 + seed) * 4;
  return (
    <g transform={`translate(${x} ${y + bob}) scale(${s})`}>
      {sign && <g><line x1={26} y1={-70} x2={26} y2={-150} stroke="#fff" strokeWidth={6} /><rect x={-18} y={-190} width={124} height={54} rx={10} fill="#fff" stroke={C.ink} strokeWidth={5} />
        <T x={44} y={-150} size={30} fill={C.red} stroke="none" sw={0}>{sign}</T></g>}
      <path d="M -34 60 Q -34 -14 0 -14 Q 34 -14 34 60 Z" fill={color} stroke={C.ink} strokeWidth={6} />
      <circle cy={-44} r={26} fill="#ffd9b5" stroke={C.ink} strokeWidth={6} />
    </g>
  );
};

const House: React.FC<{ x: number; y: number; s?: number; color?: string }> = ({ x, y, s = 1, color = '#94a3b8' }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-70} y={-60} width={140} height={110} fill={color} stroke={C.ink} strokeWidth={6} />
    <path d="M -90 -58 L 0 -130 L 90 -58 Z" fill="#b45309" stroke={C.ink} strokeWidth={6} strokeLinejoin="round" />
    <rect x={-16} y={0} width={32} height={50} fill="#475569" /><rect x={30} y={-34} width={30} height={30} fill={C.yellow} />
  </g>
);

// ---------- latar & kerangka adegan ----------
const ACCENT = [C.cyan, C.green, C.pink, C.yellow, '#a78bfa', '#6366f1', C.red, C.yellow, C.green, C.pink, C.red];
const sceneWin = (i: number) => ({ a: i === 0 ? 0 : S(i), b: i === SENT.length - 1 ? DUR + 5 : S(i + 1) });

const Background: React.FC<{ t: number; idx: number }> = ({ t, idx }) => {
  const ac = ACCENT[idx];
  const off = (t * 24) % 90;
  return (
    <g>
      <defs>
        <linearGradient id="bg" x1="0" y1="0" x2="0.4" y2="1"><stop offset="0" stopColor="#0b1020" /><stop offset="1" stopColor="#241450" /></linearGradient>
      </defs>
      <rect width={W} height={H} fill="url(#bg)" />
      <g stroke="rgba(255,255,255,0.06)" strokeWidth={2}>
        {Array.from({ length: 14 }, (_, k) => <line key={'v' + k} x1={k * 90} y1={0} x2={k * 90} y2={H} />)}
        {Array.from({ length: 24 }, (_, k) => <line key={'h' + k} x1={0} y1={k * 90 - 90 + off} x2={W} y2={k * 90 - 90 + off} />)}
      </g>
      <circle cx={540} cy={900} r={520 + Math.sin(t * 1.5) * 20} fill={ac} opacity={0.10} />
    </g>
  );
};

// ---------- ADEGAN ----------
const Sc1: React.FC<{ t: number }> = ({ t }) => {
  const wifiT = cue(0, 'Wi-Fi'), tetT = cue(0, 'tetangga');
  return (
    <g>
      <Pop t={t} at={0.05} x={540} y={300} s={1.2}><T x={0} y={0} size={150} fill={C.yellow}>POV:</T></Pop>
      <Pop t={t} at={cue(0, 'lo')} x={540} y={430}><T x={0} y={0} size={96}>LO JADI</T></Pop>
      <Pop t={t} at={wifiT} x={540} y={560} s={1.1}><T x={0} y={0} size={140} fill={C.cyan}>WI-FI</T></Pop>
      <Pop t={t} at={tetT} x={540} y={690}><T x={0} y={0} size={110} fill={C.pink}>TETANGGA?</T></Pop>
      {t > wifiT && <WifiArcs t={t - wifiT} x={540} y={1060} s={1.5} />}
      <Router t={t} x={540} y={1130 + Math.sin(t * 3) * 10} s={1.5} mood="happy" />
      {[[170, 1380, 0.8], [900, 1330, 0.7], [160, 1000, 0.6], [920, 980, 0.6]].map(([hx, hy, hs], k) => (
        <Pop key={k} t={t} at={tetT + 0.12 * k} x={hx} y={hy} s={hs}><House x={0} y={0} color={['#94a3b8', '#fca5a5', '#a5b4fc', '#86efac'][k]} /></Pop>
      ))}
    </g>
  );
};

const Sc2: React.FC<{ t: number }> = ({ t }) => {
  const name = 'Wi-Fi_Gratis_Coba_Saja';
  const n0 = cue(1, 'Nama'), n1 = cue(1, 'saja');
  const shown = name.slice(0, Math.floor(prog(t, n0, n1 - n0 + 0.3) * name.length));
  const digs = ['satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan'];
  const pw = '12345678';
  return (
    <g>
      <Pop t={t} at={n0} x={540} y={250}><T x={0} y={0} size={64} fill={C.cyan}>NAMA WI-FI</T></Pop>
      <rect x={90} y={300} width={900} height={170} rx={34} fill="#0f172a" stroke={C.cyan} strokeWidth={8} />
      <g transform="translate(150 385) scale(0.5)"><WifiArcs t={0.6} x={0} y={60} s={1} color={C.cyan} speed={0} /></g>
      <T x={250} y={412} size={56} anchor="start" stroke="none" sw={0}>{shown}{(t * 2) % 1 < 0.5 && t < n1 + 0.5 ? '|' : ''}</T>
      <Stamp t={t} at={cue(1, 'gratis')} x={790} y={545} text="GRATIS" color={C.green} size={60} rot={-9} />
      <Pop t={t} at={cue(1, 'Password')} x={540} y={620}><T x={0} y={0} size={64} fill={C.yellow}>PASSWORD</T></Pop>
      {pw.split('').map((d, k) => {
        const at = cue(1, digs[k]); const cx = 150 + k * 111;
        return (
          <g key={k}>
            <rect x={cx - 48} y={670} width={96} height={130} rx={20} fill="#0f172a" stroke={t >= at ? C.yellow : '#475569'} strokeWidth={6} />
            {t < at ? <circle cx={cx} cy={735} r={9} fill="#64748b" /> : (
              <g transform={`translate(${cx} 770) scale(${eb(prog(t, at, 0.3))})`}><T x={0} y={0} size={86} fill={C.yellow}>{d}</T></g>)}
          </g>);
      })}
      {t > cue(1, 'delapan') + 0.2 && <Pop t={t} at={cue(1, 'delapan') + 0.2} x={540} y={900}><T x={0} y={0} size={54} fill={C.red}>TEBAKAN SEMUA ORANG</T></Pop>}
      <WifiArcs t={t} x={540} y={1260} s={1.2} />
      <Router t={t} x={540} y={1330} s={1.3} mood="smile" />
    </g>
  );
};

const Sc3: React.FC<{ t: number }> = ({ t }) => {
  const rt = cue(2, 'RT');
  const cnt = Math.floor(eo(prog(t, cue(2, 'nyambung'), 1.8)) * 47);
  const flow = (x1: number, y1: number, x2: number, y2: number, at: number) => t < at ? null : (
    <g>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={C.cyan} strokeWidth={5} strokeDasharray="14 12" opacity={0.7} />
      {[0, 1, 2, 3].map((k) => { const p = (t * 0.9 + k / 4) % 1; return <circle key={k} cx={x1 + (x2 - x1) * p} cy={y1 + (y2 - y1) * p} r={10} fill={C.yellow} />; })}
    </g>);
  const pix = (k: number) => hash(Math.floor(t * 3) + k * 17);
  return (
    <g>
      <Pop t={t} at={rt} x={540} y={250} s={1.1}><T x={0} y={0} size={140} fill={C.yellow}>1 RT</T></Pop>
      <Pop t={t} at={cue(2, 'nyambung')} x={540} y={350}><T x={0} y={0} size={56} fill={C.green}>{`${cnt} DEVICE NYAMBUNG`}</T></Pop>
      <WifiArcs t={t} x={540} y={720} s={1.0} />
      <Router t={t} x={540} y={800} s={1.1} mood="panic" ledRate={14} />
      {flow(430, 930, 260, 1060, cue(2, 'bocil'))}
      {flow(650, 930, 820, 1060, cue(2, 'bapak-bapak'))}
      <Pop t={t} at={cue(2, 'bocil')} x={270} y={1200}>
        <rect x={-210} y={-140} width={420} height={400} rx={36} fill="#1e293b" stroke={C.pink} strokeWidth={8} />
        <T x={0} y={-80} size={46} fill={C.pink}>BOCIL</T>
        <rect x={-60} y={-50} width={120} height={200} rx={20} fill="#0f172a" stroke="#fff" strokeWidth={6} />
        {t >= cue(2, 'ML') && <T x={0} y={70} size={60} fill={C.yellow}>ML</T>}
        <T x={0} y={215} size={34} fill="#cbd5e1" stroke="none" sw={0}>Mobile Legends</T>
      </Pop>
      <Pop t={t} at={cue(2, 'bapak-bapak')} x={810} y={1200}>
        <rect x={-210} y={-140} width={420} height={400} rx={36} fill="#1e293b" stroke={C.green} strokeWidth={8} />
        <T x={0} y={-80} size={46} fill={C.green}>BAPAK-BAPAK</T>
        <rect x={-150} y={-45} width={300} height={170} rx={12} fill="#0f172a" stroke="#fff" strokeWidth={5} />
        {t >= cue(2, '144p') ? (
          <g>{Array.from({ length: 30 }, (_, k) => <rect key={k} x={-150 + (k % 10) * 30} y={-45 + Math.floor(k / 10) * 56} width={30} height={56} fill={mixHex('#334155', '#94a3b8', pix(k))} />)}
            <T x={100} y={110} size={40} fill={C.red}>144p</T></g>
        ) : <polygon points="-18,-8 -18,68 40,30" fill={C.red} />}
        <T x={0} y={215} size={34} fill="#cbd5e1" stroke="none" sw={0}>Ceramah YouTube</T>
      </Pop>
    </g>
  );
};

const Sc4: React.FC<{ t: number }> = ({ t }) => {
  const lt = t - S(3);
  const rows: [string, string, number, string][] = [
    ['LIBUR', '0 HARI', cue(3, 'libur'), C.red],
    ['GAJI', 'Rp 0', cue(3, 'dibayar'), C.red],
    ['MAKASIH', '0x', cue(3, 'makasih'), C.red],
  ];
  return (
    <g>
      <Pop t={t} at={cue(3, 'kerja')} x={540} y={200}><T x={0} y={0} size={72} fill={C.yellow}>LO KERJA...</T></Pop>
      <g transform="translate(540 580)">
        <circle r={230} fill="#f8fafc" stroke={C.ink} strokeWidth={14} />
        {Array.from({ length: 12 }, (_, k) => <line key={k} x1={0} y1={-200} x2={0} y2={-176} stroke={C.ink} strokeWidth={9} transform={`rotate(${k * 30})`} />)}
        <line x1={0} y1={0} x2={0} y2={-110} stroke={C.ink} strokeWidth={16} strokeLinecap="round" transform={`rotate(${lt * 200})`} />
        <line x1={0} y1={0} x2={0} y2={-170} stroke={C.red} strokeWidth={10} strokeLinecap="round" transform={`rotate(${lt * 2400})`} />
        <circle r={16} fill={C.ink} />
      </g>
      <Pop t={t} at={cue(3, '24')} x={540} y={900} s={1.1}><T x={0} y={0} size={120} fill={C.cyan}>24 JAM</T></Pop>
      {rows.map(([a, b, at, col], k) => {
        const y = 1020 + k * 150;
        return (
          <g key={k}>
            <Pop t={t} at={at} x={540} y={y}>
              <rect x={-420} y={-60} width={840} height={110} rx={28} fill="#1e293b" stroke={col} strokeWidth={6} />
              <T x={-300} y={20} size={52} anchor="start" fill="#fff">{a}</T>
              <T x={380} y={20} size={56} anchor="end" fill={col}>{b}</T>
            </Pop>
            <Cross t={t} at={at + 0.35} x={540 - 360} y={y - 5} r={30} />
          </g>);
      })}
    </g>
  );
};

const Sc5: React.FC<{ t: number }> = ({ t }) => {
  const lag = cue(4, 'nge-lag'), ng = cue(4, 'ngatain'), lm = cue(4, 'lemot');
  const tiles = [[150, 450], [560, 450], [150, 740], [560, 740]];
  const colors = [C.pink, C.green, C.yellow, C.cyan];
  const glitch = t >= lag;
  return (
    <g>
      <Pop t={t} at={cue(4, 'Zoom')} x={540} y={250}><T x={0} y={0} size={78} fill={C.blue}>ZOOM MEETING</T></Pop>
      <Pop t={t} at={cue(4, 'penting')} x={540} y={340} s={1}><T x={0} y={0} size={56} fill={C.yellow}>PENTING!</T></Pop>
      <rect x={90} y={390} width={900} height={640} rx={30} fill="#0f172a" stroke="#475569" strokeWidth={6} />
      {tiles.map(([tx, ty], k) => {
        const gx = glitch ? (hash(Math.floor(t * 12) + k * 5) - 0.5) * 36 : 0;
        return (
          <g key={k} transform={`translate(${gx} 0)`}>
            <rect x={tx} y={ty} width={370} height={250} rx={20} fill="#1e293b" />
            <Person t={glitch ? 0 : t} x={tx + 185} y={ty + 190} s={1.6} color={colors[k]} seed={k} />
            {glitch && hash(Math.floor(t * 10) + k) > 0.5 && <rect x={tx} y={ty + hash(k + Math.floor(t * 10)) * 200} width={370} height={22} fill={C.cyan} opacity={0.5} />}
          </g>);
      })}
      {glitch && (
        <g transform="translate(540 710)">
          <circle r={64} fill="rgba(0,0,0,0.65)" />
          <path d="M 0 -44 A 44 44 0 1 1 -44 0" fill="none" stroke="#fff" strokeWidth={12} strokeLinecap="round" transform={`rotate(${t * 360})`} />
        </g>)}
      {glitch && <Pop t={t} at={lag} x={540} y={1080}><rect x={-380} y={-50} width={760} height={90} rx={22} fill={C.red} /><T x={0} y={14} size={44} stroke="none" sw={0}>KONEKSI TIDAK STABIL</T></Pop>}
      <Router t={t} x={540} y={1360} s={0.85} mood={t >= ng ? 'panic' : t >= lag ? 'tired' : 'happy'} />
      <Pop t={t} at={lm} x={210} y={1230} s={1.15} rot={-8}><rect x={-170} y={-50} width={340} height={90} rx={26} fill="#fff" /><T x={0} y={18} size={48} fill={C.red} stroke="none" sw={0}>LEMOT!!</T></Pop>
      <Pop t={t} at={ng} x={880} y={1250} rot={7}><rect x={-190} y={-50} width={380} height={90} rx={26} fill="#fff" /><T x={0} y={14} size={36} fill={C.ink} stroke="none" sw={0}>WIFINYA KENAPA?</T></Pop>
          </g>
  );
};

const Sc6: React.FC<{ t: number }> = ({ t }) => {
  const hotT = cue(5, 'panas'), deadT = cue(5, 'mokat');
  const heat = eo(prog(t, hotT - 0.9, 1.3));
  const dead = t >= deadT;
  const dl = prog(t, cue(5, 'download'), deadT - cue(5, 'download'));
  const shk = dead ? shake(t - deadT, 18 * Math.max(0, 1 - (t - deadT))) : { x: 0, y: 0 };
  return (
    <g transform={`translate(${shk.x} ${shk.y})`}>
      <rect width={W} height={H} fill="#020617" opacity={0.55 * eo(prog(t, S(5), 0.4))} />
      {Array.from({ length: 28 }, (_, k) => <circle key={k} cx={hash(k) * W} cy={60 + hash(k + 99) * 700} r={2 + hash(k + 50) * 4} fill="#fff" opacity={0.4 + 0.6 * Math.abs(Math.sin(t * 2 + k))} />)}
      <circle cx={880} cy={260} r={90} fill="#fef3c7" /><circle cx={915} cy={240} r={80} fill="#1b1448" />
      <Pop t={t} at={cue(5, 'malam')} x={300} y={270} s={1.1}><T x={0} y={0} size={110} fill={C.yellow}>MALAM</T></Pop>
      <Pop t={t} at={cue(5, 'download')} x={540} y={600}>
        <rect x={-440} y={-130} width={880} height={300} rx={34} fill="#1e293b" stroke={C.pink} strokeWidth={8} />
        <T x={-400} y={-60} size={40} anchor="start" fill="#fff" stroke="none" sw={0}>DRAKOR_FULL_16EP.mkv</T>
        <rect x={-400} y={-10} width={800} height={50} rx={25} fill="#0f172a" />
        <rect x={-400} y={-10} width={Math.max(2, 800 * dl)} height={50} rx={25} fill={mixHex(C.green, C.red, heat)} />
        <T x={-400} y={120} size={46} anchor="start" fill={C.cyan} stroke="none" sw={0}>{`${(dl * 10).toFixed(1)} / 10 GB`}</T>
        <T x={400} y={120} size={40} anchor="end" fill={C.yellow} stroke="none" sw={0}>{dead ? '0 KB/s' : '9 MB/s'}</T>
      </Pop>
      <Pop t={t} at={cue(5, 'giga')} x={540} y={900} s={1.1}><T x={0} y={0} size={110} fill={C.pink}>10 GIGA!</T></Pop>
      {heat > 0.2 && Array.from({ length: 7 }, (_, k) => {
        const ph = (t * 0.7 + k / 7) % 1;
        return <circle key={k} cx={400 + hash(k) * 280 + Math.sin(t * 3 + k) * 20} cy={1270 - ph * 330} r={22 + ph * 36} fill="#cbd5e1" opacity={(1 - ph) * 0.5 * heat} />;
      })}
      <Router t={t} x={540} y={1340} s={1.4} heat={heat} mood={dead ? 'dead' : t >= hotT ? 'panic' : 'tired'} ledRate={heat > 0.4 ? 20 : 6} />
      <Stamp t={t} at={deadT} x={540} y={1060} text="MOKAT" color={C.red} size={120} rot={-8} />
    </g>
  );
};

const Sc7: React.FC<{ t: number }> = ({ t }) => {
  const a = S(6), korban = cue(6, 'korban'), pelaku = cue(6, 'pelaku'), like = cue(6, 'LIKE'), sub = cue(6, 'SUBSCRIBE');
  const click = sub + 0.55; const subd = t >= click;
  const sh = shake(t, 10);
  const titleOp = 1 - prog(t, korban - 0.3, 0.3);
  const bell = subd ? Math.sin((t - click) * 22) * 22 * Math.max(0, 1 - (t - click) * 0.7) : 0;
  const cx = 300 + (700 - 300 + 70) * eo(prog(t, like + 0.2, sub + 0.4 - like - 0.2)); // kursor menuju SUBSCRIBE
  const cy = 1150 - 240 * eo(prog(t, like + 0.2, sub + 0.4 - like - 0.2));
  return (
    <g>
      {t < korban + 0.05 && (
        <g opacity={titleOp} transform={`translate(${sh.x} ${sh.y})`}>
          <Pop t={t} at={a + 0.0} x={540} y={300}><T x={0} y={0} size={120} fill={C.red}>EH BENTAR</T></Pop>
          <Pop t={t} at={cue(6, 'Bro')} x={540} y={430}><T x={0} y={0} size={130} fill={C.yellow}>BRO!</T></Pop>
          <Pop t={t} at={cue(6, 'stop')} x={540} y={680} s={1.2}>
            <polygon points="-90,-220 90,-220 220,-90 220,90 90,220 -90,220 -220,90 -220,-90" transform="scale(0.8)" fill={C.red} stroke="#fff" strokeWidth={12} />
            <T x={0} y={26} size={86} stroke="none" sw={0}>STOP</T>
          </Pop>
        </g>)}
      <Pop t={t} at={korban} x={290} y={400}><rect x={-230} y={-60} width={460} height={120} rx={30} fill={C.blue} stroke="#fff" strokeWidth={6} /><T x={0} y={18} size={44} stroke="none" sw={0}>TIM KORBAN</T></Pop>
      <Pop t={t} at={pelaku} x={790} y={400}><rect x={-230} y={-60} width={460} height={120} rx={30} fill="#f97316" stroke="#fff" strokeWidth={6} /><T x={0} y={18} size={44} stroke="none" sw={0}>TIM PELAKU</T></Pop>
      <Pop t={t} at={cue(6, 'tim')} x={540} y={600}><T x={0} y={0} size={84} fill={C.yellow}>LO TIM MANA?</T></Pop>
      <Pop t={t} at={like} x={300} y={940}>
        <rect x={-190} y={-170} width={380} height={340} rx={50} fill="#1d4ed8" stroke="#fff" strokeWidth={8} />
        <path d="M -70 90 L -70 -20 L -20 -20 L 20 -110 Q 70 -110 56 -40 L 100 -40 Q 124 -40 118 -10 L 98 80 Q 94 100 70 100 Z" fill="#fff" />
        <rect x={-120} y={-20} width={36} height={120} rx={8} fill="#fff" />
        <T x={0} y={150} size={44} stroke="none" sw={0}>LIKE</T>
      </Pop>
      <Pop t={t} at={sub} x={740} y={940}>
        <rect x={-210} y={-90} width={420} height={170} rx={40} fill={subd ? '#475569' : '#dc2626'} stroke="#fff" strokeWidth={8} />
        <T x={0} y={22} size={subd ? 40 : 46} stroke="none" sw={0}>{subd ? 'SUBSCRIBED' : 'SUBSCRIBE'}</T>
        <g transform={`translate(150 -110) rotate(${bell})`}><path d="M -26 30 Q -26 -30 0 -36 Q 26 -30 26 30 L 36 44 L -36 44 Z" fill={C.yellow} stroke={C.ink} strokeWidth={5} /><circle cy={54} r={9} fill={C.yellow} stroke={C.ink} strokeWidth={4} /></g>
      </Pop>
      {t >= like + 0.2 && t < click + 0.6 && <path d={`M ${cx} ${cy} l 0 70 l 18 -16 l 16 36 l 14 -6 l -16 -36 l 24 0 Z`} fill="#fff" stroke={C.ink} strokeWidth={5} transform={`translate(0 ${t >= click ? 8 : 0})`} />}
      <Router t={t} x={540} y={1370} s={0.9} mood={t >= cue(6, 'semangat') ? 'happy' : 'tired'} />
      {t >= cue(6, 'semangat') && (
        <g>
          {Array.from({ length: 6 }, (_, k) => { const ph = ((t - cue(6, 'semangat')) * 0.8 + k / 6) % 1; return <path key={k} d="M 0 10 C -30 -20 -34 -44 0 -30 C 34 -44 30 -20 0 10 Z" fill={C.pink} transform={`translate(${380 + k * 64 + Math.sin(t * 3 + k) * 14} ${1250 - ph * 200}) scale(${0.8})`} opacity={1 - ph} />; })}
        </g>)}
    </g>
  );
};

const Sc8: React.FC<{ t: number }> = ({ t }) => {
  const lt = t - S(7); const p = eo(prog(lt, 0, 0.25));
  return (
    <g>
      <rect width={W} height={H} fill={C.yellow} opacity={0.14 * (1 - prog(lt, 0, 0.3))} />
      <g transform={`translate(${-500 + 500 * p} 0)`}>
        <T x={540} y={880} size={190} fill={C.green}>LANJUT</T>
        {[0, 1, 2].map((k) => <polygon key={k} points="0,-60 80,0 0,60" fill={C.yellow} stroke={C.ink} strokeWidth={8} transform={`translate(${340 + k * 120 + ((lt * 300) % 120)} 1050)`} opacity={0.4 + 0.2 * k} />)}
      </g>
    </g>
  );
};

const Sc9: React.FC<{ t: number }> = ({ t }) => {
  const gT = cue(8, 'ganti'), pT = cue(8, 'password'), rT = cue(8, 'RT'), dT = cue(8, 'demo');
  const fin = 'x9#Qm2$k';
  const pw = t < pT ? '12345678' : t < pT + 0.6 ? Array.from({ length: 8 }, (_, k) => '#$%&@!?*'[Math.floor(hash(Math.floor(t * 20) + k) * 8)]).join('') : fin;
  return (
    <g>
      <Pop t={t} at={cue(8, 'Besoknya')} x={540} y={240} s={1.1}><T x={0} y={0} size={110} fill={C.green}>BESOKNYA</T></Pop>
      <House x={230} y={720} s={2} color="#bfdbfe" />
      <Person t={t} x={230} y={850} s={1.5} color={C.green} />
      <Pop t={t} at={gT} x={700} y={560}>
        <rect x={-300} y={-90} width={600} height={220} rx={30} fill="#0f172a" stroke={C.red} strokeWidth={8} />
        <T x={0} y={-25} size={44} fill={C.red}>GANTI PASSWORD</T>
        <T x={0} y={65} size={70} fill={C.yellow} stroke="none" sw={0}>{pw}</T>
      </Pop>
      {Array.from({ length: 15 }, (_, k) => {
        const st = rT + k * 0.07; const p = eo(prog(t, st, 1.0));
        const tx = 150 + (k % 5) * 190, ty = 1230 + Math.floor(k / 5) * 130;
        const sx = 1250 + hash(k) * 300;
        const jit = t >= dT ? (hash(Math.floor(t * 10) + k) - 0.5) * 10 : 0;
        return t < st ? null : <Person key={k} t={t} x={sx + (tx - sx) * p + jit} y={ty} s={0.8} color={[C.pink, C.yellow, C.cyan, '#a78bfa', '#fb923c'][k % 5]} seed={k} sign={t >= dT ? 'WIFI!' : undefined} jump={t >= dT} />;
      })}
      <Pop t={t} at={dT} x={540} y={1010}><T x={0} y={0} size={96} fill={C.red}>DEMO!!</T></Pop>
    </g>
  );
};

const Sc10: React.FC<{ t: number }> = ({ t }) => {
  const kT = cue(9, 'kotak'), ked = cue(9, 'kedip-kedip'), tb = cue(9, 'tiba-tiba'), reb = cue(9, 'rebutan'), pen = cue(9, 'pensiun');
  const spot = eo(prog(t, tb, 0.4));
  return (
    <g>
      {spot > 0 && <polygon points="440,0 640,0 960,1300 120,1300" fill="#fff" opacity={0.12 * spot} />}
      <Pop t={t} at={kT} x={540} y={250}><T x={0} y={0} size={72} fill={C.cyan}>CUMA KOTAK KECIL</T></Pop>
      <Router t={t} x={540} y={930} s={1.0} mood={t >= pen ? 'tired' : 'happy'} ledRate={t >= ked ? 16 : 5} />
      {Array.from({ length: 16 }, (_, k) => {
        const st = tb + k * 0.1; const p = eo(prog(t, st, 0.9));
        const side = k % 2 === 0 ? -150 : 1230;
        const tx = 120 + hash(k + 3) * 840, ty = 1060 + hash(k + 40) * 260;
        const j = t >= reb ? (hash(Math.floor(t * 12) + k) - 0.5) * 24 : 0;
        return t < st ? null : <Person key={k} t={t} x={side + (tx - side) * p + j} y={ty} s={0.7} color={[C.pink, C.yellow, C.green, '#a78bfa'][k % 4]} seed={k} jump={t >= reb} />;
      })}
      {[100, 330, 560, 790, 1000].map((hx, k) => <House key={k} x={hx} y={1470 + (k % 2) * 20} s={0.75} color="#475569" />)}
      <Pop t={t} at={reb} x={540} y={420} s={1}><T x={0} y={0} size={110} fill={C.red}>REBUTAN!</T></Pop>
      <Pop t={t} at={pen} x={730} y={620}>
        <ellipse rx={230} ry={120} fill="#fff" stroke={C.ink} strokeWidth={6} />
        <circle cx={-170} cy={-40} r={34} fill={C.yellow} />
        <rect x={-116} y={-10} width={14} height={80} fill="#92400e" /><path d="M -109 -10 q -60 -30 -90 10 M -109 -10 q 60 -30 90 10 M -109 -10 q 0 -50 0 -64" stroke="#16a34a" strokeWidth={12} fill="none" strokeLinecap="round" />
        <T x={80} y={20} size={36} fill={C.ink} stroke="none" sw={0}>PENSIUN</T>
        <T x={80} y={66} size={36} fill={C.ink} stroke="none" sw={0}>DINI</T>
        <circle cx={-170} cy={150} r={14} fill="#fff" stroke={C.ink} strokeWidth={4} /><circle cx={-120} cy={190} r={8} fill="#fff" stroke={C.ink} strokeWidth={4} />
      </Pop>
    </g>
  );
};

const Sc11: React.FC<{ t: number }> = ({ t }) => {
  const b = cue(10, 'bukan'), am = cue(10, 'amal'), jar = cue(10, 'jariah'), dp = cue(10, 'dipaksa'), ro = cue(10, 'rodi'), ov = cue(10, 'overheat');
  const heat = prog(t, dp, ov - dp + 0.6);
  const sh = t >= ov ? shake(t, 16) : { x: 0, y: 0 };
  const swing = Math.sin(t * 5) * 10;
  return (
    <g transform={`translate(${sh.x} ${sh.y})`}>
      <Pop t={t} at={b} x={540} y={240}><T x={0} y={0} size={96} fill={C.red}>BUKAN WI-FI!</T></Pop>
      {t >= am && <ellipse cx={540} cy={560 + Math.sin(t * 3) * 8} rx={120} ry={26} fill="none" stroke={C.yellow} strokeWidth={14} />}
      <Pop t={t} at={am} x={540} y={330}><T x={0} y={0} size={72} fill={C.yellow}>AMAL JARIAH</T></Pop>
      {t >= ro && [-1, 1].map((sg) => (
        <g key={sg} stroke="#94a3b8" strokeWidth={10} fill="none">
          {Array.from({ length: 5 }, (_, k) => <ellipse key={k} cx={540 + sg * (300 + k * 40)} cy={1080 + k * 52 + swing * 0.3} rx={26} ry={16} transform={`rotate(${sg * 40} ${540 + sg * (300 + k * 40)} ${1080 + k * 52})`} />)}
        </g>))}
      {heat > 0.25 && Array.from({ length: 9 }, (_, k) => { const ph = (t * 0.8 + k / 9) % 1; return <circle key={k} cx={400 + hash(k) * 280} cy={900 - ph * 420} r={24 + ph * 40} fill="#e2e8f0" opacity={(1 - ph) * 0.55 * heat} />; })}
      <Router t={t} x={540} y={900} s={1.8} heat={heat} mood={t >= ov ? 'dead' : t >= dp ? 'panic' : 'tired'} ledRate={heat > 0.3 ? 22 : 6} />
      <Pop t={t} at={dp} x={160} y={560}><T x={0} y={0} size={46} fill={C.cyan}>DIPAKSA</T></Pop>
      <Pop t={t} at={ro} x={900} y={560}><T x={0} y={0} size={46} fill={C.pink}>KERJA RODI</T></Pop>
      <g transform="translate(930 1250)">
        <rect x={-30} y={-210} width={60} height={290} rx={30} fill="#0f172a" stroke="#fff" strokeWidth={6} />
        <rect x={-18} y={80 - 280 * heat} width={36} height={Math.max(8, 280 * heat)} rx={18} fill={mixHex(C.green, C.red, heat)} />
        <circle cy={96} r={44} fill={mixHex(C.green, C.red, heat)} stroke="#fff" strokeWidth={6} />
      </g>
      <Stamp t={t} at={ov} x={540} y={1280} text="OVERHEAT" color={C.red} size={110} rot={-6} />
    </g>
  );
};

const SCENES = [Sc1, Sc2, Sc3, Sc4, Sc5, Sc6, Sc7, Sc8, Sc9, Sc10, Sc11];

// ---------- teks karaoke (dari kata di timing.json) ----------
const Captions: React.FC<{ t: number }> = ({ t }) => {
  let si = -1;
  for (let i = 0; i < SENT.length; i++) if (t >= SENT[i].start - 0.05) si = i;
  if (si < 0) return null;
  const s = SENT[si]; if (t > s.end + 0.6) return null;
  let wi = 0;
  s.words.forEach((w, k) => { if (t >= w.start) wi = k; });
  // kelompokkan kata: maks ~22 huruf per baris
  const groups: number[][] = []; let cur: number[] = [], len = 0;
  s.words.forEach((w, k) => { if (len + w.w.length > 22 && cur.length) { groups.push(cur); cur = []; len = 0; } cur.push(k); len += w.w.length + 1; });
  if (cur.length) groups.push(cur);
  const g = groups.find((gr) => gr.includes(wi)) || groups[0];
  const chars = g.reduce((a, k) => a + s.words[k].w.length + 1, 0);
  const size = 66; const bw = Math.min(1000, chars * size * 0.62 + 70);
  return (
    <g>
      <rect x={540 - bw / 2} y={1560} width={bw} height={120} rx={30} fill="rgba(2,6,23,0.72)" />
      <text x={540} y={1642} fontSize={size} fontWeight={800} textAnchor="middle" style={{ fontFamily: FONT }}>
        {g.map((k) => <tspan key={k} fill={k === wi ? C.yellow : '#fff'}>{s.words[k].w + ' '}</tspan>)}
      </text>
    </g>
  );
};

// ---------- komponen inti ----------
export const Video: React.FC<{ t: number }> = ({ t }) => {
  let idx = 0;
  for (let i = 0; i < SENT.length; i++) if (t >= sceneWin(i).a) idx = i;
  const Sc = SCENES[idx];
  const { a, b } = sceneWin(idx);
  const fadeIn = clamp((t - a) / 0.18); const fadeOut = clamp((b - t) / 0.12);
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} xmlns="http://www.w3.org/2000/svg" style={{ display: 'block', background: C.navy }}>
      <Background t={t} idx={idx} />
      <g opacity={idx === 0 ? 1 : Math.min(fadeIn, idx === SENT.length - 1 ? 1 : fadeOut)}><Sc t={t} /></g>
      <rect x={30} y={30} width={300} height={64} rx={32} fill="rgba(0,0,0,0.45)" />
      <T x={60} y={75} size={30} anchor="start" fill={C.yellow} stroke="none" sw={0}>POV • WIFI GRATISAN</T>
      <rect x={0} y={H - 14} width={W * clamp(t / DUR)} height={14} fill={ACCENT[idx]} />
      <Captions t={t} />
    </svg>
  );
};
export default Video;
