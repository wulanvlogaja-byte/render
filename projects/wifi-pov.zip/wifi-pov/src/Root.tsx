import React from 'react';
import { AbsoluteFill, Audio, Composition, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Poppins';
import timing from './timing.json';
import { Video, W, H } from './Video';

// Font dimuat dari Google Fonts lewat paket resmi (di-bundle saat render, tidak butuh font lokal).
loadFont('normal', { weights: ['600', '800'], subsets: ['latin'] });

// Pembungkus Remotion: frame -> t (detik) -> komponen murni <Video t={t} />
const Wrapper: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  return (
    <AbsoluteFill>
      <Video t={t} />
      <Audio src={staticFile('narasi.mp3')} />
    </AbsoluteFill>
  );
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="WifiPOV"
    component={Wrapper}
    durationInFrames={timing.durationInFrames}
    fps={timing.fps}
    width={W}
    height={H}
  />
);
