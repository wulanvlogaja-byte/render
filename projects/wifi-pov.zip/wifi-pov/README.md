# wifi-pov — video POV "Lo jadi Wi-Fi tetangga" (Remotion)

9:16 · 1080x1920 · 30 fps · ±59 detik · narasi `public/narasi.mp3`

## Struktur
```
wifi-pov/
├─ public/narasi.mp3        audio narasi
├─ scripts/narasi.srt       sumber teks kalimat (timestamp SRT diabaikan)
├─ timing.cjs               ffmpeg silencedetect -> DP -> src/timing.json
├─ src/timing.json          durasi, fps, kalimat + waktu tiap kata
├─ src/Video.tsx            komponen murni Video({ t }) — semua animasi = f(t)
├─ src/Root.tsx             pembungkus Remotion (frame -> t) + <Audio>
├─ src/index.ts             registerRoot
├─ package.json             remotion 4.0.290 (pin), skrip "render"
└─ .github/workflows/       contoh workflow (opsional)
```

## Menjalankan di GitHub Actions
1. Commit folder `wifi-pov/` ke repo (jalankan `npm install` sekali lokal untuk membuat `package-lock.json`, lalu commit).
2. Actions -> **render-remotion** -> *Run workflow*.
3. Hasil: `out/wifi-pov.mp4` (artifact).

Perintah di runner: `npm ci` lalu `npm run render`.

## Mengganti audio/teks
Ganti `public/narasi.mp3` dan `scripts/narasi.srt`, lalu `node timing.cjs` (butuh ffmpeg) untuk membuat ulang `src/timing.json`.
Jika jumlah kalimat berubah, sesuaikan adegan di `src/Video.tsx` (cue memakai kata dari `timing.json`).
