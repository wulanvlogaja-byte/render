// Hitung timing narasi: ffmpeg silencedetect -> DP monoton -> src/timing.json
// Pakai: node timing.cjs [audio.mp3] [narasi.srt] [fps]
const { execFileSync, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const AUDIO = process.argv[2] || path.join(__dirname, 'public/narasi.mp3');
const SRT = process.argv[3] || path.join(__dirname, 'scripts/narasi.srt');
const FPS = Number(process.argv[4] || 30);

// 1. teks kalimat dari SRT (timestamp SRT diabaikan, hanya teks)
const sentences = fs.readFileSync(SRT, 'utf8').replace(/\r/g, '').trim().split(/\n\s*\n/)
  .map((b) => b.split('\n').slice(2).join(' ').trim()).filter(Boolean);

// 2. durasi + silencedetect
const dur = parseFloat(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration',
  '-of', 'default=nw=1:nk=1', AUDIO]).toString());
const r = spawnSync('ffmpeg', ['-hide_banner', '-i', AUDIO, '-af', 'silencedetect=noise=-35dB:d=0.25',
  '-f', 'null', '-'], { encoding: 'utf8' });
const sil = [];
for (const line of r.stderr.split(/\r|\n/)) {
  let m;
  if ((m = line.match(/silence_start: ([\d.]+)/))) sil.push({ s: +m[1], e: null });
  else if ((m = line.match(/silence_end: ([\d.]+)/)) && sil.length) sil[sil.length - 1].e = +m[1];
}
const gaps = sil.filter((g) => g.e !== null && g.s > 0.3 && g.e < dur - 0.1);
const speechStart = (sil[0] && sil[0].s < 0.05) ? sil[0].e : 0;
const lastSil = sil[sil.length - 1];
const speechEnd = (lastSil && lastSil.e === null) ? lastSil.s : dur;

// 3. bobot kata (perkiraan suku kata ~ huruf) + jeda tanda baca
const words = (t) => t.split(/\s+/).filter(Boolean);
const weight = (w) => Math.max(2, w.replace(/[^\p{L}\p{N}]/gu, '').length) + (/[.,?!]$/.test(w) ? 1.5 : 0);
const sw = sentences.map((s) => words(s).reduce((a, w) => a + weight(w), 0));

// 4. DP monoton: pilih N-1 gap sebagai batas kalimat, minimalkan deviasi laju bicara
const N = sentences.length, M = gaps.length;
if (M < N - 1) throw new Error(`Gap terdeteksi (${M}) kurang dari batas kalimat (${N - 1})`);
const gapTotalIn = (a, b) => gaps.filter((g) => g.s >= a && g.e <= b).reduce((x, g) => x + (g.e - g.s), 0);
const globalRate = sw.reduce((a, b) => a + b, 0) / (speechEnd - speechStart - gapTotalIn(speechStart, speechEnd));
// kalimat i membentang dari start (akhir gap j-1 / speechStart) sampai awal gap j / speechEnd
const segCost = (i, a, b) => {
  const speech = (b - a) - gapTotalIn(a, b);
  if (speech <= 0.2) return 1e9;
  const rate = sw[i] / speech;
  return Math.pow(Math.log(rate / globalRate), 2);
};
const INF = 1e18;
// dp[i][j]: kalimat i berakhir di gap j (i<N-1), j=-1 untuk awal
const dp = Array.from({ length: N }, () => new Array(M).fill(INF));
const bk = Array.from({ length: N }, () => new Array(M).fill(-1));
for (let j = 0; j < M; j++) dp[0][j] = segCost(0, speechStart, gaps[j].s);
for (let i = 1; i < N - 1; i++)
  for (let j = i; j < M; j++)
    for (let k = i - 1; k < j; k++) {
      if (dp[i - 1][k] >= INF) continue;
      const c = dp[i - 1][k] + segCost(i, gaps[k].e, gaps[j].s);
      if (c < dp[i][j]) { dp[i][j] = c; bk[i][j] = k; }
    }
let best = INF, bj = -1;
for (let j = N - 2; j < M; j++) {
  if (dp[N - 2][j] >= INF) continue;
  const c = dp[N - 2][j] + segCost(N - 1, gaps[j].e, speechEnd);
  if (c < best) { best = c; bj = j; }
}
if (bj < 0) throw new Error('DP gagal');
const cut = new Array(N - 1);
for (let i = N - 2, j = bj; i >= 0; i--) { cut[i] = j; j = bk[i][j]; }

// 5. waktu per kata: bagi waktu bicara (tanpa jeda internal) sesuai bobot
const out = [];
for (let i = 0; i < N; i++) {
  const a = i === 0 ? speechStart : gaps[cut[i - 1]].e;
  const b = i === N - 1 ? speechEnd : gaps[cut[i]].s;
  const inner = gaps.filter((g) => g.s >= a && g.e <= b);
  const speech = (b - a) - inner.reduce((x, g) => x + (g.e - g.s), 0);
  const toReal = (u) => { // u = detik "bicara" sejak a -> detik nyata
    let t = a + u;
    for (const g of inner) if (t >= g.s) t += g.e - g.s;
    return t;
  };
  const ws = words(sentences[i]);
  const tot = ws.reduce((x, w) => x + weight(w), 0);
  let acc = 0;
  const wl = ws.map((w) => {
    const s0 = acc / tot * speech; acc += weight(w); const s1 = acc / tot * speech;
    return { w, start: +toReal(s0).toFixed(3), end: +toReal(s1 - 1e-6).toFixed(3) };
  });
  const rate = (tot / speech);
  out.push({ i, text: sentences[i], start: +a.toFixed(3), end: +b.toFixed(3), words: wl,
    rateRel: +(rate / globalRate).toFixed(2) });
}
const bad = out.filter((s) => s.rateRel < 0.6 || s.rateRel > 1.6);
if (bad.length) console.warn('PERINGATAN laju bicara janggal pada kalimat:', bad.map((s) => s.i + 1).join(','));

const durationInFrames = Math.ceil((dur + 0.5) * FPS);
fs.writeFileSync(path.join(__dirname, 'src/timing.json'), JSON.stringify({
  duration: +dur.toFixed(3), fps: FPS, durationInFrames, sentences: out,
}, null, 1));
console.log(`OK: ${N} kalimat, ${dur.toFixed(2)}s, ${durationInFrames} frame`);
out.forEach((s) => console.log(String(s.i + 1).padStart(2), s.start.toFixed(2), s.end.toFixed(2), 'rel', s.rateRel, s.text.slice(0, 40)));
