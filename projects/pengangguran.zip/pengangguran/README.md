# pengangguran (video Remotion paper-cut, 9:16, 30 fps)

POV Pengangguran tapi Duit Banyak. Durasi narasi 83,07 detik, 1080x1920, 30 fps, 18 kalimat, 15 adegan.

## Struktur
- `public/narasi.mp3` audio narasi
- `narasi.txt` satu kalimat per baris (dari SRT, tag [CTA] dibuang karena tidak diucapkan)
- `timing.cjs` hitung timing dari audio (ffprobe + silencedetect + DP) -> `src/timing.json`
- `src/theme.ts` semua warna dan ukuran (satu-satunya tempat hex)
- `src/helpers.ts` easing dan `cue(kalimat, kata)` (waktu diambil dari kata di timing.json)
- `src/parts.tsx` komponen kertas (karakter, laptop, pita, awan, grafik, dll.)
- `src/scenesA.tsx`, `src/scenesB.tsx` 15 adegan; `src/Video.tsx` komposisi `Video({ t })`
- `src/Root.tsx` pembungkus Remotion (Composition `Pengangguran`, `<Audio>`), `src/index.ts`

## Job di GitHub Actions (workflow_dispatch)
1. checkout
2. setup-node (Node 20 atau 22)
3. `npm install` (tidak ada lockfile, jadi jangan `npm ci`)
4. `npm run render` (hasil: `out/video.mp4`)
5. upload-artifact `out/video.mp4`

Semua paket `remotion` dan `@remotion/*` harus satu versi. Versi di sini `4.0.250` (asumsi, samakan dengan repo).

## Membuat ulang timing
`FPS=30 W=1080 H=1920 node timing.cjs` (butuh ffmpeg/ffprobe). Ganti mp3 dan `narasi.txt`, lalu sesuaikan kata cue di adegan bila teks berubah (cue yang tidak ketemu akan error dengan pesan jelas).

## Catatan
- Font: Fredoka 700 lewat `@remotion/google-fonts/Fredoka`.
- Nama komposisi `Pengangguran` harus sama dengan yang dipakai skrip render.
