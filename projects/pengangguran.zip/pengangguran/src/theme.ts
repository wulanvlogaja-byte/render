// Semua warna dan ukuran didefinisikan SATU kali di sini.
// 1 dasar terang + 4 aksen (biru, teal, kuning, merah) + tint terangnya + netral.
export const theme = {
  font: "'Fredoka', 'Baloo 2', 'Trebuchet MS', sans-serif",
  c: {
    bg: '#F7FAFC',
    sky: '#EAF6FF',
    ink: '#1B2A3A',
    inkSoft: '#4A5A6A',
    white: '#FFFFFF',
    // aksen
    blue: '#2D9CDB',
    teal: '#00BFA6',
    yellow: '#FFC93C',
    red: '#FF5D5D',
    // tint
    blue1: '#CDEEFB',
    blue2: '#9BD3F2',
    blue3: '#5DB6E8',
    teal1: '#C9F4EC',
    teal2: '#8EE3D3',
    yellow1: '#FFF3CC',
    yellow2: '#FFE08A',
    red1: '#FFDADA',
    red2: '#FFB3B3',
    // netral
    skin: '#FFD9B8',
    skin2: '#F2B98F',
    gray1: '#E6ECF1',
    gray2: '#C9D3DC',
    gray3: '#9FB0BF',
  },
  shadow: { dy: 3.5, std: 2.6, opacity: 0.28 },
  view: { w: 360, h: 640 },
  tr: 0.55, // durasi transisi antar adegan (detik)
  endPad: 1.2, // jeda setelah narasi selesai (detik)
  caption: {
    fontPx: 54,
    padPx: 34,
    bottomPx: 70,
    sidePx: 56,
  },
} as const;
export type Theme = typeof theme;
