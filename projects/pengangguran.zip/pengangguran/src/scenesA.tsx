import React from 'react';
import { theme } from './theme';
import { cue, cueEnd, sStart, sEnd, enter, pop, bump, sw, lerp, clamp, easeInOut, easeOut } from './helpers';
import { Backdrop, Person, Laptop, Desk, Coin, Bubble, Pill, Clock, CandleChart, Heartbeat, Heart, Wifi, House, Bed, Building, Card, P, Txt } from './parts';

const c = theme.c;
export type SceneProps = { t: number };

/* ---------- 0: judul + tetangga + emak (kalimat 0-1) ---------- */
export const Sc0: React.FC<SceneProps> = ({ t }) => {
  const tB = cue(0, 'banyak'), tN = cue(1, 'tetangga'), tE = cue(1, 'emak'), tPs = cue(1, 'pesugihan'), tGj = cue(1, 'ginjal');
  const nx = (1 - enter(t, tN, 0.6)) * -130, ex = (1 - enter(t, tE, 0.6)) * 130;
  return (
    <Backdrop t={t} v="blue" seed={0}>
      <Card x={180} y={92} w={318} h={98} sc={pop(t, 0.1)}>
        <Txt x={0} y={-6} s={25}>POV: PENGANGGURAN</Txt>
        <rect x={-118} y={6} width={236} height={30} rx={15} fill={c.yellow} />
        <Txt x={0} y={29} s={22}>TAPI DUIT BANYAK</Txt>
      </Card>
      <Person t={t} x={180} y={422} s={1.15} armL={48} armR={48} mood={1} shirt={c.blue} hat={false} />
      <Desk x={180} y={384} w={176} />
      <Laptop x={180} y={384} s={0.7} />
      {[0, 1, 2, 3].map(i => {
        const k = clamp((t - (tB + i * 0.18)) / 1.4);
        if (k <= 0 || k >= 1) return null;
        return <Coin key={i} x={140 + i * 27 + sw(t, 5, 1.2, i)} y={350 - easeOut(k) * 150} r={12} rot={sw(t, 18, 1, i)} o={Math.min(1, (1 - k) * 2.2)} />;
      })}
      <Person t={t} x={50 + nx} y={442} s={0.92} armR={40} armL={10} mood={3} shirt={c.teal} seed={1} />
      <Person t={t} x={312 + ex} y={442} s={0.92} armL={40} armR={10} mood={3} shirt={c.yellow} hair={c.gray3} flip seed={2} />
      <Bubble x={70} y={286} w={118} lines={['Pesugihan?!']} sc={pop(t, tPs)} tail="d" fill={c.red1} />
      <Bubble x={286} y={286} w={124} lines={['Jual ginjal?!']} sc={pop(t, tGj)} tail="d" fill={c.red1} />
    </Backdrop>
  );
};

/* ---------- 1: candle merah hijau + detak jantung (kalimat 2) ---------- */
export const Sc1: React.FC<SceneProps> = ({ t }) => {
  const tD = cue(2, 'dua'), tM = cue(2, 'merah'), tH = cue(2, 'hijau'), tHb = cue(2, 'detak'), tC = cue(2, 'candle');
  return (
    <Backdrop t={t} v="teal" seed={1}>
      <Card x={180} y={200} w={312} h={196} sc={enter(t, sStart(2) + 0.1, 0.5)}>
        {[0, 1, 2, 3].map(i => <rect key={i} x={-140} y={-70 + i * 40} width={280} height={2} rx={1} fill={c.gray1} />)}
      </Card>
      <CandleChart t={t} x={40} y={128} w={280} h={140} n={13} speed={2.2} />
      <Pill x={95} y={92} w={118} text="12 JAM" fill={c.blue1} fs={20} sc={pop(t, tD)} />
      <Pill x={110} y={330} w={110} text="MERAH" fill={c.red1} fs={18} sc={pop(t, tM)} rot={-3} />
      <Pill x={250} y={330} w={110} text="HIJAU" fill={c.teal1} fs={18} sc={pop(t, tH)} rot={3} />
      <g opacity={enter(t, tHb, 0.4)}><Heartbeat t={t} x={78} y={385} w={190} amp={22} /></g>
      <Heart x={44} y={385} s={1 + 0.25 * bump(t, tHb, 0.5) + 0.12 * Math.max(0, Math.sin(t * 7)) * (t > tHb ? 1 : 0)} />
      <Person t={t} x={318} y={452} s={0.85} mood={3} flip armL={10} armR={10} shirt={c.yellow} />
    </Backdrop>
  );
};

/* ---------- 2: bangun jam sebelas, market London buka (kalimat 3) ---------- */
export const Sc2: React.FC<SceneProps> = ({ t }) => {
  const tB = cue(3, 'bangun'), tJ = cue(3, 'jam'), tS = cue(3, 'sebelas'), tL = cue(3, 'london'), tBk = cue(3, 'buka');
  const kw = easeInOut((t - tB) / 0.9);
  const kc = easeInOut((t - tJ) / (tS - tJ + 0.5));
  const sun = enter(t, sStart(3), 1);
  return (
    <Backdrop t={t} v="yellow" seed={2}>
      <P tf={`translate(300 ${150 - 40 * (1 - sun)})`} o={sun}>
        <circle r={44} fill={c.yellow1} /><circle r={32} fill={c.yellow2} /><circle r={21} fill={c.yellow} />
      </P>
      <Clock x={120} y={150} r={54} hour={lerp(7, 11, kc)} min={sw(t, 1.5, 0.5)} sc={pop(t, tJ - 0.2)} />
      <Pill x={120} y={236} w={110} text="JAM 11" fill={c.yellow2} fs={22} sc={pop(t, tS)} />
      <Bed x={92} y={430} />
      <Person t={t} x={lerp(128, 200, kw)} y={lerp(392, 432, kw)} rot={-90 * (1 - kw)} mood={kw < 0.5 ? 0 : 3} armL={lerp(5, 120, bump(t, tB + 0.3, 1))} armR={lerp(5, 120, bump(t, tB + 0.3, 1))} shirt={c.teal} />
      {t < tB && <Txt x={110 + sw(t, 4, 0.6)} y={350 - (t * 12) % 30} s={26} fill={c.inkSoft}>Zzz</Txt>}
      <Building x={296} y={430} s={0.95} col={c.blue2} />
      <Pill x={296} y={302} w={118} text="LONDON" fill={c.blue1} fs={20} sc={pop(t, tL)} rot={-3} />
      <Pill x={296} y={268} w={92} text="BUKA!" fill={c.teal1} fs={20} sc={pop(t, tBk)} rot={3} />
    </Backdrop>
  );
};

/* ---------- 3: KRL desak-desakan (kalimat 4) ---------- */
export const Sc3: React.FC<SceneProps> = ({ t }) => {
  const tT = cue(4, 'teman'), tK = cue(4, 'krl'), tD = cue(4, 'desakdesekan');
  const x = (1 - enter(t, tT - 0.1, 0.9)) * 420;
  const bob = sw(t, 1.6, 2.2);
  const heads = [0, 1, 2, 3];
  return (
    <Backdrop t={t} v="blue" seed={3}>
      <P tf={`translate(${x} ${bob + 34})`}>
        <rect x={20} y={236} width={320} height={150} rx={20} fill={c.blue} />
        <rect x={20} y={338} width={320} height={14} fill={c.yellow} />
        {heads.map(i => {
          const wx = 34 + i * 76;
          return (
            <g key={i}>
              <rect x={wx} y={256} width={62} height={72} rx={9} fill={c.blue1} />
              {[0, 1].map(j => {
                const hx = wx + 20 + j * 22 + sw(t, 2.2, 2.4, i + j);
                const hy = 304 + (j % 2) * 3;
                return (
                  <g key={j}>
                    <circle cx={hx} cy={hy} r={15} fill={c.skin} />
                    <path d={`M${hx - 15} ${hy - 2} a15 15 0 0 1 30 0 q-8 -8 -15 -6 q-8 -2 -15 6z`} fill={j ? c.ink : c.gray3} />
                    <circle cx={hx - 5} cy={hy + 2} r={1.8} fill={c.ink} /><circle cx={hx + 5} cy={hy + 2} r={1.8} fill={c.ink} />
                    <path d={`M${hx - 4} ${hy + 10} q4 -4 8 0`} stroke={c.ink} strokeWidth={1.8} fill="none" strokeLinecap="round" />
                  </g>
                );
              })}
            </g>
          );
        })}
        {[70, 150, 250, 310].map(wx => <circle key={wx} cx={wx} cy={388} r={14} fill={c.gray2} />)}
      </P>
      <Pill x={180} y={236} w={90} text="KRL" fill={c.yellow} fs={26} sc={pop(t, tK)} rot={-3} />
      <Pill x={180} y={188} w={226} text="DESAK-DESAKAN" fill={c.red1} fs={21} sc={pop(t, tD)} rot={2} />
    </Backdrop>
  );
};

/* ---------- 4: geser dari kasur ke meja, kopi sachet, Wi-Fi tetangga (kalimat 5) ---------- */
export const Sc4: React.FC<SceneProps> = ({ t }) => {
  const tG = cue(5, 'geser'), tM = cueEnd(5, 'meja'), tKp = cue(5, 'kopi'), tWf = cue(5, 'wifi'), tSd = cue(5, 'sadap');
  const k = easeInOut((t - tG) / (tM - tG));
  const px = lerp(95, 205, k), hop = 38 * Math.sin(Math.PI * k);
  return (
    <Backdrop t={t} v="teal" seed={4}>
      <Bed x={80} y={430} />
      <path d="M95 345 Q150 262 205 345" fill="none" stroke={c.blue} strokeWidth={4} strokeLinecap="round" pathLength={100} strokeDasharray={`${k * 100} 100`} opacity={0.8 * Math.min(1, k * 6)} />
      <Person t={t} x={px} y={432 - hop} rot={sw(t, 3, 1.2) * (k > 0 && k < 1 ? 1 : 0)} mood={k > 0.95 ? 1 : 3} armL={k > 0.95 ? 70 : 20} armR={k > 0.95 ? 70 : 20} shirt={c.blue} />
      <House x={318} y={262} s={0.8} />
      <Desk x={285} y={384} w={118} />
      <Laptop x={292} y={384} s={0.75} />
      <Wifi t={t} x={300} y={322} s={0.9} o={enter(t, tWf, 0.3)} />
      <Pill x={225} y={205} w={158} text="WI-FI TETANGGA" fill={c.teal1} fs={17} sc={pop(t, tWf)} rot={-3} />
      <Pill x={282} y={160} w={104} text="SADAP!" fill={c.red1} fs={20} sc={pop(t, tSd)} rot={5} />
      <P tf={`translate(${252} ${372 - 8 * (1 - enter(t, tKp, 0.4))})`} o={enter(t, tKp, 0.3)}>
        <rect x={-9} y={-24} width={18} height={26} rx={3} fill={c.yellow2} />
        <rect x={-9} y={-24} width={18} height={6} fill={c.yellow} />
      </P>
      <Pill x={110} y={250} w={156} text="KOPI SACHET" fill={c.yellow2} fs={18} sc={pop(t, tKp)} rot={-4} />
    </Backdrop>
  );
};

/* ---------- 5: miskin? lalu saldo lebih tebal dari skripsi (kalimat 6-7) ---------- */
export const Sc5: React.FC<SceneProps> = ({ t }) => {
  const t7 = sStart(7), tMk = cue(6, 'miskin'), tSl = cue(7, 'saldo'), tTb = cue(7, 'tebal'), tSk = cue(7, 'skripsi');
  const ex = enter(t, t7, 0.5);
  const grow = clamp((t - tSl) / (tTb - tSl + 0.9));
  const layers = Math.floor(easeOut(grow) * 9);
  return (
    <Backdrop t={t} v="yellow" seed={5}>
      <P tf={`translate(180 ${300 + 220 * ex})`} o={1 - ex}>
        <rect x={-62} y={-34} width={124} height={68} rx={14} fill={c.yellow2} />
        <rect x={-62} y={-34} width={124} height={22} rx={10} fill={c.yellow} />
        <circle cx={34} cy={6} r={9} fill={c.white} />
      </P>
      <Pill x={180} y={196} w={170} text="MISKIN?" fill={c.red1} fs={30} sc={pop(t, tMk) * (1 - ex)} rot={-4} />
      <Person t={t} x={lerp(80, 180, ex)} y={448} s={0.95} mood={ex < 0.5 ? 2 : 1} armR={ex < 0.5 ? 15 : 110} armL={15} shirt={c.blue} />
      <g opacity={ex}>
        <P tf={`translate(100 ${430 + 40 * (1 - ex)})`}>
          <rect x={-46} y={-16} width={92} height={16} rx={3} fill={c.blue} />
          <rect x={-42} y={-32} width={86} height={16} rx={3} fill={c.teal} />
          <Txt x={0} y={-4} s={12} fill={c.ink}>SKRIPSI</Txt>
        </P>
      </g>
      <Pill x={100} y={352} w={110} text="SKRIPSI" fill={c.blue1} fs={17} sc={pop(t, tSk)} />
      <P tf={`translate(262 430)`} o={ex}>
        {Array.from({ length: 9 }, (_, i) => i < layers ? <rect key={i} x={-48 + (i % 2) * 4} y={-14 - i * 14} width={92} height={13} rx={3} fill={i % 2 ? c.teal2 : c.teal} /> : null)}
      </P>
      <Pill x={262} y={Math.max(250, 410 - layers * 14 - 20)} w={104} text="SALDO" fill={c.teal1} fs={19} sc={pop(t, tSl)} />
    </Backdrop>
  );
};

/* ---------- 6: bukan hoki, MC tujuh kali (kalimat 8) ---------- */
export const Sc6: React.FC<SceneProps> = ({ t }) => {
  const tHk = cue(8, 'hoki'), tMc = cue(8, 'mc'), tTj = cue(8, 'tujuh'), tEnd = sEnd(8);
  const xs = [45, 135, 225, 315, 90, 180, 270], ys = [228, 228, 228, 228, 296, 296, 296];
  const dt = (tEnd - 0.6 - tMc) / 7;
  return (
    <Backdrop t={t} v="red" seed={6}>
      <P tf={`translate(180 ${128 + sw(t, 3, 0.8)}) rotate(${sw(t, 8, 0.5)})`}>
        <rect x={-38} y={-38} width={76} height={76} rx={14} fill={c.white} />
        {[[-16, -16], [16, 16], [0, 0], [-16, 16], [16, -16]].map(([a, b], i) => <circle key={i} cx={a} cy={b} r={5.5} fill={c.ink} />)}
      </P>
      <g opacity={enter(t, tHk, 0.3)}>
        <rect x={-6} y={-50 * enter(t, tHk, 0.3)} width={12} height={100 * enter(t, tHk, 0.3)} rx={6} fill={c.red} transform="translate(180 128) rotate(45)" />
        <rect x={-6} y={-50 * enter(t, tHk, 0.3)} width={12} height={100 * enter(t, tHk, 0.3)} rx={6} fill={c.red} transform="translate(180 128) rotate(-45)" />
      </g>
      {xs.map((x, i) => <circle key={'r' + i} cx={x} cy={ys[i]} r={27} fill={c.white} stroke={c.red2} strokeWidth={4} strokeDasharray="6 6" opacity={enter(t, sStart(8) + 0.1, 0.4)} />)}
      {xs.map((x, i) => {
        const s0 = pop(t, tMc + i * dt, 0.35);
        return s0 > 0 ? (
          <P key={i} tf={`translate(${x} ${ys[i]}) scale(${s0})`}>
            <circle r={27} fill={c.red} /><circle r={19} fill={c.red1} />
            <Txt x={0} y={7} s={19}>MC</Txt>
          </P>
        ) : null;
      })}
      <Pill x={236} y={392} w={190} text="7x MARGIN CALL" fill={c.yellow2} fs={19} sc={pop(t, tTj)} rot={-3} />
      <Person t={t} x={62} y={452} s={0.95} mood={2} armL={25} armR={25} shirt={c.blue} />
    </Backdrop>
  );
};

/* ---------- 7: nangis lihat portofolio minus 80% (kalimat 9) ---------- */
export const Sc7: React.FC<SceneProps> = ({ t }) => {
  const tNg = cue(9, 'nangis'), tPf = cue(9, 'portofolio'), tMn = cue(9, 'minus'), tPr = cue(9, 'persen');
  const k = enter(t, tPf, 1.3);
  const pts = Array.from({ length: 21 }, (_, i) => {
    const u = i / 20, px = 40 + u * 280, py = 120 + u * 120 + Math.sin(i * 1.7) * 12;
    return [px, py] as const;
  });
  const n = Math.max(2, Math.floor(k * pts.length));
  const line = pts.slice(0, n).map(p => p.join(',')).join(' ');
  const area = `${pts[0][0]},262 ${line} ${pts[n - 1][0]},262`;
  return (
    <Backdrop t={t} v="red" seed={7}>
      <Card x={180} y={186} w={312} h={190} sc={enter(t, sStart(9) + 0.05, 0.5)} />
      <polygon points={area} fill={c.red1} />
      <polyline points={line} fill="none" stroke={c.red} strokeWidth={6} strokeLinejoin="round" strokeLinecap="round" />
      <Pill x={110} y={106} w={150} text="PORTOFOLIO" fill={c.blue1} fs={17} sc={pop(t, tPf)} />
      <Pill x={244} y={150} w={150} text="-80%" fill={c.red} fs={38} sc={pop(t, tMn)} rot={-6} />
      <Person t={t} x={180} y={456} s={1.2} mood={2} tears={t > tNg} armL={30} armR={30} shirt={c.teal} />
    </Backdrop>
  );
};
