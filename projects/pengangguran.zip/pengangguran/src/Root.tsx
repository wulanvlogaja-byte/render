import React from 'react';
import { AbsoluteFill, Audio, Composition, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import { Video } from './Video';
import { timing } from './helpers';
import { theme } from './theme';

loadFont('normal', { weights: ['700'] });

const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  return (
    <AbsoluteFill style={{ background: theme.c.bg }}>
      <Video t={t} />
      <Audio src={staticFile('narasi.mp3')} />
    </AbsoluteFill>
  );
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Pengangguran"
    component={Main}
    durationInFrames={Math.ceil((timing.duration + theme.endPad) * timing.fps)}
    fps={timing.fps}
    width={timing.width}
    height={timing.height}
  />
);
