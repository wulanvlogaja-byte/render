import React from 'react';
import { theme } from './theme';
import { cue, sStart, sEnd, enter, pop, bump, sw, lerp, clamp, easeInOut, easeOut, hash, wrap } from './helpers';
import { Backdrop, Person, Laptop, Desk, Coin, Bubble, Pill, Building, Eye, Thumb, Bell, Card, Swirl, P, Txt } from './parts';
import type { SceneProps } from './scenesA';

const c = theme.c;

/* ---------- 8: dikira gila sama keluarga (kalimat 10) ---------- */
export const Sc8: React.FC<SceneProps> = ({ t }) => {
  const tGl = cue(10, 'gila'), tKl = cue(10, 'keluarga'), tKt = cue(10, 'kantoran');
  const fam = enter(t, cue(10, 'dikira'), 0.6);
  const xk = enter(t, tKt, 0.4);
  return (
    <Backdrop t={t} v="blue" seed={8}>
      <Building x={296} y={250} s={0.95} col={c.blue2} />
      <g opacity={xk}>
        <rect x={-7} y={-62 * xk} width={14} height={124 * xk} rx={7} fill={c.red} transform="translate(296 196) rotate(45)" />
        <rect x={-7} y={-62 * xk} width={124 * 0 + 14} height={124 * xk} rx={7} fill={c.red} transform="translate(296 196) rotate(-45)" />
      </g>
      <Pill x={296} y={282} w={112} text="KANTORAN" fill={c.yellow2} fs={17} sc={pop(t, tKt)} />
      <Person t={t} x={46 - 120 * (1 - fam)} y={444} s={0.95} armR={95} armL={10} mood={3} shirt={c.teal} seed={1} />
      <Person t={t} x={108 - 120 * (1 - fam)} y={444} s={0.9} armR={100} armL={10} mood={3} shirt={c.yellow} hair={c.gray3} seed={2} />
      <Person t={t} x={158 - 120 * (1 - fam)} y={444} s={0.68} armR={100} armL={10} mood={3} shirt={c.red} seed={3} />
      {t > tGl && [46, 108].map((sx, i) => <Swirl key={i} t={t} x={sx - 8} y={338 + i * 2} s={0.55} />)}
      <Bubble x={100} y={250} w={120} lines={['GILA!']} fs={26} sc={pop(t, tGl)} tail="d" fill={c.red1} />
      <Desk x={290} y={392} w={110} />
      <Person t={t} x={290} y={430} s={1} armL={50} armR={50} mood={1} shirt={c.blue} seed={4} />
      <Desk x={290} y={392} w={110} />
      <Laptop x={290} y={392} s={0.62} />
    </Backdrop>
  );
};

/* ---------- 9: jelasin atau misterius (kalimat 11) ---------- */
export const Sc9: React.FC<SceneProps> = ({ t }) => {
  const tBr = cue(11, 'bro'), tTg = cue(11, 'tetangga'), tPs = cue(11, 'pesugihan'), tJl = cue(11, 'jelasin'), tAt = cue(11, 'atau'), tMs = cue(11, 'misterius');
  const p1 = 1 + 0.03 * Math.sin((t - tJl) * 5) * (t > tJl ? 1 : 0);
  const p2 = 1 + 0.03 * Math.sin((t - tMs) * 5) * (t > tMs ? 1 : 0);
  return (
    <Backdrop t={t} v="yellow" seed={9}>
      <Card x={180} y={118} w={290} h={74} fill={c.blue1} sc={pop(t, sStart(11) + 0.3) * p1}><Txt x={0} y={11} s={34}>JELASIN</Txt></Card>
      <Txt x={180} y={188} s={22} o={enter(t, sStart(11) + 0.6, 0.3)}>ATAU</Txt>
      <Card x={180} y={256} w={290} h={96} fill={c.yellow2} sc={pop(t, sStart(11) + 0.5) * p2}>
        <Txt x={0} y={-4} s={30}>BIARIN SAJA</Txt>
        <Txt x={0} y={30} s={30}>MISTERIUS</Txt>
      </Card>
      <Person t={t} x={58 - 100 * (1 - enter(t, tTg, 0.6))} y={448} s={0.9} armR={55} mood={3} shirt={c.teal} seed={1} />
      <Bubble x={86} y={346} w={124} lines={['Pesugihan?!']} sc={pop(t, tPs)} tail="d" fill={c.red1} fs={16} />
      <Person t={t} x={262} y={452} s={1.1} mood={3} armL={10} armR={90} shirt={c.blue} seed={2} />
      <Bubble x={286} y={326} w={64} lines={['Bro?']} sc={pop(t, tBr)} tail="d" fs={20} />
    </Backdrop>
  );
};

/* ---------- 10: like, subscribe, algoritma (kalimat 12) ---------- */
export const Sc10: React.FC<SceneProps> = ({ t }) => {
  const tLk = cue(12, 'like'), tSb = cue(12, 'subscribe'), tAl = cue(12, 'algoritma'), tTm = cue(12, 'tim'), tCn = cue(12, 'cuan');
  const ring = t > tSb ? sw(t, 16, 2.4) * Math.exp(-(t - tSb) * 0.5) : 0;
  const gear = pop(t, tAl);
  return (
    <Backdrop t={t} v="red" seed={10}>
      <Thumb x={86} y={176} s={1.45 * pop(t, tLk)} rot={-8 + sw(t, 4, 1)} />
      <Pill x={242} y={150} w={186} text="SUBSCRIBE" fill={c.red} fs={26} sc={pop(t, tSb)} rot={3} />
      <Bell x={306} y={236} s={1.1 * pop(t, tSb + 0.2)} rot={ring} />
      <P tf={`translate(66 286) rotate(${t * 60}) scale(${gear})`}>
        <circle r={22} fill={c.blue} />
        {Array.from({ length: 8 }, (_, i) => <rect key={i} x={-5} y={-31} width={10} height={14} rx={3} fill={c.blue} transform={`rotate(${i * 45})`} />)}
        <circle r={9} fill={c.blue1} />
      </P>
      <Pill x={196} y={286} w={176} text="ALGORITMA" fill={c.blue1} fs={21} sc={pop(t, tAl + 0.1)} />
      <Pill x={180} y={330} w={316} text="TIM PENGANGGURAN CUAN" fill={c.teal1} fs={21} sc={pop(t, tTm)} rot={-2} />
      {[0, 1, 2].map(i => {
        const k = clamp((t - (tCn + i * 0.12)) / 1.2);
        return k > 0 && k < 1 ? <Coin key={i} x={[34, 326, 52][i]} y={340 - easeOut(k) * 120} r={13} rot={k * 200} o={Math.min(1, (1 - k) * 2)} /> : null;
      })}
      <Person t={t} x={180} y={464} s={1.0} mood={1} armL={150} armR={150 + sw(t, 10, 2)} shirt={c.yellow} />
    </Backdrop>
  );
};

/* ---------- 11: rahasia cuma satu, enggak rugi hari ini (kalimat 13-14) ---------- */
export const Sc11: React.FC<SceneProps> = ({ t }) => {
  const t14 = sStart(14), tRh = cue(13, 'rahasia'), tSt = cue(13, 'satu'), tSh = cue(13, 'sehari'), tDt = cue(13, 'duit'), tRg = cue(14, 'rugi'), tHr = cue(14, 'hari');
  const sw14 = enter(t, t14, 0.55);
  const one = enter(t, tSt, 0.3);
  return (
    <Backdrop t={t} v="blue" seed={11}>
      <g opacity={1 - sw14} transform={`translate(${-200 * sw14} 0)`}>
        <P tf={`translate(180 ${222 + sw(t, 3, 0.8)}) scale(${pop(t, Math.min(tRh, sStart(13) + 0.1))})`}>
          <path d="M-34 -40 v-26 a34 34 0 0 1 68 0 v26" fill="none" stroke={c.gray3} strokeWidth={13} strokeLinecap="round" />
          <rect x={-58} y={-44} width={116} height={92} rx={16} fill={c.yellow} />
          <rect x={-58} y={-44} width={116} height={20} rx={10} fill={c.yellow2} />
          <Txt x={0} y={30} s={62} o={one}>1</Txt>
          <circle cx={0} cy={0} r={9} fill={c.ink} opacity={1 - one} />
        </P>
        <P tf={`translate(100 ${352 + 160 * 0}) scale(${pop(t, tDt)})`}>
          <rect x={-48} y={-38} width={96} height={76} rx={10} fill={c.white} />
          <rect x={-48} y={-38} width={96} height={22} rx={10} fill={c.red} />
          <Txt x={0} y={20} s={22}>1 HARI</Txt>
        </P>
        <Coin x={236} y={338} r={16} o={enter(t, tDt, 0.3)} /><Coin x={266} y={356} r={16} o={enter(t, tDt, 0.3)} />
        <g opacity={enter(t, tSh, 0.3)}>
          <rect x={-8} y={-60 * enter(t, tSh, 0.3)} width={16} height={120 * enter(t, tSh, 0.3)} rx={8} fill={c.red} transform="translate(180 350) rotate(60)" />
          <rect x={-8} y={-60 * enter(t, tSh, 0.3)} width={16} height={120 * enter(t, tSh, 0.3)} rx={8} fill={c.red} transform="translate(180 350) rotate(-60)" />
        </g>
      </g>
      <g opacity={sw14} transform={`translate(${200 * (1 - sw14)} 0)`}>
        <P tf={`translate(180 ${214 + sw(t, 3, 0.8)}) scale(${pop(t, t14 + 0.1)})`}>
          <path d="M0 -76 L62 -54 V4 Q62 56 0 82 Q-62 56 -62 4 V-54 Z" fill={c.white} />
          <path d="M0 -62 L50 -45 V4 Q50 46 0 68 Q-50 46 -50 4 V-45 Z" fill={c.blue1} />
          <polyline points="-24,4 -6,24 28,-18" fill="none" stroke={c.teal} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" />
        </P>
        <Pill x={180} y={332} w={252} text="ENGGAK RUGI" fill={c.teal1} fs={26} sc={pop(t, tRg)} rot={-2} />
        <Pill x={170} y={382} w={170} text="HARI INI" fill={c.yellow2} fs={22} sc={pop(t, tHr)} rot={2} />
      </g>
      <Person t={t} x={318} y={456} s={1} mood={1} flip armL={10} armR={sw14 > 0.5 ? 100 : 15} shirt={c.teal} />
    </Backdrop>
  );
};

/* ---------- 12: roket kaya cepat vs kura-kura hidup lama (kalimat 15) ---------- */
export const Sc12: React.FC<SceneProps> = ({ t }) => {
  const tKy = cue(15, 'kaya'), tCp = cue(15, 'cepat'), tHd = cue(15, 'hidup'), tLm = cue(15, 'lama'), tMk = cue(15, 'market');
  const up = easeOut((t - sStart(15)) / (tCp - sStart(15) + 0.7));
  const fall = easeInOut((t - tHd) / 0.9);
  const ry = lerp(340, 150, up) + 250 * fall, rr = 160 * fall + sw(t, 3, 3) * (1 - fall);
  const walk = clamp((t - tHd) / (sEnd(15) - tHd));
  const tx = lerp(140, 262, walk), ty = 428 + sw(t, 2, 1.6);
  const flame = 14 + 6 * Math.sin(t * 30);
  return (
    <Backdrop t={t} v="teal" seed={12}>
      <Pill x={92} y={96} w={150} text="KAYA CEPAT" fill={c.red1} fs={20} sc={pop(t, Math.min(tKy, sStart(15) + 0.2))} rot={-3} />
      <P tf={`translate(92 ${ry}) rotate(${rr}) scale(1.6)`} o={ry > 470 ? 0 : 1}>
        <path d="M0 -58 Q24 -30 20 14 H-20 Q-24 -30 0 -58 Z" fill={c.red} />
        <circle cx={0} cy={-26} r={9} fill={c.blue1} />
        <path d="M-20 -2 L-36 22 L-20 14 Z M20 -2 L36 22 L20 14 Z" fill={c.yellow} />
        <path d={`M-10 14 L0 ${14 + flame} L10 14 Z`} fill={c.yellow2} />
      </P>
      <Pill x={250} y={288} w={170} text="HIDUP LAMA" fill={c.teal1} fs={20} sc={pop(t, tHd)} rot={2} />
      <P tf={`translate(${tx} ${ty}) scale(1.3)`}>
        <path d="M-32 0 a32 26 0 0 1 64 0 z" fill={c.teal} />
        {[-14, 2, 16].map((a, i) => <circle key={i} cx={a} cy={-10 + (i === 1 ? -4 : 0)} r={5} fill={c.teal2} />)}
        <circle cx={40} cy={-8} r={10} fill={c.teal2} />
        <circle cx={43} cy={-10} r={2} fill={c.ink} />
        <rect x={-20} y={-2} width={11} height={10 + 3 * Math.sin(t * 5)} rx={4} fill={c.teal2} />
        <rect x={10} y={-2} width={11} height={10 - 3 * Math.sin(t * 5)} rx={4} fill={c.teal2} />
      </P>
      <P tf={`translate(326 ${428 - 8 * (1 - pop(t, tMk))})`} o={pop(t, tMk)}>
        <rect x={-2} y={-64} width={4} height={64} fill={c.gray3} />
        <path d="M2 -64 h30 l-8 11 l8 11 h-30 z" fill={c.blue} />
      </P>
      <Pill x={286} y={344} w={110} text="MARKET" fill={c.blue1} fs={18} sc={pop(t, tMk)} rot={-3} />
    </Backdrop>
  );
};

/* ---------- 13: karyawan vs rebahan dibayar dolar (kalimat 16) ---------- */
export const Sc13: React.FC<SceneProps> = ({ t }) => {
  const tBl = cue(16, 'balik'), tKy = cue(16, 'karyawan'), tRb = cue(16, 'rebahan', 0), tDl = cue(16, 'dolar');
  const wk = enter(t, tBl, 2.2);
  return (
    <Backdrop t={t} v="yellow" seed={13}>
      <Building x={70} y={316} s={1.05} col={c.blue2} />
      <Pill x={80} y={168} w={132} text="KARYAWAN" fill={c.yellow2} fs={19} sc={pop(t, tKy)} rot={-3} />
      {[0, 1, 2].map(i => <Person key={i} t={t} x={150 + i * 28 - 80 * wk} y={444 + (i % 2) * 2} s={0.72} rot={sw(t, 2.5, 2.2, i)} mood={2} armL={14} armR={14} shirt={c.blue} seed={i + 1} />)}
      <P tf="translate(290 430)">
        <rect x={-66} y={-34} width={132} height={34} rx={14} fill={c.teal} />
        <rect x={-66} y={-70} width={44} height={70} rx={16} fill={c.teal2} />
      </P>
      <Person t={t} x={308} y={398} rot={-62} s={1} mood={1} armL={60} armR={60} shirt={c.yellow} />
      <Laptop x={274} y={388} s={0.62} />
      <Pill x={286} y={282} w={132} text="REBAHAN" fill={c.teal1} fs={20} sc={pop(t, tRb)} rot={3} />
      {t > tDl && [0, 1, 2, 3, 4].map(i => {
        const per = 1.6, ph = (t - tDl - i * 0.28) / per;
        if (ph < 0) return null;
        const f = ph % 1, x = 200 + hash(i + Math.floor(ph) * 7) * 130, y = 40 + f * 330;
        return (
          <g key={i} transform={`translate(${x + sw(t, 6, 1, i)} ${y}) rotate(${sw(t, 25, 1.2, i)})`}>
            <rect x={-12} y={-6} width={26} height={14} rx={3} fill={c.ink} opacity={0.14} />
            <rect x={-13} y={-8} width={26} height={14} rx={3} fill={c.teal2} />
            <Txt x={0} y={3} s={11}>$</Txt>
          </g>
        );
      })}
    </Backdrop>
  );
};

/* ---------- 14: kerjaan enggak kelihatan sama orang yang lihat seragam (kalimat 17) ---------- */
export const Sc14: React.FC<SceneProps> = ({ t }) => {
  const tPg = cue(17, 'pengangguran'), tKj = cue(17, 'kerjaan'), tKl = cue(17, 'kelihatan'), tSg = cue(17, 'seragam');
  return (
    <Backdrop t={t} v="blue" seed={14}>
      <Card x={180} y={70} w={316} h={58} fill={c.yellow1} sc={pop(t, tPg)}><Txt x={0} y={8} s={20}>TIM PENGANGGURAN CUAN</Txt></Card>
      <Eye x={92} y={166} s={0.95} look={sw(t, 3, 0.5)} />
      <P tf={`translate(92 ${250 + sw(t, 2, 0.7)}) rotate(${sw(t, 3, 0.6)})`}>
        <path d="M0 -30 q0 -12 12 -12 a8 8 0 1 0 -8 -8" fill="none" stroke={c.gray3} strokeWidth={5} strokeLinecap="round" />
        <path d="M-52 -4 L-24 -30 H24 L52 -4 L40 10 L28 2 V50 H-28 V2 L-40 10 Z" fill={c.blue} />
        <path d="M-12 -30 L0 -14 L12 -30 Z" fill={c.white} />
        <circle cx={-16} cy={14} r={7} fill={c.yellow} />
      </P>
      <Pill x={92} y={336} w={124} text="SERAGAM" fill={c.yellow2} fs={19} sc={pop(t, tSg)} rot={-3} />
      <Pill x={268} y={228} w={150} text="KERJAAN LO" fill={c.teal1} fs={19} sc={pop(t, tKj)} rot={2} />
      <Eye x={268} y={166} s={0.95} slash={enter(t, tKl, 0.4)} look={sw(t, 3, 0.5)} />
      <Person t={t} x={262} y={428} s={1.05} mood={1} armL={52} armR={52} shirt={c.teal} />
      <Desk x={262} y={388} w={118} />
      <Laptop x={262} y={388} s={0.62} />
    </Backdrop>
  );
};
