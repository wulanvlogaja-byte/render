import React from 'react';
import { theme } from './theme';
import { S, sStart, easeOut, clamp } from './helpers';
import { Defs } from './parts';
import { Sc0, Sc1, Sc2, Sc3, Sc4, Sc5, Sc6, Sc7 } from './scenesA';
import { Sc8, Sc9, Sc10, Sc11, Sc12, Sc13, Sc14 } from './scenesB';

const c = theme.c;
// Adegan = rentang kalimat. Awal adegan diambil dari timing.json (tidak ada angka detik manual).
const scenes: { from: number; Comp: React.FC<{ t: number }> }[] = [
  { from: 0, Comp: Sc0 }, { from: 2, Comp: Sc1 }, { from: 3, Comp: Sc2 }, { from: 4, Comp: Sc3 },
  { from: 5, Comp: Sc4 }, { from: 6, Comp: Sc5 }, { from: 8, Comp: Sc6 }, { from: 9, Comp: Sc7 },
  { from: 10, Comp: Sc8 }, { from: 11, Comp: Sc9 }, { from: 12, Comp: Sc10 }, { from: 13, Comp: Sc11 },
  { from: 15, Comp: Sc12 }, { from: 16, Comp: Sc13 }, { from: 17, Comp: Sc14 },
];
const starts = scenes.map(s => (s.from === 0 ? 0 : sStart(s.from)));

const Caption: React.FC<{ t: number }> = ({ t }) => {
  let idx = 0;
  for (let i = 0; i < S.length; i++) if (t >= S[i].start - 0.05) idx = i;
  const s = S[idx];
  const cp = theme.caption;
  return (
    <div style={{ position: 'absolute', left: cp.sidePx, right: cp.sidePx, bottom: cp.bottomPx, background: c.white, borderRadius: 52, padding: `${cp.padPx}px ${cp.padPx + 6}px`, boxShadow: '0 12px 30px rgba(27,42,58,0.28)', textAlign: 'center', fontFamily: theme.font, fontWeight: 700, fontSize: cp.fontPx, lineHeight: 1.3, color: c.ink }}>
      {s.words.map((w, i) => {
        const active = t >= w.start && t < w.end;
        const past = t >= w.end;
        return (
          <span key={i} style={{ display: 'inline-block', margin: '2px 3px', padding: '0 12px', borderRadius: 24, background: active ? c.yellow : 'transparent', color: past || active ? c.ink : c.inkSoft }}>{w.w}</span>
        );
      })}
    </div>
  );
};

export const Video: React.FC<{ t: number }> = ({ t }) => {
  let base = 0;
  for (let i = 0; i < scenes.length; i++) if (t >= starts[i] + (i === 0 ? 0 : theme.tr)) base = i;
  const nxt = base + 1 < scenes.length && t >= starts[base + 1] ? base + 1 : -1;
  const B = scenes[base].Comp;
  const N = nxt >= 0 ? scenes[nxt].Comp : null;
  const k = nxt >= 0 ? easeOut(clamp((t - starts[nxt]) / theme.tr)) : 1;
  const { w, h } = theme.view;
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: c.bg, overflow: 'hidden' }}>
      <svg viewBox={`0 0 ${w} ${h}`} width="100%" height="100%" style={{ position: 'absolute', left: 0, top: 0 }}>
        <Defs />
        <B t={t} />
        {N && <g transform={`translate(${(1 - k) * w} 0)`}><N t={t} /></g>}
      </svg>
      <Caption t={t} />
    </div>
  );
};
