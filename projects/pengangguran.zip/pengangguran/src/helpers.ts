import T from './timing.json';

export const S = T.sentences;
export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const easeOut = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
export const easeInOut = (x: number) => { const k = clamp(x); return k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2; };
export const easeBack = (x: number) => { const k = clamp(x), c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
export const fract = (x: number) => x - Math.floor(x);
export const hash = (n: number) => fract(Math.sin(n * 127.1 + 311.7) * 43758.5453);
export const wrap = (x: number, a: number, b: number) => a + ((((x - a) % (b - a)) + (b - a)) % (b - a));
// masuk bertahap: 0 -> 1 dalam dur detik sejak t0
export const enter = (t: number, t0: number, dur = 0.7) => easeOut((t - t0) / dur);
export const pop = (t: number, t0: number, dur = 0.45) => (t < t0 ? 0 : easeBack((t - t0) / dur));
export const bump = (t: number, t0: number, dur = 0.6) => { const k = (t - t0) / dur; return k < 0 || k > 1 ? 0 : Math.sin(k * Math.PI); };
export const sw = (t: number, amp: number, f = 1, ph = 0) => Math.sin(t * f * Math.PI * 2 + ph) * amp;

const norm = (w: string) => w.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
// waktu mulai kata ke-n (0 = kemunculan pertama) di kalimat s (0-based). Tidak ada angka detik manual.
export function cue(s: number, word: string, n = 0): number {
  const sent = S[s];
  if (!sent) throw new Error(`cue: kalimat ${s} tidak ada`);
  const target = norm(word);
  let c = 0;
  for (const w of sent.words) {
    if (norm(w.w) === target) { if (c === n) return w.start; c++; }
  }
  throw new Error(`cue: kata "${word}" (ke-${n}) tidak ditemukan di kalimat ${s}: "${sent.text}"`);
}
export function cueEnd(s: number, word: string, n = 0): number {
  const sent = S[s];
  const target = norm(word);
  let c = 0;
  for (const w of sent.words) {
    if (norm(w.w) === target) { if (c === n) return w.end; c++; }
  }
  throw new Error(`cueEnd: kata "${word}" tidak ditemukan di kalimat ${s}`);
}
export const sStart = (s: number) => S[s].start;
export const sEnd = (s: number) => S[s].end;
export const timing = T;
