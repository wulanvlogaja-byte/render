import React from 'react';
import { theme } from './theme';
import { clamp, hash, easeOut, sw, wrap } from './helpers';

const c = theme.c;
const F = theme.font;

/** Defs bayangan kertas: ps (jatuh ke bawah), pu (jatuh ke atas, untuk pita). */
export const Defs: React.FC = () => (
  <defs>
    <filter id="ps" x="-30%" y="-30%" width="160%" height="170%">
      <feDropShadow dx={0} dy={theme.shadow.dy} stdDeviation={theme.shadow.std} floodColor={c.ink} floodOpacity={theme.shadow.opacity} />
    </filter>
    <filter id="pu" x="-5%" y="-40%" width="110%" height="180%">
      <feDropShadow dx={0} dy={-theme.shadow.dy} stdDeviation={theme.shadow.std} floodColor={c.ink} floodOpacity={theme.shadow.opacity} />
    </filter>
  </defs>
);

export const P: React.FC<{ children?: React.ReactNode; tf?: string; o?: number }> = ({ children, tf, o = 1 }) => (
  <g filter="url(#ps)" transform={tf} opacity={o}>{children}</g>
);

export const Txt: React.FC<{ x: number; y: number; s: number; fill?: string; anchor?: 'start' | 'middle' | 'end'; children: React.ReactNode; tf?: string; o?: number }> = ({ x, y, s, fill = c.ink, anchor = 'middle', children, tf, o = 1 }) => (
  <text x={x} y={y} fontSize={s} fontFamily={F} fontWeight={700} fill={fill} textAnchor={anchor} transform={tf} opacity={o}>{children}</text>
);

/** Pita bergelombang (air/bukit). Periode 60, bergeser dx = (t*speed) % 60. */
export const Ribbon: React.FC<{ t: number; y: number; fill: string; speed?: number; bob?: number; ph?: number; up?: boolean }> = ({ t, y, fill, speed = 8, bob = 3, ph = 0, up = true }) => {
  const dx = (t * speed) % 60;
  const yy = y + Math.sin(t * 1.3 + ph) * bob;
  let d = `M-60 ${yy} q15 -12 30 0`;
  for (let i = 0; i < 23; i++) d += ' t30 0';
  d += ' L660 700 L-60 700 Z';
  return <g filter={up ? 'url(#pu)' : 'url(#ps)'}><path d={d} fill={fill} transform={`translate(${-dx} 0)`} /></g>;
};

export const Cloud: React.FC<{ t: number; x0: number; y: number; s?: number; v?: number }> = ({ t, x0, y, s = 1, v = 6 }) => {
  const x = wrap(x0 + t * v, -120, 480);
  return (
    <P tf={`translate(${x} ${y + Math.sin(t * 0.8 + x0) * 2}) scale(${s})`}>
      <circle cx={0} cy={0} r={22} fill={c.white} />
      <circle cx={26} cy={-9} r={26} fill={c.white} />
      <circle cx={54} cy={0} r={21} fill={c.white} />
      <rect x={-22} y={0} width={98} height={22} rx={11} fill={c.white} />
    </P>
  );
};

type Variant = 'blue' | 'teal' | 'yellow' | 'red';
const VAR: Record<Variant, { sky: string; r: [string, string, string] }> = {
  blue: { sky: c.sky, r: [c.blue1, c.blue2, c.blue3] },
  teal: { sky: c.teal1, r: [c.teal1, c.teal2, c.teal] },
  yellow: { sky: c.yellow1, r: [c.yellow1, c.yellow2, c.yellow] },
  red: { sky: c.red1, r: [c.red1, c.red2, c.red] },
};

/** Latar adegan: langit terang, awan, dua pita belakang; children disisipkan; pita depan. */
export const Backdrop: React.FC<{ t: number; v?: Variant; seed?: number; children?: React.ReactNode; clouds?: boolean }> = ({ t, v = 'blue', seed = 0, children, clouds = true }) => {
  const k = VAR[v];
  return (
    <g>
      <rect x={-10} y={-10} width={380} height={660} fill={k.sky} />
      {clouds && <>
        <Cloud t={t} x0={20 + seed * 40} y={70 + (seed % 3) * 14} s={0.8} v={5} />
        <Cloud t={t} x0={230 + seed * 25} y={120} s={0.6} v={8} />
      </>}
      <Ribbon t={t} y={410} fill={k.r[0]} speed={6} ph={seed} />
      <Ribbon t={t} y={432} fill={k.r[1]} speed={10} ph={seed + 1} />
      {children}
      <Ribbon t={t} y={462} fill={k.r[2]} speed={16} ph={seed + 2} bob={4} />
    </g>
  );
};

type PersonProps = {
  t: number; x: number; y: number; s?: number; rot?: number; sx?: number; sy?: number;
  armL?: number; armR?: number; mood?: 0 | 1 | 2 | 3; shirt?: string; hair?: string; flip?: boolean; tears?: boolean; o?: number; seed?: number; hat?: boolean;
};
/** Karakter kertas. Titik tumpu di kaki (x,y). armL/armR = sudut angkat lengan (0 turun, 180 lurus ke atas). */
export const Person: React.FC<PersonProps> = ({ t, x, y, s = 1, rot = 0, sx = 1, sy = 1, armL = 15, armR = 15, mood = 1, shirt = c.blue, hair = c.ink, flip = false, tears = false, o = 1, seed = 0, hat = false }) => {
  const blink = ((t + seed * 0.7) % 3.2) < 0.12;
  const eyeH = blink ? 0.6 : 3.2;
  const m = mood === 1 ? <path d="M-6 -76 q6 7 12 0" stroke={c.ink} strokeWidth={2.2} fill="none" strokeLinecap="round" />
    : mood === 2 ? <path d="M-6 -72 q6 -6 12 0" stroke={c.ink} strokeWidth={2.2} fill="none" strokeLinecap="round" />
    : mood === 3 ? <ellipse cx={0} cy={-73} rx={3.6} ry={4.4} fill={c.ink} />
    : <rect x={-5} y={-74} width={10} height={2.2} rx={1.1} fill={c.ink} />;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${(flip ? -1 : 1) * s * sx} ${s * sy})`} opacity={o}>
      <g filter="url(#ps)">
        <rect x={-11} y={-26} width={9} height={26} rx={4} fill={c.ink} />
        <rect x={2} y={-26} width={9} height={26} rx={4} fill={c.ink} />
        <rect x={-16} y={-62} width={32} height={40} rx={11} fill={shirt} />
        <g transform={`translate(-16 -56) rotate(${armL})`}><rect x={-4} y={0} width={8} height={28} rx={4} fill={shirt} /><circle cx={0} cy={28} r={4.6} fill={c.skin} /></g>
        <g transform={`translate(16 -56) rotate(${-armR})`}><rect x={-4} y={0} width={8} height={28} rx={4} fill={shirt} /><circle cx={0} cy={28} r={4.6} fill={c.skin} /></g>
        <rect x={-4} y={-68} width={8} height={9} rx={3} fill={c.skin2} />
        <circle cx={0} cy={-80} r={17} fill={c.skin} />
        <path d="M-17 -82 a17 17 0 0 1 34 0 q-8 -9 -17 -7 q-9 -2 -17 7 z" fill={hair} />
        {hat && <rect x={-19} y={-98} width={38} height={7} rx={3.5} fill={c.yellow} />}
        <ellipse cx={-6} cy={-80} rx={2.3} ry={eyeH} fill={c.ink} />
        <ellipse cx={6} cy={-80} rx={2.3} ry={eyeH} fill={c.ink} />
        {m}
        {tears && [0, 1, 2].map(i => {
          const k = ((t * 1.4 + i * 0.33) % 1);
          return <circle key={i} cx={i % 2 ? 9 : -9} cy={-76 + k * 30} r={2.6 * (1 - k * 0.4)} fill={c.blue3} opacity={1 - k * 0.5} />;
        })}
      </g>
    </g>
  );
};

export const Laptop: React.FC<{ x: number; y: number; s?: number; children?: React.ReactNode; o?: number }> = ({ x, y, s = 1, children, o = 1 }) => (
  <P tf={`translate(${x} ${y}) scale(${s})`} o={o}>
    <rect x={-36} y={-48} width={72} height={46} rx={5} fill={c.gray2} />
    <rect x={-31} y={-43} width={62} height={36} rx={3} fill={c.white} />
    {children}
    <rect x={-46} y={-3} width={92} height={7} rx={3.5} fill={c.gray3} />
  </P>
);

export const Desk: React.FC<{ x: number; y: number; w?: number; color?: string }> = ({ x, y, w = 150, color = c.yellow2 }) => (
  <P>
    <rect x={x - w / 2} y={y} width={w} height={12} rx={4} fill={color} />
    <rect x={x - w / 2 + 8} y={y + 12} width={9} height={52} rx={3} fill={c.yellow} />
    <rect x={x + w / 2 - 17} y={y + 12} width={9} height={52} rx={3} fill={c.yellow} />
  </P>
);

export const Coin: React.FC<{ x: number; y: number; r?: number; rot?: number; o?: number }> = ({ x, y, r = 12, rot = 0, o = 1 }) => (
  <P tf={`translate(${x} ${y}) rotate(${rot})`} o={o}>
    <circle r={r} fill={c.yellow} />
    <circle r={r * 0.72} fill={c.yellow2} />
    <Txt x={0} y={r * 0.36} s={r * 1.05} fill={c.ink}>$</Txt>
  </P>
);

export const Bubble: React.FC<{ x: number; y: number; w: number; lines: string[]; sc?: number; tail?: 'l' | 'r' | 'd'; fill?: string; fs?: number; o?: number }> = ({ x, y, w, lines, sc = 1, tail = 'd', fill = c.white, fs = 17, o = 1 }) => {
  const h = 14 + lines.length * (fs + 4);
  const tl = tail === 'd' ? `M-8 ${h} l8 14 l10 -14 z` : tail === 'l' ? `M6 ${h - 4} l-12 16 l22 -8 z` : `M${w - 6} ${h - 4} l12 16 l-22 -8 z`;
  return (
    <P tf={`translate(${x} ${y}) scale(${sc})`} o={o}>
      <g transform={`translate(${-w / 2} 0)`}>
        <rect width={w} height={h} rx={14} fill={fill} />
        <path d={tail === 'd' ? `M${w / 2 - 8} ${h - 1} l8 14 l10 -14 z` : tl} fill={fill} />
        {lines.map((l, i) => <Txt key={i} x={w / 2} y={fs + 6 + i * (fs + 4)} s={fs}>{l}</Txt>)}
      </g>
    </P>
  );
};

export const Pill: React.FC<{ x: number; y: number; w: number; text: string; fill: string; fs?: number; sc?: number; rot?: number; o?: number }> = ({ x, y, w, text, fill, fs = 17, sc = 1, rot = 0, o = 1 }) => (
  <P tf={`translate(${x} ${y}) rotate(${rot}) scale(${sc})`} o={o}>
    <rect x={-w / 2} y={-fs * 0.95} width={w} height={fs * 1.6} rx={fs * 0.8} fill={fill} />
    <Txt x={0} y={fs * 0.27} s={fs}>{text}</Txt>
  </P>
);

export const Clock: React.FC<{ x: number; y: number; r?: number; hour: number; min: number; sc?: number }> = ({ x, y, r = 40, hour, min, sc = 1 }) => (
  <P tf={`translate(${x} ${y}) scale(${sc})`}>
    <circle r={r} fill={c.white} />
    <circle r={r * 0.86} fill={c.yellow1} />
    {Array.from({ length: 12 }, (_, i) => <rect key={i} x={-1.5} y={-r * 0.8} width={3} height={r * 0.1} rx={1.5} fill={c.ink} transform={`rotate(${i * 30})`} />)}
    <rect x={-2.6} y={-r * 0.5} width={5.2} height={r * 0.5} rx={2.6} fill={c.ink} transform={`rotate(${hour * 30 + min * 0.5})`} />
    <rect x={-1.8} y={-r * 0.72} width={3.6} height={r * 0.72} rx={1.8} fill={c.blue} transform={`rotate(${min * 6})`} />
    <circle r={3.6} fill={c.red} />
  </P>
);

/** Grafik candle. Candle ke-i dihitung dari hash (deterministik), jendela bergulir sesuai t. */
export const CandleChart: React.FC<{ t: number; x: number; y: number; w: number; h: number; n?: number; speed?: number; bias?: number }> = ({ t, x, y, w, h, n = 13, speed = 2.2, bias = 0 }) => {
  const pos = t * speed, base = Math.floor(pos), fr = pos - base, step = w / n;
  const price = (i: number) => 0.5 + 0.28 * Math.sin(i * 0.55) + 0.2 * (hash(i) - 0.5) + bias * i * 0.02;
  const items = [];
  for (let k = -1; k <= n; k++) {
    const i = base + k, o = price(i), cl = price(i + 1);
    const up = cl >= o;
    const hi = Math.max(o, cl) + 0.05 + hash(i + 9) * 0.06, lo = Math.min(o, cl) - 0.05 - hash(i + 5) * 0.06;
    const px = x + (k - fr) * step + step / 2;
    const Y = (v: number) => y + h - clamp(v, 0, 1) * h;
    const col = up ? c.teal : c.red;
    items.push(
      <g key={i}>
        <rect x={px - 1.4} y={Y(hi)} width={2.8} height={Y(lo) - Y(hi)} fill={col} />
        <rect x={px - step * 0.3} y={Y(Math.max(o, cl))} width={step * 0.6} height={Math.max(3, Y(Math.min(o, cl)) - Y(Math.max(o, cl)))} rx={2} fill={col} />
      </g>
    );
  }
  return (
    <g>
      <clipPath id={`cc${Math.round(x)}${Math.round(y)}`}><rect x={x} y={y - 4} width={w} height={h + 8} /></clipPath>
      <g clipPath={`url(#cc${Math.round(x)}${Math.round(y)})`}>{items}</g>
    </g>
  );
};

/** Garis detak jantung (EKG) bergulir. */
export const Heartbeat: React.FC<{ t: number; x: number; y: number; w: number; amp?: number; color?: string }> = ({ t, x, y, w, amp = 26, color = c.red }) => {
  const pts: string[] = [];
  for (let i = 0; i <= 60; i++) {
    const u = i / 60, ph = (u * 3 - t * 0.9) % 1, p = (ph + 1) % 1;
    let v = 0;
    if (p > 0.40 && p < 0.46) v = -(p - 0.40) / 0.06;
    else if (p >= 0.46 && p < 0.52) v = -1 + ((p - 0.46) / 0.06) * 2.0;
    else if (p >= 0.52 && p < 0.58) v = 1 - ((p - 0.52) / 0.06) * 1.0;
    pts.push(`${(x + u * w).toFixed(1)},${(y + v * amp).toFixed(1)}`);
  }
  return <polyline points={pts.join(' ')} fill="none" stroke={color} strokeWidth={4} strokeLinejoin="round" strokeLinecap="round" />;
};

export const Heart: React.FC<{ x: number; y: number; s?: number; fill?: string }> = ({ x, y, s = 1, fill = c.red }) => (
  <P tf={`translate(${x} ${y}) scale(${s})`}>
    <path d="M0 14 C-26 -6 -14 -26 0 -12 C14 -26 26 -6 0 14 Z" fill={fill} />
  </P>
);

export const Wifi: React.FC<{ t: number; x: number; y: number; s?: number; col?: string; o?: number }> = ({ t, x, y, s = 1, col = c.teal, o = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} opacity={o}>
    {[34, 24, 14].map((r, i) => {
      const a = 0.35 + 0.65 * Math.max(0, Math.sin(t * 4 - i * 0.9));
      return <path key={r} d={`M${-r * 0.8} ${-r * 0.6} A${r} ${r} 0 0 1 ${r * 0.8} ${-r * 0.6}`} fill="none" stroke={col} strokeWidth={6} strokeLinecap="round" opacity={a} />;
    })}
    <circle cx={0} cy={4} r={5} fill={col} />
  </g>
);

export const House: React.FC<{ x: number; y: number; s?: number; roof?: string; wall?: string }> = ({ x, y, s = 1, roof = c.red, wall = c.white }) => (
  <P tf={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-30} y={-34} width={60} height={34} fill={wall} />
    <path d="M-38 -34 L0 -64 L38 -34 Z" fill={roof} />
    <rect x={-7} y={-22} width={14} height={22} rx={3} fill={c.yellow} />
    <rect x={14} y={-28} width={11} height={11} rx={2} fill={c.blue1} />
  </P>
);

export const Bed: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <P tf={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-60} y={-22} width={120} height={22} rx={6} fill={c.blue2} />
    <rect x={-60} y={-44} width={14} height={44} rx={5} fill={c.blue3} />
    <rect x={-44} y={-30} width={34} height={12} rx={6} fill={c.white} />
    <rect x={-6} y={-30} width={62} height={10} rx={5} fill={c.blue1} />
  </P>
);

export const Thumb: React.FC<{ x: number; y: number; s?: number; rot?: number }> = ({ x, y, s = 1, rot = 0 }) => (
  <P tf={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-38} y={-8} width={22} height={50} rx={6} fill={c.blue} />
    <path d="M-12 -4 L2 -40 q8 -6 14 2 l-4 26 h26 q10 2 8 12 l-6 28 q-2 8 -10 8 h-28 z" fill={c.yellow} />
  </P>
);

export const Bell: React.FC<{ x: number; y: number; s?: number; rot?: number }> = ({ x, y, s = 1, rot = 0 }) => (
  <P tf={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <path d="M-24 14 q4 -6 4 -24 q0 -22 20 -24 q20 2 20 24 q0 18 4 24 z" fill={c.yellow} />
    <rect x={-8} y={-44} width={16} height={8} rx={4} fill={c.yellow2} />
    <circle cx={0} cy={20} r={6} fill={c.yellow2} />
  </P>
);

export const Eye: React.FC<{ x: number; y: number; s?: number; slash?: number; look?: number }> = ({ x, y, s = 1, slash = 0, look = 0 }) => (
  <P tf={`translate(${x} ${y}) scale(${s})`}>
    <path d="M-34 0 Q0 -30 34 0 Q0 30 -34 0 Z" fill={c.white} />
    <circle cx={look} cy={0} r={12} fill={c.blue} />
    <circle cx={look} cy={0} r={5.5} fill={c.ink} />
    {slash > 0 && <rect x={-3.5} y={-34} width={7} height={68 * slash} rx={3.5} fill={c.red} transform="rotate(-40)" />}
  </P>
);

export const Building: React.FC<{ x: number; y: number; s?: number; col?: string }> = ({ x, y, s = 1, col = c.blue2 }) => (
  <P tf={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-34} y={-110} width={68} height={110} rx={4} fill={col} />
    {[0, 1, 2, 3].map(r => [0, 1, 2].map(q => <rect key={r * 3 + q} x={-24 + q * 18} y={-100 + r * 22} width={11} height={13} rx={2} fill={c.white} />))}
    <rect x={-8} y={-22} width={16} height={22} rx={3} fill={c.yellow} />
  </P>
);

/** Kartu judul kertas putih. */
export const Card: React.FC<{ x: number; y: number; w: number; h: number; sc?: number; o?: number; fill?: string; children?: React.ReactNode }> = ({ x, y, w, h, sc = 1, o = 1, fill = c.white, children }) => (
  <P tf={`translate(${x} ${y}) scale(${sc})`} o={o}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={16} fill={fill} />
    {children}
  </P>
);

export const Swirl: React.FC<{ t: number; x: number; y: number; s?: number }> = ({ t, x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) rotate(${t * 240}) scale(${s})`}>
    <path d="M0 0 q8 -8 14 0 q6 12 -6 18 q-20 6 -26 -12 q-4 -22 20 -28 q30 -4 38 22" fill="none" stroke={c.blue} strokeWidth={4} strokeLinecap="round" />
  </g>
);

export { sw, easeOut };
