// Hitung timing kalimat dan kata dari audio. Pakai: node timing.cjs  (env: FPS, W, H)
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const FPS = +(process.env.FPS || 30), W = +(process.env.W || 1080), H = +(process.env.H || 1920);
const audio = path.join(__dirname, 'public/narasi.mp3');
const sents = fs.readFileSync(path.join(__dirname, 'narasi.txt'), 'utf8').split('\n').map(s => s.trim()).filter(Boolean);

const dur = +spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', audio], { encoding: 'utf8' }).stdout.trim();
const sd = spawnSync('ffmpeg', ['-hide_banner', '-i', audio, '-af', 'silencedetect=noise=-35dB:d=0.25', '-f', 'null', '-'], { encoding: 'utf8' }).stderr;
const sil = []; let cur = null;
for (const l of sd.split('\n')) {
  let m;
  if ((m = l.match(/silence_start: ([\d.]+)/))) cur = +m[1];
  else if ((m = l.match(/silence_end: ([\d.]+)/))) { sil.push([cur == null ? 0 : cur, +m[1]]); cur = null; }
}
if (cur != null) sil.push([cur, dur]);
// komplemen jeda = segmen bicara
let segs = []; let p = 0;
for (const [a, b] of sil) { if (a - p > 0.05) segs.push([p, a]); p = Math.max(p, b); }
if (dur - p > 0.05) segs.push([p, dur]);
const m = segs.length, K = sents.length;
if (m < K) throw new Error(`segmen bicara (${m}) < kalimat (${K})`);
const clen = s => s.replace(/[^\p{L}\p{N}]/gu, '').length;
const chars = sents.map(clen);
const pre = [0]; segs.forEach(s => pre.push(pre[pre.length - 1] + (s[1] - s[0])));
const sp = (i, j) => pre[j + 1] - pre[i]; // durasi bicara segmen i..j

function solve(med) {
  const INF = 1e18, dp = Array.from({ length: K + 1 }, () => Array(m + 1).fill(INF)), bk = Array.from({ length: K + 1 }, () => Array(m + 1).fill(-1));
  dp[0][0] = 0;
  for (let k = 1; k <= K; k++) for (let j = k; j <= m; j++) for (let i = k - 1; i < j; i++) {
    if (dp[k - 1][i] >= INF) continue;
    const rate = chars[k - 1] / sp(i, j - 1);
    const c = dp[k - 1][i] + Math.abs(Math.log(rate / med)) + 0.15 * (j - i - 1);
    if (c < dp[k][j]) { dp[k][j] = c; bk[k][j] = i; }
  }
  const out = []; let j = m;
  for (let k = K; k >= 1; k--) { const i = bk[k][j]; out.unshift([i, j - 1]); j = i; }
  return out;
}
let med = chars.reduce((a, b) => a + b, 0) / pre[m], asg;
for (let it = 0; it < 6; it++) {
  asg = solve(med);
  const r = asg.map(([i, j], k) => chars[k] / sp(i, j)).sort((a, b) => a - b);
  med = r[Math.floor(r.length / 2)];
}
const sentences = sents.map((text, k) => {
  const [i, j] = asg[k];
  const start = segs[i][0], end = segs[j][1];
  const parts = segs.slice(i, j + 1);
  const words = text.split(/\s+/);
  const wt = words.map(w => clen(w) + 1.5);
  const tot = wt.reduce((a, b) => a + b, 0), speech = sp(i, j);
  // peta posisi bicara kumulatif -> waktu nyata (lompati jeda)
  const at = x => { let r = x; for (const [a, b] of parts) { if (r <= b - a + 1e-9) return a + r; r -= (b - a); } return end; };
  let acc = 0;
  const ws = words.map((w, n) => { const s0 = at(acc / tot * speech); acc += wt[n]; const e0 = at(acc / tot * speech); return { w, start: +s0.toFixed(3), end: +e0.toFixed(3) }; });
  return { text, start: +start.toFixed(3), end: +end.toFixed(3), rate: +(chars[k] / speech).toFixed(2), words: ws };
});
const rates = sentences.map(s => s.rate).sort((a, b) => a - b), medR = rates[Math.floor(rates.length / 2)];
sentences.forEach((s, k) => { const x = s.rate / medR; if (x < 0.6 || x > 1.6) console.warn(`! kalimat ${k + 1} laju ${s.rate} (${x.toFixed(2)}x median)`); });
fs.writeFileSync(path.join(__dirname, 'src/timing.json'), JSON.stringify({ duration: +dur.toFixed(3), fps: FPS, width: W, height: H, sentences }, null, 1));
console.log('ok', dur, 'dtk', K, 'kalimat, median laju', medR.toFixed(2));
sentences.forEach((s, k) => console.log(k + 1, s.start.toFixed(2), s.end.toFixed(2), s.rate, s.text.slice(0, 40)));
