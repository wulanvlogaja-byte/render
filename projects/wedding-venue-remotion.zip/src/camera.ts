import {Easing} from 'remotion';

export type V = [number, number, number];
export const FPS = 30;

type EaseName = 'io' | 'lin' | 'in' | 'out';

type Move = {
  kind: 'move'; name: string; sec: number; ease?: EaseName; sway?: number;
  p0: V; p1: V; l0: V; l1: V; f0: number; f1: number;
};
type Orbit = {
  kind: 'orbit'; name: string; sec: number; ease?: EaseName; sway?: number;
  c: V; a0: number; a1: number; r0: number; r1: number; h0: number; h1: number;
  l0: V; l1: V; f0: number; f1: number;
};
type Shot = Move | Orbit;

/**
 * Sumbu: x kanan, y atas, z ke arah jalan (depan gedung = +z).
 * Gedung di z -32..-4, halaman depan z -4..26, jalan z ~40, parkir x 12..36.
 * Sudut orbit (derajat) dari sumbu +x; 90 = depan (sisi jalan).
 */
export const SHOTS: Shot[] = [
  // 1. DRONE REVEAL: turun dari ketinggian, wide establishing
  {kind: 'move', name: 'drone-reveal', sec: 7, ease: 'io', sway: 0.05,
    p0: [70, 55, 95], p1: [30, 16, 52], l0: [0, 3, -12], l1: [0, 4, -8], f0: 50, f1: 42},
  // 2. DOLLY RENDAH masuk lewat gerbang ke halaman depan
  {kind: 'move', name: 'front-dolly', sec: 5, ease: 'io',
    p0: [0, 1.8, 40], p1: [0, 2.2, 12], l0: [0, 3.5, -6], l1: [0, 3.5, -6], f0: 55, f1: 45},
  // 3. DRONE ORBIT 360 mengelilingi gedung
  {kind: 'orbit', name: 'orbit-360', sec: 9, ease: 'io', sway: 0.05,
    c: [0, 0, -14], a0: 90, a1: 450, r0: 58, r1: 46, h0: 26, h1: 20,
    l0: [0, 3, -14], l1: [0, 3, -14], f0: 48, f1: 48},
  // 4. TRUCK samping di area parkir + zoom in (lensa menyempit)
  {kind: 'move', name: 'parkir-truck', sec: 6, ease: 'io',
    p0: [10, 4, 32], p1: [38, 5, 30], l0: [22, 0.8, 12], l1: [26, 0.8, 12], f0: 40, f1: 30},
  // 5. PUSH-IN ke pintu masuk
  {kind: 'move', name: 'teras-pushin', sec: 4.5, ease: 'io',
    p0: [0, 2.4, 16], p1: [0, 2.6, 2], l0: [0, 3, -4], l1: [0, 3.5, -14], f0: 40, f1: 55},
  // 6. DOLLY masuk area tamu menyusuri karpet merah menuju pelaminan
  {kind: 'move', name: 'tamu-dolly', sec: 7, ease: 'io',
    p0: [0, 2.0, -5], p1: [0, 2.4, -20], l0: [0, 3, -31], l1: [0, 3.5, -31], f0: 60, f1: 50},
  // 7. CRANE turun dari atas ke antara meja tamu
  {kind: 'move', name: 'tamu-crane', sec: 5, ease: 'io',
    p0: [-12, 6.2, -8], p1: [-7.75, 1.7, -12.5], l0: [4, 1.5, -22], l1: [5, 1.2, -22], f0: 55, f1: 50},
  // 8. ORBIT busur mengitari pelaminan sambil mendekat
  {kind: 'orbit', name: 'pelaminan-arc', sec: 8, ease: 'io',
    c: [0, 0, -28], a0: 55, a1: 125, r0: 11, r1: 9, h0: 3.2, h1: 2.4,
    l0: [0, 2.2, -28], l1: [0, 2.6, -29], f0: 48, f1: 40},
  // 9. ZOOM + dolly ke papan "Design by idin Iskandar"
  {kind: 'move', name: 'papan-zoom', sec: 5.5, ease: 'io', sway: 0.015,
    p0: [0, 3.5, -20], p1: [0, 5.0, -27], l0: [0, 4.8, -31.3], l1: [0, 5.35, -31.3], f0: 45, f1: 24},
  // 10. FINALE: tarik mundur + naik jadi drone, wide di waktu senja
  {kind: 'move', name: 'finale-pullout', sec: 7, ease: 'io', sway: 0.04,
    p0: [2, 3, 17], p1: [50, 38, 66], l0: [0, 4, -6], l1: [0, 4, -12], f0: 45, f1: 50},
];

const fr = (s: number) => Math.round(s * FPS);
export const TOTAL = SHOTS.reduce((a, s) => a + fr(s.sec), 0);

const EASE: Record<EaseName, (x: number) => number> = {
  io: Easing.inOut(Easing.cubic),
  in: Easing.in(Easing.quad),
  out: Easing.out(Easing.cubic),
  lin: (x) => x,
};

const mix = (a: number, b: number, t: number) => a + (b - a) * t;
const mixV = (a: V, b: V, t: number): V => [mix(a[0], b[0], t), mix(a[1], b[1], t), mix(a[2], b[2], t)];

export const getCam = (frame: number) => {
  let start = 0;
  let idx = 0;
  for (; idx < SHOTS.length; idx++) {
    const len = fr(SHOTS[idx].sec);
    if (frame < start + len || idx === SHOTS.length - 1) break;
    start += len;
  }
  const s = SHOTS[idx];
  const len = fr(s.sec);
  const lf = Math.min(Math.max(frame - start, 0), len - 1);
  const e = EASE[s.ease ?? 'io'](lf / (len - 1));

  let pos: V;
  if (s.kind === 'move') {
    pos = mixV(s.p0, s.p1, e);
  } else {
    const a = (mix(s.a0, s.a1, e) * Math.PI) / 180;
    const r = mix(s.r0, s.r1, e);
    pos = [s.c[0] + Math.cos(a) * r, mix(s.h0, s.h1, e), s.c[2] + Math.sin(a) * r];
  }
  const look = mixV(s.l0, s.l1, e);
  const fov = mix(s.f0, s.f1, e);

  // goyangan halus ala gimbal / drone biar nggak kaku
  const k = s.sway ?? 0.03;
  pos = [
    pos[0] + Math.sin(frame * 0.07) * k,
    pos[1] + Math.sin(frame * 0.05 + 1) * k * 0.8,
    pos[2] + Math.cos(frame * 0.06) * k,
  ];

  return {pos, look, fov, lf, len, idx, name: s.name};
};
