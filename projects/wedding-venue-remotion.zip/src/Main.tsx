import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';
import * as THREE from 'three';
import {getCam, TOTAL} from './camera';
import {Scene} from './Scene';

const CameraRig: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const {camera} = useThree();
  const c = getCam(frame);
  const cam = camera as THREE.PerspectiveCamera;
  const aspect = width / height;
  cam.position.set(c.pos[0], c.pos[1], c.pos[2]);
  cam.fov = Math.min(100, aspect < 1 ? c.fov * 1.5 : c.fov); // vertikal: lebarkan sedikit
  cam.aspect = aspect;
  cam.lookAt(c.look[0], c.look[1], c.look[2]);
  cam.updateProjectionMatrix();
  cam.updateMatrixWorld();
  return null;
};

export const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const c = getCam(frame);
  const fIn = interpolate(c.lf, [0, 6], [1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const fOut = interpolate(c.lf, [c.len - 7, c.len - 1], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const dip = Math.max(fIn, fOut);

  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      <ThreeCanvas
        width={width}
        height={height}
        shadows
        camera={{fov: 50, near: 0.1, far: 600, position: [0, 10, 40]}}
        gl={{antialias: true, preserveDrawingBuffer: true}}
      >
        <CameraRig />
        <Scene t={frame / TOTAL} />
      </ThreeCanvas>
      <AbsoluteFill style={{backgroundColor: '#000', opacity: dip, pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
