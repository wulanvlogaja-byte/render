import React, {useMemo} from 'react';
import * as THREE from 'three';
import {interpolate, random, useCurrentFrame} from 'remotion';

type V = [number, number, number];
const CL = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/* ---------- primitif low-poly (flat shading) ---------- */
const Mat: React.FC<{c: string; e?: string; ei?: number}> = ({c, e, ei = 0}) => (
  <meshStandardMaterial color={c} flatShading roughness={0.9} metalness={0} emissive={e ?? '#000000'} emissiveIntensity={ei} />
);

type BxP = {p: V; s: V; c: string; e?: string; ei?: number; r?: V; cast?: boolean};
const Bx: React.FC<BxP> = ({p, s, c, e, ei = 0, r = [0, 0, 0], cast = true}) => (
  <mesh position={p} scale={s} rotation={r} castShadow={cast} receiveShadow>
    <boxGeometry args={[1, 1, 1]} />
    <Mat c={c} e={e} ei={ei} />
  </mesh>
);

type CyP = {p: V; r: number; h: number; seg?: number; c: string; e?: string; ei?: number; rot?: V; rt?: number};
const Cy: React.FC<CyP> = ({p, r, h, seg = 8, c, e, ei = 0, rot = [0, 0, 0], rt}) => (
  <mesh position={p} rotation={rot} castShadow receiveShadow>
    <cylinderGeometry args={[rt ?? r, r, h, seg]} />
    <Mat c={c} e={e} ei={ei} />
  </mesh>
);

const Co: React.FC<{p: V; r: number; h: number; seg?: number; c: string}> = ({p, r, h, seg = 6, c}) => (
  <mesh position={p} castShadow receiveShadow>
    <coneGeometry args={[r, h, seg]} />
    <Mat c={c} />
  </mesh>
);

const Ic: React.FC<{p: V; r: number; c: string; e?: string; ei?: number; s?: V; cast?: boolean}> = ({p, r, c, e, ei = 0, s = [1, 1, 1], cast = true}) => (
  <mesh position={p} scale={s} castShadow={cast}>
    <icosahedronGeometry args={[r, 0]} />
    <Mat c={c} e={e} ei={ei} />
  </mesh>
);

/* ---------- objek ---------- */
const Tree: React.FC<{p: V; s?: number; k?: number}> = ({p, s = 1, k = 0}) => {
  const g = ['#3f8f4a', '#4aa35a', '#2f7d45'][k % 3];
  return (
    <group position={p} scale={s}>
      <Cy p={[0, 1, 0]} r={0.25} h={2} seg={5} c="#7a5230" />
      <Co p={[0, 3, 0]} r={1.5} h={3} c={g} />
      <Co p={[0, 4.6, 0]} r={1.1} h={2.4} c={g} />
    </group>
  );
};

const Car: React.FC<{p: V; ry: number; c: string}> = ({p, ry, c}) => (
  <group position={p} rotation={[0, ry, 0]}>
    <Bx p={[0, 0.55, 0]} s={[4.2, 0.8, 1.9]} c={c} />
    <Bx p={[-0.2, 1.2, 0]} s={[2.3, 0.7, 1.7]} c={c} />
    <Bx p={[-0.2, 1.22, 0]} s={[2.0, 0.45, 1.74]} c="#bfe3f5" />
    {[[-1.3, -0.95], [-1.3, 0.95], [1.3, -0.95], [1.3, 0.95]].map(([x, z], i) => (
      <Cy key={i} p={[x, 0.35, z]} r={0.35} h={0.3} seg={8} c="#1d1d1d" rot={[Math.PI / 2, 0, 0]} />
    ))}
  </group>
);

const Lamp: React.FC<{p: V; glow: number}> = ({p, glow}) => (
  <group position={p}>
    <Cy p={[0, 2.5, 0]} r={0.09} h={5} seg={6} c="#3a3f45" />
    <Bx p={[0.35, 5.05, 0]} s={[0.8, 0.08, 0.08]} c="#3a3f45" />
    <Ic p={[0.7, 4.9, 0]} r={0.3} c="#fff3c4" e="#ffe39a" ei={0.15 + glow * 3} cast={false} />
  </group>
);

const Table: React.FC<{p: V}> = ({p}) => (
  <group position={p}>
    <Cy p={[0, 0.65, 0]} r={0.9} h={0.7} seg={8} c="#f7f3ea" />
    <Cy p={[0, 0.3, 0]} r={0.25} h={0.7} seg={6} c="#d8d2c4" />
    <Ic p={[0, 1.15, 0]} r={0.25} c="#e88fa6" />
    {Array.from({length: 6}, (_, i) => {
      const a = (i / 6) * Math.PI * 2;
      return (
        <group key={i} position={[Math.cos(a) * 1.35, 0, Math.sin(a) * 1.35]} rotation={[0, Math.PI / 2 - a, 0]}>
          <Bx p={[0, 0.5, 0]} s={[0.5, 0.45, 0.5]} c="#e5d3a6" />
          <Bx p={[0, 0.95, 0.22]} s={[0.5, 0.55, 0.08]} c="#e5d3a6" />
        </group>
      );
    })}
  </group>
);

const Sign: React.FC = () => {
  const tex = useMemo(() => {
    const cv = document.createElement('canvas');
    cv.width = 2048;
    cv.height = 332;
    const g = cv.getContext('2d')!;
    g.fillStyle = '#14352a';
    g.fillRect(0, 0, 2048, 332);
    g.strokeStyle = '#d9b45b';
    g.lineWidth = 10;
    g.strokeRect(14, 14, 2020, 304);
    g.fillStyle = '#f3d98b';
    g.font = 'bold 118px "DejaVu Serif", Georgia, serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText('Design by idin Iskandar', 1024, 176);
    const t = new THREE.CanvasTexture(cv);
    t.colorSpace = THREE.SRGBColorSpace;
    t.anisotropy = 8;
    return t;
  }, []);
  return (
    <group position={[0, 5.35, -31.3]}>
      <Bx p={[0, 0, 0]} s={[8.4, 1.5, 0.2]} c="#c9a24a" />
      <mesh position={[0, 0, 0.11]}>
        <planeGeometry args={[8, 1.3]} />
        <meshBasicMaterial map={tex} toneMapped={false} />
      </mesh>
    </group>
  );
};

/* ---------- scene utama ---------- */
const PASTELS = ['#d9d4cc', '#c9d3dc', '#e4cdbf', '#b9c4c0', '#dcd8e6'];
const CARS = ['#d94f4f', '#2f5da8', '#f2f2f2', '#2b2b2b', '#e0a82e', '#6a7f8c'];
const FLOWERS = ['#f4a6b8', '#ffffff', '#ffd1a6', '#e88fa6'];
const CLOUDS: V[] = [[-90, 60, -60], [-30, 64, -120], [60, 58, -90], [110, 62, -20], [-120, 56, 20], [-60, 66, 70], [20, 60, 130]];

export const Scene: React.FC<{t: number}> = ({t}) => {
  const frame = useCurrentFrame();
  const k = interpolate(t, [0.35, 1], [0, 1], CL); // siang -> senja
  const glow = interpolate(t, [0.5, 0.85], [0, 1], CL); // lampu menyala

  const sky = new THREE.Color('#8fcdf5').lerp(new THREE.Color('#f2a07a'), k);
  const sunColor = new THREE.Color('#fff4dc').lerp(new THREE.Color('#ff9a5a'), k);
  const sunPos: V = [45 + (-75 - 45) * k, 75 + (16 - 75) * k, 50 + (45 - 50) * k];

  const city = useMemo(
    () =>
      Array.from({length: 36}, (_, i) => {
        const a = random(`ca${i}`) * Math.PI * 2;
        const r = 90 + random(`cr${i}`) * 70;
        const w = 8 + random(`cw${i}`) * 14;
        const h = 10 + random(`ch${i}`) * 34;
        const d = 8 + random(`cd${i}`) * 14;
        return {p: [Math.cos(a) * r, h / 2, Math.sin(a) * r - 14] as V, s: [w, h, d] as V, c: PASTELS[Math.floor(random(`cc${i}`) * PASTELS.length)]};
      }),
    [],
  );

  const trees = useMemo(() => {
    const a: {p: V; s: number; k: number}[] = [];
    const add = (n: number, tag: string, fx: (r: number) => number, fz: (r: number) => number) => {
      for (let i = 0; i < n; i++) a.push({p: [fx(random(`${tag}x${i}`)), 0, fz(random(`${tag}z${i}`))], s: 0.8 + random(`${tag}s${i}`) * 0.7, k: i});
    };
    add(14, 'L', (r) => -(9 + r * 45), (r) => -2 + r * 22);
    add(8, 'R', (r) => 16 + r * 40, (r) => -30 + r * 28);
    add(4, 'P', (r) => 40 + r * 14, (r) => 2 + r * 20);
    add(8, 'B', (r) => -30 + r * 60, (r) => -38 - r * 10);
    return a;
  }, []);

  const cars = useMemo(() => {
    const a: {p: V; c: string}[] = [];
    for (let row = 0; row < 2; row++)
      for (let i = 0; i < 7; i++) {
        if (random(`car${row}${i}`) < 0.35) continue;
        a.push({p: [14.5 + i * 3.2, 0, row === 0 ? 5.5 : 18], c: CARS[Math.floor(random(`cc${row}${i}`) * CARS.length)]});
      }
    return a;
  }, []);

  return (
    <>
      <color attach="background" args={[sky]} />
      <fog attach="fog" args={[sky, 120, 330]} />
      <hemisphereLight args={[sky, '#6b8f5a', 0.7 - 0.25 * k]} />
      <directionalLight
        position={sunPos}
        color={sunColor}
        intensity={2.6 - 1.0 * k}
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-75}
        shadow-camera-right={75}
        shadow-camera-top={75}
        shadow-camera-bottom={-75}
        shadow-camera-near={1}
        shadow-camera-far={300}
        shadow-bias={-0.0004}
        shadow-normalBias={0.05}
      />

      {/* lampu hangat di dalam gedung */}
      {([[0, 5.5, -10], [0, 5.5, -20], [-9, 5.5, -15], [9, 5.5, -15], [0, 5.5, -28]] as V[]).map((p, i) => (
        <pointLight key={i} position={p} color="#ffe3b0" intensity={60 + glow * 30} distance={28} decay={2} />
      ))}

      {/* ===== tanah, jalan, kota ===== */}
      <mesh position={[0, -0.25, 0]} receiveShadow>
        <boxGeometry args={[500, 0.5, 500]} />
        <Mat c="#7fb069" />
      </mesh>
      <Bx p={[0, 0.02, 40]} s={[500, 0.06, 12]} c="#3a3d42" cast={false} />
      {Array.from({length: 19}, (_, i) => (
        <Bx key={i} p={[(i - 9) * 8, 0.07, 40]} s={[3, 0.02, 0.25]} c="#f5f5f5" cast={false} />
      ))}
      <Bx p={[0, 0.05, 32]} s={[500, 0.1, 4]} c="#bdbdb5" cast={false} />
      {city.map((b, i) => (
        <Bx key={i} p={b.p} s={b.s} c={b.c} />
      ))}
      {CLOUDS.map((p, i) => (
        <group key={i} position={[p[0] + frame * 0.015, p[1], p[2]]}>
          <Ic p={[0, 0, 0]} r={9} c="#ffffff" s={[1.6, 0.7, 1]} cast={false} />
          <Ic p={[8, -1, 2]} r={7} c="#f6f6f6" s={[1.4, 0.6, 1]} cast={false} />
          <Ic p={[-8, -1, -2]} r={6} c="#f6f6f6" s={[1.4, 0.6, 1]} cast={false} />
        </group>
      ))}

      {/* ===== halaman depan ===== */}
      <Bx p={[0, 0.03, 11]} s={[10, 0.06, 30]} c="#c7c3b8" cast={false} />
      <Bx p={[-5.8, 0.5, 11]} s={[1, 1, 28]} c="#2d7a4b" />
      <Bx p={[5.8, 0.5, 11]} s={[1, 1, 28]} c="#2d7a4b" />
      {Array.from({length: 11}, (_, i) => (
        <React.Fragment key={i}>
          <Ic p={[-5.8, 1.05, -2 + i * 2.6]} r={0.22} c={FLOWERS[i % 4]} cast={false} />
          <Ic p={[5.8, 1.05, -2 + i * 2.6]} r={0.22} c={FLOWERS[(i + 2) % 4]} cast={false} />
        </React.Fragment>
      ))}
      {/* pagar + gerbang */}
      <Bx p={[-33, 0.6, 26]} s={[54, 1.2, 0.4]} c="#efe9dc" />
      <Bx p={[33, 0.6, 26]} s={[54, 1.2, 0.4]} c="#efe9dc" />
      {[-6.6, 6.6].map((x) => (
        <React.Fragment key={x}>
          <Bx p={[x, 1.4, 26]} s={[1, 2.8, 1]} c="#efe9dc" />
          <Ic p={[x, 3.1, 26]} r={0.3} c="#fff3c4" e="#ffe39a" ei={0.2 + glow * 3} cast={false} />
        </React.Fragment>
      ))}
      {([[-7, 0, 2], [7, 0, 2], [-7, 0, 10], [7, 0, 10], [-7, 0, 18], [7, 0, 18], [20, 0, 12], [30, 0, 12]] as V[]).map((p, i) => (
        <Lamp key={i} p={p} glow={glow} />
      ))}

      {/* ===== parkir ===== */}
      <Bx p={[24, 0.04, 13]} s={[24, 0.08, 22]} c="#4a4d52" cast={false} />
      <Bx p={[8.5, 0.04, 14]} s={[7, 0.08, 6]} c="#4a4d52" cast={false} />
      {Array.from({length: 8}, (_, i) => (
        <React.Fragment key={i}>
          <Bx p={[13 + i * 3.2, 0.1, 5.5]} s={[0.12, 0.02, 6.8]} c="#f2f2f2" cast={false} />
          <Bx p={[13 + i * 3.2, 0.1, 18]} s={[0.12, 0.02, 6.8]} c="#f2f2f2" cast={false} />
        </React.Fragment>
      ))}
      {cars.map((c, i) => (
        <Car key={i} p={c.p} ry={Math.PI / 2} c={c.c} />
      ))}

      {/* ===== pohon ===== */}
      {trees.map((tr, i) => (
        <Tree key={i} p={tr.p} s={tr.s} k={tr.k} />
      ))}

      {/* ===== gedung ===== */}
      <Bx p={[0, 0.15, -18]} s={[28, 0.3, 28]} c="#d8d2c4" />
      <Bx p={[0, 0.15, -1.5]} s={[14, 0.3, 5]} c="#cfc9bb" />
      <Bx p={[0, 3.8, -32]} s={[28, 7, 0.5]} c="#efe9dc" />
      <Bx p={[-14, 3.8, -18]} s={[0.5, 7, 28]} c="#efe9dc" />
      <Bx p={[14, 3.8, -18]} s={[0.5, 7, 28]} c="#efe9dc" />
      <Bx p={[-9.25, 3.8, -4]} s={[9.5, 7, 0.5]} c="#f2eee6" />
      <Bx p={[9.25, 3.8, -4]} s={[9.5, 7, 0.5]} c="#f2eee6" />
      <Bx p={[0, 6.85, -4]} s={[28.2, 0.9, 0.6]} c="#2f4b5a" />
      {[-12, -7, 7, 12].map((x) => (
        <Bx key={x} p={[x, 3.4, -3.7]} s={[2.4, 3.6, 0.15]} c="#9fd0e6" e="#cfeaff" ei={0.15 + glow * 0.8} />
      ))}
      <Bx p={[0, 7.6, -18]} s={[31, 0.6, 31]} c="#5b6770" />
      <Bx p={[0, 7.2, -18]} s={[27.4, 0.2, 27.4]} c="#f5f1e8" cast={false} />
      <Bx p={[0, 9.2, -3]} s={[12, 3.4, 3.5]} c="#f1ede4" />
      <Bx p={[0, 8.0, -1.2]} s={[12, 0.25, 0.2]} c="#c9a24a" e="#ffd98a" ei={glow * 1.5} />
      {[-5.2, 5.2].map((x) => (
        <Bx key={x} p={[x, 3.9, -2]} s={[0.7, 7.2, 0.7]} c="#ffffff" />
      ))}
      {[-3, 3].map((x) => (
        <React.Fragment key={x}>
          <Bx p={[x, 0.55, 0.2]} s={[1.4, 0.5, 0.9]} c="#d9d3c5" />
          <Ic p={[x - 0.35, 1.0, 0.2]} r={0.3} c="#f4a6b8" cast={false} />
          <Ic p={[x + 0.35, 1.0, 0.2]} r={0.3} c="#ffffff" cast={false} />
        </React.Fragment>
      ))}

      {/* ===== area tamu ===== */}
      <Bx p={[0, 0.32, -14.5]} s={[2.2, 0.04, 21]} c="#8c1d2c" cast={false} />
      {[-10, -5.5, 5.5, 10].flatMap((x) => [-10, -15, -20].map((z) => <Table key={`${x}${z}`} p={[x, 0.3, z]} />))}
      {([[0, -12], [0, -20], [-9, -15], [9, -15]] as [number, number][]).map(([x, z], i) => (
        <group key={i} position={[x, 0, z]}>
          <Cy p={[0, 6.6, 0]} r={0.03} h={1.2} seg={4} c="#555" />
          <Ic p={[0, 5.9, 0]} r={0.55} c="#fff1cf" e="#ffe2a8" ei={1.4} cast={false} />
        </group>
      ))}

      {/* ===== pelaminan ===== */}
      <Bx p={[0, 0.7, -28]} s={[14, 0.8, 6.5]} c="#efe9dc" />
      <Bx p={[0, 0.5, -24.4]} s={[5, 0.4, 0.8]} c="#e2dccd" />
      <Bx p={[0, 1.12, -28]} s={[10, 0.04, 5]} c="#8c1d2c" cast={false} />
      <Bx p={[0, 3.7, -31.6]} s={[15, 6.8, 0.4]} c="#f4efe6" />
      <Bx p={[0, 3.5, -31.38]} s={[12, 5.8, 0.1]} c="#e6d6b8" />
      {[-6.8, 6.8].map((x) => (
        <Bx key={x} p={[x, 3.7, -31]} s={[0.7, 6.8, 0.7]} c="#c9a24a" />
      ))}
      <Bx p={[0, 1.2, -31.2]} s={[11, 0.08, 0.05]} c="#ffe2a8" e="#ffd98a" ei={1.5} cast={false} />
      {Array.from({length: 14}, (_, i) => (
        <Ic key={i} p={[-6.5 + i, 1.7 + (i % 3) * 0.35, -31.0]} r={0.45} c={FLOWERS[i % 4]} cast={false} />
      ))}
      <Bx p={[0, 1.45, -29.6]} s={[3.6, 0.7, 1.3]} c="#c9a24a" />
      <Bx p={[0, 2.1, -30.2]} s={[3.6, 1.4, 0.3]} c="#c9a24a" />
      {[-3.2, 3.2].map((x) => (
        <React.Fragment key={x}>
          <Bx p={[x, 1.4, -29.4]} s={[1.1, 0.6, 1]} c="#e5d3a6" />
          <Bx p={[x, 1.95, -29.85]} s={[1.1, 0.8, 0.2]} c="#e5d3a6" />
        </React.Fragment>
      ))}
      {[-8, 8].map((x) => (
        <React.Fragment key={x}>
          <Cy p={[x, 1.6, -29]} r={0.35} h={1} seg={6} c="#d9d3c5" />
          <Ic p={[x, 2.4, -29]} r={0.7} c="#f4a6b8" cast={false} />
          <Ic p={[x + 0.3, 2.9, -29]} r={0.45} c="#ffffff" cast={false} />
        </React.Fragment>
      ))}
      <Sign />
    </>
  );
};
