# video-parkir-ghaib

Video Remotion "POV tukang parkir portal gaib" — 9:16 (1080x1920), 30 fps, ±53,7 detik.
Gaya visual: ilustrasi vektor cerah (sama dengan storyboard), caption karaoke per kata.

## Struktur

```
video-parkir-ghaib/
├── package.json        # remotion & @remotion/* dipin 4.0.250, skrip "render"
├── tsconfig.json
├── timing.cjs          # pembuat src/timing.json (ffmpeg silencedetect + DP ke kalimat)
├── narasi.txt          # teks narasi, satu kalimat per baris (masukan timing.cjs)
├── public/
│   └── narasi.mp3      # audio narasi (dibaca lewat staticFile)
└── src/
    ├── index.ts        # registerRoot
    ├── Root.tsx        # pembungkus Remotion: frame -> t, <Audio>, durasi dari timing.json
    ├── Video.tsx       # komposisi inti React murni: Video({ t })
    └── timing.json     # durasi, fps, kalimat + waktu tiap kata (hasil timing.cjs)
```

## Menjalankan di GitHub Actions (render-remotion.yml, workflow_dispatch)

Langkah yang dibutuhkan job-nya:

1. `actions/checkout`, `actions/setup-node` (Node 18+ atau 20).
2. `working-directory: video-parkir-ghaib`, lalu `npm install` (tidak ada package-lock.json; gunakan `npm install`, bukan `npm ci`).
3. `npm run render`, hasilnya di `video-parkir-ghaib/out/video.mp4`.
4. `actions/upload-artifact` dengan path `video-parkir-ghaib/out/video.mp4`.

Runner `ubuntu-latest` sudah cukup; Remotion mengunduh Chromium sendiri saat render pertama.

## Catatan

- Samakan versi Remotion dengan repo kamu: ubah `4.0.250` di `package.json` (semua paket `remotion` / `@remotion/*` harus satu versi).
- Font Fredoka dimuat lewat `@remotion/google-fonts` (perlu internet di runner, aman di GitHub Actions).
- Timing dibuat ulang bila audio/teks berubah: letakkan audio di `public/narasi.mp3`, edit `narasi.txt`, jalankan `node timing.cjs` (butuh `ffmpeg`/`ffprobe`). Opsi: `FPS=30 W=1080 H=1920`.
- Cue animasi di `Video.tsx` memakai kata dari `timing.json` (fungsi `cue(kalimat, kata)`); bila teks berubah, sesuaikan kata cue-nya. Cue yang tidak ditemukan membuat render gagal dengan pesan jelas.
- Layout dirancang untuk 9:16. Untuk 16:9 perlu tata letak ulang di `Video.tsx`.
