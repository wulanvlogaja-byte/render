#!/usr/bin/env node
// Hitung timing narasi dari audio: ffmpeg silencedetect -> DP monoton ke kalimat -> waktu per kata.
// Pakai:  node timing.cjs [audio] [narasi.txt] [out]      env: FPS (30), W (1080), H (1920)
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const audio = process.argv[2] || path.join(__dirname, 'public', 'narasi.mp3');
const textFile = process.argv[3] || path.join(__dirname, 'narasi.txt');
const out = process.argv[4] || path.join(__dirname, 'src', 'timing.json');
const FPS = +(process.env.FPS || 30), W = +(process.env.W || 1080), H = +(process.env.H || 1920);
const NOISE = '-35dB', MIN_SIL = 0.25, MIN_SEG = 0.05;

const probe = spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', audio], { encoding: 'utf8' });
const dur = parseFloat(probe.stdout);
if (!(dur > 0)) throw new Error('ffprobe gagal membaca durasi audio');

const sd = spawnSync('ffmpeg', ['-hide_banner', '-nostats', '-i', audio, '-af', `silencedetect=noise=${NOISE}:d=${MIN_SIL}`, '-f', 'null', '-'], { encoding: 'utf8' });
const sil = [];
let open = null;
for (const line of sd.stderr.split('\n')) {
  let m;
  if ((m = line.match(/silence_start:\s*(-?[\d.]+)/))) open = Math.max(0, parseFloat(m[1]));
  else if ((m = line.match(/silence_end:\s*(-?[\d.]+)/)) && open !== null) { sil.push([open, parseFloat(m[1])]); open = null; }
}
if (open !== null) sil.push([open, dur]);

const segs = [];
let cur = 0;
for (const [a, b] of sil) { if (a - cur > MIN_SEG) segs.push({ a: cur, b: a }); cur = Math.max(cur, b); }
if (dur - cur > MIN_SEG) segs.push({ a: cur, b: dur });

const sents = fs.readFileSync(textFile, 'utf8').split('\n').map((s) => s.trim()).filter(Boolean);
const chars = sents.map((s) => s.replace(/[^\p{L}\p{N}]/gu, '').length);
const N = sents.length, M = segs.length;
if (M < N) throw new Error(`segmen bicara (${M}) < kalimat (${N}); longgarkan noise/durasi silence`);

const median = (xs) => { const s = [...xs].sort((a, b) => a - b); return s[Math.floor(s.length / 2)]; };
let r0 = chars.reduce((a, b) => a + b, 0) / segs.reduce((a, s) => a + (s.b - s.a), 0);
let assign = null;
for (let iter = 0; iter < 4; iter++) {
  const INF = 1e18;
  const dp = Array.from({ length: N + 1 }, () => new Array(M + 1).fill(INF));
  const bp = Array.from({ length: N + 1 }, () => new Array(M + 1).fill(-1));
  dp[0][0] = 0;
  for (let i = 1; i <= N; i++) for (let j = i; j <= M; j++) for (let a = i - 1; a < j; a++) {
    if (dp[i - 1][a] >= INF) continue;
    const span = segs[j - 1].b - segs[a].a;
    const c = Math.abs(Math.log(chars[i - 1] / span / r0)) + 0.12 * (j - a - 1);
    if (dp[i - 1][a] + c < dp[i][j]) { dp[i][j] = dp[i - 1][a] + c; bp[i][j] = a; }
  }
  if (dp[N][M] >= INF) throw new Error('DP gagal menyelaraskan');
  assign = new Array(N);
  for (let i = N, j = M; i > 0; i--) { const a = bp[i][j]; assign[i - 1] = [a, j]; j = a; }
  r0 = median(assign.map(([a, b], i) => chars[i] / (segs[b - 1].b - segs[a].a)));
}

const r3 = (x) => Math.round(x * 1000) / 1000;
const sentences = sents.map((text, i) => {
  const [a, b] = assign[i];
  const ss = segs.slice(a, b);
  const total = ss.reduce((acc, s) => acc + (s.b - s.a), 0);
  const words = text.split(/\s+/);
  const wt = words.map((w) => w.replace(/[^\p{L}\p{N}]/gu, '').length + 1.2);
  const sumW = wt.reduce((x, y) => x + y, 0);
  const at = (f) => {
    let rest = f * total;
    for (const s of ss) { const d = s.b - s.a; if (rest <= d) return s.a + rest; rest -= d; }
    return ss[ss.length - 1].b;
  };
  let acc = 0;
  const out = words.map((w, k) => {
    const s = at(acc / sumW); acc += wt[k]; const e = at(acc / sumW);
    return { w, start: r3(s), end: r3(e) };
  });
  const start = ss[0].a, end = ss[ss.length - 1].b;
  return { i, text, start: r3(start), end: r3(end), chars: chars[i], rate: r3(chars[i] / (end - start)), words: out };
});

const med = median(sentences.map((s) => s.rate));
let warn = 0;
for (const s of sentences) {
  const ratio = s.rate / med;
  const flag = ratio < 0.6 || ratio > 1.6;
  if (flag) warn++;
  console.log(`${String(s.i).padStart(2)} ${s.start.toFixed(2).padStart(6)}-${s.end.toFixed(2).padStart(6)}  ${s.rate.toFixed(1).padStart(5)} c/s  x${ratio.toFixed(2)}${flag ? '  <-- LAJU ANEH' : ''}  ${s.text.slice(0, 40)}`);
}
for (let i = 1; i < sentences.length; i++) if (sentences[i].start < sentences[i - 1].end - 1e-6) throw new Error('urutan tidak monoton di kalimat ' + i);
console.log(`segmen=${M} kalimat=${N} median=${med.toFixed(1)} c/s peringatan=${warn}`);

fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify({ audio: 'narasi.mp3', duration: r3(dur), fps: FPS, width: W, height: H, noise: NOISE, minSilence: MIN_SIL, sentences }, null, 1));
console.log('tulis', out);
