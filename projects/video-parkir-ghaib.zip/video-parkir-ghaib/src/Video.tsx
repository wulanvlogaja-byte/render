import React from 'react';
import timing from './timing.json';

// ---------- util murni (semua fungsi dari t, tanpa state/timer/random) ----------
const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const prog = (t: number, t0: number, d: number) => clamp((t - t0) / d);
const eOut = (k: number) => 1 - Math.pow(1 - clamp(k), 3);
const eBack = (k: number) => { k = clamp(k); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };
const pop = (t: number, t0: number, d = 0.4) => eBack(prog(t, t0, d));
const hash = (n: number) => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
const mixHex = (a: string, b: string, k: number) => {
  const p = (h: string, i: number) => parseInt(h.slice(1 + i * 2, 3 + i * 2), 16);
  const c = [0, 1, 2].map((i) => Math.round(lerp(p(a, i), p(b, i), clamp(k))));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
};

// ---------- cue visual diambil dari kata di timing.json ----------
type Word = { w: string; start: number; end: number };
type Sent = { i: number; text: string; start: number; end: number; words: Word[] };
const S = timing.sentences as Sent[];
const norm = (w: string) => w.toLowerCase().replace(/[^a-z0-9]/g, '');
const cue = (s: number, word: string, n = 0): number => {
  let c = 0;
  for (const w of S[s].words) if (norm(w.w) === word) { if (c === n) return w.start; c++; }
  throw new Error(`cue "${word}" tidak ada di kalimat ${s}`);
};
const cueEnd = (s: number, word: string): number => {
  for (const w of S[s].words) if (norm(w.w) === word) return w.end;
  throw new Error(`cue "${word}" tidak ada di kalimat ${s}`);
};
const sStart = (s: number) => S[s].start;
const sEnd = (s: number) => S[s].end;

// adegan = rentang kalimat
const SCENES: [number, number][] = [[0, 1], [2, 2], [3, 3], [4, 4], [5, 5], [6, 6], [7, 8], [9, 10], [11, 13], [14, 14], [15, 16], [17, 17]];
const scStart = (k: number) => (k === 0 ? 0 : sStart(SCENES[k][0]));
const TR = 0.35; // durasi transisi
const trAt = (k: number) => scStart(k) - 0.2;

// ---------- karakter (koordinat 60x100, titik tumpu di kaki) ----------
type CP = { x: number; y: number; w: number; h: number; rot?: number; sx?: number; sy?: number; t?: number; op?: number };
const Place: React.FC<CP & { children: React.ReactNode }> = ({ x, y, w, h, rot = 0, sx = 1, sy = 1, op = 1, children }) => (
  <g opacity={op} transform={`translate(${x + w / 2} ${y + h}) rotate(${rot}) scale(${(sx * w) / 60} ${(sy * h) / 100}) translate(-30 -100)`}>{children}</g>
);
const blink = (t = 0, o = 0) => (((t + o) % 3.4) < 0.12 ? 0.15 : 1);

const Hero: React.FC<CP & { mood?: 'smile' | 'sad' | 'shock' | 'wow'; arm?: number }> = ({ mood = 'smile', arm = 0, ...p }) => {
  const b = blink(p.t, 0.3);
  return (
    <Place {...p}>
      <g transform={`rotate(${-arm} 48 46)`}><rect x="44" y="42" width="8" height="24" rx="4" fill="#ff8a1f" /><circle cx="48" cy={arm > 60 ? 66 : 66} r="4.5" fill="#f2c9a0" /></g>
      <rect x="8" y="42" width="8" height="24" rx="4" fill="#ff8a1f" />
      <rect x="16" y="40" width="28" height="36" rx="6" fill="#ff8a1f" />
      <rect x="16" y="54" width="28" height="4" fill="#fff59d" />
      <rect x="20" y="74" width="8" height="24" fill="#334155" /><rect x="32" y="74" width="8" height="24" fill="#334155" />
      <circle cx="30" cy="26" r="13" fill="#f2c9a0" />
      <path d="M16 22 Q30 2 44 22Z" fill="#1d4ed8" /><rect x="30" y="20" width="20" height="5" rx="2" fill="#1d4ed8" />
      {mood === 'shock' || mood === 'wow' ? (<><ellipse cx="26" cy="28" rx="2.4" ry={2.8 * b} fill="#222" /><ellipse cx="34" cy="28" rx="2.4" ry={2.8 * b} fill="#222" /><ellipse cx="30" cy="35" rx="2.6" ry="3.2" fill="#7f1d1d" /></>) : (<><ellipse cx="26" cy="28" rx="1.8" ry={1.8 * b} fill="#222" /><ellipse cx="34" cy="28" rx="1.8" ry={1.8 * b} fill="#222" />
        {mood === 'sad' ? <path d="M26 36 Q30 33 34 36" stroke="#222" fill="none" /> : <path d="M25 34 Q30 39 35 34" stroke="#222" fill="none" strokeWidth="1.4" />}</>)}
    </Place>
  );
};
const Kunti: React.FC<CP> = (p) => {
  const b = blink(p.t, 1.1);
  return (
    <Place {...p}>
      <path d="M10 22 Q30 -6 50 22 L54 85 L6 85Z" fill="#2b2140" />
      <path d="M14 42 L46 42 L56 98 L4 98Z" fill="#fff" stroke="#d6d3e0" />
      <circle cx="30" cy="30" r="13" fill="#eee9dc" />
      <ellipse cx="25" cy="29" rx="2.2" ry={2.2 * b} fill="#2b2140" /><ellipse cx="35" cy="29" rx="2.2" ry={2.2 * b} fill="#2b2140" />
      <path d="M26 36 Q30 39 34 36" stroke="#d62839" fill="none" strokeWidth="2.5" />
    </Place>
  );
};
const Pocong: React.FC<CP & { angry?: boolean }> = ({ angry, ...p }) => {
  const b = blink(p.t, 2.0);
  return (
    <Place {...p}>
      <ellipse cx="30" cy="54" rx="20" ry="42" fill="#fff" stroke="#d6d3e0" />
      <circle cx="30" cy="28" r="11" fill="#eee9dc" />
      <ellipse cx="26" cy="27" rx="2" ry={2 * b} fill="#222" /><ellipse cx="34" cy="27" rx="2" ry={2 * b} fill="#222" />
      {angry && <path d="M22 21 L29 25 M38 21 L31 25" stroke="#7f1d1d" strokeWidth="2" strokeLinecap="round" />}
      {angry ? <path d="M26 36 Q30 32 34 36" stroke="#222" fill="none" strokeWidth="1.5" /> : <ellipse cx="30" cy="34" rx="3" ry="2" fill="#222" />}
      <rect x="22" y="40" width="16" height="3" fill="#b8b4c8" /><rect x="22" y="70" width="16" height="3" fill="#b8b4c8" /><rect x="22" y="92" width="16" height="3" fill="#b8b4c8" />
    </Place>
  );
};
const Tuyul: React.FC<CP> = (p) => {
  const b = blink(p.t, 0.7);
  return (
    <Place {...p}>
      <rect x="14" y="50" width="32" height="26" rx="8" fill="#38bdf8" />
      <rect x="18" y="74" width="9" height="20" fill="#9ccf8f" /><rect x="33" y="74" width="9" height="20" fill="#9ccf8f" />
      <circle cx="12" cy="30" r="6" fill="#9ccf8f" /><circle cx="48" cy="30" r="6" fill="#9ccf8f" />
      <circle cx="30" cy="30" r="18" fill="#9ccf8f" />
      <ellipse cx="24" cy="30" rx="3" ry={3 * b} fill="#222" /><ellipse cx="36" cy="30" rx="3" ry={3 * b} fill="#222" />
      <path d="M23 40 Q30 46 37 40Z" fill="#fff" stroke="#222" />
    </Place>
  );
};

// ---------- properti dekor ----------
const Coin: React.FC<{ x: number; y: number; r: number; spin?: number; label?: string; op?: number }> = ({ x, y, r, spin = 0, label, op = 1 }) => {
  const k = Math.max(0.12, Math.abs(Math.cos(spin)));
  return (
    <g opacity={op} transform={`translate(${x} ${y}) scale(${k} 1)`}>
      <circle r={r} fill="#fbbf24" stroke="#d97706" strokeWidth={Math.max(1.2, r / 9)} />
      <circle r={r * 0.78} fill="none" stroke="#fde68a" strokeWidth={Math.max(0.8, r / 14)} />
      {label && k > 0.5 ? <text y={r * 0.12} textAnchor="middle" fontSize={r * 0.42} fontWeight={700} fill="#92400e">{label}</text> : null}
    </g>
  );
};
const Bubble: React.FC<{ x: number; y: number; w: number; text: string; k: number; color?: string; tail?: 'l' | 'r' }> = ({ x, y, w, text, k, color = '#8b5cf6', tail = 'r' }) => (
  <g transform={`translate(${x + w / 2} ${y + 17}) scale(${k}) translate(${-w / 2} -17)`} opacity={clamp(k * 2)}>
    <rect width={w} height="26" rx="12" fill="#fff" stroke={color} strokeWidth="1.5" />
    <path d={tail === 'r' ? `M${w - 22} 25 l4 9 l7 -9Z` : `M14 25 l-1 9 l9 -9Z`} fill="#fff" stroke={color} strokeWidth="1.5" strokeLinejoin="round" />
    <rect x={tail === 'r' ? w - 23 : 12} y="23" width="14" height="4" fill="#fff" />
    <text x={w / 2} y="17.5" textAnchor="middle" fontSize="11" fontWeight={700} fill={color}>{text}</text>
  </g>
);
const Clouds: React.FC<{ t: number; y?: number }> = ({ t, y = 62 }) => (
  <g opacity="0.9">
    {[0, 1, 2].map((i) => {
      const x = ((hash(i + 3) * 260 + t * (4 + i * 2)) % 260) - 40;
      const yy = y + i * 26 + hash(i) * 10;
      return <g key={i} transform={`translate(${x} ${yy})`} fill="#fff"><ellipse cx="0" cy="0" rx="16" ry="6" /><ellipse cx="9" cy="-4" rx="9" ry="6" /><ellipse cx="-8" cy="-3" rx="7" ry="5" /></g>;
    })}
  </g>
);
const Ground: React.FC<{ c?: string }> = ({ c = '#9be37a' }) => (<><rect y="255" width="180" height="65" fill={c} /><rect y="255" width="180" height="3" fill="#000" opacity="0.06" /></>);
const Sparks: React.FC<{ t: number; t0: number; cx: number; cy: number; n?: number; r?: number; color?: string }> = ({ t, t0, cx, cy, n = 8, r = 30, color = '#fde047' }) => {
  const k = prog(t, t0, 0.7);
  if (k <= 0 || k >= 1) return null;
  return <g>{Array.from({ length: n }, (_, i) => { const a = (i / n) * Math.PI * 2 + hash(i) * 0.6; const d = eOut(k) * r * (0.6 + hash(i + 9) * 0.6); return <circle key={i} cx={cx + Math.cos(a) * d} cy={cy + Math.sin(a) * d} r={3 * (1 - k)} fill={color} />; })}</g>;
};
const Portal: React.FC<{ t: number; cx: number; cy: number; rx: number; ry: number; k?: number; glow?: number; tape?: number[]; cracks?: number }> = ({ t, cx, cy, rx, ry, k = 1, glow = 0, tape, cracks = 0 }) => {
  const pulse = 1 + Math.sin(t * 3) * 0.03;
  const s = k * pulse;
  return (
    <g transform={`translate(${cx} ${cy}) scale(${s})`}>
      <ellipse rx={rx} ry={ry} fill="#7c3aed" /><ellipse rx={rx * 0.77} ry={ry * 0.83} fill="#c4b5fd" /><ellipse rx={rx * 0.5} ry={ry * 0.6} fill="#f5f3ff" />
      {[0, 1, 2, 3, 4, 5].map((i) => { const a = t * 0.9 + (i * Math.PI) / 3; return <circle key={i} cx={Math.cos(a) * rx * 0.65} cy={Math.sin(a) * ry * 0.72} r="2.4" fill="#fde047" />; })}
      <path d={`M${-rx * 0.3} ${ry * 0.1} q${rx * 0.3} ${-ry * 0.35} ${rx * 0.6} 0 q${-rx * 0.3} ${ry * 0.35} ${-rx * 0.6} 0`} fill="none" stroke="#8b5cf6" strokeWidth="1.4" opacity={0.7} transform={`rotate(${t * 60})`} />
      {glow > 0 && <ellipse rx={rx * (1 + glow * 0.18)} ry={ry * (1 + glow * 0.12)} fill="none" stroke="#fde047" strokeWidth={2.5 * glow} opacity={0.8} />}
      {cracks > 0 && <path d={`M0 ${-ry} l${-6 * cracks} ${ry * 0.3 * cracks} l${10 * cracks} ${ry * 0.2 * cracks} l${-8 * cracks} ${ry * 0.3 * cracks}`} stroke="#1e1b4b" strokeWidth="2.2" fill="none" strokeLinejoin="round" />}
      {tape && tape.map((q, i) => {
        const L = rx * 2.4 * q;
        const ang = [-14, 10, -8, 84][i] ?? 0; const off = [-ry * 0.55, 0, ry * 0.55, 0][i] ?? 0;
        return <rect key={i} x={-L / 2} y={off - 7} width={L} height="14" fill="#1f2937" transform={`rotate(${ang})`} />;
      })}
    </g>
  );
};
const Barrier: React.FC<{ x: number; y: number; arm: number }> = ({ x, y, arm }) => (
  <g>
    <rect x={x - 6} y={y - 10} width="10" height="40" rx="2" fill="#64748b" />
    <g transform={`rotate(${-arm} ${x} ${y})`}>
      <rect x={x} y={y - 4} width="130" height="9" fill="#fff" stroke="#e5e7eb" />
      {[0, 1, 2, 3].map((i) => <rect key={i} x={x + 8 + i * 30} y={y - 4} width="14" height="9" fill="#ef4444" />)}
    </g>
  </g>
);
const Tag: React.FC<{ x: number; y: number; w: number; text: string; fill: string; color: string; k?: number }> = ({ x, y, w, text, fill, color, k = 1 }) => (
  <g transform={`translate(${x + w / 2} ${y + 8}) scale(${k}) translate(${-w / 2} -8)`} opacity={clamp(k * 2)}><rect width={w} height="17" rx="8" fill={fill} /><text x={w / 2} y="12.5" textAnchor="middle" fontSize="9.5" fontWeight={700} fill={color}>{text}</text></g>
);

// ---------- adegan ----------
type SP = { t: number };

const Scene1: React.FC<SP> = ({ t }) => {
  const l = t;
  const hero = pop(t, 0.05);
  const portalK = pop(t, cue(0, 'portal'), 0.5);
  const man = pop(t, cue(1, 'manusia')), jin = pop(t, cue(1, 'jin'));
  const gate = pop(t, cue(1, 'gerbang'));
  return (
    <g>
      <rect y="0" width="180" height="320" fill="#cfeeff" /><Clouds t={l} /><Ground />
      <Portal t={t} cx={90} cy={132} rx={60} ry={82} k={0.001 + portalK} glow={prog(t, cue(1, 'gerbang'), 0.5) * (1 - prog(t, cue(1, 'gerbang') + 0.6, 0.6))} />
      <g transform={`translate(0 ${(1 - man) * 20})`} opacity={clamp(man * 2)}>
        <rect x="6" y="206" width="34" height="30" fill="#fde68a" stroke="#b45309" strokeWidth="1.2" /><path d="M2 208 L23 188 L44 208Z" fill="#ef4444" /><rect x="18" y="216" width="10" height="20" fill="#92400e" /><rect x="10" y="212" width="7" height="7" fill="#bae6fd" />
      </g>
      <Tag x={4} y={170} w={50} text="MANUSIA" fill="#16a34a" color="#fff" k={man} />
      <g transform={`translate(0 ${(1 - jin) * 20})`} opacity={clamp(jin * 2)}>
        <path d="M146 236 L146 214 Q160 196 174 214 L174 236Z" fill="#cbd5e1" stroke="#64748b" strokeWidth="1.2" /><rect x="158" y="206" width="3" height="12" fill="#64748b" /><rect x="154" y="210" width="11" height="3" fill="#64748b" />
        <path d="M148 190 q4 -14 10 0 q4 -12 10 2" fill="none" stroke="#7c3aed" strokeWidth="2" />
      </g>
      <Tag x={138} y={170} w={36} text="JIN" fill="#7c3aed" color="#fff" k={jin} />
      <Barrier x={26} y={236} arm={Math.sin(prog(t, cue(1, 'gerbang'), 0.6) * Math.PI) * 14} />
      <Hero t={t} x={62} y={176} w={56} h={94 * (0.6 + 0.4 * hero)} sy={1} mood="smile" arm={prog(t, cue(0, 'parkir'), 0.3) * 150 * (1 - prog(t, cue(0, 'parkir') + 0.9, 0.3))} op={clamp(hero * 3)} />
      <g opacity={clamp(prog(t, 0.2, 0.3) * (1 - prog(t, cue(0, 'tukang'), 0.3)))}><rect x="60" y="60" width="60" height="22" rx="11" fill="#1e1b4b" /><text x="90" y="75.5" textAnchor="middle" fontSize="12" fontWeight={700} fill="#fde047">POV</text></g>
    </g>
  );
};

const Scene2: React.FC<SP> = ({ t }) => {
  const c0 = cue(2, 'dua'), cH = cue(2, 'hantu');
  const big = pop(t, c0, 0.5);
  const gh = pop(t, cue(2, 'per'), 0.4);
  const fly = (i: number) => prog(t, cH + i * 0.18, 0.55);
  return (
    <g>
      <rect width="180" height="320" fill="#fff3b0" /><Ground />
      {Array.from({ length: 10 }, (_, i) => <circle key={i} cx={hash(i) * 180} cy={40 + hash(i + 5) * 120} r={1.5 + hash(i + 2) * 2} fill="#fbbf24" opacity={0.55 + Math.sin(t * 3 + i) * 0.3} />)}
      <g transform={`translate(90 95) scale(${big}) rotate(${Math.sin(t * 2) * 4})`}><Coin x={0} y={0} r={52} spin={prog(t, cue(2, 'perak'), 0.7) * Math.PI * 2} label="Rp2.000" /></g>
      <Kunti t={t} x={6} y={196} w={36} h={60 * gh} />
      <Pocong t={t} x={138} y={196} w={36} h={60 * gh} />
      {[0, 1].map((i) => { const k = fly(i); if (k <= 0 || k >= 1) return null; const sx = i === 0 ? 24 : 156; return <Coin key={i} x={lerp(sx, 90, eOut(k))} y={lerp(210, 215, k) - Math.sin(k * Math.PI) * 50} r={8} spin={k * 12} />; })}
      <Hero t={t} x={62} y={176} w={56} h={94} mood="smile" arm={prog(t, cH, 0.3) * 120} />
      <g opacity={clamp(prog(t, cH + 0.4, 0.2)) * (1 - prog(t, cH + 1.2, 0.4))} transform={`translate(0 ${-prog(t, cH + 0.4, 1) * 14})`}><text x="90" y="168" textAnchor="middle" fontSize="13" fontWeight={700} fill="#15803d">+ Rp2.000</text></g>
    </g>
  );
};

const Scene3: React.FC<SP> = ({ t }) => {
  const kw = cue(3, 'kuntilanak'), gr = cue(3, 'gratis');
  const night = prog(t, cue(3, 'malam'), 0.6);
  const enter = eOut(prog(t, kw - 0.1, 0.7));
  const kx = lerp(210, 98, enter);
  return (
    <g>
      <rect width="180" height="320" fill={mixHex('#fde9c9', '#e3d9ff', night)} /><Ground c="#a7e08a" />
      <circle cx={140} cy={lerp(120, 62, night)} r="22" fill="#fef9c3" /><circle cx={149} cy={lerp(116, 58, night)} r="18" fill={mixHex('#fde9c9', '#e3d9ff', night)} />
      {Array.from({ length: 12 }, (_, i) => <circle key={i} cx={hash(i + 40) * 170 + 5} cy={40 + hash(i + 70) * 90} r="1.8" fill="#fde047" opacity={night * (0.5 + 0.5 * Math.sin(t * 4 + i * 2))} />)}
      <g transform={`translate(0 ${Math.sin(t * 2) * 0})`}><rect x="10" y="150" width="34" height="34" rx="6" fill="#2563eb" /><text x="27" y="175" textAnchor="middle" fontSize="22" fontWeight={700} fill="#fff">P</text><rect x="25" y="184" width="4" height="72" fill="#64748b" /></g>
      <Kunti t={t} x={kx} y={150 - Math.sin(t * 3) * 4 * enter} w={68} h={112} rot={Math.sin(t * 2.5) * 3} op={clamp(enter * 3)} />
      <Bubble x={46} y={102} w={104} text="Gratis ya?" k={pop(t, gr, 0.45)} />
      <Sparks t={t} t0={gr} cx={120} cy={150} />
      <Hero t={t} x={26} y={190} w={44} h={74} mood={t > gr ? 'sad' : 'smile'} arm={prog(t, kw + 0.2, 0.3) * 150 * 0.0} />
    </g>
  );
};

const Scene4: React.FC<SP> = ({ t }) => {
  const pw = cue(4, 'pocong'), dk = cue(4, 'diskon'), mb = cue(4, 'member');
  const enter = eOut(prog(t, pw - 0.1, 0.7));
  const hop = Math.abs(Math.sin(t * 6)) * 10 * (enter < 1 ? 1 : 0.35);
  return (
    <g>
      <rect width="180" height="320" fill="#ffe0ec" /><Clouds t={t} y={50} /><Ground />
      <Pocong t={t} x={lerp(210, 88, enter)} y={140 - hop} w={76} h={124} rot={Math.sin(t * 6) * 4} op={clamp(enter * 3)} />
      <g transform={`translate(${14 + (1 - pop(t, mb)) * -40} 170) rotate(${-8 + Math.sin(t * 4) * 3} 31 20)`} opacity={clamp(pop(t, mb) * 2)}>
        <rect width="62" height="40" rx="6" fill="#facc15" stroke="#ca8a04" strokeWidth="2" /><rect y="10" width="62" height="8" fill="#ca8a04" /><text x="31" y="33" textAnchor="middle" fontSize="10" fontWeight={700} fill="#713f12">MEMBER</text>
      </g>
      <Bubble x={30} y={86} w={110} text="Diskon 50%" k={pop(t, dk, 0.45)} color="#ec4899" />
      <Hero t={t} x={14} y={214} w={34} h={56} mood="shock" />
      <g opacity={prog(t, dk + 0.3, 0.2)}><path d="M52 226 q3 6 0 9 q-3 -3 0 -9Z" fill="#38bdf8" transform={`translate(0 ${Math.sin(t * 5) * 1.5})`} /></g>
    </g>
  );
};

const Scene5: React.FC<SP> = ({ t }) => {
  const tw = cue(5, 'tuyul'), hl = cue(5, 'helm'), en = cue(5, 'enggak');
  const enter = eOut(prog(t, tw - 0.1, 0.6));
  const hk = pop(t, hl, 0.45);
  const x1 = prog(t, hl + 0.35, 0.25);
  return (
    <g>
      <rect width="180" height="320" fill="#d9f7e6" /><Clouds t={t} y={55} /><Ground />
      <Tuyul t={t} x={lerp(-80, 90, enter)} y={140 - Math.abs(Math.sin(t * 8)) * 6 * (1 - enter * 0.8)} w={76} h={124} op={clamp(enter * 3)} />
      <g transform={`translate(50 112) scale(${hk})`} opacity={clamp(hk * 2)}>
        <path d="M-28 6 A28 28 0 0 1 28 6 L28 18 L-28 18Z" fill="#ef4444" stroke="#991b1b" strokeWidth="2" /><rect x="-20" y="-4" width="22" height="6" rx="3" fill="#fecaca" />
        <circle r="40" cy="0" fill="none" stroke="#dc2626" strokeWidth="6" opacity={x1} /><line x1="-28" y1="28" x2="28" y2="-28" stroke="#dc2626" strokeWidth="6" strokeLinecap="round" opacity={x1} />
      </g>
      <Hero t={t} x={10} y={190} w={44} h={74} mood="shock" arm={prog(t, en, 0.25) * 150} rot={Math.sin(t * 9) * 2 * prog(t, en, 0.1) * (1 - prog(t, en + 0.8, 0.2))} />
    </g>
  );
};

const Scene6: React.FC<SP> = ({ t }) => {
  const a = cue(6, 'tolak'), push = cue(6, 'push'), sub = cue(6, 'subuh');
  const dawn = prog(t, push, cueEnd(6, 'subuh') - push);
  const bar = prog(t, push, cueEnd(6, 'subuh') - push);
  const ph = pop(t, push - 0.1, 0.45);
  return (
    <g>
      <rect width="180" height="320" fill={mixHex('#312e81', '#ffd9a8', dawn)} />
      {Array.from({ length: 14 }, (_, i) => <circle key={i} cx={hash(i + 11) * 175} cy={30 + hash(i + 31) * 120} r="1.6" fill="#fff" opacity={(1 - dawn) * (0.5 + 0.5 * Math.sin(t * 3 + i))} />)}
      <circle cx="90" cy={lerp(330, 235, eOut(dawn))} r="72" fill="#fb923c" />
      <Ground c={mixHex('#3f6212', '#a7e08a', dawn)} />
      <g transform={`translate(90 126) scale(${ph})`}>
        <rect x="-42" y="-78" width="84" height="150" rx="14" fill="#1e293b" /><rect x="-36" y="-68" width="72" height="130" rx="6" fill="#38bdf8" />
        <path d="M-18 -26 L-10 -48 L0 -34 L10 -48 L18 -26Z" fill="#fde047" /><rect x="-18" y="-22" width="36" height="8" fill="#fde047" />
        <text y="2" textAnchor="middle" fontSize="12" fontWeight={700} fill="#fff">RANK UP</text>
        <rect x="-26" y="26" width="52" height="9" rx="4.5" fill="#0c4a6e" /><rect x="-26" y="26" width={52 * bar} height="9" rx="4.5" fill="#fde047" />
        <text y="52" textAnchor="middle" fontSize="9" fontWeight={700} fill="#fff">{bar > 0.98 ? 'SUBUH!' : 'MALAM'}</text>
      </g>
      <Kunti t={t} x={2} y={190 - Math.abs(Math.sin(t * 5)) * 3} w={40} h={66} /><Pocong t={t} x={138} y={190 - Math.abs(Math.sin(t * 5 + 1)) * 3} w={40} h={66} />
      <Hero t={t} x={64} y={200} w={52} h={70} mood={t > sub ? 'sad' : 'shock'} rot={t > a ? Math.sin(t * 3) * 3 : 0} />
    </g>
  );
};

const Scene7: React.FC<SP> = ({ t }) => {
  const lk = cue(7, 'like'), sb = cue(7, 'subscribe');
  const pw = cue(8, 'pocongnya'), ng = cue(8, 'ngamuk'), kc = cue(8, 'karcis');
  const likeK = pop(t, lk, 0.45);
  const press = Math.sin(prog(t, lk + 0.15, 0.25) * Math.PI) * 0.14;
  const subK = pop(t, sb, 0.45);
  const subDone = t > sb + 0.5;
  const sp = Math.sin(prog(t, sb + 0.5, 0.25) * Math.PI) * 0.1;
  const pK = eOut(prog(t, pw - 0.1, 0.5));
  const shake = t > ng ? Math.sin(t * 38) * 2 : 0;
  const ticket = prog(t, kc, 0.6);
  return (
    <g>
      <rect width="180" height="320" fill="#fff1f2" /><Ground />
      <g transform={`translate(62 85) scale(${likeK * (1 - press)})`}><circle r="38" fill="#2563eb" /><rect x="-24" y="-4" width="10" height="26" rx="2" fill="#fff" /><path d="M-10 22 L-10 -2 L0 -22 Q8 -22 6 -8 L22 -8 Q26 -8 24 -2 L20 20 Q19 24 15 24Z" fill="#fff" /></g>
      <Sparks t={t} t0={lk + 0.15} cx={62} cy={85} r={48} color="#60a5fa" />
      <g transform={`translate(142 58) rotate(${Math.sin(prog(t, sb + 0.3, 0.8) * Math.PI * 6) * 14 * (1 - prog(t, sb + 0.3, 0.8))}) scale(${subK})`} opacity={clamp(subK * 2)}><path d="M-14 6 a14 14 0 0 1 28 0 v14 l6 8 h-40 l6-8z" fill="#facc15" stroke="#ca8a04" strokeWidth="2" /><circle cy="34" r="4" fill="#ca8a04" /></g>
      <g transform={`translate(90 148) scale(${subK * (1 - sp)})`}><rect x="-66" y="-18" width="132" height="36" rx="8" fill={subDone ? '#6b7280' : '#dc2626'} /><text y="6" textAnchor="middle" fontSize="15" fontWeight={700} fill="#fff">{subDone ? 'SUBSCRIBED' : 'SUBSCRIBE'}</text></g>
      <Pocong t={t} angry={t > ng} x={104 + (1 - pK) * 100 + shake} y={188 - Math.abs(Math.sin(t * 7)) * 5 * (1 - pK)} w={44} h={72} op={clamp(pK * 3)} />
      {t > ng && <path d="M112 182 l-8 -10 M128 178 l0 -12 M144 182 l8 -10" stroke="#dc2626" strokeWidth="3" strokeLinecap="round" opacity={0.6 + 0.4 * Math.sin(t * 20)} />}
      <g opacity={ticket > 0 ? 1 : 0} transform={`translate(${lerp(44, 100, eOut(ticket))} ${lerp(205, 205, ticket) - Math.sin(ticket * Math.PI) * 24}) rotate(${ticket * 360})`}><rect x="-13" y="-8" width="26" height="16" fill="#fde68a" stroke="#ca8a04" /><rect x="-7" y="-3" width="14" height="2" fill="#ca8a04" /></g>
      <Hero t={t} x={28} y={196} w={46} h={64} mood={t > pw ? 'shock' : 'smile'} arm={t > kc ? 150 : 0} />
    </g>
  );
};

const Scene8: React.FC<SP> = ({ t }) => {
  const lp = cue(9, 'lompatlompat'), kj = cue(9, 'karcisnya'), jt = cue(9, 'jatuh'), pb = cue(10, 'portalnya'), kb = cue(10, 'kebuka');
  const open = eOut(prog(t, pb, 0.6));
  const jumpPh = Math.max(0, (t - lp) * 2.2);
  const jump = t >= lp - 0.2 ? Math.abs(Math.sin(jumpPh * Math.PI)) * 46 * (1 - prog(t, kb + 0.5, 0.6)) : 0;
  return (
    <g>
      <rect width="180" height="320" fill="#cfeeff" /><Clouds t={t} y={60} /><Ground />
      <Portal t={t} cx={90} cy={124} rx={62} ry={84} k={1 + open * 0.08} glow={open} />
      <Sparks t={t} t0={pb} cx={90} cy={124} n={12} r={70} />
      <Barrier x={20} y={236} arm={open * 78} />
      <Pocong t={t} angry x={62 + Math.sin(t * 2.6) * 6} y={134 - jump} w={56} h={92} rot={Math.sin(t * 5.2) * 8} />
      {[0, 1, 2].map((i) => {
        const k = prog(t, jt - 0.15 + i * 0.12, 0.7); if (k <= 0) return null;
        return <g key={i} transform={`translate(${lerp(70, 40 + i * 50, k) + (hash(i) - 0.5) * 10} ${lerp(160, 244, k * k)}) rotate(${k * (200 + i * 90)})`}><rect x="-13" y="-8" width="26" height="16" fill="#fde68a" stroke="#ca8a04" /><rect x="-7" y="-3" width="14" height="2" fill="#ca8a04" /></g>;
      })}
      <Hero t={t} x={140} y={206} w={34} h={56} mood="shock" arm={prog(t, kj, 0.2) * 150} />
    </g>
  );
};

const Scene9: React.FC<SP> = ({ t }) => {
  const sj = cue(11, 'setan'), es = cue(11, 'es'), lp = cue(12, 'lipstik'), ck = cue(13, 'chiki');
  const gk = pop(t, sj, 0.5);
  return (
    <g>
      <rect width="180" height="320" fill="#dbeafe" /><Clouds t={t} y={36} />
      <rect y="270" width="180" height="50" fill="#cbd5e1" />
      <rect x="10" y="64" width="160" height="206" fill="#fff" stroke="#94a3b8" strokeWidth="2" />
      <rect x="10" y="64" width="160" height="30" fill="#ef4444" /><text x="90" y="85" textAnchor="middle" fontSize="15" fontWeight={700} fill="#fff">MINIMARKET</text>
      <path d="M10 94 h160 v14 q-8 10 -16 0 q-8 10 -16 0 q-8 10 -16 0 q-8 10 -16 0 q-8 10 -16 0 q-8 10 -16 0 q-8 10 -16 0 q-8 10 -16 0 q-8 10 -16 0Z" fill="#2563eb" />
      <rect x="20" y="124" width="140" height="146" fill="#e0f2fe" />
      <rect x="22" y="170" width="136" height="4" fill="#94a3b8" /><rect x="22" y="206" width="136" height="4" fill="#94a3b8" />
      {[0, 1, 2, 3, 4, 5].map((i) => <rect key={i} x={28 + i * 22} y={152} width="14" height="18" fill={['#f97316', '#22c55e', '#eab308', '#ec4899', '#38bdf8', '#a855f7'][i]} />)}
      <Kunti t={t} x={22} y={176 + (1 - gk) * 40} w={38} h={90} op={clamp(gk * 2)} />
      <Pocong t={t} x={70} y={176 + (1 - gk) * 40} w={38} h={90} op={clamp(gk * 2)} />
      <Tuyul t={t} x={118} y={176 + (1 - gk) * 40} w={38} h={90} op={clamp(gk * 2)} />
      <g transform={`translate(89 ${172}) scale(${pop(t, es, 0.45)})`} opacity={clamp(pop(t, es) * 2)}><path d="M-9 4 h18 l-9 -28z" fill="#fcd34d" /><circle cy="-30" r="9" fill="#f9a8d4" /><circle cx="6" cy="-24" r="7" fill="#fff" /></g>
      <g transform={`translate(38 ${164}) scale(${pop(t, lp, 0.45)})`} opacity={clamp(pop(t, lp) * 2)}><rect x="-6" y="-8" width="12" height="16" rx="2" fill="#be123c" /><path d="M-4 -8 l4 -12 l4 12z" fill="#fb7185" /></g>
      <g transform={`translate(137 ${160}) scale(${pop(t, ck, 0.45)})`} opacity={clamp(pop(t, ck) * 2)}><rect x="-17" y="-17" width="34" height="34" rx="4" fill="#f97316" /><text y="4" textAnchor="middle" fontSize="9" fontWeight={700} fill="#fff">Chiki</text></g>
      <Sparks t={t} t0={es} cx={89} cy={156} r={24} /><Sparks t={t} t0={lp} cx={38} cy={160} r={24} color="#fb7185" /><Sparks t={t} t0={ck} cx={137} cy={156} r={24} color="#fdba74" />
    </g>
  );
};

const Scene10: React.FC<SP> = ({ t }) => {
  const bs = cue(14, 'bos'), mm = cue(14, 'marahmarah'), jb = cue(14, 'jebol'), lr = cue(14, 'liar');
  const k = pop(t, bs, 0.55);
  const mad = t > mm ? 1 : 0;
  const jit = Math.sin(t * 40) * 2 * mad;
  return (
    <g>
      <rect width="180" height="320" fill="#ffe4d6" /><Ground />
      <Portal t={t} cx={48} cy={176} rx={50} ry={66} k={0.8} cracks={prog(t, jb, 0.4)} />
      <g transform={`translate(${118 + jit} ${156}) scale(${k * 0.72 * (1 + mad * 0.05 * Math.sin(t * 20))})`}>
        <path d="M-52 -92 L-34 -44 L-58 -56Z M52 -92 L34 -44 L58 -56Z" fill="#7f1d1d" />
        <circle cy="-30" r="56" fill="#ef4444" />
        <path d="M-38 -46 L-8 -34 M38 -46 L8 -34" stroke="#450a0a" strokeWidth="6" strokeLinecap="round" />
        <circle cx="-20" cy="-28" r="7" fill="#fef9c3" /><circle cx="20" cy="-28" r="7" fill="#fef9c3" /><circle cx="-20" cy="-28" r="3" fill="#450a0a" /><circle cx="20" cy="-28" r="3" fill="#450a0a" />
        <path d="M-26 6 Q0 -12 26 6 Q0 26 -26 6Z" fill="#450a0a" /><path d="M-18 4 h8 l-4 7z M10 4 h8 l-4 7z" fill="#fff" />
        <rect x="-40" y="22" width="80" height="54" rx="14" fill="#7c3aed" />
        {mad > 0 && <path d="M-70 -50 l-12 -16 M70 -50 l12 -16 M0 -92 l0 -20" stroke="#f59e0b" strokeWidth="4" strokeLinecap="round" />}
      </g>
      <g transform={`translate(48 ${90}) scale(${pop(t, lr, 0.45)})`} opacity={clamp(pop(t, lr) * 2)}><rect x="-16" y="-16" width="32" height="32" rx="6" fill="#2563eb" /><text y="8" textAnchor="middle" fontSize="22" fontWeight={700} fill="#fff">P</text><circle r="22" fill="none" stroke="#dc2626" strokeWidth="4" /><line x1="-16" y1="16" x2="16" y2="-16" stroke="#dc2626" strokeWidth="4" /></g>
      <Hero t={t} x={70} y={214} w={34} h={56} mood="shock" rot={Math.sin(t * 25) * 3 * mad} />
    </g>
  );
};

const Scene11: React.FC<SP> = ({ t }) => {
  const rs = cue(15, 'resign'), lk = cue(16, 'lakban'), ht = cue(16, 'hitam');
  const paper = eOut(prog(t, rs - 0.1, 0.5));
  const tp = [0, 1, 2, 3].map((i) => eOut(prog(t, lk + i * 0.22, 0.35)));
  const wave = t > ht ? Math.sin(t * 9) * 4 : 0;
  return (
    <g>
      <rect width="180" height="320" fill="#cfeeff" /><Clouds t={t} y={60} /><Ground />
      <Portal t={t} cx={104} cy={120} rx={58} ry={78} k={1} tape={tp} />
      <g transform={`translate(${lerp(30, 142, paper)} ${lerp(260, 205, paper)}) rotate(${lerp(-40, 8, paper)})`} opacity={clamp(paper * 2)}><rect x="-22" y="-26" width="44" height="52" fill="#fff" stroke="#94a3b8" /><rect x="-14" y="-18" width="28" height="3" fill="#cbd5e1" /><rect x="-14" y="-10" width="28" height="3" fill="#cbd5e1" /><text y="14" textAnchor="middle" fontSize="10" fontWeight={700} fill="#dc2626">RESIGN</text></g>
      <g transform={`translate(${104} ${250})`} opacity={clamp(prog(t, lk - 0.2, 0.3))}><circle r="13" fill="#1f2937" /><circle r="5" fill="#cfeeff" /></g>
      <Hero t={t} x={18} y={176} w={52} h={88} mood={t > lk ? 'smile' : 'sad'} arm={t > rs && t < lk ? 110 : 0} rot={wave} />
    </g>
  );
};

const Scene12: React.FC<SP> = ({ t }) => {
  const pk = cue(17, 'parkir'), ay = cue(17, 'ayam'), gp = cue(17, 'geprek'), cn = cue(17, 'cuan');
  const sign = pop(t, pk - 0.1, 0.5);
  const plate = pop(t, ay, 0.45);
  const cK = prog(t, cn, 1.6);
  return (
    <g>
      <rect width="180" height="320" fill="#fff3b0" /><Clouds t={t} y={36} /><Ground />
      <g transform={`translate(90 83) scale(${sign})`} opacity={clamp(sign * 2)}><rect x="-76" y="-23" width="152" height="46" rx="8" fill="#dc2626" /><text y="-3" textAnchor="middle" fontSize="15" fontWeight={700} fill="#fff">PARKIR</text><text y="16" textAnchor="middle" fontSize="15" fontWeight={700} fill="#fef08a">AYAM GEPREK</text></g>
      <rect x="14" y="204" width="152" height="12" fill="#a16207" /><rect x="22" y="216" width="6" height="40" fill="#78350f" /><rect x="152" y="216" width="6" height="40" fill="#78350f" />
      <g transform={`translate(90 180) scale(${plate})`}><ellipse cy="10" rx="48" ry="14" fill="#fff" stroke="#94a3b8" strokeWidth="2" /><ellipse cy="4" rx="30" ry="14" fill="#f59e0b" stroke="#b45309" strokeWidth="2" /><circle cx="-10" cy="0" r="4" fill="#dc2626" /><circle cx="6" cy="4" r="4" fill="#dc2626" /><circle cx="12" cy="-4" r="3" fill="#16a34a" /></g>
      {t > gp && <g opacity={0.5 + 0.5 * Math.sin(t * 8)}>{[0, 1, 2].map((i) => <path key={i} d={`M${72 + i * 18} ${150} q-4 -8 0 -14 q4 -6 0 -12`} stroke="#fb923c" strokeWidth="2" fill="none" strokeLinecap="round" transform={`translate(0 ${Math.sin(t * 4 + i) * 2})`} />)}</g>}
      <Hero t={t} x={62} y={196} w={56} h={74} mood="smile" arm={t > cn ? 150 : 0} rot={t > cn ? Math.sin(t * 6) * 3 : 0} />
      {cK > 0 && cK < 1 && Array.from({ length: 14 }, (_, i) => { const a = -Math.PI / 2 + (hash(i) - 0.5) * 2.4; const sp = 60 + hash(i + 3) * 70; const x = 90 + Math.cos(a) * sp * cK; const y = 196 + Math.sin(a) * sp * cK + 120 * cK * cK; return <Coin key={i} x={x} y={y} r={7} spin={cK * 14 + i} op={1 - prog(cK, 0.75, 0.25)} />; })}
    </g>
  );
};

const SCENE_COMPONENTS: React.FC<SP>[] = [Scene1, Scene2, Scene3, Scene4, Scene5, Scene6, Scene7, Scene8, Scene9, Scene10, Scene11, Scene12];

// ---------- teks / caption ----------
const Caption: React.FC<{ t: number }> = ({ t }) => {
  let idx = 0;
  for (let i = 0; i < S.length; i++) if (S[i].start <= t + 0.04) idx = i;
  const s = S[idx];
  return (
    <div style={{ position: 'absolute', left: 0, top: 1560, width: 1080, height: 360, background: '#2b1d6b', borderTopLeftRadius: 56, borderTopRightRadius: 56, boxShadow: '0 -8px 0 #fde047' }}>
      <div style={{ position: 'absolute', left: 60, top: 26, width: 960, height: 306, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignContent: 'center', gap: '4px 18px' }}>
        {s.words.map((w, k) => {
          const on = t >= w.start && t < w.end + 0.05;
          const done = t >= w.end + 0.05;
          const kk = on ? 1 + 0.12 * Math.sin(clamp((t - w.start) / Math.max(0.12, w.end - w.start)) * Math.PI) : 1;
          return <span key={k} style={{ fontSize: 68, lineHeight: '84px', fontWeight: 700, color: on ? '#fde047' : '#fff', opacity: done || on ? 1 : 0.42, transform: `scale(${kk})`, display: 'inline-block', textShadow: '0 4px 0 rgba(0,0,0,0.25)' }}>{w.w}</span>;
        })}
      </div>
    </div>
  );
};

// ---------- komposisi inti ----------
export function Video({ t, fontFamily }: { t: number; fontFamily?: string }) {
  let cur = 0;
  for (let i = 1; i < SCENES.length; i++) if (t >= trAt(i) + TR) cur = i;
  const upd = cur + 1 < SCENES.length && t >= trAt(cur + 1) ? cur + 1 : -1;
  const trK = upd >= 0 ? prog(t, trAt(upd), TR) : 0;
  const A = SCENE_COMPONENTS[cur];
  const B = upd >= 0 ? SCENE_COMPONENTS[upd] : null;
  const e = eOut(trK);
  return (
    <div style={{ position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, overflow: 'hidden', background: '#2b1d6b', fontFamily: fontFamily || "'Fredoka','Baloo 2','Arial Rounded MT Bold','Trebuchet MS',sans-serif" }}>
      <svg width={1080} height={1560} viewBox="0 30 180 260" style={{ position: 'absolute', left: 0, top: 0 }} role="img">
        <defs><clipPath id="vclip"><rect x="0" y="30" width="180" height="260" /></clipPath></defs>
        <g clipPath="url(#vclip)">
          <A t={t} />
          {B ? (
            <g transform={`translate(0 ${lerp(260, 0, e)})`}>
              <rect x="-4" y="-12" width="188" height="12" fill="#fde047" />
              <B t={t} />
            </g>
          ) : null}
        </g>
      </svg>
      <Caption t={t} />
    </div>
  );
}
