import React from 'react';
import { Audio, Composition, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import timing from './timing.json';
import { Video } from './Video';

// Font Google (Fredoka) dimuat lewat @remotion/google-fonts saat render di runner.
const { fontFamily } = loadFont('normal', { weights: ['700'], subsets: ['latin'] });

const TAIL_SECONDS = 0.3; // jeda singkat setelah narasi selesai

const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  return (
    <>
      <Audio src={staticFile('narasi.mp3')} />
      <Video t={t} fontFamily={`${fontFamily}, sans-serif`} />
    </>
  );
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="ParkirGhaib"
    component={Main}
    durationInFrames={Math.ceil((timing.duration + TAIL_SECONDS) * timing.fps)}
    fps={timing.fps}
    width={timing.width}
    height={timing.height}
  />
);
