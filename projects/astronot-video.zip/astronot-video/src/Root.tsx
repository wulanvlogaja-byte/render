import React from 'react';
import { AbsoluteFill, Audio, Composition, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import { theme } from './theme';
import timing from './timing.json';
import { Video } from './Video';

loadFont('normal', { weights: ['700'] });

const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill>
      <Audio src={staticFile('narasi.mp3')} />
      <Video t={frame / fps} />
    </AbsoluteFill>
  );
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Astronot"
    component={Main}
    durationInFrames={Math.ceil((timing.duration + theme.tail) * timing.fps)}
    fps={timing.fps}
    width={timing.width}
    height={timing.height}
  />
);
