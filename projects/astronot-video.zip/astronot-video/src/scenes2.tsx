import React from 'react';
import { theme } from './theme';
import { clamp, easeOut, back, enter, hash, wrap, cue } from './util';
import { Bg, T, Chip, Cloud, Ribbon, Star4, Stars, Moon, Earth, Rocket, Char, Heart, XMark, Check, Floor, Hills } from './paper';

const c = theme.c;
type P = { t: number };

// ---------- G: kalimat 6 ----------
const KG = { pilot: cue(6, 'pilot'), muntah: cue(6, 'muntah'), lo: cue(6, 'lo'), tidur: cue(6, 'ketiduran'), getar: cue(6, 'getarannya') };
export const SceneG = ({ t }: P) => {
  const jit = Math.sin(t * 40) * 1.1;
  const sick = t >= KG.muntah;
  const pr = clamp((t - KG.muntah) / 0.8);
  const jx = 180 + Math.sin(t * 0.8) * 14;
  return (
    <g>
      <Bg fill={c.sky} />
      <Hills t={t} a={c.blueT2} b={c.tealT2} y={330} />
      <Cloud x={wrap(70 + t * 7, -60, 420)} y={235} s={0.8} />
      <g filter="url(#ps)">
        <g transform={`translate(${jx},${158 + Math.sin(t * 1.3) * 4}) rotate(${-4 + Math.sin(t) * 2})`}>
          <polygon points="-14,0 8,0 -20,34 -32,34" fill={c.orange} />
          <polygon points="-40,-2 -52,-22 -34,-22 -22,-2" fill={c.orange} />
          <ellipse cx={0} cy={0} rx={46} ry={11} fill={c.white} />
          <path d="M40,-5 Q52,0 40,5Z" fill={c.blue} />
          {[8, 20, 32].map((x) => <circle key={x} cx={x - 6} cy={-2} r={2.6} fill={c.blue} />)}
        </g>
      </g>
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <Chip x={95} y={298} text="Pilot jet" size={17} fill={c.white} p={enter(t, KG.pilot, 0.4)} />
      <Chip x={232} y={298} text="Lo" size={19} fill={c.yellow} p={enter(t, KG.lo, 0.4)} />
      <g transform={`translate(${jit},0)`}>
        <Char x={95} y={426} t={t} sx={1.25} sy={1.25} suit helmet={1} skin={sick ? c.tealT2 : c.skin} mood={sick ? 'sick' : 'strain'} armL={20} armR={20} seed={6} />
      </g>
      {sick && (
        <g>
          <path d="M-12,-16 L12,-16 L9,0 L-9,0Z" fill={c.orange} transform="translate(140,426)" />
          {pr < 1 && [0, 1, 2, 3, 4].map((i) => (
            <circle key={i} cx={112 + 26 * pr + i * 3} cy={362 + 56 * pr * pr + hash(i) * 6 - i * 2} r={3.4} fill={c.teal} />
          ))}
        </g>
      )}
      <g transform={`translate(${jit},0)`}>
        <Char x={255} y={426} t={t} sx={1.25} sy={1.25} rot={Math.sin(t * 1.5) * 3} mood="sleep" armL={14} armR={14} seed={7} />
      </g>
      {t > KG.tidur && [0, 1, 2].map((i) => {
        const q = ((t - KG.tidur) * 0.5 + i * 0.33) % 1;
        return <T key={i} x={290 + i * 6} y={350 - q * 70} size={14 + i * 4} fill={c.orange} anchor="middle">Z</T>;
      })}
      {t > KG.getar && [0, 1].map((i) => (
        <path key={i} d="M0,0 q-8,12 0,24" fill="none" stroke={c.orange} strokeWidth={3} strokeLinecap="round"
          opacity={0.5 + 0.5 * Math.sin(t * 14 + i * 2)} transform={`translate(${i ? 306 : 204},${376})`} />
      ))}
    </g>
  );
};

// ---------- H1: kalimat 7 (pilihan) ----------
const KH = { bentar: cue(7, 'bentar'), lanjut: cue(7, 'lanjut'), kabur: cue(7, 'kabur'), like: cue(7, 'like') };
export const SceneH1 = ({ t }: P) => {
  const pl = back((t - (KH.lanjut - 0.3)) / 0.5), pk = back((t - (KH.kabur - 0.3)) / 0.5);
  const pulse = 1 + 0.025 * Math.sin(t * 5);
  return (
    <g>
      <Bg fill={c.cream} />
      <Hills t={t} a={c.yellowT2} b={c.orangeT1} y={330} />
      <Floor t={t} a={c.orangeT1} b={c.yellowT2} f={c.blueT2} />
      <Chip x={180} y={105} text="Lo pilih yang mana?" size={21} fill={c.white} p={enter(t, KH.bentar, 0.5)} />
      <g filter="url(#ps)" opacity={clamp(pl * 3)}>
        <g transform={`translate(100,262) scale(${clamp(pl, 0, 1.15) * pulse})`}>
          <rect x={-64} y={-80} width={128} height={160} rx={18} fill={c.white} />
          <g transform="translate(0,12) scale(0.9)"><Rocket x={0} y={0} s={1} flame={0.8} t={t} /></g>
          <T x={0} y={44} size={18}>Lanjut</T><T x={0} y={63} size={18}>terbang</T>
        </g>
      </g>
      <g filter="url(#ps)" opacity={clamp(pk * 3)}>
        <g transform={`translate(260,262) scale(${clamp(pk, 0, 1.15) * pulse})`}>
          <rect x={-64} y={-80} width={128} height={160} rx={18} fill={c.white} />
          <polygon points="-28,-6 0,-34 28,-6" fill={c.orange} />
          <rect x={-20} y={-6} width={40} height={30} fill={c.blueT2} />
          <rect x={-5} y={7} width={10} height={17} fill={c.yellow} />
          <T x={0} y={44} size={18}>Kabur</T><T x={0} y={63} size={18}>pulang</T>
        </g>
      </g>
      <Char x={180} y={428} t={t} sx={1.1} sy={1.1} armL={20} armR={t > KH.bentar ? 150 + Math.sin(t * 8) * 22 : 20} mood="shock" seed={8} o={enter(t, KH.bentar, 0.3)} />
    </g>
  );
};

// ---------- H2: kalimat 7 (like & subscribe) ----------
const KI = { like: cue(7, 'like'), sub: cue(7, 'subscribe'), peng: cue(7, 'pengangguran') };
export const SceneH2 = ({ t }: P) => {
  const hp = enter(t, KI.like, 0.5), sp = enter(t, KI.sub, 0.5);
  return (
    <g>
      <Bg fill={c.sky} />
      <Floor t={t} a={c.tealT1} b={c.blueT1} f={c.yellowT2} />
      <Chip x={180} y={105} text="Like & Subscribe" size={22} fill={c.white} p={hp} />
      {hp > 0.01 && <g transform={`translate(100,205) scale(${1.7 * hp * (1 + 0.08 * Math.sin(t * 6))}) translate(-100,-205)`}><Heart x={100} y={205} s={1} /></g>}
      <Chip x={100} y={270} text="Like" size={20} fill={c.yellow} p={hp} />
      {sp > 0.01 && (
        <g filter="url(#ps)" opacity={clamp(sp * 2)}>
          <g transform={`translate(250,208) scale(${0.6 + 0.4 * sp})`}>
            <rect x={-66} y={-23} width={132} height={46} rx={14} fill={c.yellow} />
            <T x={0} y={0} size={19}>Subscribe</T>
          </g>
        </g>
      )}
      {sp > 0.01 && (
        <g transform={`translate(250,150) rotate(${Math.sin(t * 10) * 14 * Math.max(0, 1 - (t - KI.sub) / 2)})`}>
          <g filter="url(#ps)">
            <path d="M0,-20 C-14,-20 -16,-4 -16,6 L-20,14 L20,14 L16,6 C16,-4 14,-20 0,-20Z" fill={c.orange} />
            <circle cx={0} cy={18} r={4.5} fill={c.orange} />
          </g>
        </g>
      )}
      {Array.from({ length: 7 }, (_, i) => {
        const p = back((t - KI.peng - i * 0.12) / 0.4);
        if (p <= 0.01) return null;
        return (
          <g key={i} filter="url(#ps)">
            <g transform={`translate(${45 + i * 45},${338 + Math.sin(t * 3 + i) * 3}) scale(${clamp(p, 0, 1.2)})`}>
              <circle r={17} fill={c.white} opacity={0.9} /><circle r={17} fill="none" stroke={c.yellow} strokeWidth={3} />
              <circle r={10} fill={c.skin} /><circle cx={-3.5} cy={-1} r={1.4} fill={c.ink} /><circle cx={3.5} cy={-1} r={1.4} fill={c.ink} />
            </g>
          </g>
        );
      })}
      <Chip x={180} y={385} text="Pengangguran siap terbang" size={15} fill={c.tealT2} p={enter(t, KI.peng + 0.3, 0.5)} />
    </g>
  );
};

// ---------- I: kalimat 8 (peluncuran) ----------
const KL = { pel: cue(8, 'peluncuran'), nyala: cue(8, 'nyala'), suara: cue(8, 'suaranya'), sesak: cue(8, 'sesak'), tiga: cue(8, 'tiga'), luar: cue(8, 'luar') };
export const SceneI = ({ t }: P) => {
  const lift = Math.pow(clamp((t - KL.tiga) / (KL.luar - KL.tiga + 0.7)), 2);
  const ly = 418 - 20 * easeOut((t - KL.nyala) / 2) - 640 * lift;
  const shake = t > KL.nyala ? Math.sin(t * 55) * 1.6 * (1 - lift) : 0;
  const sm = clamp((t - KL.nyala) / 3);
  const so = t > KL.nyala ? 1 - clamp((t - KL.tiga) / 3) * 0.85 : 0;
  return (
    <g>
      <Bg fill={c.sky} />
      <Stars t={t} n={12} seed={11} y0={30} y1={380} o={enter(t, KL.luar - 0.8, 1)} />
      <Cloud x={wrap(60 + t * 6, -60, 420)} y={160} s={0.8} o={1 - enter(t, KL.luar, 0.8)} />
      {t > KL.luar - 0.5 && <g transform={`translate(0,${(1 - enter(t, KL.luar - 0.5, 1.2)) * 120})`}><Earth x={262} y={330} R={72} t={t} /></g>}
      <Ribbon y={432} fill={c.tealT1} t={t} speed={6} amp={8} />
      <Ribbon y={460} fill={c.tealT2} t={t} speed={10} amp={8} phase={20} />
      <Ribbon y={578} fill={c.yellowT2} t={t} speed={14} amp={10} phase={40} />
      <Rocket x={180 + shake} y={ly} s={1.5} flame={enter(t, KL.nyala, 0.3) * (1 + lift)} t={t} />
      {so > 0.01 && [0, 1, 2, 3, 4].map((k) => (
        <Cloud key={k} x={180 + (k - 2) * (32 + 28 * sm)} y={426 - Math.abs(k - 2) * 4} s={0.5 + 0.7 * sm} o={so} />
      ))}
      {t > KL.suara && [0, 1, 2].map((i) => {
        const r = ((t - KL.suara) * 60 + i * 24) % 72 + 30;
        return <circle key={i} cx={180} cy={372} r={r} fill="none" stroke={c.orange} strokeWidth={3} opacity={clamp(1 - (r - 30) / 72) * 0.8 * (1 - clamp(lift * 3))} />;
      })}
      <Chip x={180} y={105} text="Hari peluncuran!" size={21} fill={c.white} p={enter(t, KL.pel, 0.5)} />
      <Chip x={76} y={250} text="Dada sesak!" size={16} fill={c.orangeT2} rot={-6} p={enter(t, KL.sesak, 0.4)} />
      <Chip x={286} y={200} text="3 menit" size={22} fill={c.yellow} rot={5} p={enter(t, KL.tiga, 0.4)} />
    </g>
  );
};

// ---------- J: kalimat 9 (jendela) ----------
const KJ = {
  jendela: cue(9, 'jendela'), bumi: cue(9, 'bumi'), sepi: cue(9, 'sepi'),
  e0: cue(9, 'enggak', 0), e1: cue(9, 'enggak', 1), e2: cue(9, 'enggak', 2),
  w0: cue(9, 'cicilan'), w1: cue(9, 'tagihan'), w2: cue(9, 'lowongan'),
};
export const SceneJ = ({ t }: P) => {
  const w = back((t - (KJ.jendela - 0.3)) / 0.6);
  const e = enter(t, KJ.bumi, 0.7);
  const items = [['Cicilan', KJ.e0, KJ.w0], ['Tagihan', KJ.e1, KJ.w1], ['Lowongan kerja', KJ.e2, KJ.w2]] as any[];
  return (
    <g>
      <Bg fill={c.cream} />
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <g filter="url(#ps)" opacity={clamp(w * 3)}>
        <g transform={`translate(180,226) scale(${clamp(w, 0, 1.1)})`}>
          <circle r={98} fill={c.yellow} /><circle r={88} fill={c.white} /><circle r={78} fill={c.blueT2} />
          {Array.from({ length: 8 }, (_, i) => <circle key={i} cx={Math.cos((i * Math.PI) / 4) * 93} cy={Math.sin((i * Math.PI) / 4) * 93} r={4} fill={c.orange} />)}
          <Stars t={t} n={7} seed={21} y0={-60} y1={60} />
          <g transform={`scale(${e})`}><Earth x={Math.sin(t * 0.5) * 6} y={0} R={48} t={t} /></g>
        </g>
      </g>
      <Chip x={180} y={88} text="Sepi..." size={22} fill={c.white} p={enter(t, KJ.sepi, 0.5)} />
      {items.map(([txt, ce, cw], i) => (
        <g key={i}>
          <Chip x={180} y={358 + i * 32} text={txt} size={16} w={214} h={30} p={enter(t, ce, 0.4)} />
          <XMark x={92} y={358 + i * 32} r={11} p={enter(t, cw, 0.3)} />
        </g>
      ))}
    </g>
  );
};

// ---------- K1: kalimat 10 awal (merasa tidak berguna) ----------
const KK = {
  selama: cue(10, 'selama'), enggak: cue(10, 'enggak'), tapi: cue(10, 'tapi'), empat: cue(10, 'empat'),
  ss: cue(10, 'satusatunya'), rumah: cue(10, 'rumahnya'),
};
export const SceneK1 = ({ t }: P) => {
  const cp = back((t - KK.enggak) / 0.5);
  return (
    <g>
      <Bg fill={c.sky} />
      <Hills t={t} a={c.blueT2} b={c.tealT1} y={310} />
      <Cloud x={wrap(60 + t * 6, -60, 420)} y={140} s={0.8} />
      <Earth x={180} y={632} R={242} t={t} />
      <Chip x={180} y={105} text="Selama ini..." size={22} fill={c.white} p={enter(t, KK.selama, 0.5)} />
      <Char x={180} y={392} t={t} sx={1.3} sy={1.3} mood="sad" armL={8} armR={8} seed={9} />
      {cp > 0.01 && (
        <g opacity={clamp(cp * 2)}>
          <circle cx={172} cy={286} r={4} fill={c.white} /><circle cx={176} cy={272} r={6} fill={c.white} />
          <g transform={`translate(180,216) scale(${clamp(cp, 0, 1.1) * 1.7}) translate(-180,-216)`}>
            <Cloud x={180} y={216} s={1} />
          </g>
          <T x={176} y={222} size={17}>Enggak guna</T>
        </g>
      )}
    </g>
  );
};

// ---------- K2: kalimat 10 akhir (400 km) ----------
export const SceneK2 = ({ t }: P) => {
  const ay = 222 + Math.sin(t * 1.5) * 6;
  const pin = back((t - KK.rumah) / 0.5);
  return (
    <g>
      <Bg fill={c.sky} />
      <Stars t={t} n={14} seed={31} y0={30} y1={380} />
      <Earth x={180} y={550} R={210} t={t} />
      <path d={`M180,${ay + 30} V334`} stroke={c.orange} strokeWidth={3} strokeDasharray="7 8" strokeLinecap="round" fill="none" />
      <Char x={180} y={ay} t={t} sx={1.4} sy={1.4} suit helmet={1} armL={40} armR={40} legL={10 + Math.sin(t * 2) * 8} legR={-10 - Math.sin(t * 2) * 8} seed={10} />
      <Chip x={248} y={288} text="400 km" size={22} fill={c.yellow} rot={4} p={enter(t, KK.empat, 0.4)} />
      <Chip x={180} y={105} text="Satu-satunya!" size={23} fill={c.white} p={enter(t, KK.ss, 0.5)} />
      {pin > 0.01 && (
        <g filter="url(#ps)" opacity={clamp(pin * 2)}>
          <g transform={`translate(180,${350 + Math.sin(t * 6) * 2}) scale(${clamp(pin, 0, 1.2)})`}>
            <polygon points="-7,-14 7,-14 0,0" fill={c.orange} /><circle cx={0} cy={-20} r={11} fill={c.orange} /><circle cx={0} cy={-20} r={5} fill={c.white} />
          </g>
        </g>
      )}
      <Chip x={108} y={334} text="Rumah lo" size={16} fill={c.white} rot={-6} p={enter(t, KK.rumah, 0.4)} />
    </g>
  );
};

// ---------- L: kalimat 11 (rebahan ada gunanya) ----------
const KZ = { pertama: cue(11, 'pertama'), rebahan: cue(11, 'rebahan'), guna: cue(11, 'gunanya') };
export const SceneL = ({ t }: P) => {
  const g = enter(t, KZ.guna, 0.6);
  return (
    <g>
      <Bg fill={c.sky} />
      <Stars t={t} n={14} seed={41} y0={30} y1={390} />
      <Earth x={256} y={528} R={200} t={t} />
      {g > 0.01 && <g opacity={g}><Star4 x={196} y={262} r={86 * g} fill={c.yellow} /></g>}
      <Char x={96} y={262 + Math.sin(t * 1.5) * 6} t={t} rot={90 + Math.sin(t * 1.2) * 3} sx={1.9} sy={1.9} suit helmet={1} armL={165} armR={165} legL={6} legR={-6} seed={12} />
      <Chip x={180} y={118} text="Rebahan ada gunanya!" size={20} fill={c.yellow} p={enter(t, KZ.rebahan, 0.5)} />
      <Check x={292} y={186} r={26} p={g} />
    </g>
  );
};
