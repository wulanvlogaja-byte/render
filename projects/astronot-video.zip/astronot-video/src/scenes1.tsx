import React from 'react';
import { theme } from './theme';
import { clamp, easeOut, back, enter, hash, wrap, cue } from './util';
import { Bg, T, Chip, Cloud, Ribbon, Star4, Stars, Sun, Moon, Earth, Char, Arrow, XMark, Floor, Defs, Hills } from './paper';

const c = theme.c;
type P = { t: number };

/** tempat tidur + karakter rebahan (dipakai adegan A dan D) */
export function Bed({ t, phone = false, hot = 0, scroll = 0 }: any) {
  const phoneRot = 8 + Math.sin(t * 9) * hot * 2;
  return (
    <g>
      <g filter="url(#ps)">
        <rect x={112} y={392} width={10} height={36} rx={3} fill={c.blue} />
        <rect x={278} y={392} width={10} height={36} rx={3} fill={c.blue} />
        <rect x={100} y={366} width={200} height={28} rx={8} fill={c.blue} />
        <rect x={288} y={270} width={22} height={126} rx={10} fill={c.orange} />
      </g>
      <g filter="url(#ps)">
        <rect x={100} y={330} width={192} height={40} rx={14} fill={c.blueT1} />
        <rect x={226} y={314} width={54} height={28} rx={14} fill={c.white} />
      </g>
      <Char x={170} y={312} t={t} rot={90} sx={1.6} sy={1.6} armL={phone ? 90 + Math.sin(t * 3) * 5 : 15} armR={10}
        mood={phone ? 'happy' : 'sad'} seed={1} />
      <g filter="url(#ps)"><rect x={98} y={322} width={92} height={40} rx={16} fill={c.tealT2} /></g>
      {phone && (
        <g transform={`translate(237,233) rotate(${phoneRot})`}>
          <rect x={-15} y={-26} width={30} height={52} rx={6} fill={c.ink} />
          <rect x={-12} y={-22} width={24} height={44} rx={4} fill={c.tealT2} />
          {[0, 1, 2].map((k) => (
            <rect key={k} x={-9} y={wrap(k * 12 - t * 18 * (0.4 + scroll), 0, 36) - 22} width={18} height={7} rx={3} fill={c.white} />
          ))}
        </g>
      )}
    </g>
  );
}

// ---------- A: kalimat 0 ----------
const KA = { nasa: cue(0, 'nasa'), dua: cue(0, 'dua'), panas: cue(0, 'panas'), scroll: cue(0, 'scroll') };
export const SceneA = ({ t }: P) => {
  const hot = enter(t, KA.panas, 0.8);
  const clock = enter(t, KA.dua, 0.5);
  return (
    <g>
      <Bg fill={c.cream} />
      <Floor t={t} a={c.yellowT2} b={c.orangeT1} f={c.blueT2} />
      <Bed t={t} phone hot={hot} scroll={enter(t, KA.scroll, 0.5)} />
      {hot > 0.01 && [0, 1, 2].map((i) => (
        <path key={i} d="M0,0 q5,-7 0,-14 t0,-14" fill="none" stroke={c.orange} strokeWidth={3} strokeLinecap="round"
          opacity={hot * 0.9} transform={`translate(${222 + i * 15 + Math.sin(t * 6 + i) * 3},${200 - ((t * 20 + i * 7) % 14)})`} />
      ))}
      {clock > 0.01 && (
        <g filter="url(#ps)" opacity={clamp(clock * 2)}>
          <g transform={`translate(80,226) scale(${0.5 + 0.5 * clock})`}>
            <circle r={22} fill={c.white} />
            {[0, 90, 180, 270].map((a) => <rect key={a} x={-1.5} y={-19} width={3} height={5} fill={c.ink} transform={`rotate(${a})`} />)}
            <rect x={-1.8} y={-12} width={3.6} height={12} rx={1.8} fill={c.ink} transform="rotate(40)" />
            <rect x={-1.2} y={-17} width={2.4} height={17} rx={1.2} fill={c.orange} transform={`rotate(${(t - KA.dua) * 240})`} />
          </g>
        </g>
      )}
      <Chip x={82} y={274} text="12 jam" size={17} fill={c.yellow} p={enter(t, KA.dua + 0.15, 0.4)} />
      <Chip x={300} y={172} text="NASA" size={16} fill={c.tealT2} rot={8} p={enter(t, KA.nasa, 0.4)} />
      <Chip x={180} y={98} text="POV: Dipanggil NASA" size={22} w={316} h={52} p={enter(t, 0.15, 0.6)} />
    </g>
  );
};

// ---------- B: kalimat 1 ----------
const KB = { pagi: cue(1, 'pagipagi'), email: cue(1, 'email'), selamat: cue(1, 'selamat'), artemis: cue(1, 'artemis'), spam: cue(1, 'spam'), lo: cue(1, 'lo') };
export const SceneB = ({ t }: P) => {
  const ey = 262 + (1 - back((t - KB.email) / 0.9)) * -330;
  const shake = t > KB.spam ? Math.sin(t * 50) * 2 * Math.max(0, 1 - (t - KB.spam) / 1.2) : 0;
  const colors = [c.yellow, c.orange, c.teal, c.blue];
  return (
    <g>
      <Bg fill={c.sky} />
      <Sun x={292} y={100} r={28} p={enter(t, KB.pagi, 1)} />
      <Cloud x={wrap(60 + t * 6, -60, 420)} y={150} s={0.8} />
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <g filter="url(#ps)">
        <g transform={`translate(${180 + shake},${ey})`}>
          <rect x={-95} y={-58} width={190} height={116} rx={10} fill={c.white} />
          <polygon points="-95,58 0,-4 95,58" fill={c.yellowT2} />
          <polygon points="-95,-58 95,-58 0,10" fill={c.blueT2} />
          <circle cx={0} cy={10} r={13} fill={c.yellow} />
          <Star4 x={0} y={10} r={8} fill={c.orange} />
        </g>
      </g>
      <Chip x={180} y={168} text="Selamat, Anda terpilih!" size={15} fill={c.yellow} p={enter(t, KB.selamat, 0.5)} />
      <Chip x={180} y={352} text="Misi Artemis" size={17} fill={c.tealT2} p={enter(t, KB.artemis, 0.5)} />
      <Chip x={238} y={296} text="SPAM?" size={24} fill={c.orangeT2} rot={-12} p={enter(t, KB.spam, 0.25)} />
      {t > KB.selamat && Array.from({ length: 16 }, (_, k) => {
        const x0 = hash(k) * 340 + 10, sp = 60 + hash(k + 9) * 50;
        const y = wrap(60 + (t - KB.selamat) * sp, 60, 430);
        return <rect key={k} x={x0 + Math.sin(t * 2 + k) * 8} y={y} width={7} height={4} fill={colors[k % 4]} transform={`rotate(${t * 120 + k * 40} ${x0} ${y})`} opacity={enter(t, KB.selamat, 0.3)} />;
      })}
      <Char x={62} y={428} t={t} sx={1.1} sy={1.1} armL={150} armR={150} mood="shock" seed={2} o={enter(t, KB.lo, 0.3)} />
    </g>
  );
};

// ---------- C: kalimat 2 ----------
const KC = { nasa: cue(2, 'nasa'), orang: cue(2, 'orang'), awam: cue(2, 'awam'), bertahan: cue(2, 'bertahan'), luar: cue(2, 'luar') };
export const SceneC = ({ t }: P) => {
  const fl = enter(t, KC.luar, 1.4);
  const cy = 424 - fl * 70 + Math.sin(t * 2) * 3 * fl;
  const sw = Math.sin(t * 2) * 10 * fl;
  const nb = enter(t, KC.nasa, 0.6);
  return (
    <g>
      <Bg fill={c.sky} />
      <Stars t={t} n={12} seed={3} y0={30} y1={330} />
      <Moon x={275} y={172} r={52} />
      {nb > 0.01 && (
        <g filter="url(#ps)" opacity={clamp(nb * 2)}>
          <g transform={`translate(78,150) scale(${0.5 + 0.5 * nb})`}>
            <circle r={38} fill={c.yellow} />
            <ellipse rx={50} ry={14} fill="none" stroke={c.orange} strokeWidth={3} transform={`rotate(${-20 + t * 12})`} />
            <T x={0} y={0} size={17}>NASA</T>
          </g>
        </g>
      )}
      <Floor t={t} a={c.yellowT1} b={c.yellowT2} f={c.blueT2} />
      <Char x={170} y={cy} t={t} sx={1.5} sy={1.5} legL={sw} legR={-sw} armL={20 + fl * 30} armR={20 + fl * 30} suit={fl > 0.5} helmet={enter(t, KC.luar + 0.2, 0.6)} seed={3} o={enter(t, KC.orang, 0.4)} />
      <Chip x={170} y={cy - 134} text="Orang awam" size={16} fill={c.white} p={enter(t, KC.awam, 0.4)} />
      <Chip x={130} y={222} text="Bertahan hidup!" size={17} fill={c.tealT2} rot={-4} p={enter(t, KC.bertahan, 0.5)} />
    </g>
  );
};

// ---------- D: kalimat 3 ----------
const KD = { grav0: cue(3, 'gravitasi', 0), kasur: cue(3, 'kasur'), tiba: cue(3, 'tibatiba'), bumi: cue(3, 'bumi') };
export const SceneD = ({ t }: P) => {
  const s = enter(t, KD.tiba - 0.1, 0.7);
  const a = enter(t, KD.grav0, 0.5);
  const b = enter(t, KD.bumi, 0.5);
  const strain = Math.sin(t * 5);
  return (
    <g>
      <Bg fill={c.cream} />
      <Floor t={t} a={c.orangeT1} b={c.yellowT2} f={c.blueT2} />
      <g transform={`translate(${-s * 420},0)`}>
        <Bed t={t} />
        {[130, 195, 260].map((x, i) => <Arrow key={i} x={x} y={200 + ((t * 25 + i * 8) % 22)} s={1.1} o={a * 0.9} />)}
        <Chip x={180} y={130} text="Gravitasi kasur" size={20} fill={c.orangeT2} p={enter(t, KD.kasur, 0.5)} />
      </g>
      <g transform={`translate(${(1 - s) * 420},0)`}>
        <Hills t={t} a={c.blueT2} b={c.tealT1} y={330} />
        <Earth x={180} y={660} R={240} t={t} />
        <g filter="url(#ps)">
          <g transform={`translate(180,${322 + strain * 2}) rotate(${strain * 2.5})`}>
            <rect x={-72} y={-4} width={144} height={8} rx={4} fill={c.gray2} />
            <circle cx={-64} cy={0} r={17} fill={c.orange} /><circle cx={64} cy={0} r={17} fill={c.orange} />
            <circle cx={-78} cy={0} r={11} fill={c.yellow} /><circle cx={78} cy={0} r={11} fill={c.yellow} />
          </g>
        </g>
        <Char x={180} y={422 + strain * 1.5} t={t} sx={1.3} sy={1.3} armL={168} armR={168} legL={4} legR={-4} mood="strain" seed={4} />
        {[130, 180, 230].map((x, i) => <Arrow key={i} x={x} y={232 + ((t * 25 + i * 8) % 22)} s={0.9} o={b * 0.9} />)}
        <Chip x={180} y={150} text="Gravitasi bumi" size={20} fill={c.orangeT2} p={b} />
      </g>
    </g>
  );
};

// ---------- E: kalimat 4 ----------
const KE = { lari: cue(4, 'lari'), lima: cue(4, 'lima'), tangga: cue(4, 'tangga'), kos: cue(4, 'kos'), ngos: cue(4, 'ngosngosan') };
export const SceneE = ({ t }: P) => {
  const run = t < KE.ngos;
  const sw = run ? Math.sin(t * 10) : 0;
  const bob = run ? Math.abs(Math.sin(t * 10)) * 4 : 0;
  const st = enter(t, KE.tangga, 0.7);
  const sign = enter(t, KE.lima, 0.5) * (1 - enter(t, KE.tangga - 0.1, 0.4));
  return (
    <g>
      <Bg fill={c.sky} />
      <Cloud x={wrap(80 + t * 8, -60, 420)} y={140} s={0.9} />
      <Cloud x={wrap(260 + t * 5, -60, 420)} y={210} s={0.7} />
      <Hills t={t} a={c.blueT2} b={c.tealT1} y={320} />
      <Ribbon y={428} fill={c.orangeT1} t={t} speed={run ? 50 : 6} amp={8} />
      <Ribbon y={456} fill={c.orangeT2} t={t} speed={run ? 70 : 10} amp={8} phase={20} />
      <Ribbon y={578} fill={c.yellowT2} t={t} speed={14} amp={10} phase={40} />
      <g transform={`translate(0,${(1 - st) * 160})`} opacity={clamp(st * 3)}>
        {[0, 1, 2, 3, 4].map((i) => (
          <g key={i} filter="url(#ps)"><rect x={185 + i * 32} y={428 - (i + 1) * 24} width={32} height={(i + 1) * 24 + 30} fill={i % 2 ? c.tealT1 : c.tealT2} /></g>
        ))}
        <Chip x={300} y={262} text="Kos" size={18} fill={c.yellow} p={enter(t, KE.kos, 0.4)} />
      </g>
      {sign > 0.01 && (
        <g>
          <rect x={285} y={330} width={5} height={100} fill={c.gray2} />
          <Chip x={287} y={326} text="5 km" size={22} fill={c.yellow} w={84} h={40} p={sign} />
        </g>
      )}
      <Char x={120} y={426 - bob} t={t} rot={run ? 7 : 12} legL={sw * 42} legR={-sw * 42} armL={run ? 25 + sw * 35 : 15} armR={run ? 25 - sw * 35 : 15}
        mood={run ? (t > KE.tangga ? 'strain' : 'happy') : 'tired'} seed={5} sx={1.5} sy={1.5} />
      <Chip x={160} y={150} text="Lari 5 km" size={20} fill={c.white} p={enter(t, KE.lari, 0.5)} />
    </g>
  );
};

// ---------- F: kalimat 5 ----------
const KF = { cent: cue(5, 'centrifuge'), muka: cue(5, 'muka'), gagal: cue(5, 'gagal') };
export const SceneF = ({ t }: P) => {
  const m = enter(t, KF.muka, 0.6);
  const stretch = 1 + 0.45 * enter(t, KF.muka, 1.0) + 0.05 * Math.sin(t * 16);
  return (
    <g>
      <Bg fill={c.sky} />
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <circle cx={180} cy={200} r={80} fill="none" stroke={c.blueT3} strokeWidth={3} strokeDasharray="8 10" />
      <g filter="url(#ps)">
        <g transform="translate(180,200)">
          <g transform={`rotate(${t * 170})`}>
            <rect x={-80} y={-7} width={160} height={14} rx={7} fill={c.orange} />
            <circle cx={-80} cy={0} r={18} fill={c.white} /><circle cx={80} cy={0} r={18} fill={c.white} />
            <circle cx={-80} cy={0} r={18} fill="none" stroke={c.yellow} strokeWidth={4} /><circle cx={80} cy={0} r={18} fill="none" stroke={c.yellow} strokeWidth={4} />
            <circle cx={-80} cy={0} r={8} fill={c.skin} /><circle cx={80} cy={0} r={8} fill={c.skin} />
          </g>
          <circle r={22} fill={c.yellow} />
          <T x={0} y={0} size={19}>8G</T>
        </g>
      </g>
      <Chip x={180} y={80} text="Centrifuge 8G" size={21} fill={c.white} p={enter(t, KF.cent, 0.5)} />
      {m > 0.01 && (
        <g filter="url(#ps)" opacity={clamp(m * 2)}>
          <g transform={`translate(180,372) scale(${0.5 + 0.5 * m})`}>
            <circle r={66} fill={c.yellow} /><circle r={60} fill={c.white} />
            <ellipse rx={32 * stretch} ry={36 / (1 + 0.18 * (stretch - 1))} fill={c.skin} />
            <circle cx={-30 * stretch} cy={10} r={8} fill={c.orange} opacity={0.5} />
            <circle cx={30 * stretch} cy={10} r={8} fill={c.orange} opacity={0.5} />
            <path d="M-24,-8 L-9,-3 M24,-8 L9,-3" stroke={c.ink} strokeWidth={3.2} strokeLinecap="round" />
            <path d="M-17,16 Q0,30 17,16" stroke={c.ink} strokeWidth={3} fill="none" strokeLinecap="round" />
          </g>
        </g>
      )}
      <Chip x={282} y={318} text="Filter gagal" size={15} fill={c.orangeT2} rot={8} p={enter(t, KF.gagal, 0.4)} />
    </g>
  );
};
