# astronot-video (Remotion, 9:16, 30 fps)

Video "POV: Dipanggil NASA" bergaya paper-cut, disinkronkan per kata dengan narasi `public/narasi.mp3`.
Watermark teks **"Idin Riset"** ada di pojok kiri atas.

## Struktur
```
astronot-video/
  public/narasi.mp3     audio narasi
  narasi.txt            kalimat narasi (satu per baris)
  narasi.srt            SRT asli (hanya pembanding)
  timing.cjs            hitung timing dari audio -> src/timing.json
  src/theme.ts          SEMUA warna/ukuran/watermark/caption ada di sini
  src/timing.json       waktu tiap kalimat dan kata
  src/util.ts           easing, hash deterministik, cue(kalimat, kata)
  src/paper.tsx         komponen kertas (karakter, awan, roket, bumi, pita)
  src/scenes1.tsx       adegan A-F        src/scenes2.tsx  adegan G-L
  src/Video.tsx         komposisi murni Video({ t }) + transisi + caption + watermark
  src/Root.tsx          pembungkus Remotion (frame -> t, <Audio>)
  src/index.ts          registerRoot
```

## Render di GitHub Actions
Job di `render-remotion.yml` kira-kira:
1. `actions/checkout`
2. `actions/setup-node` (Node 20+)
3. `npm install` (tidak ada lockfile, jadi jangan `npm ci`)
4. `npm run render` -> menghasilkan `out/video.mp4`
5. `actions/upload-artifact` untuk `out/video.mp4`

Komposisi bernama `Astronot` (`remotion render src/index.ts Astronot out/video.mp4 --codec=h264 --crf=18`).
Pastikan working-directory job menunjuk ke folder `astronot-video`.

## Ubah watermark
Edit `theme.watermark` di `src/theme.ts` (`text`, `left`, `top`, `font`, `opacity`). Default: pojok kiri atas,
di bawah area status bar dan di luar zona tombol TikTok/Reels.

## Buat ulang timing (kalau audio diganti)
Butuh `ffmpeg`/`ffprobe`. Ganti `public/narasi.mp3` dan `narasi.txt`, lalu `node timing.cjs`.
Skrip menandai kalimat dengan laju bicara di luar 0,6-1,6x median. Cue visual diambil dari kata
(`cue(kalimat, kata)`), jadi kalau teks narasi berubah dan kata cue hilang, build akan error dengan pesan jelas.

## Catatan
- Versi Remotion di-pin `4.0.250` (semua paket remotion/@remotion/* harus satu versi; samakan dengan repo kamu).
- Font: Fredoka 700 via `@remotion/google-fonts` (dimuat saat render).
