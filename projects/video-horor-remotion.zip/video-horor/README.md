# Video Horor Narasi (Remotion)

Video vertikal 1080x1920, 30 fps, 58 detik, disinkronkan dengan audio narasi ElevenLabs (public/narasi.mp3).

## Cara pakai
1. Pastikan Node.js 18+ sudah terpasang.
2. `npm install`
   (kalau npm protes soal versi Remotion, jalankan `npx remotion upgrade`)
3. Preview: `npm run dev`  -> buka Remotion Studio, pilih komposisi "HorrorStory"
4. Render MP4: `npm run build`  -> hasil di `out/video-horor.mp4`

## Struktur adegan (detik)
- 0-14      Pendaki malam, hitungan 10 -> 11, judul "Gunung Sinabung"
- 14-21,6   Tiga kuntilanak melayang di atas pohon
- 21,6-34   Makam keramat, gamelan (gong), sosok menyeret kaki
- 34-51,5   Rumah bekas dukun, wanita berwajah merah, dua kuntilanak berayun, timer 10 menit
- 51,5-58   Penutup "Berani uji nyali?"

## Edit
- Waktu subtitle: `src/captions.ts` (SEGMENTS, dalam detik)
- Batas adegan: `src/timing.ts` (objek T)
- Visual tiap adegan: `src/scenes.tsx`
