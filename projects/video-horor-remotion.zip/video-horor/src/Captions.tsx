import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { CHUNKS } from "./captions";
import { fontFamily } from "./fonts";
import { C, FPS } from "./timing";

const HIGHLIGHT = new Set([
  "11", "kuntilanak", "gamelan", "mistis", "teror", "kengerian", "menyeramkan",
  "merah", "darah", "dukun", "nyali", "langkah", "misterius", "keramat",
]);

const clean = (w: string) => w.toLowerCase().replace(/[^\p{L}\p{N}]/gu, "");

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const chunk = CHUNKS.find((c) => t >= c.start && t < c.end + 0.04);
  if (!chunk) return null;
  const f = frame - Math.round(chunk.start * FPS);
  const op = interpolate(f, [0, 4], [0, 1], C);
  const sc = interpolate(f, [0, 5], [0.9, 1], C);
  return (
    <div
      style={{
        position: "absolute",
        left: 0,
        right: 0,
        bottom: 300,
        padding: "0 90px",
        textAlign: "center",
        fontFamily,
        fontWeight: 700,
        fontSize: 82,
        lineHeight: 1.12,
        textTransform: "uppercase",
        letterSpacing: 2,
        opacity: op,
        scale: String(sc),
      }}
    >
      {chunk.text.split(" ").map((w, i) => (
        <span
          key={i}
          style={{
            color: HIGHLIGHT.has(clean(w)) ? "#ff3b3b" : "#f4f1ea",
            textShadow: "0 4px 0 rgba(0,0,0,0.9), 0 0 30px rgba(0,0,0,0.95), 0 0 6px rgba(0,0,0,1)",
            marginRight: 18,
            display: "inline-block",
          }}
        >
          {w}
        </span>
      ))}
    </div>
  );
};
