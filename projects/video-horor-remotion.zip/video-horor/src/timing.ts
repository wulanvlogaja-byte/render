import { interpolate } from "remotion";

export const FPS = 30;
export const TOTAL_FRAMES = 1740; // 58 detik (audio 57,89 detik)
export const sec = (s: number) => Math.round(s * FPS);

// Batas adegan (detik, absolut) - hasil deteksi jeda di audio narasi
export const T = {
  A: [0, 14.0],
  B: [14.0, 21.62],
  C: [21.62, 34.35],
  D: [34.35, 51.56],
  E: [51.56, 58.0],
} as const;

export const C = {
  extrapolateLeft: "clamp",
  extrapolateRight: "clamp",
} as const;

export const rand = (seed: number) => {
  const x = Math.sin(seed * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

export const fadeInOut = (frame: number, dur: number, edge = 12) =>
  interpolate(frame, [0, edge, dur - edge, dur], [0, 1, 1, 0], C);
