import React from "react";
import {
  AbsoluteFill,
  Easing,
  interpolate,
  useCurrentFrame,
} from "remotion";
import { fontFamily } from "./fonts";
import { C, fadeInOut, rand, sec } from "./timing";

export const Fade: React.FC<{ dur: number; children: React.ReactNode }> = ({
  dur,
  children,
}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ opacity: fadeInOut(frame, dur) }}>
      {children}
    </AbsoluteFill>
  );
};

export const Sky: React.FC<{ top?: string; bottom?: string }> = ({
  top = "#04050b",
  bottom = "#0e1424",
}) => (
  <AbsoluteFill
    style={{ background: `linear-gradient(180deg, ${top} 0%, ${bottom} 100%)` }}
  />
);

export const Stars: React.FC<{ count?: number; seed?: number }> = ({
  count = 70,
  seed = 1,
}) => {
  const frame = useCurrentFrame();
  return (
    <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0 }}>
      {Array.from({ length: count }).map((_, i) => {
        const x = rand(i + seed) * 1080;
        const y = rand(i * 3 + seed + 9) * 900;
        const r = 0.8 + rand(i + 50) * 1.6;
        const tw = 0.4 + 0.6 * Math.abs(Math.sin(frame / 20 + i));
        return <circle key={i} cx={x} cy={y} r={r} fill="#dfe6ff" opacity={tw * 0.8} />;
      })}
    </svg>
  );
};

export const Moon: React.FC<{ x: number; y: number; r: number; color?: string }> = ({
  x,
  y,
  r,
  color = "#dfe6f5",
}) => (
  <svg width={1080} height={1920} style={{ position: "absolute", left: 0, top: 0 }}>
    <defs>
      <radialGradient id="moonGlow">
        <stop offset="0%" stopColor={color} stopOpacity="0.35" />
        <stop offset="100%" stopColor={color} stopOpacity="0" />
      </radialGradient>
    </defs>
    <circle cx={x} cy={y} r={r * 3.2} fill="url(#moonGlow)" />
    <circle cx={x} cy={y} r={r} fill={color} opacity={0.92} />
  </svg>
);

export const Fog: React.FC<{ opacity?: number; y?: number }> = ({
  opacity = 0.35,
  y = 1100,
}) => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{ pointerEvents: "none" }}>
      {[0, 1, 2].map((i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: -260,
            top: y + i * 170 - 200,
            width: 1600,
            height: 520,
            background: `radial-gradient(ellipse at center, rgba(180,190,210,${opacity}) 0%, rgba(180,190,210,0) 68%)`,
            translate: `${Math.sin(frame / 90 + i * 2) * 160}px 0px`,
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

export const Vignette: React.FC<{ strength?: number }> = ({ strength = 0.85 }) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at 50% 50%, rgba(0,0,0,0) 40%, rgba(0,0,0,${strength}) 100%)`,
      pointerEvents: "none",
    }}
  />
);

export const Pine: React.FC<{ x: number; y: number; h: number; fill: string }> = ({
  x,
  y,
  h,
  fill,
}) => {
  const w = h * 0.3;
  const tiers = [0, 1, 2].map((k) => {
    const top = y - h + k * h * 0.28;
    const bottom = y - h * (0.62 - k * 0.31) + h * 0.08;
    const ww = w * (0.55 + k * 0.3);
    return `M${x} ${top} L${x + ww} ${bottom} L${x - ww} ${bottom} Z`;
  });
  return (
    <g fill={fill}>
      {tiers.map((d, i) => (
        <path key={i} d={d} />
      ))}
      <rect x={x - 6} y={y - h * 0.12} width={12} height={h * 0.12} />
    </g>
  );
};

export const KuntiDefs: React.FC = () => (
  <defs>
    <linearGradient id="gown" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#e9edf5" stopOpacity="0.95" />
      <stop offset="1" stopColor="#e9edf5" stopOpacity="0" />
    </linearGradient>
    <radialGradient id="glowW">
      <stop offset="0" stopColor="#bcd0ff" stopOpacity="0.28" />
      <stop offset="1" stopColor="#bcd0ff" stopOpacity="0" />
    </radialGradient>
  </defs>
);

export const Kunti: React.FC<{
  x: number;
  y: number;
  s?: number;
  t0: number; // frame mulai muncul (lokal)
  phase?: number;
  faceFill?: string;
  eyes?: boolean;
  bobAmp?: number;
}> = ({ x, y, s = 1, t0, phase = 0, faceFill = "#d9dee8", eyes = true, bobAmp = 18 }) => {
  const frame = useCurrentFrame();
  if (frame < t0) return null;
  const op = interpolate(frame, [t0, t0 + 20], [0, 1], C);
  const bob = Math.sin(frame / 18 + phase) * bobAmp;
  const sway = Math.sin(frame / 25 + phase) * 4;
  return (
    <g transform={`translate(${x} ${y + bob}) scale(${s}) rotate(${sway})`} opacity={op}>
      <ellipse cx={0} cy={200} rx={170} ry={290} fill="url(#glowW)" />
      <path
        d="M-46 -8 C-70 140 -52 300 -10 360 C 30 300 62 140 46 -8 C 36 -58 -36 -58 -46 -8 Z"
        fill="#05060a"
      />
      <path
        d="M-48 62 C-70 200 -120 330 -135 430 Q -60 400 0 440 Q 60 400 135 430 C 120 330 70 200 48 62 Z"
        fill="url(#gown)"
      />
      <ellipse cx={0} cy={-2} rx={27} ry={34} fill={faceFill} />
      <path d="M-27 -14 C-20 -50 20 -50 27 -14 C 14 -30 -14 -30 -27 -14 Z" fill="#05060a" />
      {eyes && (
        <g>
          <circle cx={-10} cy={2} r={9} fill="#ff2020" opacity={0.28} />
          <circle cx={10} cy={2} r={9} fill="#ff2020" opacity={0.28} />
          <ellipse cx={-10} cy={2} rx={4.5} ry={3} fill="#ff1e1e" />
          <ellipse cx={10} cy={2} rx={4.5} ry={3} fill="#ff1e1e" />
        </g>
      )}
    </g>
  );
};

export const RedEyes: React.FC<{ x: number; y: number; s?: number; t0: number }> = ({
  x,
  y,
  s = 1,
  t0,
}) => {
  const frame = useCurrentFrame();
  if (frame < t0) return null;
  const op = interpolate(frame, [t0, t0 + 12], [0, 1], C);
  const blink = frame % 90 > 84 ? 0.1 : 1;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} opacity={op * blink}>
      <circle cx={-34} cy={0} r={34} fill="#ff1a1a" opacity={0.18} />
      <circle cx={34} cy={0} r={34} fill="#ff1a1a" opacity={0.18} />
      <ellipse cx={-34} cy={0} rx={18} ry={9} fill="#ff2323" />
      <ellipse cx={34} cy={0} rx={18} ry={9} fill="#ff2323" />
    </g>
  );
};

export const Title: React.FC<{
  text: string;
  sub?: string;
  at: number; // detik lokal adegan
  until?: number; // detik lokal adegan
}> = ({ text, sub, at, until }) => {
  const frame = useCurrentFrame();
  const f = frame - sec(at);
  const op =
    interpolate(f, [0, 18], [0, 1], C) *
    (until ? interpolate(frame, [sec(until - 0.5), sec(until)], [1, 0], C) : 1);
  const y = interpolate(f, [0, 24], [30, 0], { ...C, easing: Easing.out(Easing.cubic) });
  return (
    <div
      style={{
        position: "absolute",
        top: 230,
        left: 0,
        right: 0,
        textAlign: "center",
        opacity: op,
        translate: `0px ${y}px`,
        fontFamily,
      }}
    >
      {sub && (
        <div style={{ fontSize: 46, letterSpacing: 14, color: "#ff4a4a", fontWeight: 500 }}>
          {sub}
        </div>
      )}
      <div
        style={{
          fontSize: 108,
          fontWeight: 700,
          color: "#f4f1ea",
          lineHeight: 1.05,
          textShadow: "0 0 40px rgba(0,0,0,0.9)",
          padding: "0 70px",
        }}
      >
        {text}
      </div>
    </div>
  );
};
