// Waktu kalimat (detik) diambil dari jeda diam di audio.
// Pembagian kata per potongan subtitle diperkirakan berdasarkan panjang karakter.
type Seg = { start: number; end: number; text: string };

export const SEGMENTS: Seg[] = [
  { start: 0.0, end: 3.12, text: "Pernahkah kamu membayangkan mendaki gunung di malam hari," },
  { start: 3.48, end: 9.4, text: "lalu saat berhitung, jumlah rombongan yang tadinya 10 orang tiba-tiba terdengar menjadi 11 orang?" },
  { start: 9.93, end: 13.47, text: "Kejadian mistis ini dialami sekelompok pendaki di Gunung Sinabung." },
  { start: 14.02, end: 16.45, text: "Bukan cuma mendengar suara langkah misterius," },
  { start: 16.95, end: 21.62, text: "mereka bahkan melihat tiga sosok kuntilanak terbang mengawasi dari atas pohon." },
  { start: 22.1, end: 23.36, text: "Belum cukup sampai di situ," },
  { start: 23.86, end: 29.79, text: "teror berlanjut ke sebuah makam keramat di mana alunan gamelan tiba-tiba menggema di tengah malam sunyi," },
  { start: 30.26, end: 33.85, text: "diiringi penampakan sosok menyeramkan yang berjalan menyeret kaki." },
  { start: 34.35, end: 39.18, text: "Puncak kengerian dirasakan seorang wanita hamil yang tinggal di rumah bekas praktik dukun." },
  { start: 39.69, end: 44.12, text: "Ia dikejutkan oleh wanita berwajah merah darah yang berdiri di dekat suaminya," },
  { start: 44.61, end: 51.03, text: "serta dua ekor kuntilanak yang melayang dan berayun di atap kamar selama sepuluh menit penuh tanpa bisa bergerak." },
  { start: 51.56, end: 56.2, text: "Tiga kisah nyata ini membuktikan bahwa dimensi lain sangat dekat dengan kita." },
  { start: 56.77, end: 57.89, text: "Berani uji nyali?" },
];

export type Chunk = { start: number; end: number; text: string };

export const CHUNKS: Chunk[] = SEGMENTS.flatMap((seg) => {
  const words = seg.text.split(" ");
  const groups: string[][] = [];
  let cur: string[] = [];
  for (const w of words) {
    cur.push(w);
    if (cur.join(" ").length >= 16 || cur.length >= 4) {
      groups.push(cur);
      cur = [];
    }
  }
  if (cur.length) {
    if (groups.length && cur.join(" ").length < 8) {
      groups[groups.length - 1].push(...cur);
    } else {
      groups.push(cur);
    }
  }
  const total = groups.reduce((a, g) => a + g.join(" ").length + 1, 0);
  let t = seg.start;
  return groups.map((g) => {
    const d = ((g.join(" ").length + 1) / total) * (seg.end - seg.start);
    const chunk = { start: t, end: t + d, text: g.join(" ") };
    t += d;
    return chunk;
  });
});
