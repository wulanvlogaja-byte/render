import { Composition } from "remotion";
import { HorrorVideo } from "./Video";
import { FPS, TOTAL_FRAMES } from "./timing";

export const Root = () => {
  return (
    <Composition
      id="HorrorStory"
      component={HorrorVideo}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={1080}
      height={1920}
    />
  );
};
