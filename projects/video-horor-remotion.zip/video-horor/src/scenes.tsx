import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import {
  Fade, Fog, Kunti, KuntiDefs, Moon, Pine, RedEyes, Sky, Stars, Title, Vignette,
} from "./parts";
import { fontFamily } from "./fonts";
import { C, FPS, T, rand, sec } from "./timing";

const dur = (k: keyof typeof T) => sec(T[k][1] - T[k][0]);
const SVG: React.CSSProperties = { position: "absolute", left: 0, top: 0 };

/* ============ ADEGAN A: pendaki, hitungan 10 -> 11 (0 - 14 dtk) ============ */
export const SceneA: React.FC = () => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const P0 = [130, 1600], P1 = [640, 1560], P2 = [690, 1070];
  const pos = (u: number) => {
    const a = (1 - u) ** 2, b = 2 * u * (1 - u), c = u * u;
    return [a * P0[0] + b * P1[0] + c * P2[0], a * P0[1] + b * P1[1] + c * P2[1]];
  };

  let n = t < 3.6 ? 0 : Math.min(10, Math.floor((t - 3.6) / 0.3) + 1);
  if (t >= 7.4 && t < 8.4) n = Math.floor(frame / 3) % 2 === 0 ? 10 : 11;
  if (t >= 8.4) n = 11;
  const isRed = n === 11 && t >= 8.4;
  const shake = isRed && t < 9.6 ? 10 : 0;
  const counterOp =
    interpolate(t, [3.5, 3.7], [0, 1], C) * interpolate(t, [9.9, 10.4], [1, 0.45], C);

  const ghost = pos(0.5);
  const ghostOp = t < 8.2 ? 0 : frame % 4 < 2 || t > 8.8 ? 1 : 0.2;

  return (
    <Fade dur={dur("A")}>
      <Sky />
      <Stars />
      <Moon x={900} y={330} r={70} />
      <svg width={1080} height={1920} style={SVG}>
        <path d="M0 1100 L180 820 L330 960 L560 600 L760 880 L900 760 L1080 950 L1080 1920 L0 1920 Z" fill="#0b1122" />
        <path d="M0 1350 L220 1130 L420 1280 L700 1000 L1080 1250 L1080 1920 L0 1920 Z" fill="#060912" />
        <path
          d={`M${P0[0]} ${P0[1]} Q${P1[0]} ${P1[1]} ${P2[0]} ${P2[1]}`}
          stroke="rgba(255,255,255,0.07)" strokeWidth={10} fill="none" strokeDasharray="8 20"
        />
        {Array.from({ length: 10 }).map((_, i) => {
          const [x, y] = pos(0.06 + (0.88 * i) / 9);
          const op = interpolate(frame, [sec(0.5 + i * 0.28), sec(0.5 + i * 0.28) + 8], [0, 1], C);
          return (
            <g key={i} opacity={op}>
              <polygon points={`${x},${y} ${x + 74},${y - 48} ${x + 74},${y - 6}`} fill="rgba(255,226,150,0.12)" />
              <circle cx={x} cy={y} r={26} fill="#ffd98a" opacity={0.18} />
              <circle cx={x} cy={y} r={9} fill="#ffe7ae" />
            </g>
          );
        })}
        <g opacity={ghostOp}>
          <polygon points={`${ghost[0] + 36},${ghost[1] + 22} ${ghost[0] + 110},${ghost[1] - 26} ${ghost[0] + 110},${ghost[1] + 16}`} fill="rgba(255,40,40,0.16)" />
          <circle cx={ghost[0] + 36} cy={ghost[1] + 22} r={34} fill="#ff2a2a" opacity={0.25} />
          <circle cx={ghost[0] + 36} cy={ghost[1] + 22} r={10} fill="#ff4040" />
        </g>
      </svg>
      <Fog opacity={0.28} y={1250} />
      <Vignette />
      <div
        style={{
          position: "absolute", top: 470, left: 0, right: 0, textAlign: "center",
          fontFamily, opacity: counterOp,
          translate: `${(rand(frame) - 0.5) * shake}px ${(rand(frame + 7) - 0.5) * shake}px`,
        }}
      >
        <div
          style={{
            fontSize: 360, fontWeight: 700, lineHeight: 1,
            color: isRed ? "#ff2d2d" : "#f4f1ea",
            textShadow: isRed ? "0 0 60px rgba(255,30,30,0.8)" : "0 0 40px rgba(0,0,0,0.9)",
          }}
        >
          {n}
        </div>
        <div style={{ fontSize: 54, letterSpacing: 16, color: "#9aa4bd", fontWeight: 500 }}>
          ORANG
        </div>
      </div>
      <Title text="GUNUNG SINABUNG" sub="KISAH 1" at={9.93} />
    </Fade>
  );
};

/* ============ ADEGAN B: tiga kuntilanak di atas pohon (14 - 21.6 dtk) ============ */
export const SceneB: React.FC = () => {
  const frame = useCurrentFrame();
  const g = (s: number) => sec(s - T.B[0]);
  const steps = [14.3, 14.95, 15.6, 16.2];
  return (
    <Fade dur={dur("B")}>
      <Sky top="#03050a" bottom="#0a1018" />
      <Stars seed={5} />
      <Moon x={200} y={300} r={60} />
      <svg width={1080} height={1920} style={SVG}>
        <KuntiDefs />
        {Array.from({ length: 14 }).map((_, i) => (
          <Pine key={`f${i}`} x={i * 85 - 20 + rand(i) * 20} y={1560} h={400 + rand(i + 3) * 180} fill="#070b14" />
        ))}
        {steps.map((ts, i) => {
          const f = frame - g(ts);
          if (f < 0 || f > 24) return null;
          const r = interpolate(f, [0, 24], [10, 170], C);
          const o = interpolate(f, [0, 24], [0.55, 0], C);
          return (
            <ellipse key={i} cx={i % 2 ? 700 : 380} cy={1640} rx={r} ry={r * 0.35}
              stroke="#aab4c8" strokeWidth={4} fill="none" opacity={o} />
          );
        })}
        <Kunti x={270} y={720} s={1.0} t0={g(18.4)} phase={0} />
        <Kunti x={540} y={520} s={1.2} t0={g(19.0)} phase={2} />
        <Kunti x={810} y={780} s={0.9} t0={g(19.6)} phase={4} />
        {Array.from({ length: 11 }).map((_, i) => (
          <Pine key={`n${i}`} x={i * 105 - 10 + rand(i + 20) * 25} y={1800} h={520 + rand(i + 9) * 200} fill="#03050a" />
        ))}
      </svg>
      <Fog opacity={0.3} y={1300} />
      <Vignette />
    </Fade>
  );
};

/* ============ ADEGAN C: makam keramat, gamelan, sosok menyeret kaki (21.6 - 34.35 dtk) ============ */
const Grave: React.FC<{ x: number; y: number; w: number; h: number; fill: string; cross?: boolean }> = ({
  x, y, w, h, fill, cross,
}) => (
  <g fill={fill}>
    {cross ? (
      <g>
        <rect x={x - w * 0.12} y={y - h} width={w * 0.24} height={h} />
        <rect x={x - w * 0.45} y={y - h * 0.8} width={w * 0.9} height={w * 0.22} />
      </g>
    ) : (
      <path d={`M${x - w} ${y} L${x - w} ${y - h + w} A${w} ${w} 0 0 1 ${x + w} ${y - h + w} L${x + w} ${y} Z`} />
    )}
  </g>
);

export const SceneC: React.FC = () => {
  const frame = useCurrentFrame();
  const g = (s: number) => sec(s - T.C[0]);
  const gongStart = g(27.3);
  const f0 = frame - gongStart;
  const pulse = f0 >= 0 ? 1 + 0.06 * Math.max(0, 1 - (f0 % 28) / 8) : 1;
  const gongOp = interpolate(frame, [g(26.8), g(27.3)], [0, 1], C);

  const walkT0 = g(30.26);
  const walkT = interpolate(frame, [walkT0, g(34.2)], [0, 1], C);
  const wt = walkT - Math.sin(walkT * 40) * 0.015;
  const figX = interpolate(wt, [0, 1], [980, 240], C) + Math.sin(frame / 3.2) * 7;
  const figOp = interpolate(frame, [walkT0, walkT0 + 15], [0, 1], C);
  const lean = Math.sin(frame / 6.4) * 5 + 5;

  return (
    <Fade dur={dur("C")}>
      <Sky top="#040809" bottom="#0e1d20" />
      <Stars seed={9} count={50} />
      <Moon x={170} y={300} r={56} color="#cfe6e4" />
      <svg width={1080} height={1920} style={SVG}>
        <defs>
          <radialGradient id="gongG">
            <stop offset="0" stopColor="#e8c569" />
            <stop offset="1" stopColor="#7a5a1c" />
          </radialGradient>
          <radialGradient id="backGlow">
            <stop offset="0" stopColor="#78aaaa" stopOpacity="0.4" />
            <stop offset="1" stopColor="#78aaaa" stopOpacity="0" />
          </radialGradient>
        </defs>
        <rect x={0} y={1280} width={1080} height={640} fill="#070d0f" />
        {[130, 330, 560, 760, 940].map((x, i) => (
          <Grave key={`a${i}`} x={x} y={1330} w={34} h={120} fill="#0b1417" cross={i % 3 === 1} />
        ))}
        {/* gong */}
        <g opacity={gongOp}>
          <line x1={340} y1={420} x2={740} y2={420} stroke="#2a1f10" strokeWidth={14} />
          <line x1={540} y1={420} x2={540} y2={590} stroke="#2a1f10" strokeWidth={5} />
          {[0, 1, 2, 3].map((j) => {
            const ff = (((f0 - j * 28) % 112) + 112) % 112;
            if (f0 - j * 28 < 0) return null;
            return (
              <circle key={j} cx={540} cy={700} r={interpolate(ff, [0, 84], [110, 560], C)}
                stroke="#d9b45a" strokeWidth={5} fill="none"
                opacity={interpolate(ff, [0, 84], [0.6, 0], C)} />
            );
          })}
          <g transform={`translate(540 700) scale(${pulse})`}>
            <circle r={120} fill="url(#gongG)" stroke="#5a4214" strokeWidth={6} />
            <circle r={80} fill="none" stroke="#5a4214" strokeWidth={3} opacity={0.6} />
            <circle r={32} fill="#b88f35" stroke="#5a4214" strokeWidth={4} />
          </g>
        </g>
        {/* sosok menyeret kaki */}
        <g opacity={figOp}>
          <ellipse cx={figX} cy={1150} rx={260} ry={420} fill="url(#backGlow)" />
          <line x1={figX + 20} y1={1500} x2={Math.min(1080, figX + 20 + (980 - figX) * 0.5)} y2={1500}
            stroke="rgba(0,0,0,0.7)" strokeWidth={7} strokeDasharray="14 10" />
          <g transform={`translate(${figX} 960) rotate(${lean})`}>
            <path d="M-40 40 Q-78 300 -52 540 L-20 540 L0 350 L24 540 L56 540 Q 78 300 40 40 Z" fill="#020304" />
            <path d="M-40 60 Q-95 220 -78 420" stroke="#020304" strokeWidth={14} fill="none" strokeLinecap="round" />
            <path d="M40 60 Q95 220 78 420" stroke="#020304" strokeWidth={14} fill="none" strokeLinecap="round" />
            <circle cx={4} cy={0} r={36} fill="#020304" />
            <circle cx={-8} cy={-2} r={5} fill="#ff2a2a" />
            <circle cx={14} cy={-2} r={5} fill="#ff2a2a" />
          </g>
        </g>
        {[80, 300, 540, 800, 1000].map((x, i) => (
          <Grave key={`b${i}`} x={x} y={1760} w={60} h={230} fill="#050a0c" cross={i === 2} />
        ))}
      </svg>
      <Fog opacity={0.32} y={1250} />
      <Vignette />
      <Title text="MAKAM KERAMAT" sub="KISAH 2" at={25.3 - T.C[0]} until={29.5 - T.C[0]} />
    </Fade>
  );
};

/* ============ ADEGAN D: rumah bekas dukun, wanita hamil (34.35 - 51.56 dtk) ============ */
export const SceneD: React.FC = () => {
  const frame = useCurrentFrame();
  const g = (s: number) => sec(s - T.D[0]);
  const extOp = interpolate(frame, [g(39.2), g(39.9)], [1, 0], C);
  const intOp = interpolate(frame, [g(39.2), g(39.9)], [0, 1], C);
  const flick = 0.55 + 0.45 * rand(Math.floor(frame / 3));

  const timerIn = interpolate(frame, [g(47.6), g(48.1)], [0, 1], C);
  const prog = interpolate(frame, [g(48.1), g(51.0)], [0, 1], C);
  const CIRC = 2 * Math.PI * 110;
  const vig = interpolate(frame, [g(48.1), g(51.0)], [70, 22], C);
  const vigOp = interpolate(frame, [g(47.8), g(48.6)], [0, 1], C);

  const swing1 = Math.sin(frame / 20) * 12;
  const swing2 = Math.sin(frame / 20 + 2.2) * 10;

  return (
    <Fade dur={dur("D")}>
      {/* eksterior */}
      <AbsoluteFill style={{ opacity: extOp }}>
        <Sky top="#04050a" bottom="#101424" />
        <Stars seed={13} count={45} />
        <Moon x={540} y={760} r={190} />
        <svg width={1080} height={1920} style={SVG}>
          <rect x={0} y={1400} width={1080} height={520} fill="#04060a" />
          <polygon points="250,1060 540,800 830,1060" fill="#05070c" />
          <rect x={300} y={1060} width={480} height={420} fill="#05070c" />
          <rect x={440} y={1180} width={110} height={130} fill="#ffcf70" opacity={flick} />
          <rect x={440} y={1180} width={110} height={130} fill="none" stroke="#05070c" strokeWidth={8} />
          <line x1={495} y1={1180} x2={495} y2={1310} stroke="#05070c" strokeWidth={6} />
          <line x1={440} y1={1245} x2={550} y2={1245} stroke="#05070c" strokeWidth={6} />
          <rect x={620} y={1290} width={90} height={190} fill="#020305" />
          {[[120, 1420], [960, 1440]].map(([x, y], i) => (
            <g key={i} stroke="#030407" strokeWidth={12} strokeLinecap="round" fill="none">
              <path d={`M${x} ${y} L${x} ${y - 420}`} />
              <path d={`M${x} ${y - 250} L${x - 90} ${y - 360}`} />
              <path d={`M${x} ${y - 320} L${x + 80} ${y - 430}`} />
            </g>
          ))}
        </svg>
        <Fog opacity={0.3} y={1300} />
        <Vignette />
        <Title text="RUMAH BEKAS DUKUN" sub="KISAH 3" at={36.3 - T.D[0]} until={39.4 - T.D[0]} />
      </AbsoluteFill>

      {/* interior kamar */}
      <AbsoluteFill style={{ opacity: intOp }}>
        <svg width={1080} height={1920} style={SVG}>
          <KuntiDefs />
          <defs>
            <linearGradient id="moonBeam" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0" stopColor="#bcd0ff" stopOpacity="0.28" />
              <stop offset="1" stopColor="#bcd0ff" stopOpacity="0" />
            </linearGradient>
          </defs>
          <rect x={0} y={0} width={1080} height={1920} fill="#0a0608" />
          <polygon points="0,0 1080,0 900,260 180,260" fill="#0c0709" />
          <polygon points="0,0 180,260 180,1250 0,1500" fill="#120a0d" />
          <polygon points="1080,0 900,260 900,1250 1080,1500" fill="#120a0d" />
          <rect x={180} y={260} width={720} height={990} fill="#1b1114" />
          <polygon points="0,1500 180,1250 900,1250 1080,1500 1080,1920 0,1920" fill="#0f0809" />
          <rect x={260} y={440} width={160} height={300} fill="#8aa0d6" opacity={0.35} />
          <polygon points="260,740 420,740 520,1250 120,1250" fill="url(#moonBeam)" />
          {/* ranjang */}
          <rect x={230} y={1140} width={620} height={360} rx={16} fill="#2a1a1e" />
          <rect x={230} y={1250} width={620} height={250} fill="#3a2328" />
          <rect x={320} y={1160} width={170} height={56} rx={22} fill="#b9aeb0" opacity={0.7} />
          <rect x={600} y={1165} width={170} height={56} rx={22} fill="#b9aeb0" opacity={0.7} />
          <circle cx={405} cy={1200} r={32} fill="#6b4e48" />
          <circle cx={685} cy={1205} r={32} fill="#6b4e48" />
          <ellipse cx={420} cy={1290} rx={130} ry={56} fill="#4a2d33" />
          <ellipse cx={690} cy={1294} rx={120} ry={54} fill="#4a2d33" />
          <circle cx={735} cy={1280} r={50} fill="#4a2d33" />
          {/* wanita berwajah merah */}
          <Kunti x={170} y={760} s={1.05} t0={g(41.3)} phase={1} faceFill="#8a0f14" eyes={false} bobAmp={6} />
          {/* dua kuntilanak berayun di atap */}
          <g transform={`rotate(${swing1} 420 240)`}>
            <Kunti x={420} y={450} s={0.8} t0={g(45.7)} phase={0} bobAmp={4} />
          </g>
          <g transform={`rotate(${swing2} 700 240)`}>
            <Kunti x={700} y={450} s={0.8} t0={g(46.3)} phase={2} bobAmp={4} />
          </g>
        </svg>
        <Fog opacity={0.18} y={1200} />
        <Vignette strength={0.9} />
        <AbsoluteFill
          style={{
            opacity: vigOp,
            background: `radial-gradient(circle at 50% 58%, rgba(0,0,0,0) ${vig}%, rgba(0,0,0,0.94) 100%)`,
          }}
        />
        <div style={{ position: "absolute", left: 0, right: 0, top: 150, opacity: timerIn, fontFamily, textAlign: "center" }}>
          <svg width={300} height={300} viewBox="0 0 300 300" style={{ display: "block", margin: "0 auto" }}>
            <circle cx={150} cy={150} r={110} stroke="rgba(255,255,255,0.12)" strokeWidth={12} fill="none" />
            <circle cx={150} cy={150} r={110} stroke="#ff2d2d" strokeWidth={12} fill="none" strokeLinecap="round"
              strokeDasharray={CIRC} strokeDashoffset={CIRC * (1 - prog)} transform="rotate(-90 150 150)" />
            <text x={150} y={170} textAnchor="middle" fontSize={96} fontWeight={700} fill="#f4f1ea" fontFamily={fontFamily}>10</text>
            <text x={150} y={218} textAnchor="middle" fontSize={34} letterSpacing={8} fill="#ff6a6a" fontFamily={fontFamily}>MENIT</text>
          </svg>
        </div>
      </AbsoluteFill>
    </Fade>
  );
};

/* ============ ADEGAN E: penutup (51.56 - 58 dtk) ============ */
export const SceneE: React.FC = () => {
  const frame = useCurrentFrame();
  const g = (s: number) => sec(s - T.E[0]);
  const t1 = interpolate(frame, [g(51.7), g(52.2)], [0, 1], C);
  const q = interpolate(frame, [g(56.77), g(57.1)], [0, 1], C);
  const qScale = 1 + 0.04 * Math.sin(frame / 5);
  const flash = frame >= g(56.77) && frame < g(56.77) + 6 ? 0.35 : 0;
  return (
    <Fade dur={dur("E")}>
      <Sky top="#030306" bottom="#0b0a12" />
      <Stars seed={21} count={30} />
      <svg width={1080} height={1920} style={SVG}>
        <RedEyes x={300} y={740} s={1.1} t0={g(52.4)} />
        <RedEyes x={730} y={1000} s={1.4} t0={g(53.4)} />
        <RedEyes x={430} y={1250} s={0.9} t0={g(54.4)} />
      </svg>
      <Fog opacity={0.4} y={1000} />
      <Vignette strength={0.92} />
      <div
        style={{
          position: "absolute", top: 250, left: 0, right: 0, textAlign: "center",
          fontFamily, opacity: t1,
        }}
      >
        <div style={{ fontSize: 150, fontWeight: 700, color: "#ff3b3b", textShadow: "0 0 50px rgba(255,30,30,0.6)" }}>3</div>
        <div style={{ fontSize: 76, fontWeight: 700, color: "#f4f1ea", letterSpacing: 6 }}>KISAH NYATA</div>
      </div>
      <div
        style={{
          position: "absolute", top: 640, left: 0, right: 0, textAlign: "center",
          fontFamily, fontWeight: 700, fontSize: 132, lineHeight: 1.05, color: "#ff2d2d",
          opacity: q, scale: String(qScale), padding: "0 60px",
          textShadow: "0 0 60px rgba(255,20,20,0.7), 0 6px 0 rgba(0,0,0,0.9)",
        }}
      >
        BERANI
        <br />
        UJI NYALI?
      </div>
      <AbsoluteFill style={{ background: "#ff0000", opacity: flash, mixBlendMode: "screen" }} />
    </Fade>
  );
};
