import { loadFont } from "@remotion/google-fonts/Oswald";

export const { fontFamily } = loadFont("normal", {
  weights: ["500", "700"],
  subsets: ["latin"],
});
