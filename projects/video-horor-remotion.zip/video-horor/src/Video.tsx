import React from "react";
import { AbsoluteFill, Sequence, staticFile, useCurrentFrame } from "remotion";
import { Audio } from "@remotion/media";
import { Captions } from "./Captions";
import { SceneA, SceneB, SceneC, SceneD, SceneE } from "./scenes";
import { T, TOTAL_FRAMES, rand, sec } from "./timing";

const seq = (k: keyof typeof T) => ({
  from: sec(T[k][0]),
  durationInFrames: k === "E" ? TOTAL_FRAMES - sec(T[k][0]) : sec(T[k][1] - T[k][0]),
});

export const HorrorVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const flicker = 0.03 + 0.06 * rand(Math.floor(frame / 2));
  return (
    <AbsoluteFill style={{ backgroundColor: "#000" }}>
      <Audio src={staticFile("narasi.mp3")} />
      <Sequence {...seq("A")}><SceneA /></Sequence>
      <Sequence {...seq("B")}><SceneB /></Sequence>
      <Sequence {...seq("C")}><SceneC /></Sequence>
      <Sequence {...seq("D")}><SceneD /></Sequence>
      <Sequence {...seq("E")}><SceneE /></Sequence>
      <AbsoluteFill style={{ backgroundColor: "#000", opacity: flicker, pointerEvents: "none" }} />
      <Captions />
    </AbsoluteFill>
  );
};
