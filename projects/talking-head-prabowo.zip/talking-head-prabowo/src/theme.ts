// Semua warna, ukuran, dan teks yang bisa diubah ada di sini. Tidak ada hex di file lain.
export const theme = {
  c: {
    page: '#FFF8E8', white: '#FFFFFF', ink: '#1B2A3A', dim: '#4A5A6C', shadow: '#1B2A3A',
    blue: '#2D9CDB', teal: '#00BFA6', yellow: '#FFC93C', red: '#FF5D5D',
    blueT: '#DDF0FB', tealT: '#D5F5EF', yellowT: '#FFF0C2', redT: '#FFE1E1',
  },
  shadowCss: '0 10px 26px rgba(27,42,58,0.22)',
  shadowSoftCss: '0 6px 16px rgba(27,42,58,0.18)',
  text: {
    channel: 'NAMA CHANNEL',                       // ganti dengan nama channel
    title: 'Setia kepada Republik & Rakyat',        // ganti dengan judul video
    sticker: 'Cuplikan pidato',                     // '' = matikan
    attribution: 'Pernyataan narasumber dalam pidato', // '' = matikan chip atribusi
  },
  size: { w: 1920, h: 1080, pad: 10, captionFont: 56, captionMaxWords: 7 },
  header: { y: 24, h: 72 },
  caption: { x: 60, y: 868, w: 1800, h: 184, r: 44 },
  footage: { baseZoom: 1.25, altZoom: 1.09, push: 0.035, originX: '50%', originY: '0%' }, // baseZoom >= 1.25 menyembunyikan subtitle burn-in di bawah frame
  motion: { layoutMin: 6.5, layoutDur: 0.6, sceneIn: 0.5, sceneOut: 0.4, tailNoLayout: 3 },
  layouts: [
    { name: 'cardLeft', F: { x: 60, y: 150, w: 1000, h: 562, r: 44 }, S: { x: 1110, y: 215, w: 750 } },
    { name: 'circleRight', F: { x: 1280, y: 170, w: 560, h: 560, r: 280 }, S: { x: 70, y: 195, w: 1100 } },
    { name: 'cornerSmall', F: { x: 1340, y: 150, w: 520, h: 292, r: 36 }, S: { x: 60, y: 140, w: 1230 } },
    { name: 'hero', F: { x: 60, y: 140, w: 1180, h: 664, r: 48 }, S: { x: 1280, y: 300, w: 580 } },
    { name: 'circleLeft', F: { x: 80, y: 170, w: 560, h: 560, r: 280 }, S: { x: 740, y: 195, w: 1100 } },
    { name: 'cardRight', F: { x: 860, y: 150, w: 1000, h: 562, r: 44 }, S: { x: 60, y: 215, w: 750 } },
  ],
} as const;
export type Layout = (typeof theme.layouts)[number];
