import timing from './timing.json';
import { theme } from './theme';

export type Word = { w: string; start: number; end: number; unit: number };
export const T = timing as unknown as { fps: number; width: number; height: number; duration: number; cuts: { src0: number; src1: number; out0: number; out1: number }[]; words: Word[]; units: { text: string; start: number; end: number }[] };

export const norm = (s: string) => s.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
/** Waktu (detik, waktu hasil edit) kata ke-n yang diucapkan. Melempar error jelas bila tidak ada. */
export function cue(kata: string, n = 0): number {
  let c = 0;
  for (const w of T.words) if (norm(w.w) === kata) { if (c === n) return w.start; c++; }
  throw new Error(`cue("${kata}", ${n}) tidak ditemukan di timing.json`);
}

/** Titik zoom (semua potongan + titik layout) dan titik ganti layout. Murni, deterministik. */
export function makePlan() {
  const cutStarts = T.cuts.slice(1).map((c) => c.out0);
  const cand = [...new Set([...cutStarts, ...T.units.map((u) => u.start)])].filter((x) => x > 1 && x < T.duration - theme.motion.tailNoLayout).sort((a, b) => a - b);
  const layoutBeats: number[] = [0];
  for (const c of cand) if (c - layoutBeats[layoutBeats.length - 1] >= theme.motion.layoutMin) layoutBeats.push(c);
  const beats = [...new Set([0, ...cutStarts, ...layoutBeats])].sort((a, b) => a - b);
  return { beats, layoutBeats };
}
export const PLAN = makePlan();

export type Chunk = { words: Word[]; start: number };
export function makeChunks(): Chunk[] {
  const out: Chunk[] = []; let cur: Word[] = [];
  for (const w of T.words) {
    cur.push(w);
    const punct = /[.,?!;:]$/.test(w.w);
    if (cur.length >= theme.size.captionMaxWords || (punct && cur.length >= 3) || (w !== T.words[T.words.length - 1] && T.words[T.words.indexOf(w) + 1].unit !== w.unit && cur.length >= 3)) { out.push({ words: cur, start: cur[0].start }); cur = []; }
  }
  if (cur.length) out.push({ words: cur, start: cur[0].start });
  return out;
}
export const CHUNKS = makeChunks();
