import React from 'react';
import { theme } from './theme';
import { cue } from './plan';

const c = theme.c;
export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const easeBack = (x: number) => { const k = 1.70158, q = clamp(x) - 1; return 1 + (k + 1) * q * q * q + k * q * q; };
export const easeIO = (x: number) => { const q = clamp(x); return q < 0.5 ? 4 * q * q * q : 1 - Math.pow(-2 * q + 2, 3) / 2; };

type Ctx = { t: number; lt: number; e: number };
type ChipDef = { text: string; at: number; x: number; y: number; col: string };
export type Scene = { key: string; a: number; chips: ChipDef[]; art: (k: Ctx) => React.ReactNode };

const Person = ({ x, y, s = 1, fill }: { x: number; y: number; s?: number; fill: string }) => (
  <g filter="url(#ps)"><circle cx={x} cy={y - 36 * s} r={8 * s} fill={fill} /><rect x={x - 11 * s} y={y - 27 * s} width={22 * s} height={27 * s} rx={11 * s} fill={fill} /></g>
);
const Star = ({ x, y, r, fill }: { x: number; y: number; r: number; fill: string }) => (
  <path d={`M${x} ${y - r} Q${x} ${y} ${x + r} ${y} Q${x} ${y} ${x} ${y + r} Q${x} ${y} ${x - r} ${y} Q${x} ${y} ${x} ${y - r}Z`} fill={fill} />
);
const accents = [c.blue, c.teal, c.yellow, c.red];

const Mic = ({ t }: Ctx) => (
  <g>
    {Array.from({ length: 14 }, (_, i) => i - 7).filter((i) => Math.abs(i + 0.5) > 2.2).map((i) => { const h = 12 + 44 * Math.abs(Math.sin(t * 3.1 + i * 0.85)); return <rect key={i} x={186 + i * 15} y={78 - h / 2} width={9} height={h} rx={4.5} fill={accents[((i % 4) + 4) % 4]} filter="url(#ps)" />; })}
    <g filter="url(#ps)"><rect x={166} y={42} width={28} height={58} rx={14} fill={c.white} /><rect x={166} y={66} width={28} height={8} fill={c.yellow} /></g>
    <path d="M154 80 a26 26 0 0 0 52 0" stroke={c.ink} strokeWidth={5} fill="none" strokeLinecap="round" />
    <rect x={177.5} y={106} width={5} height={34} fill={c.ink} /><rect x={158} y={138} width={44} height={7} rx={3.5} fill={c.ink} />
  </g>
);
const Republik = (_: Ctx) => (
  <g>
    <g filter="url(#ps)"><path d="M32 86 L90 52 L148 86Z" fill={c.red} /><rect x={36} y={86} width={108} height={8} fill={c.yellow} />
      {[48, 68, 88, 108, 126].map((x) => <rect key={x} x={x} y={94} width={12} height={48} fill={c.white} />)}
      <rect x={32} y={142} width={116} height={9} rx={2} fill={c.blue} /><rect x={24} y={151} width={132} height={9} rx={2} fill={c.teal} /></g>
    {[218, 246, 274, 302, 330].map((x, i) => <Person key={x} x={x} y={152} s={0.95 + (i % 3) * 0.08} fill={accents[i % 4]} />)}
  </g>
);
const Shield = ({ t }: Ctx) => (
  <g>
    <path d="M180 36 L228 52 V98 C228 126 206 144 180 156 C154 144 132 126 132 98 V52 Z" fill={c.blue} filter="url(#ps)" />
    <path d="M180 50 L216 62 V98 C216 118 200 133 180 144 C160 133 144 118 144 98 V62 Z" fill={c.white} />
    <path d="M180 124 C150 104 156 80 172 82 C178 83 180 88 180 92 C180 88 182 83 188 82 C204 80 210 104 180 124Z" fill={c.red} transform={`translate(0 ${Math.sin(t * 4) * 1.5})`} />
    <Star x={108} y={62} r={9} fill={c.yellow} /><Star x={258} y={52} r={11} fill={c.yellow} /><Star x={272} y={112} r={7} fill={c.teal} />
  </g>
);
const Islands = ({ mode, t }: Ctx & { mode: 'tanah' | 'sm' }) => {
  const bl: [number, number, number, number, number][] = [[62, 92, 26, 11, -35], [118, 124, 38, 7, 12], [188, 100, 34, 22, 0], [246, 112, 22, 15, 30], [304, 98, 24, 17, -10], [148, 78, 12, 8, 0]];
  return (
    <g>
      {bl.map(([x, y, rx, ry, rot], i) => <ellipse key={i} cx={x} cy={y} rx={rx} ry={ry} fill={[c.teal, c.yellow, c.teal, c.blue, c.yellow, c.blue][i]} transform={`rotate(${rot} ${x} ${y})`} filter="url(#ps)" />)}
      {mode === 'sm' ? (
        <g><path d="M50 74 Q180 34 316 74" stroke={c.red} strokeWidth={3} strokeDasharray="7 6" fill="none" strokeLinecap="round" strokeDashoffset={-t * 14} />
          {[50, 316].map((x) => <g key={x} filter="url(#ps)"><path d={`M${x} 82 C${x - 12} 66 ${x - 12} 56 ${x} 56 C${x + 12} 56 ${x + 12} 66 ${x} 82Z`} fill={c.red} /><circle cx={x} cy={65} r={4} fill={c.white} /></g>)}</g>
      ) : (
        <g filter="url(#ps)"><path d="M188 66 C174 50 174 38 188 38 C202 38 202 50 188 66Z" fill={c.red} transform={`translate(0 ${Math.sin(t * 4) * 2})`} /></g>
      )}
    </g>
  );
};
const Target = ({ t }: Ctx) => (
  <g>
    <g filter="url(#ps)">{[62, 48, 34, 20, 8].map((r, i) => <circle key={r} cx={160} cy={96} r={r} fill={[c.red, c.white, c.red, c.white, c.yellow][i]} />)}</g>
    <g transform={`translate(${Math.sin(t * 3) * 1.5} 0)`}><line x1={160} y1={96} x2={232} y2={34} stroke={c.ink} strokeWidth={5} strokeLinecap="round" /><path d="M232 34 L246 26 L242 44Z" fill={c.blue} /><path d="M222 42 L238 34 L234 52Z" fill={c.teal} /></g>
  </g>
);
const House = ({ t }: Ctx) => (
  <g>
    <g filter="url(#ps)"><rect x={118} y={96} width={104} height={58} fill={c.white} /><path d="M108 100 L170 54 L232 100Z" fill={c.red} /><rect x={160} y={118} width={20} height={36} rx={3} fill={c.yellow} /><rect x={130} y={110} width={20} height={20} rx={3} fill={c.blue} /><rect x={192} y={110} width={20} height={20} rx={3} fill={c.blue} /></g>
    <g filter="url(#ps)"><rect x={273} y={112} width={5} height={42} fill={c.teal} /><path d="M276 126 C262 124 256 112 258 102 C270 102 278 112 276 126Z" fill={c.teal} transform={`rotate(${Math.sin(t * 2) * 3} 276 126)`} /><path d="M278 118 C290 116 296 106 294 96 C282 96 276 106 278 118Z" fill={c.teal} transform={`rotate(${-Math.sin(t * 2) * 3} 278 118)`} /></g>
    <g filter="url(#ps)">{[0, 1, 2].map((i) => <ellipse key={i} cx={64} cy={152 - i * 10} rx={26} ry={8} fill={c.yellow} />)}</g>
  </g>
);
const Badge = ({ t }: Ctx) => (
  <g>
    <circle cx={180} cy={92} r={62} fill={c.white} filter="url(#ps)" />
    <circle cx={180} cy={92} r={52} fill="none" stroke={c.teal} strokeWidth={6} strokeDasharray="10 8" strokeDashoffset={-t * 10} />
    <text x={180} y={106} textAnchor="middle" fontSize={56} fill={c.ink} style={{ fontWeight: 700 }}>80</text>
    <text x={180} y={130} textAnchor="middle" fontSize={17} fill={c.dim} style={{ fontWeight: 700 }}>tahun</text>
    <Star x={92} y={56} r={9} fill={c.yellow} /><Star x={272} y={64} r={11} fill={c.red} /><Star x={276} y={124} r={7} fill={c.blue} />
  </g>
);
const Umbrella = ({ t }: Ctx) => (
  <g>
    {[0, 1, 2, 3, 4, 5].map((i) => { const x = 60 + i * 48 + ((t * 40) % 48), y = 30 + ((t * 70 + i * 37) % 110); return <line key={i} x1={x} y1={y} x2={x - 3} y2={y + 9} stroke={c.blue} strokeWidth={3} strokeLinecap="round" />; })}
    <g transform="translate(0 14)"><g filter="url(#ps)"><path d="M92 78 A88 62 0 0 1 268 78 Q250 68 236 78 Q222 68 208 78 Q194 68 180 78 Q166 68 152 78 Q138 68 124 78 Q110 68 92 78Z" fill={c.red} /></g>
    {[-60, -30, 0, 30, 60].map((dx) => <path key={dx} d={`M180 16 Q${180 + dx * 0.75} 40 ${180 + dx * 1.2} 74`} stroke={c.white} strokeWidth={3} fill="none" />)}
    <path d="M180 78 V124 q0 9 -9 9 q-9 0 -9 -9" stroke={c.ink} strokeWidth={4.5} fill="none" strokeLinecap="round" /></g>
    <Person x={118} y={152} s={0.8} fill={c.teal} /><Person x={240} y={152} s={0.95} fill={c.yellow} /><Person x={268} y={152} s={0.6} fill={c.blue} />
  </g>
);
const Questions = ({ t }: Ctx) => (
  <g>
    {[70, 145, 220, 295].map((x, i) => (
      <g key={x}><Person x={x} y={154} s={1.1} fill={accents[i]} />
        <g transform={`translate(0 ${Math.sin(t * 3 + i) * 2.5})`} filter="url(#ps)"><rect x={x - 17} y={56} width={34} height={30} rx={10} fill={c.white} /><path d={`M${x - 5} 85 L${x} 94 L${x + 5} 85Z`} fill={c.white} /></g>
        <text x={x} y={79} textAnchor="middle" fontSize={24} fill={c.ink} style={{ fontWeight: 700 }}>?</text></g>
    ))}
  </g>
);
const Puzzle = ({ lt }: Ctx) => {
  const g = 2 + 16 * (1 - easeIO(lt / 1.4)), s = 58, cx = 180, cy = 92;
  const P: [number, number, string][] = [[-s - g / 2, -s - g / 2, c.blue], [g / 2, -s - g / 2, c.teal], [-s - g / 2, g / 2, c.yellow], [g / 2, g / 2, c.red]];
  return <g>{P.map(([dx, dy, f], i) => <rect key={i} x={cx + dx} y={cy + dy} width={s} height={s} rx={12} fill={f} filter="url(#ps)" />)}
    {[[0, -s / 2 - g / 2, c.blue], [0, s / 2 + g / 2, c.yellow]].map(([dx, dy, f], i) => <circle key={i} cx={cx + (dx as number)} cy={cy + (dy as number)} r={9} fill={f as string} />)}</g>;
};
const Quote = ({ t }: Ctx) => (
  <g>
    <g filter="url(#ps)"><rect x={120} y={36} width={160} height={84} rx={18} fill={c.white} /><path d="M140 118 L128 144 L168 118Z" fill={c.white} /></g>
    <text x={142} y={96} fontSize={64} fill={c.yellow} style={{ fontWeight: 700 }}>“</text>
    {[196, 196, 196].map((x, i) => <rect key={i} x={x} y={58 + i * 18} width={[70, 58, 42][i]} height={8} rx={4} fill={c.dim} opacity={0.35} />)}
    <Person x={92} y={156} s={1.5} fill={c.blue} />
    <g transform={`translate(${290} ${142 + Math.sin(t * 3) * 3})`} filter="url(#ps)"><path d="M0 14 C-22 0 -18 -18 -6 -17 C-2 -16 0 -12 0 -9 C0 -12 2 -16 6 -17 C18 -18 22 0 0 14Z" fill={c.red} /></g>
  </g>
);
const Sign = ({ t }: Ctx) => (
  <g>
    <rect x={118} y={26} width={7} height={130} rx={3} fill={c.ink} />
    {[['A', c.blue, 32], ['B', c.teal, 70], ['C', c.yellow, 108]].map(([l, f, y], i) => (
      <g key={l as string} transform={`translate(${Math.sin(t * 2 + i) * 2} 0)`}><g filter="url(#ps)"><path d={`M125 ${y} h120 l22 15 l-22 15 h-120Z`} fill={c.white} /><rect x={125} y={y as number} width={14} height={30} fill={f as string} /></g>
        <text x={190} y={(y as number) + 22} textAnchor="middle" fontSize={22} fill={c.ink} style={{ fontWeight: 700 }}>{l as string}</text></g>
    ))}
  </g>
);

export const SCENES: Scene[] = (() => {
  const S: Scene[] = [
    { key: 'mic', a: 0, chips: [], art: (k) => <Mic {...k} /> },
    { key: 'republik', a: cue('republik') - 0.15, chips: [{ text: 'republik', at: cue('republik'), x: 90, y: 28, col: c.red }, { text: 'rakyat', at: cue('rakyat'), x: 275, y: 66, col: c.teal }], art: (k) => <Republik {...k} /> },
    { key: 'nilai', a: cue('nilainilai') - 0.15, chips: [{ text: 'nilai-nilai', at: cue('nilainilai'), x: 180, y: 20, col: c.blue }], art: (k) => <Shield {...k} /> },
    { key: 'tanah', a: cue('tanah') - 0.15, chips: [{ text: 'tanah air', at: cue('tanah'), x: 180, y: 20, col: c.teal }], art: (k) => <Islands {...k} mode="tanah" /> },
    { key: 'tujuan', a: cue('tujuan') - 0.15, chips: [{ text: 'tujuan bernegara', at: cue('tujuan'), x: 180, y: 20, col: c.red }], art: (k) => <Target {...k} /> },
    { key: 'sejahtera', a: cue('sejahtera') - 0.15, chips: [{ text: 'sejahtera', at: cue('sejahtera'), x: 180, y: 28, col: c.teal }], art: (k) => <House {...k} /> },
    { key: 'delapan', a: cue('delapan') - 0.15, chips: [{ text: 'setelah 80 tahun', at: cue('delapan'), x: 180, y: 20, col: c.yellow }], art: (k) => <Badge {...k} /> },
    { key: 'lemah', a: cue('lemah') - 0.15, chips: [{ text: 'yang paling lemah', at: cue('lemah'), x: 180, y: 12, col: c.red }], art: (k) => <Umbrella {...k} /> },
    { key: 'saudara', a: cue('saudaranya') - 0.15, chips: [{ text: 'tidak ditanya', at: cue('saudaranya'), x: 180, y: 28, col: c.yellow }], art: (k) => <Questions {...k} /> },
    { key: 'sabang', a: cue('sabang') - 0.15, chips: [{ text: 'Sabang', at: cue('sabang'), x: 64, y: 34, col: c.red }, { text: 'Merauke', at: cue('merauke'), x: 296, y: 34, col: c.red }], art: (k) => <Islands {...k} mode="sm" /> },
    { key: 'bersatu', a: cue('bersatu') - 0.15, chips: [{ text: 'bersatu', at: cue('bersatu'), x: 180, y: 16, col: c.teal }], art: (k) => <Puzzle {...k} /> },
    { key: 'ayah', a: cue('almarhum') - 0.15, chips: [{ text: 'pesan ayah', at: cue('almarhum'), x: 200, y: 22, col: c.blue }], art: (k) => <Quote {...k} /> },
    { key: 'menteri', a: cue('menterimenteri') - 0.15, chips: [{ text: 'A atau B atau C', at: cue('menterimenteri'), x: 180, y: 16, col: c.yellow }], art: (k) => <Sign {...k} /> },
    { key: 'kecil', a: cue('kecil') - 0.15, chips: [{ text: 'rakyat kecil', at: cue('kecil'), x: 180, y: 12, col: c.red }, { text: 'yang harus kita bela', at: cue('bela'), x: 180, y: 182, col: c.teal }], art: (k) => <Umbrella {...k} /> },
  ];
  for (let i = 1; i < S.length; i++) if (!(S[i].a > S[i - 1].a)) throw new Error(`Urutan adegan salah: ${S[i].key} (${S[i].a}) tidak setelah ${S[i - 1].key}`);
  return S;
})();

export const Chip = ({ x, y, text, col, k, t }: { x: number; y: number; text: string; col: string; k: number; t: number }) => {
  const w = text.length * 8.4 + 30, p = easeBack((t - k) / 0.35);
  if (t < k) return null;
  return (
    <g transform={`translate(${x} ${y}) scale(${Math.max(0.01, p)})`} filter="url(#ps)">
      <rect x={-w / 2} y={-13} width={w} height={26} rx={13} fill={c.white} />
      <circle cx={-w / 2 + 14} cy={0} r={5} fill={col} />
      <text x={8} y={5.5} textAnchor="middle" fontSize={15} fill={c.ink} style={{ fontWeight: 700 }}>{text}</text>
    </g>
  );
};

export const Stage = ({ t, x, y, w }: { t: number; x: number; y: number; w: number }) => {
  const h = (w * 210) / 360;
  const wob = Math.sin(t * 1.2) * 6;
  return (
    <svg viewBox="0 0 360 210" style={{ position: 'absolute', left: x, top: y, width: w, height: h, overflow: 'visible' }}>
      <defs>
        <filter id="ps" x="-20%" y="-20%" width="140%" height="150%"><feDropShadow dx="0" dy="2.5" stdDeviation="2.2" floodColor={c.shadow} floodOpacity="0.28" /></filter>
        <filter id="pu" x="-20%" y="-30%" width="140%" height="150%"><feDropShadow dx="0" dy="-2.5" stdDeviation="2.2" floodColor={c.shadow} floodOpacity="0.22" /></filter>
        <clipPath id="sc"><rect width="360" height="210" rx="20" /></clipPath>
      </defs>
      <rect width="360" height="210" rx="20" fill={c.blueT} filter="url(#ps)" />
      <g clipPath="url(#sc)">
        <g transform={`translate(${wob - 20} 0)`}><path d="M-40 156 Q0 138 40 156 T120 156 T200 156 T280 156 T360 156 T440 156 V220 H-40Z" fill={c.teal} filter="url(#pu)" /></g>
        <g transform={`translate(${-wob - 20} 0)`}><path d="M-40 176 Q0 160 40 176 T120 176 T200 176 T280 176 T360 176 T440 176 V220 H-40Z" fill={c.yellow} filter="url(#pu)" /></g>
        {SCENES.map((s, i) => {
          const next = SCENES[i + 1], end = next ? next.a : 1e9;
          if (t < s.a || t > end + theme.motion.sceneOut) return null;
          const lt = t - s.a, e = easeBack(lt / theme.motion.sceneIn);
          const o = next && t > end ? clamp((t - end) / theme.motion.sceneOut) : 0;
          return (
            <g key={s.key} opacity={clamp(lt / 0.2) * (1 - o)} transform={`translate(${-50 * o} ${(1 - e) * 26}) translate(180 105) scale(${0.82 + 0.18 * e}) translate(-180 -105)`}>
              {s.art({ t, lt, e })}
              {s.chips.map((ch, j) => <Chip key={j} x={ch.x} y={ch.y} text={ch.text} col={ch.col} k={ch.at} t={t} />)}
            </g>
          );
        })}
      </g>
    </svg>
  );
};
