import React from 'react';
import { theme, Layout } from './theme';
import { PLAN, CHUNKS, T } from './plan';
import { Stage, clamp, easeIO } from './scenes';

const c = theme.c;
const lerp = (a: number, b: number, u: number) => a + (b - a) * u;
const count = (arr: number[], t: number) => arr.filter((b) => b <= t + 1e-9).length;

function layoutAt(t: number) {
  const idx = count(PLAN.layoutBeats, t) - 1;
  const L = theme.layouts;
  const cur = L[idx % L.length], prev = L[Math.max(0, idx - 1) % L.length];
  const u = idx === 0 ? 1 : easeIO((t - PLAN.layoutBeats[idx]) / theme.motion.layoutDur);
  const m = (a: Layout, b: Layout) => ({
    F: { x: lerp(a.F.x, b.F.x, u), y: lerp(a.F.y, b.F.y, u), w: lerp(a.F.w, b.F.w, u), h: lerp(a.F.h, b.F.h, u), r: lerp(a.F.r, b.F.r, u) },
    S: { x: lerp(a.S.x, b.S.x, u), y: lerp(a.S.y, b.S.y, u), w: lerp(a.S.w, b.S.w, u) },
  });
  return m(prev, cur);
}

function zoomAt(t: number) {
  const bi = count(PLAN.beats, t) - 1, b0 = PLAN.beats[bi], b1 = PLAN.beats[bi + 1] ?? T.duration;
  const prog = clamp((t - b0) / Math.max(0.5, b1 - b0));
  const { baseZoom, altZoom, push } = theme.footage;
  return baseZoom * (bi % 2 === 1 ? altZoom : 1) * (1 + push * prog);
}

export function Video({ t, fontFamily, footage }: { t: number; fontFamily: string; footage: React.ReactNode }) {
  const { w: W, h: H, pad } = theme.size;
  const { F, S } = layoutAt(t);
  const z = zoomAt(t);
  const chunk = [...CHUNKS].reverse().find((k) => k.start <= t + 0.05) ?? CHUNKS[0];
  const cap = theme.caption;
  const attrScale = Math.min(1, F.w / 640);
  return (
    <div style={{ position: 'relative', width: W, height: H, background: c.page, overflow: 'hidden', fontFamily, color: c.ink }}>
      {/* dekor kertas */}
      <div style={{ position: 'absolute', left: -180 + Math.sin(t * 0.3) * 20, top: 560, width: 560, height: 560, borderRadius: 280, background: c.tealT }} />
      <div style={{ position: 'absolute', left: 1520 - Math.cos(t * 0.25) * 20, top: -190, width: 520, height: 520, borderRadius: 260, background: c.yellowT }} />
      <div style={{ position: 'absolute', left: 1180, top: 700, width: 300, height: 300, borderRadius: 150, background: c.redT }} />

      {/* header */}
      <div style={{ position: 'absolute', left: 40, top: theme.header.y, height: theme.header.h, padding: '0 28px', display: 'flex', alignItems: 'center', gap: 14, background: c.yellow, borderRadius: 36, boxShadow: theme.shadowSoftCss, fontSize: 30, letterSpacing: 1 }}>
        <div style={{ width: 20, height: 20, borderRadius: 10, background: c.red }} />{theme.text.channel}
      </div>
      <div style={{ position: 'absolute', left: 40 + 340 + 24, top: theme.header.y, height: theme.header.h, padding: '0 36px', display: 'flex', alignItems: 'center', background: c.white, borderRadius: 36, boxShadow: theme.shadowSoftCss, fontSize: 34 }}>{theme.text.title}</div>

      <Stage t={t} x={S.x} y={S.y} w={S.w} />

      {/* kartu footage */}
      <div style={{ position: 'absolute', left: F.x, top: F.y, width: F.w, height: F.h, padding: pad, boxSizing: 'border-box', background: c.white, borderRadius: F.r + pad, boxShadow: theme.shadowCss }}>
        <div style={{ position: 'relative', width: '100%', height: '100%', borderRadius: F.r, overflow: 'hidden' }}>
          <div style={{ position: 'absolute', inset: 0, transform: `scale(${z})`, transformOrigin: `${theme.footage.originX} ${theme.footage.originY}` }}>{footage}</div>
        </div>
      </div>
      {theme.text.sticker ? (
        <div style={{ position: 'absolute', left: F.x + 18, top: F.y - 20, padding: '8px 22px', background: c.yellow, borderRadius: 20, fontSize: 26, transform: 'rotate(-4deg)', boxShadow: theme.shadowSoftCss }}>{theme.text.sticker}</div>
      ) : null}
      {theme.text.attribution ? (
        <div style={{ position: 'absolute', left: F.x + F.w / 2, top: F.y + F.h - 2, transform: `translate(-50%, -50%) scale(${attrScale})`, whiteSpace: 'nowrap', padding: '7px 22px', background: c.white, borderRadius: 22, fontSize: 24, color: c.ink, boxShadow: theme.shadowSoftCss, display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ width: 14, height: 14, borderRadius: 7, background: c.teal, display: 'inline-block' }} />{theme.text.attribution}
        </div>
      ) : null}

      {/* caption per kata */}
      <div style={{ position: 'absolute', left: cap.x, top: cap.y, width: cap.w, height: cap.h, background: c.white, borderRadius: cap.r, boxShadow: theme.shadowCss, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 40px', boxSizing: 'border-box' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '4px 6px', fontSize: theme.size.captionFont, lineHeight: 1.15 }}>
          {chunk.words.map((wd, i) => {
            const active = wd.start <= t && t < wd.end, past = t >= wd.end;
            return <span key={i} style={{ padding: '4px 14px', borderRadius: 20, background: active ? c.yellow : 'transparent', color: active || past ? c.ink : c.dim }}>{wd.w}</span>;
          })}
        </div>
      </div>
      {/* progres */}
      <div style={{ position: 'absolute', left: 60, top: 1064, width: 1800, height: 8, borderRadius: 4, background: c.blueT }}><div style={{ width: `${clamp(t / T.duration) * 100}%`, height: 8, borderRadius: 4, background: c.blue }} /></div>
    </div>
  );
}
