import React from 'react';
import { Composition, Sequence, OffthreadVideo, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import { Video } from './Video';
import { T } from './plan';

const { fontFamily } = loadFont('normal', { weights: ['700'], subsets: ['latin'] });

const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const footage = (
    <>
      {T.cuts.map((cut, i) => {
        const from = Math.round(cut.out0 * fps);
        const dur = Math.round(cut.out1 * fps) - from; // batas dibulatkan konsisten: tanpa celah/tumpang tindih
        return (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <OffthreadVideo src={staticFile('footage.mp4')} startFrom={Math.round(cut.src0 * fps)} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </Sequence>
        );
      })}
    </>
  );
  return <Video t={t} fontFamily={fontFamily} footage={footage} />;
};

export const RemotionRoot: React.FC = () => (
  <Composition id="TalkingHead" component={Main} durationInFrames={Math.round(T.duration * T.fps)} fps={T.fps} width={T.width} height={T.height} />
);
