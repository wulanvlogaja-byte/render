# talking-head-prabowo (Remotion 4.0.250, 16:9 1920x1080, 30 fps)

Edit talking head: jump cut, footage yang berganti bentuk (kartu, lingkaran, pojok kecil, hero), caption per kata, dan ilustrasi paper-cut yang muncul saat kata kuncinya diucapkan.

## Struktur
- `public/footage.mp4`: footage sumber (subtitle burn-in disembunyikan lewat crop zoom 1,25x)
- `source.srt`, `timing.cjs`, `anchors.cjs`, `ocr-raw.txt`: bahan membuat ulang timing
- `src/timing.json`: rencana potong + waktu tiap kata (hasil edit)
- `src/theme.ts`: semua warna, ukuran, teks (channel, judul, stiker, atribusi), urutan layout
- `src/Video.tsx` (komposisi murni `Video({ t, fontFamily, footage })`), `src/scenes.tsx` (ilustrasi + cue), `src/plan.ts`, `src/Root.tsx`

## Job workflow (render-remotion.yml, workflow_dispatch)
checkout -> setup-node (v20+) -> `npm install` (bukan `npm ci`) -> `npm run render` -> upload-artifact `out/video.mp4`.
Jika perlu: `npx remotion render src/index.ts TalkingHead out/video.mp4 --codec=h264`.

## Opsi di theme.ts
- `text.channel`, `text.title`: GANTI (sekarang placeholder)
- `text.attribution = ''` mematikan chip atribusi; `text.sticker = ''` mematikan stiker
- `layouts` + `motion.layoutMin`: urutan/ukuran layout dan jarak minimum ganti layout
- `footage.baseZoom`: jangan di bawah 1.25 bila subtitle burn-in masih ingin disembunyikan

## Membuat ulang timing
`node timing.cjs` (butuh ffmpeg). Env: `NOISE` (default -21; rekaman ini noise floor-nya tinggi sehingga -35dB tidak menemukan jeda), `MINSIL`, `PAD`, `KEEP_GAP`, `FPS`, `W`, `H`. `anchors.cjs` membuat `src/anchors.json` dari OCR subtitle burn-in (opsional).
Mengubah teks SRT: edit `source.srt` lalu jalankan ulang `node timing.cjs`.
