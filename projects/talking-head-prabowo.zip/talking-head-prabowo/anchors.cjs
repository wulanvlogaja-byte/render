// anchors.cjs — (opsional) patokan waktu dari subtitle yang ke-burn di footage.
// Input: ocr-raw.txt (baris "nomorFrame|teks OCR", 2 fps, frame 0001 = 0.0 dtk). Output: src/anchors.json [{pos, t}]
const fs = require('fs');
const norm = s => s.toLowerCase().replace(/[^a-z]/g, '');
const srt = fs.readFileSync('source.srt', 'utf8').replace(/\r/g, '').split(/\n\s*\n/).map(b => b.trim().split('\n')).filter(a => a.length >= 3).map(a => a.slice(2).join(' ')).join(' ');
const W = srt.split(/\s+/).map(norm).filter(Boolean);
const lev = (a, b) => { const d = Array.from({ length: a.length + 1 }, (_, i) => [i]); for (let j = 1; j <= b.length; j++) d[0][j] = j; for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[a.length][b.length]; };
const eq = (a, b) => a === b || (a.length >= 5 && b.length >= 5 && lev(a, b) <= (a.length >= 8 ? 2 : 1));
const frames = fs.readFileSync('ocr-raw.txt', 'utf8').trim().split('\n').map(l => { const [n, ...r] = l.split('|'); return { t: (+n - 1) * 0.5, toks: r.join('|').split(/[^A-Za-z]+/).map(x => x.toLowerCase()).filter(x => x.length >= 3) }; });
let prev = 0; const hits = [];
for (const f of frames) {
  if (f.toks.length < 2) continue;
  let best = null;
  for (let j = Math.max(0, prev - 4); j < Math.min(W.length, prev + 70); j++) {
    const win = W.slice(j, j + 10); let sc = 0, first = -1, last = -1;
    for (const tk of f.toks) { const k = win.findIndex(w => eq(tk, w)); if (k >= 0) { sc++; if (first < 0 || k < first) first = k; if (k > last) last = k; } }
    if (sc >= 2 && (!best || sc > best.sc || (sc === best.sc && j < best.j))) best = { j, sc, j0: j + first, j1: j + last };
  }
  if (best && best.sc >= Math.min(3, f.toks.length)) { hits.push({ t: f.t, j0: best.j0, j1: best.j1 }); prev = Math.max(prev, best.j0); }
}
// kelompokkan frame berurutan dengan j0 sama -> satu potongan subtitle
const groups = []; for (const h of hits) { const g = groups[groups.length - 1]; if (g && g.j0 === h.j0) { g.t1 = h.t + 0.5; } else groups.push({ j0: h.j0, j1: h.j1, t0: h.t, t1: h.t + 0.5 }); }
let anchors = groups.map(g => ({ pos: (g.j0 + g.j1) / 2, t: (g.t0 + g.t1) / 2 }));
// buang outlier: harus naik monoton terhadap tetangga
anchors = anchors.filter((a, i, arr) => (i === 0 || a.t > arr[i - 1].t - 0.01) && (i === arr.length - 1 || a.t < arr[i + 1].t + 0.01));
fs.writeFileSync('src/anchors.json', JSON.stringify(anchors));
console.log('kata SRT', W.length, '| frame cocok', hits.length, '| potongan', groups.length, '| anchor', anchors.length);
console.log(anchors.map(a => a.pos.toFixed(0) + '@' + a.t.toFixed(1)).join(' '));
