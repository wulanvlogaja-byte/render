// timing.cjs — hitung timing & rencana potong dari footage + SRT.
// Pakai: node timing.cjs   (env: FPS, W, H, NOISE, MINSIL, PAD, KEEP_GAP, TAIL)
// Hasil: src/timing.json
const fs = require('fs');
const { execSync } = require('child_process');
const FPS = +(process.env.FPS || 30), W = +(process.env.W || 1920), H = +(process.env.H || 1080);
const NOISE = process.env.NOISE || '-21';        // rekaman ini noise floor-nya tinggi; -35dB tidak menemukan jeda
const MINSIL = process.env.MINSIL || '0.25';
const PAD = +(process.env.PAD || 0.10), KEEP_GAP = +(process.env.KEEP_GAP || 0.45), TAIL = +(process.env.TAIL || 0.5);
const FOOTAGE = 'public/footage.mp4', SRT = 'source.srt', STEP = 0.05;

const srcDur = +execSync(`ffprobe -v error -show_entries format=duration -of csv=p=0 ${FOOTAGE}`).toString().trim();
const log = execSync(`ffmpeg -nostats -i ${FOOTAGE} -vn -af silencedetect=noise=${NOISE}dB:d=${MINSIL} -f null - 2>&1 || true`, { shell: '/bin/bash', maxBuffer: 1 << 26 }).toString();
const sil = []; let cur = null;
for (const l of log.split('\n')) {
  let m;
  if ((m = l.match(/silence_start: ([\d.]+)/))) cur = +m[1];
  if ((m = l.match(/silence_end: ([\d.]+)/)) && cur !== null) { sil.push([Math.max(0, cur), +m[1]]); cur = null; }
}
if (cur !== null) sil.push([cur, srcDur]);
// segmen bicara = komplemen jeda
const segs = []; let p = 0;
for (const [a, b] of sil) { if (a - p > 0.1) segs.push([p, a]); p = b; }
if (srcDur - p > 0.1) segs.push([p, srcDur]);
const cum = []; let acc = 0; for (const [a, b] of segs) { cum.push(acc); acc += b - a; }
const Ts = acc;
const T2src = (T, end) => { for (let k = segs.length - 1; k >= 0; k--) { const lo = cum[k], hi = lo + segs[k][1] - segs[k][0]; if (end ? (T > lo + 1e-9 && T <= hi + 1e-9) : (T >= lo - 1e-9 && T < hi - 1e-9)) return segs[k][0] + (T - lo); } return end ? segs[segs.length - 1][1] : segs[0][0]; };
const src2T = (s) => { for (let k = 0; k < segs.length; k++) if (s <= segs[k][1]) return cum[k] + Math.max(0, s - segs[k][0]); return Ts; };

// ---- SRT -> unit (tiap cue, dipecah lagi di . ? !) dengan perkiraan awal
const ts = (s) => { const m = s.match(/(\d+):(\d+):(\d+)[,.](\d+)/); return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000; };
const cues = fs.readFileSync(SRT, 'utf8').replace(/\r/g, '').split(/\n\s*\n/).map(b => b.trim().split('\n')).filter(a => a.length >= 3)
  .map(a => { const [s, e] = a[1].split('-->'); return { s: ts(s), e: ts(e), text: a.slice(2).join(' ').replace(/\s+/g, ' ').trim() }; });
const srtEnd = cues[cues.length - 1].e;
const lastSpeech = segs[segs.length - 1][1];
const SCALE = lastSpeech / srtEnd; // SRT kasar: skala linear ke akhir ucapan footage
const units = [];
for (const c of cues) {
  const parts = c.text.match(/[^.?!]+[.?!]*/g).map(x => x.trim()).filter(Boolean);
  const tot = parts.reduce((s, x) => s + x.length, 0); let off = 0;
  for (const t of parts) { units.push({ text: t, est: (c.s + (c.e - c.s) * off / tot) * SCALE, chars: t.replace(/\s/g, '').length }); off += t.length; }
}
// anchor opsional dari subtitle burn-in (anchors.cjs): perkiraan awal unit = interpolasi posisi kata -> waktu
let WEST = 0.25;
if (fs.existsSync('src/anchors.json')) {
  const raw = JSON.parse(fs.readFileSync('src/anchors.json', 'utf8')).sort((a, b) => a.pos - b.pos || a.t - b.t);
  const an = []; for (const a of raw) { const L = an[an.length - 1]; if (L && Math.abs(L.pos - a.pos) < 0.5) { L.t = (L.t + a.t) / 2; continue; } if (!L || a.t > L.t) an.push({ ...a }); }
  let wi = 0;
  for (const u of units) {
    const pos = wi; wi += u.text.split(/\s+/).filter(Boolean).length;
    let k = an.findIndex(a => a.pos >= pos);
    if (k === 0) u.est = Math.max(0, an[0].t - (an[0].pos - pos) * 0.4);
    else if (k < 0) u.est = an[an.length - 1].t + (pos - an[an.length - 1].pos) * 0.4;
    else { const A = an[k - 1], B = an[k]; u.est = A.t + (B.t - A.t) * (pos - A.pos) / (B.pos - A.pos); }
  }
  WEST = 0.5; console.log('anchor subtitle dipakai:', an.length);
}
// ---- DP monoton di sumbu waktu-bicara T
const cand = new Set(); for (let t = 0; t <= Ts + 1e-9; t += STEP) cand.add(+t.toFixed(4));
cum.forEach(c => cand.add(+c.toFixed(4))); cand.add(+Ts.toFixed(4));
const C = [...cand].sort((a, b) => a - b), M = C.length;
const bnd = new Set(cum.map(c => +c.toFixed(4)));
const bsorted = [...bnd].sort((a, b) => a - b);
const innerCount = (a, b) => { let n = 0; for (const x of bsorted) if (x > a + 1e-6 && x < b - 1e-6) n++; return n; };
const realAt = (T) => T2src(T, false);
let med = units.reduce((s, u) => s + u.chars, 0) / Ts, bestBounds = null;
for (let iter = 0; iter < 4; iter++) {
  let prev = new Float64Array(M).fill(Infinity); prev[0] = 0;
  const back = [];
  for (let i = 0; i < units.length; i++) {
    const u = units[i], cur = new Float64Array(M).fill(Infinity), bk = new Int32Array(M).fill(-1);
    for (let a = 0; a < M; a++) {
      if (prev[a] === Infinity) continue;
      const pa = C[a], base = prev[a] + WEST * Math.abs(realAt(pa) - u.est) - (bnd.has(pa) ? 0.3 : 0);
      const dmin = u.chars / (med * 3), dmax = u.chars / (med / 3);
      for (let b = a + 1; b < M; b++) {
        const d = C[b] - pa; if (d < dmin) continue; if (d > dmax) break;
        const c = base + Math.abs(Math.log(u.chars / d / med)) + 0.05 * innerCount(pa, C[b]);
        if (c < cur[b]) { cur[b] = c; bk[b] = a; }
      }
    }
    back.push(bk); prev = cur;
  }
  let bi = 0; for (let b = 0; b < M; b++) if (prev[b] < prev[bi]) bi = b;
  const idx = [bi]; for (let i = units.length - 1; i >= 0; i--) idx.unshift(back[i][idx[0]]);
  bestBounds = idx.map(k => C[k]);
  const rates = units.map((u, i) => u.chars / (bestBounds[i + 1] - bestBounds[i]));
  med = [...rates].sort((a, b) => a - b)[Math.floor(rates.length / 2)];
}
units.forEach((u, i) => { u.T0 = bestBounds[i]; u.T1 = bestBounds[i + 1]; u.rate = u.chars / (u.T1 - u.T0); });
console.log(`footage ${srcDur.toFixed(2)}s | segmen bicara ${segs.length} | jeda ${sil.length} | skala SRT ${SCALE.toFixed(3)} | median laju ${med.toFixed(1)} huruf/dtk`);
units.forEach((u, i) => { const f = u.rate / med < 0.6 || u.rate / med > 1.6 ? '  <-- LAJU ANEH' : ''; console.log(String(i).padStart(2), T2src(u.T0).toFixed(2).padStart(7), T2src(u.T1, true).toFixed(2).padStart(7), (u.rate / med).toFixed(2), u.text.slice(0, 48) + f); });
// ---- waktu kata (sumber)
const words = [];
units.forEach((u, ui) => {
  const ws = u.text.split(/\s+/).filter(Boolean), wt = ws.map(w => w.replace(/[^\p{L}\p{N}]/gu, '').length + 1.2), tot = wt.reduce((a, b) => a + b, 0);
  let t = u.T0;
  ws.forEach((w, k) => { const t1 = k === ws.length - 1 ? u.T1 : t + (u.T1 - u.T0) * wt[k] / tot; words.push({ w, s: T2src(t, false), e: T2src(t1, true), unit: ui }); t = t1; });
});
// ---- rencana potong
const srcEnd = Math.min(srcDur, T2src(units[units.length - 1].T1, true) + TAIL);
const usable = segs.map(([a, b]) => [Math.max(0, a - PAD), Math.min(srcEnd, b + PAD)]).filter(([a, b]) => b > a + 0.05 && segs.find(s => s[0] < srcEnd));
const keep = [];
for (const [a, b] of usable) { const L = keep[keep.length - 1]; if (L && a - L[1] <= KEEP_GAP - 2 * PAD) L[1] = Math.max(L[1], b); else keep.push([a, b]); }
keep[keep.length - 1][1] = srcEnd;
let o = 0; const cuts = keep.map(([a, b]) => { const c = { src0: +a.toFixed(3), src1: +b.toFixed(3), out0: +o.toFixed(3), out1: +(o + b - a).toFixed(3) }; o += b - a; return c; });
const src2out = (s, end) => { for (const c of cuts) if (s >= c.src0 - 1e-6 && s <= c.src1 + 1e-6) return c.out0 + s - c.src0; let best = cuts[0], bd = 1e9; for (const c of cuts) { const d = Math.min(Math.abs(s - c.src0), Math.abs(s - c.src1)); if (d < bd) { bd = d; best = c; } } return Math.abs(s - best.src0) < Math.abs(s - best.src1) ? best.out0 : best.out1; };
const outWords = words.map(x => { const s = src2out(x.s), e = Math.max(src2out(x.e), s + 0.08); return { w: x.w, start: +s.toFixed(3), end: +e.toFixed(3), unit: x.unit }; });
for (let i = 0; i < outWords.length - 1; i++) if (outWords[i].end > outWords[i + 1].start) outWords[i].end = outWords[i + 1].start;
const outUnits = units.map((u, i) => ({ text: u.text, start: outWords.find(w => w.unit === i).start, end: [...outWords].reverse().find(w => w.unit === i).end }));
const out = { footage: 'footage.mp4', srcDuration: +srcDur.toFixed(3), duration: +o.toFixed(3), fps: FPS, width: W, height: H, cuts, units: outUnits, words: outWords };
fs.writeFileSync('src/timing.json', JSON.stringify(out, null, 1));
console.log(`potongan ${cuts.length} | durasi hasil ${o.toFixed(2)}s dari ${srcDur.toFixed(2)}s | kata ${outWords.length}`);
