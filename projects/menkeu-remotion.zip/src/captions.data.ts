export const SEGMENTS: {s: number; e: number; text: string}[] = [
 {
  "s": 0.0,
  "e": 6.024,
  "text": "POV lo jadi menteri keuangan padahal lo enggak paham sama sekali cara ngitung duit negara."
 },
 {
  "s": 6.024,
  "e": 13.053,
  "text": "Lo kira APBN itu saldo ATM? Lo kira utang negara itu kayak PayLater Shopee? Bisa dicicil dua belas bulan."
 },
 {
  "s": 13.053,
  "e": 17.873,
  "text": "Hari pertama ngantor staf lo bilang, Bu, Pak defisit lima ratus triliun."
 },
 {
  "s": 17.873,
  "e": 22.961,
  "text": "Lo jawab, tenang, tinggal print lagi saja uangnya. Kan ada printer di bawah."
 },
 {
  "s": 22.961,
  "e": 27.111,
  "text": "Staf lo langsung pucat, sepucat rakyat lihat harga cabai naik."
 },
 {
  "s": 27.111,
  "e": 32.065,
  "text": "Lo bagi-bagi bansos pakai feeling, subsidi lo hapus karena lo kira diskon."
 },
 {
  "s": 32.065,
  "e": 38.491,
  "text": "Akhirnya Dollar naik jadi dua puluh lima ribu. Investor kabur, negara bangkrut dalam tiga bulan."
 },
 {
  "s": 38.491,
  "e": 41.905,
  "text": "Lebih cepat dari toko online lo yang dulu bangkrut."
 },
 {
  "s": 41.905,
  "e": 48.934,
  "text": "Eh bentar Bro, kalau lo jadi menkeu begini negara bangkrut lo bakal minta maaf atau langsung booking jet?"
 },
 {
  "s": 48.934,
  "e": 53.553,
  "text": "Like dan subscribe dulu biar lo enggak jadi rakyat jelata yang kaget."
 },
 {
  "s": 53.553,
  "e": 56.298,
  "text": "Lanjut. Malamnya lo sudah di private jet."
 },
 {
  "s": 56.298,
  "e": 62.791,
  "text": "Di atas awan empat puluh ribu kaki lo lihat ke bawah lampu-lampu kota yang lo bikin gelap gulita."
 },
 {
  "s": 62.791,
  "e": 70.623,
  "text": "Lo buka jendela pakai kacamata hitam sambil bisik. Halo rakyat jelata, terima kasih pajaknya ya. Gua duluan ke Swiss."
 },
 {
  "s": 70.623,
  "e": 74.841,
  "text": "Di bawah rakyat masih antri bensin. Di atas lo antri champagne."
 }
];
