import React from 'react';
import {SEGMENTS} from './captions.data';
import {C, HILITE, lilita} from './theme';
import {usePop, useSec} from './parts';

type Chunk = {s: number; e: number; text: string};

const split = (text: string): string[] => {
  const out: string[] = [];
  let cur: string[] = [];
  for (const w of text.split(/\s+/)) {
    cur.push(w);
    const len = cur.join(' ').length;
    if (cur.length >= 4 || len >= 24 || (/[.,?!]$/.test(w) && cur.length >= 2)) {
      out.push(cur.join(' '));
      cur = [];
    }
  }
  if (cur.length) out.push(cur.join(' '));
  return out;
};

const CHUNKS: Chunk[] = SEGMENTS.flatMap((seg) => {
  const parts = split(seg.text);
  const weights = parts.map((p) => p.length + (/[.,?!]$/.test(p) ? 6 : 0));
  const total = weights.reduce((a, b) => a + b, 0);
  let t = seg.s;
  return parts.map((p, i) => {
    const d = ((seg.e - seg.s) * weights[i]) / total;
    const c = {s: t, e: t + d, text: p};
    t += d;
    return c;
  });
});

const Line: React.FC<{chunk: Chunk}> = ({chunk}) => {
  const p = usePop(chunk.s, 14);
  return (
    <div
      style={{
        fontFamily: lilita,
        fontSize: 76,
        lineHeight: 1.08,
        textAlign: 'center',
        color: '#fff',
        WebkitTextStroke: `16px ${C.ink}`,
        paintOrder: 'stroke fill',
        transform: `scale(${0.85 + 0.15 * Math.min(p, 1.1)})`,
        padding: '0 40px',
      }}
    >
      {chunk.text.split(' ').map((w, i) => (
        <span key={i} style={{color: HILITE.test(w) ? C.yellow : '#fff'}}>
          {w}{' '}
        </span>
      ))}
    </div>
  );
};

export const Captions: React.FC = () => {
  const sec = useSec();
  const c = CHUNKS.find((x) => sec >= x.s && sec < x.e);
  if (!c) return null;
  return (
    <div style={{position: 'absolute', left: 0, right: 0, top: 1450, height: 330, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <Line key={c.s} chunk={c} />
    </div>
  );
};
