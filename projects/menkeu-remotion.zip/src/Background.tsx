import React from 'react';
import {random, useCurrentFrame} from 'remotion';
import {C, GROUND, H, W} from './theme';

export type BGKind = 'forest' | 'dusk' | 'party' | 'office' | 'park' | 'sky' | 'cabin';

const PAL = {
  forest: {sky: ['#7fd0ff', '#eafbd6'], hills: ['#8fd694', '#5fb878', '#3f9a62'], ground: ['#5ab55e', '#3d9448'], trunk: '#7a4b2a', leaf: '#2f9e44'},
  dusk: {sky: ['#2b2d6e', '#ff9a76'], hills: ['#6b5b9a', '#4a4585', '#33316e'], ground: ['#3d6b58', '#2a5144'], trunk: '#3b2a24', leaf: '#1d4a45'},
  party: {sky: ['#ff595e', '#ffb347'], hills: ['#e63946', '#c1121f', '#9d0208'], ground: ['#b5172a', '#8f1020'], trunk: '#5c1a1a', leaf: '#7a0c18'},
  park: {sky: ['#8fe3ff', '#fff9d6'], hills: ['#a8e68a', '#7ad66f', '#52c25f'], ground: ['#82dd6e', '#5cc457'], trunk: '#8a5a2b', leaf: '#37b24d'},
};

const hillPath = (y: number, amp: number, ph: number, k: number) => {
  let d = `M0 ${H} L0 ${y}`;
  for (let x = 0; x <= W; x += 30) d += ` L${x} ${y + amp * Math.sin(x / k + ph)}`;
  return d + ` L${W} ${H} Z`;
};

const Pine: React.FC<{x: number; y: number; s: number; f: number; leaf: string; trunk: string}> = ({x, y, s, f, leaf, trunk}) => {
  const sw = {stroke: C.ink, strokeWidth: 4, strokeLinejoin: 'round' as const};
  return (
    <g transform={`translate(${x} ${y}) rotate(${Math.sin(f / 25 + x) * 1.8}) scale(${s})`}>
      <rect x={-9} y={-50} width={18} height={50} fill={trunk} {...sw} />
      <polygon points="0,-260 -75,-110 75,-110" fill={leaf} {...sw} />
      <polygon points="0,-210 -95,-60 95,-60" fill={leaf} {...sw} />
      <polygon points="0,-150 -110,-30 110,-30" fill={leaf} {...sw} />
    </g>
  );
};

const Office: React.FC<{f: number}> = ({f}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
    <rect width={W} height={H} fill="#f4e3c1" />
    {Array.from({length: 14}).map((_, i) => (
      <rect key={i} x={i * 80} y={0} width={40} height={GROUND} fill="rgba(180,140,80,0.12)" />
    ))}
    <rect x={0} y={1000} width={W} height={GROUND - 1000} fill="#d9b26f" />
    <rect x={0} y={996} width={W} height={12} fill="#a9783a" />
    {/* window */}
    <rect x={70} y={430} width={280} height={360} rx={14} fill="#bfe9ff" stroke={C.ink} strokeWidth={8} />
    <line x1={210} y1={430} x2={210} y2={790} stroke={C.ink} strokeWidth={8} />
    <line x1={70} y1={610} x2={350} y2={610} stroke={C.ink} strokeWidth={8} />
    <polygon points="100,470 210,470 330,790 130,790" fill="rgba(255,255,255,0.35)" />
    {/* clock */}
    <circle cx={930} cy={520} r={70} fill="#fff" stroke={C.ink} strokeWidth={8} />
    <line x1={930} y1={520} x2={930 + Math.sin((f * 2 * Math.PI) / 180) * 50} y2={520 - Math.cos((f * 2 * Math.PI) / 180) * 50} stroke={C.ink} strokeWidth={6} strokeLinecap="round" />
    <line x1={930} y1={520} x2={930 + Math.sin((f * 2 * Math.PI) / 2160) * 34} y2={520 - Math.cos((f * 2 * Math.PI) / 2160) * 34} stroke={C.red} strokeWidth={8} strokeLinecap="round" />
    {/* floor */}
    <rect x={0} y={GROUND} width={W} height={H - GROUND} fill="#8b5e3c" />
    {Array.from({length: 7}).map((_, i) => (
      <line key={i} x1={0} y1={GROUND + i * 80} x2={W} y2={GROUND + i * 80} stroke="#6f4a2d" strokeWidth={6} />
    ))}
  </svg>
);


const Night: React.FC<{f: number}> = ({f}) => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
    <defs>
      <linearGradient id="sky-night" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#0b1026" />
        <stop offset="0.7" stopColor="#2b2d6e" />
        <stop offset="1" stopColor="#6b5b9a" />
      </linearGradient>
    </defs>
    <rect width={W} height={H} fill="url(#sky-night)" />
    {Array.from({length: 70}).map((_, i) => (
      <circle key={i} cx={random(`nx${i}`) * W} cy={random(`ny${i}`) * 1100} r={1.5 + random(`nr${i}`) * 3} fill="#fff" opacity={0.4 + 0.6 * Math.abs(Math.sin(f / 12 + i))} />
    ))}
    <circle cx={850} cy={280} r={90} fill="#fff6c9" />
    <circle cx={880} cy={262} r={78} fill="#2b2d6e" opacity={0.18} />
    {Array.from({length: 14}).map((_, i) => (
      <ellipse key={i} cx={((i * 190 - f * (3 + (i % 3))) % 1500 + 1500) % 1500 - 200} cy={1180 + (i % 5) * 80} rx={170} ry={50} fill={i % 2 ? '#aab4e8' : '#c7d2ff'} opacity={0.9} />
    ))}
    {Array.from({length: 10}).map((_, i) => (
      <line key={i} x1={((i * 140 - f * 38) % 1300 + 1300) % 1300} y1={380 + (i * 97) % 700} x2={((i * 140 - f * 38) % 1300 + 1300) % 1300 + 150} y2={380 + (i * 97) % 700} stroke="#fff" strokeWidth={4} opacity={0.25} strokeLinecap="round" />
    ))}
    <rect x={0} y={GROUND + 60} width={W} height={H} fill="#aab4e8" />
  </svg>
);

const Cabin: React.FC = () => (
  <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
    <rect width={W} height={H} fill="#efe3d0" />
    <rect x={0} y={0} width={W} height={170} fill="#d9c7a8" />
    {Array.from({length: 8}).map((_, i) => (
      <rect key={i} x={40 + i * 130} y={70} width={80} height={14} rx={7} fill="#fff6c9" />
    ))}
    <rect x={0} y={1000} width={W} height={GROUND - 1000} fill="#c9b08a" />
    <rect x={0} y={996} width={W} height={12} fill="#9c8259" />
    {[170, 910].map((x, i) => (
      <g key={i}>
        <ellipse cx={x} cy={640} rx={85} ry={115} fill="#0b1026" stroke="#fff" strokeWidth={12} />
        <ellipse cx={x} cy={640} rx={85} ry={115} fill="none" stroke={C.ink} strokeWidth={5} />
        <circle cx={x - 20} cy={600} r={3} fill="#fff" /><circle cx={x + 24} cy={680} r={2.5} fill="#fff" />
      </g>
    ))}
    <rect x={0} y={GROUND} width={W} height={H - GROUND} fill="#2b3a67" />
    {Array.from({length: 9}).map((_, i) => (
      <g key={i}>
        <polygon points={`${i * 130},${GROUND + 120} ${i * 130 + 65},${GROUND + 60} ${i * 130 + 130},${GROUND + 120} ${i * 130 + 65},${GROUND + 180}`} fill="none" stroke="#4a5d99" strokeWidth={6} />
      </g>
    ))}
  </svg>
);

export const Background: React.FC<{kind: BGKind}> = ({kind}) => {
  const f = useCurrentFrame();
  if (kind === 'office') return <Office f={f} />;
  if (kind === 'sky') return <Night f={f} />;
  if (kind === 'cabin') return <Cabin />;
  const p = PAL[kind];
  const trees = Array.from({length: 9}).map((_, i) => ({
    x: i * 135 + random(`tx${i}`) * 60,
    s: 0.55 + random(`ts${i}`) * 0.5,
  }));
  return (
    <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
      <defs>
        <linearGradient id={`sky-${kind}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={p.sky[0]} />
          <stop offset="1" stopColor={p.sky[1]} />
        </linearGradient>
        <linearGradient id={`gr-${kind}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={p.ground[0]} />
          <stop offset="1" stopColor={p.ground[1]} />
        </linearGradient>
      </defs>
      <rect width={W} height={H} fill={`url(#sky-${kind})`} />
      {kind === 'party' && (
        <g transform={`rotate(${f * 0.35} 540 760)`}>
          {Array.from({length: 18}).map((_, i) => (
            <polygon key={i} points={`540,760 ${540 + Math.cos(((i * 20) * Math.PI) / 180) * 2200},${760 + Math.sin(((i * 20) * Math.PI) / 180) * 2200} ${540 + Math.cos(((i * 20 + 9) * Math.PI) / 180) * 2200},${760 + Math.sin(((i * 20 + 9) * Math.PI) / 180) * 2200}`} fill="rgba(255,255,255,0.14)" />
          ))}
        </g>
      )}
      {kind === 'dusk' && (
        <>
          {Array.from({length: 36}).map((_, i) => (
            <circle key={i} cx={random(`sx${i}`) * W} cy={random(`sy${i}`) * 700} r={2 + random(`sr${i}`) * 3} fill="#fff" opacity={0.5 + 0.5 * Math.sin(f / 10 + i)} />
          ))}
          <circle cx={860} cy={300} r={80} fill="#fff6c9" />
          <circle cx={885} cy={285} r={70} fill="#4a4a8a" opacity={0.25} />
        </>
      )}
      {(kind === 'forest' || kind === 'park') && (
        <>
          <circle cx={880} cy={260 + Math.sin(f / 30) * 8} r={90} fill="#fff3a0" opacity={0.9} />
          {[0, 1, 2].map((i) => {
            const cx = ((i * 520 + f * (0.8 + i * 0.3)) % (W + 500)) - 250;
            const cy = 330 + i * 150;
            return (
              <g key={i} fill="#fff" opacity={0.95}>
                <ellipse cx={cx} cy={cy} rx={110} ry={44} />
                <ellipse cx={cx - 60} cy={cy + 10} rx={70} ry={34} />
                <ellipse cx={cx + 66} cy={cy + 12} rx={74} ry={32} />
              </g>
            );
          })}
        </>
      )}
      <path d={hillPath(1010, 40, f * 0.006, 170)} fill={p.hills[0]} stroke={C.ink} strokeWidth={4} />
      <path d={hillPath(1110, 46, 2 + f * 0.008, 150)} fill={p.hills[1]} stroke={C.ink} strokeWidth={4} />
      <path d={hillPath(1210, 38, 4 + f * 0.01, 130)} fill={p.hills[2]} stroke={C.ink} strokeWidth={4} />
      {trees.map((t, i) => (
        <Pine key={i} x={t.x} y={GROUND - 20} s={t.s} f={f} leaf={p.leaf} trunk={p.trunk} />
      ))}
      <rect x={0} y={GROUND - 30} width={W} height={H - GROUND + 30} fill={`url(#gr-${kind})`} stroke={C.ink} strokeWidth={5} />
      {Array.from({length: 12}).map((_, i) => (
        <path key={i} d={`M${i * 100 + 20} ${GROUND + 30 + (i % 3) * 60} l14 -26 l14 26`} fill="none" stroke="rgba(0,0,0,0.18)" strokeWidth={5} strokeLinecap="round" />
      ))}
    </svg>
  );
};
