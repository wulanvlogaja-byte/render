import React from 'react';
import {Audio, Img, Sequence, random, spring, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, FPS, GROUND, H, W, bangers, lilita} from './theme';

export const useSec = () => useCurrentFrame() / FPS;

/** spring 0 -> 1 (dengan overshoot) mulai dari detik `at` */
export const usePop = (at: number, damping = 9): number => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const f = frame - Math.round(at * fps);
  if (f < 0) return 0;
  return spring({frame: f, fps, config: {damping, stiffness: 150, mass: 0.6}});
};

/** Objek muncul (pop) di titik tengah x,y */
export const Pop: React.FC<{
  at: number;
  x: number;
  y: number;
  until?: number;
  rot?: number;
  children?: React.ReactNode;
}> = ({at, x, y, until, rot = 0, children}) => {
  const p = usePop(at);
  const sec = useSec();
  if (p <= 0.001 || (until !== undefined && sec >= until)) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: 'max-content',
        transform: `translate(-50%,-50%) scale(${p}) rotate(${rot}deg)`,
        opacity: Math.min(1, p * 2.5),
      }}
    >
      {children}
    </div>
  );
};

/** Pop untuk elemen di dalam container (posisi diatur lewat style) */
export const Reveal: React.FC<{
  at: number;
  until?: number;
  style?: React.CSSProperties;
  origin?: string;
  children?: React.ReactNode;
}> = ({at, until, style, origin = '50% 50%', children}) => {
  const p = usePop(at);
  const sec = useSec();
  if (p <= 0.001 || (until !== undefined && sec >= until)) return null;
  return (
    <div style={{...style, transform: `scale(${p})`, transformOrigin: origin, opacity: Math.min(1, p * 2.5)}}>
      {children}
    </div>
  );
};

/** Objek jatuh dari atas lalu mantul */
export const Drop: React.FC<{at: number; x: number; y: number; rot?: number; children?: React.ReactNode}> = ({
  at,
  x,
  y,
  rot = 0,
  children,
}) => {
  const p = usePop(at, 11);
  if (p <= 0.001) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: 'max-content',
        transform: `translate(-50%,-50%) translateY(${-(1 - p) * 900}px) rotate(${rot * p}deg)`,
      }}
    >
      {children}
    </div>
  );
};

export const Character: React.FC<{
  src?: 'grad';
  x: number;
  h?: number;
  at?: number;
  enter?: boolean;
  until?: number;
  shake?: number;
  jump?: number;
  shades?: number; // detik kacamata hitam jatuh ke wajah
}> = ({src = 'grad', x, h = 720, at = 0, enter = true, until, shake = 0, jump = 0, shades}) => {
  const f = useCurrentFrame();
  const sec = f / FPS;
  const p = usePop(at, 12);
  const sp = usePop(shades ?? 9999, 10);
  if ((enter && p <= 0.001) || (until !== undefined && sec >= until)) return null;
  const pp = enter ? p : 1;
  const w = (h * 1024) / 1536;
  const bob = Math.sin(f / 7) * 0.012;
  const jumpY = jump ? -Math.abs(Math.sin(f / 4)) * jump : 0;
  const sx = shake ? Math.sin(f * 2.1) * shake : 0;
  return (
    <>
      <div
        style={{
          position: 'absolute', left: x - w * 0.4, top: GROUND - 14, width: w * 0.8, height: 28,
          borderRadius: '50%', background: 'rgba(0,0,0,0.25)', transform: `scale(${Math.min(1, pp)})`,
        }}
      />
      <div
        style={{
          position: 'absolute', left: x - w / 2, top: GROUND - h, width: w, height: h,
          transformOrigin: '50% 100%',
          transform: `translate(${sx}px, ${(1 - pp) * 500 + jumpY}px) scale(${1 + bob}, ${1 - bob})`,
        }}
      >
        <Img src={staticFile(`${src}.png`)} style={{position: 'absolute', left: 0, top: 0, width: '100%', height: '100%'}} />
        {shades !== undefined && sp > 0.001 && (
          <svg
            viewBox="0 0 200 70"
            style={{
              position: 'absolute', left: `${((492 - 66) / 1024) * 100}%`, top: `${((140 - 24) / 1536) * 100}%`,
              width: `${(132 / 1024) * 100}%`, overflow: 'visible',
              transform: `translateY(${-(1 - Math.min(sp, 1.2)) * 500}px)`,
            }}
          >
            <rect x="4" y="8" width="84" height="46" rx="16" fill="#111" stroke="#000" strokeWidth="4" />
            <rect x="112" y="8" width="84" height="46" rx="16" fill="#111" stroke="#000" strokeWidth="4" />
            <rect x="86" y="18" width="28" height="8" rx="4" fill="#111" />
            <line x1="14" y1="18" x2="34" y2="14" stroke="#fff" strokeWidth="5" strokeLinecap="round" opacity="0.6" />
            <line x1="122" y1="18" x2="142" y2="14" stroke="#fff" strokeWidth="5" strokeLinecap="round" opacity="0.6" />
          </svg>
        )}
      </div>
    </>
  );
};

export const Big: React.FC<{
  size?: number;
  color?: string;
  stroke?: number;
  style?: React.CSSProperties;
  children?: React.ReactNode;
}> = ({size = 120, color = C.yellow, stroke = 14, style, children}) => (
  <span
    style={{
      fontFamily: bangers,
      fontSize: size,
      color,
      letterSpacing: 2,
      lineHeight: 1.02,
      WebkitTextStroke: `${stroke}px ${C.ink}`,
      paintOrder: 'stroke fill',
      textShadow: `0 8px 0 ${C.ink}`,
      whiteSpace: 'pre-line',
      textAlign: 'center',
      display: 'inline-block',
      ...style,
    }}
  >
    {children}
  </span>
);

export const Tag: React.FC<{
  bg?: string;
  color?: string;
  size?: number;
  w?: number;
  children?: React.ReactNode;
}> = ({bg = C.blue, color = '#fff', size = 56, w, children}) => (
  <div
    style={{
      fontFamily: lilita,
      fontSize: size,
      color,
      background: bg,
      border: `8px solid ${C.ink}`,
      borderRadius: 36,
      padding: '14px 30px',
      textAlign: 'center',
      lineHeight: 1.1,
      width: w,
      boxSizing: 'border-box',
      boxShadow: `0 10px 0 ${C.ink}`,
      whiteSpace: 'pre-line',
    }}
  >
    {children}
  </div>
);

export const Stamp: React.FC<{
  at: number;
  x: number;
  y: number;
  text: string;
  color?: string;
  size?: number;
  rot?: number;
}> = ({at, x, y, text, color = C.red, size = 110, rot = -8}) => {
  const p = usePop(at, 8);
  if (p <= 0.001) return null;
  return (
    <div
      style={{
        position: 'absolute',
        left: x,
        top: y,
        width: 'max-content',
        transform: `translate(-50%,-50%) rotate(${rot}deg) scale(${1 + (1 - Math.min(p, 1)) * 2.2})`,
        opacity: Math.min(1, p * 3),
        fontFamily: bangers,
        fontSize: size,
        color,
        border: `12px solid ${color}`,
        borderRadius: 24,
        padding: '4px 36px',
        background: 'rgba(255,255,255,0.92)',
        letterSpacing: 4,
        boxShadow: `0 8px 0 ${C.ink}`,
        whiteSpace: 'pre-line',
        textAlign: 'center',
      }}
    >
      {text}
    </div>
  );
};

export const Bubble: React.FC<{
  w: number;
  h?: number;
  tailLeft?: string;
  fill?: string;
  children?: React.ReactNode;
}> = ({w, h, tailLeft = '70%', fill = '#fff', children}) => (
  <div
    style={{
      position: 'relative',
      width: w,
      minHeight: h,
      boxSizing: 'border-box',
      background: fill,
      border: `8px solid ${C.ink}`,
      borderRadius: 44,
      padding: '22px 30px',
      fontFamily: lilita,
      fontSize: 56,
      lineHeight: 1.1,
      color: C.ink,
      textAlign: 'center',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
    }}
  >
    {children}
    <div
      style={{
        position: 'absolute',
        bottom: -30,
        left: tailLeft,
        width: 48,
        height: 48,
        background: fill,
        borderRight: `8px solid ${C.ink}`,
        borderBottom: `8px solid ${C.ink}`,
        transform: 'rotate(45deg)',
      }}
    />
  </div>
);

/** Awan pikiran (lingkaran dobel supaya outline menyatu) */
export const ThoughtCloud: React.FC<{w: number; h: number; children?: React.ReactNode}> = ({w, h, children}) => {
  const circles = [
    [0.5, 0.5, 0.42], [0.22, 0.55, 0.2], [0.78, 0.55, 0.2], [0.3, 0.28, 0.2],
    [0.7, 0.28, 0.2], [0.5, 0.2, 0.2], [0.14, 0.4, 0.14], [0.86, 0.4, 0.14],
    [0.3, 0.8, 0.18], [0.7, 0.8, 0.18], [0.5, 0.82, 0.18],
  ];
  return (
    <div style={{position: 'relative', width: w, height: h}}>
      <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{position: 'absolute', left: 0, top: 0}}>
        {circles.map((c, i) => (
          <ellipse key={`o${i}`} cx={c[0] * w} cy={c[1] * h} rx={c[2] * w} ry={c[2] * h} fill={C.ink} stroke={C.ink} strokeWidth={18} />
        ))}
        {circles.map((c, i) => (
          <ellipse key={`i${i}`} cx={c[0] * w} cy={c[1] * h} rx={c[2] * w} ry={c[2] * h} fill="#fff" />
        ))}
      </svg>
      <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        {children}
      </div>
    </div>
  );
};

export const Confetti: React.FC<{at: number; n?: number}> = ({at, n = 70}) => {
  const sec = useSec();
  const t = sec - at;
  if (t < 0) return null;
  const cols = [C.red, C.yellow, C.green, C.blue, '#fff', C.orange];
  return (
    <>
      {Array.from({length: n}).map((_, i) => {
        const x0 = random(`cx${i}`) * W;
        const sp = 500 + random(`cs${i}`) * 700;
        const d = random(`cd${i}`) * 0.5;
        const tt = t - d;
        if (tt < 0) return null;
        const y = -60 + tt * sp;
        if (y > H + 60) return null;
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x0 + Math.sin(tt * 5 + i) * 60,
              top: y,
              width: 20,
              height: 34,
              background: cols[i % cols.length],
              border: `3px solid ${C.ink}`,
              transform: `rotate(${tt * (300 + random(`cr${i}`) * 400)}deg)`,
            }}
          />
        );
      })}
    </>
  );
};

export const Sfx: React.FC<{at: number; f: string; vol?: number}> = ({at, f, vol = 0.7}) => (
  <Sequence from={Math.round(at * FPS)} layout="none">
    <Audio src={staticFile(`sfx/${f}.mp3`)} volume={vol} />
  </Sequence>
);
