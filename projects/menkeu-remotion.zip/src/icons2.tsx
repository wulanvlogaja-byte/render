import React from 'react';
import {C, bangers, lilita} from './theme';

const st = {stroke: C.ink, strokeWidth: 5, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

export const Calc: React.FC<{s?: number; text?: string}> = ({s = 220, text = 'ERROR'}) => (
  <svg width={(s * 160) / 220} height={s} viewBox="0 0 160 220">
    <rect x="8" y="8" width="144" height="204" rx="18" fill="#495057" {...st} />
    <rect x="22" y="22" width="116" height="52" rx="8" fill="#c0eb75" {...st} strokeWidth={4} />
    <text x="130" y="60" textAnchor="end" fontFamily={bangers} fontSize="34" fill={C.ink}>{text}</text>
    {[0, 1, 2].flatMap((r) => [0, 1, 2].map((c) => (
      <circle key={`${r}${c}`} cx={42 + c * 38} cy={106 + r * 36} r="13" fill={r === 2 && c === 2 ? C.red : '#dee2e6'} {...st} strokeWidth={3} />
    )))}
    <rect x="28" y="176" width="104" height="22" rx="10" fill={C.orange} {...st} strokeWidth={3} />
  </svg>
);

export const Bill: React.FC<{s?: number}> = ({s = 200}) => (
  <svg width={s} height={s * 0.5} viewBox="0 0 200 100">
    <rect x="4" y="4" width="192" height="92" rx="10" fill="#8ce99a" {...st} />
    <rect x="16" y="14" width="168" height="72" rx="6" fill="none" stroke="#2b8a3e" strokeWidth="3" />
    <circle cx="100" cy="50" r="26" fill="#51cf66" {...st} strokeWidth={4} />
    <text x="100" y="60" textAnchor="middle" fontFamily={bangers} fontSize="30" fill={C.ink}>Rp</text>
    <circle cx="34" cy="28" r="6" fill="#2b8a3e" /><circle cx="166" cy="72" r="6" fill="#2b8a3e" />
  </svg>
);

export const BillStack: React.FC<{s?: number}> = ({s = 220}) => (
  <div style={{position: 'relative', width: s, height: s * 0.62}}>
    {[0, 1, 2].map((i) => (
      <div key={i} style={{position: 'absolute', left: i * 8, top: (2 - i) * (s * 0.1), transform: `rotate(${(i - 1) * 4}deg)`}}><Bill s={s * 0.88} /></div>
    ))}
  </div>
);

export const Atm: React.FC<{s?: number; line1?: string; line2?: string}> = ({s = 520, line1 = 'SALDO APBN', line2 = 'Rp 99.999.999.999'}) => (
  <svg width={(s * 300) / 520} height={s} viewBox="0 0 300 520">
    <rect x="10" y="10" width="280" height="500" rx="24" fill="#adb5bd" {...st} />
    <rect x="30" y="30" width="240" height="40" rx="10" fill={C.blue} {...st} strokeWidth={4} />
    <text x="150" y="60" textAnchor="middle" fontFamily={bangers} fontSize="30" fill="#fff" letterSpacing="3">ATM</text>
    <rect x="34" y="92" width="232" height="140" rx="12" fill="#212529" {...st} />
    <rect x="44" y="102" width="212" height="120" rx="8" fill="#74c0fc" />
    <text x="150" y="146" textAnchor="middle" fontFamily={lilita} fontSize="28" fill={C.ink}>{line1}</text>
    <text x="150" y="190" textAnchor="middle" fontFamily={lilita} fontSize="22" fill={C.red}>{line2}</text>
    {[0, 1, 2].flatMap((r) => [0, 1, 2].map((c) => (
      <rect key={`${r}${c}`} x={80 + c * 50} y={252 + r * 36} width="38" height="26" rx="6" fill="#dee2e6" {...st} strokeWidth={3} />
    )))}
    <rect x="60" y="376" width="180" height="26" rx="8" fill="#212529" {...st} strokeWidth={4} />
    <rect x="50" y="424" width="200" height="58" rx="10" fill="#343a40" {...st} />
    <rect x="66" y="440" width="168" height="14" rx="6" fill="#000" />
  </svg>
);

export const Printer: React.FC<{s?: number}> = ({s = 320}) => (
  <svg width={s} height={(s * 220) / 300} viewBox="0 0 300 220">
    <rect x="70" y="4" width="160" height="70" rx="6" fill="#fff" {...st} strokeWidth={4} />
    <line x1="90" y1="26" x2="210" y2="26" stroke="#adb5bd" strokeWidth="4" /><line x1="90" y1="46" x2="190" y2="46" stroke="#adb5bd" strokeWidth="4" />
    <rect x="10" y="66" width="280" height="110" rx="18" fill="#868e96" {...st} />
    <rect x="30" y="84" width="240" height="22" rx="8" fill="#343a40" />
    <circle cx="250" cy="140" r="10" fill={C.green} {...st} strokeWidth={3} />
    <rect x="40" y="170" width="220" height="40" rx="8" fill="#ced4da" {...st} />
    <text x="110" y="148" textAnchor="middle" fontFamily={bangers} fontSize="34" fill="#fff">PRINT</text>
  </svg>
);

export const Chili: React.FC<{s?: number}> = ({s = 200}) => (
  <svg width={s} height={s} viewBox="0 0 200 200">
    <path d="M40 40 C120 20 190 70 170 150 C165 175 150 185 142 170 C150 120 110 70 60 66 Z" fill="#e03131" {...st} />
    <path d="M30 34 C44 20 62 26 64 46 C52 52 38 50 30 34Z" fill="#2f9e44" {...st} />
    <path d="M100 56 C140 70 160 100 156 140" fill="none" stroke="#ff8787" strokeWidth="7" strokeLinecap="round" />
  </svg>
);

export const Gauge: React.FC<{s?: number; angle: number}> = ({s = 520, angle}) => {
  const arc = (a0: number, a1: number, col: string) => {
    const r = 170, cx = 200, cy = 210;
    const p = (a: number) => [cx + r * Math.cos(((a - 180) * Math.PI) / 180), cy + r * Math.sin(((a - 180) * Math.PI) / 180)];
    const [x0, y0] = p(a0), [x1, y1] = p(a1);
    return <path d={`M${x0} ${y0} A${r} ${r} 0 0 1 ${x1} ${y1}`} fill="none" stroke={col} strokeWidth="38" />;
  };
  return (
    <svg width={s} height={(s * 260) / 400} viewBox="0 0 400 260">
      <path d="M10 210 A190 190 0 0 1 390 210 L10 210Z" fill="#fff" {...st} />
      {arc(0, 60, '#51cf66')}{arc(60, 120, '#ffd43b')}{arc(120, 180, '#fa5252')}
      <g transform={`rotate(${angle} 200 210)`}>
        <polygon points="200,200 200,220 40,210" fill={C.ink} />
      </g>
      <circle cx="200" cy="210" r="18" fill={C.red} {...st} />
      <text x="200" y="256" textAnchor="middle" fontFamily={lilita} fontSize="26" fill={C.ink}>USD / RUPIAH</text>
    </svg>
  );
};

/** Orang generik (bukan tokoh nyata). run = fase lari (radian), item di tangan */
export const Person: React.FC<{s?: number; body?: string; hair?: string; skin?: string; item?: 'jerry' | 'flute' | 'case' | 'none'; run?: number; tie?: string}> = ({
  s = 300, body = '#4dabf7', hair = '#2b2b2b', skin = '#f4c08a', item = 'none', run = 0, tie = C.red,
}) => {
  const a = Math.sin(run) * 30;
  return (
    <svg width={(s * 140) / 300} height={s} viewBox="0 0 140 300">
      <g transform={`rotate(${a} 58 176)`}><rect x="44" y="170" width="26" height="112" rx="10" fill="#343a40" {...st} strokeWidth={4} /><rect x="38" y="272" width="42" height="18" rx="8" fill="#111" {...st} strokeWidth={3} /></g>
      <g transform={`rotate(${-a} 82 176)`}><rect x="70" y="170" width="26" height="112" rx="10" fill="#343a40" {...st} strokeWidth={4} /><rect x="64" y="272" width="42" height="18" rx="8" fill="#111" {...st} strokeWidth={3} /></g>
      <g transform={`rotate(${-a} 38 100)`}><rect x="22" y="92" width="22" height="84" rx="10" fill={body} {...st} strokeWidth={4} /></g>
      <rect x="34" y="84" width="72" height="100" rx="16" fill={body} {...st} />
      <polygon points="70,86 60,100 70,150 80,100" fill={tie} {...st} strokeWidth={3} />
      <g transform={`rotate(${a} 102 100)`}>
        <rect x="96" y="92" width="22" height="84" rx="10" fill={body} {...st} strokeWidth={4} />
        {item === 'jerry' && <g><rect x="94" y="170" width="40" height="46" rx="6" fill="#e03131" {...st} strokeWidth={4} /><rect x="104" y="160" width="14" height="12" fill="#e03131" {...st} strokeWidth={3} /></g>}
        {item === 'case' && <rect x="88" y="172" width="52" height="40" rx="6" fill="#8d5524" {...st} strokeWidth={4} />}
        {item === 'flute' && <g><path d="M104 150 h20 l-4 30 q-6 6 -12 0z" fill="#fff3bf" {...st} strokeWidth={3} /><line x1="114" y1="180" x2="114" y2="200" stroke={C.ink} strokeWidth="4" /></g>}
      </g>
      <circle cx="70" cy="52" r="32" fill={skin} {...st} />
      <path d="M38 46 q4 -34 32 -34 q28 0 32 34 q-20 -16 -32 -16 q-12 0 -32 16z" fill={hair} />
      <circle cx="58" cy="56" r="4" fill={C.ink} /><circle cx="82" cy="56" r="4" fill={C.ink} />
      <path d="M58 72 q12 8 24 0" fill="none" stroke={C.ink} strokeWidth="4" strokeLinecap="round" />
    </svg>
  );
};

/** Staf berseragam di balik meja (torso). Posisi sama seperti petugas di template. */
export const Staff: React.FC<{x: number; pale?: boolean; f?: number}> = ({x, pale = false, f = 0}) => {
  const skin = pale ? '#f1f3f5' : '#f4c08a';
  return (
    <svg width={360} height={560} viewBox="0 0 360 560" style={{position: 'absolute', left: x - 180, top: 1130 - 440}}>
      <path d="M30 560 q0 -250 150 -250 q150 0 150 250z" fill="#fff" {...st} />
      <polygon points="150,310 180,360 210,310" fill="#dee2e6" {...st} strokeWidth={4} />
      <polygon points="180,330 166,350 180,440 194,350" fill={C.navy} {...st} strokeWidth={4} />
      <rect x="164" y="268" width="32" height="50" fill={skin} {...st} strokeWidth={4} />
      <circle cx="180" cy="200" r="86" fill={skin} {...st} />
      <path d="M96 190 q4 -90 84 -90 q80 0 84 90 q-40 -40 -84 -40 q-44 0 -84 40z" fill="#2b2b2b" />
      <g stroke={C.ink} strokeWidth="6" fill="#fff"><circle cx="146" cy="206" r="24" /><circle cx="214" cy="206" r="24" /><line x1="170" y1="206" x2="190" y2="206" /></g>
      <circle cx="146" cy="208" r={pale ? 4 : 8} fill={C.ink} /><circle cx="214" cy="208" r={pale ? 4 : 8} fill={C.ink} />
      <line x1="120" y1="172" x2="168" y2="180" stroke={C.ink} strokeWidth="9" strokeLinecap="round" />
      <line x1="240" y1="172" x2="192" y2="180" stroke={C.ink} strokeWidth="9" strokeLinecap="round" />
      {pale ? (
        <path d="M140 262 q10 -12 20 0 q10 12 20 0 q10 -12 20 0 q10 12 20 0" fill="none" stroke={C.ink} strokeWidth="7" strokeLinecap="round" />
      ) : (
        <path d="M150 262 q30 -20 60 0" fill="none" stroke={C.ink} strokeWidth="7" strokeLinecap="round" />
      )}
      {[0, 1].map((i) => (
        <path key={i} d={`M${i ? 262 : 98} ${150 + ((f * 3 + i * 40) % 60)} c-8 12 -8 20 0 24 c8 -4 8 -12 0 -24z`} fill="#74c0fc" stroke={C.ink} strokeWidth="3" />
      ))}
      <rect x="236" y="380" width="100" height="130" rx="6" fill="#fff" transform="rotate(8 286 445)" {...st} strokeWidth={4} />
      <polyline points="250,470 270,430 290,450 318,404" fill="none" stroke={C.red} strokeWidth="7" strokeLinecap="round" transform="rotate(8 286 445)" />
    </svg>
  );
};

export const Shop: React.FC<{s?: number; closed?: boolean; sway?: number}> = ({s = 400, closed = false, sway = 0}) => (
  <svg width={s} height={(s * 340) / 380} viewBox="0 0 380 340">
    <rect x="30" y="110" width="320" height="220" fill={C.cream} {...st} />
    {[0, 1, 2, 3, 4, 5].map((i) => (
      <path key={i} d={`M${20 + i * 56} 60 h56 l8 56 h-72z`} fill={i % 2 ? '#fff' : C.red} {...st} strokeWidth={4} />
    ))}
    <rect x="70" y="10" width="240" height="46" rx="10" fill={C.navy} {...st} strokeWidth={4} />
    <text x="190" y="44" textAnchor="middle" fontFamily={lilita} fontSize="28" fill="#fff">TOKO ONLINE LO</text>
    <rect x="60" y="150" width="130" height="110" rx="6" fill="#9bd3f4" {...st} strokeWidth={4} />
    <rect x="220" y="150" width="100" height="180" rx="6" fill="#8d5524" {...st} strokeWidth={4} />
    {closed && (
      <g transform={`rotate(${sway} 270 190)`}>
        <line x1="270" y1="150" x2="270" y2="190" stroke={C.ink} strokeWidth="4" />
        <rect x="222" y="190" width="96" height="46" rx="6" fill={C.red} {...st} strokeWidth={4} />
        <text x="270" y="223" textAnchor="middle" fontFamily={bangers} fontSize="34" fill="#fff" letterSpacing="2">TUTUP</text>
      </g>
    )}
  </svg>
);

export const Jet: React.FC<{s?: number}> = ({s = 800}) => (
  <svg width={s} height={(s * 260) / 800} viewBox="0 0 800 260">
    <polygon points="250,130 130,30 190,30 330,120" fill="#ced4da" {...st} />
    <path d="M60 130 C60 70 200 60 400 60 C600 60 740 90 780 130 C740 170 600 190 400 190 C200 190 60 190 60 130Z" fill="#fff" {...st} />
    <polygon points="60,120 20,30 90,30 150,110" fill={C.red} {...st} />
    <polygon points="360,150 250,236 330,236 480,160" fill="#adb5bd" {...st} />
    <ellipse cx="400" cy="206" rx="46" ry="24" fill="#868e96" {...st} />
    {Array.from({length: 10}).map((_, i) => (
      <ellipse key={i} cx={250 + i * 46} cy="112" rx="13" ry="16" fill="#74c0fc" {...st} strokeWidth={3} />
    ))}
    <path d="M700 90 q50 10 70 40 q-30 6 -90 -4z" fill="#74c0fc" {...st} strokeWidth={4} />
    <rect x="260" y="150" width="300" height="10" fill={C.yellow} />
  </svg>
);

export const Pump: React.FC<{s?: number}> = ({s = 340}) => (
  <svg width={(s * 200) / 340} height={s} viewBox="0 0 200 340">
    <rect x="20" y="10" width="140" height="300" rx="16" fill="#e03131" {...st} />
    <rect x="40" y="34" width="100" height="64" rx="8" fill="#c0eb75" {...st} strokeWidth={4} />
    <text x="90" y="78" textAnchor="middle" fontFamily={bangers} fontSize="34" fill={C.ink}>BENSIN</text>
    <rect x="40" y="130" width="100" height="40" rx="6" fill="#fff" {...st} strokeWidth={4} />
    <path d="M160 150 q40 0 36 60 q-4 40 -26 40" fill="none" stroke={C.ink} strokeWidth="12" strokeLinecap="round" />
    <rect x="6" y="310" width="168" height="24" rx="6" fill="#868e96" {...st} />
  </svg>
);

export const Champagne: React.FC<{s?: number}> = ({s = 260}) => (
  <svg width={(s * 200) / 260} height={s} viewBox="0 0 200 260">
    <rect x="86" y="10" width="30" height="40" rx="6" fill="#2b8a3e" {...st} />
    <path d="M80 50 h42 l10 70 h-62z" fill="#2f9e44" {...st} />
    <rect x="70" y="120" width="62" height="70" fill="#2f9e44" {...st} />
    <rect x="76" y="140" width="50" height="30" fill={C.cream} {...st} strokeWidth={3} />
    <path d="M20 170 h160 l-18 84 h-124z" fill="#a5d8ff" {...st} />
    <path d="M30 190 h140" stroke="#fff" strokeWidth="6" strokeLinecap="round" opacity="0.7" />
  </svg>
);

export const SwissFlag: React.FC<{s?: number}> = ({s = 200}) => (
  <svg width={s} height={s} viewBox="0 0 200 200">
    <rect x="8" y="8" width="184" height="184" fill="#e03131" {...st} />
    <rect x="82" y="38" width="36" height="124" fill="#fff" />
    <rect x="38" y="82" width="124" height="36" fill="#fff" />
  </svg>
);

export const Mountain: React.FC<{s?: number}> = ({s = 360}) => (
  <svg width={s} height={s * 0.55} viewBox="0 0 360 200">
    <polygon points="0,196 120,30 240,196" fill="#868e96" {...st} />
    <polygon points="120,30 90,84 112,76 128,90 150,70" fill="#fff" {...st} strokeWidth={3} />
    <polygon points="150,196 262,60 360,196" fill="#adb5bd" {...st} />
    <polygon points="262,60 238,98 258,92 274,104 290,88" fill="#fff" {...st} strokeWidth={3} />
  </svg>
);

export const Sack: React.FC<{s?: number}> = ({s = 170}) => (
  <svg width={s} height={s} viewBox="0 0 170 170">
    <path d="M50 40 q35 -34 70 0 l24 100 q-4 24 -26 24 h-66 q-22 0 -26 -24z" fill="#e0b97a" {...st} />
    <path d="M52 44 q33 18 66 0" fill="none" stroke={C.ink} strokeWidth="6" />
    <text x="85" y="116" textAnchor="middle" fontFamily={bangers} fontSize="30" fill={C.red}>BANSOS</text>
  </svg>
);

export const Heart: React.FC<{s?: number}> = ({s = 200}) => (
  <svg width={s} height={s * 0.9} viewBox="0 0 200 180">
    <path d="M100 168 C-30 84 40 -10 100 50 C160 -10 230 84 100 168Z" fill="#ff6b8b" {...st} />
    <path d="M52 52 q14 -16 32 -8" fill="none" stroke="#fff" strokeWidth="8" strokeLinecap="round" opacity="0.7" />
  </svg>
);

export const Burst: React.FC<{s?: number; fill?: string; children?: React.ReactNode}> = ({s = 240, fill = C.yellow, children}) => {
  const pts = Array.from({length: 24}).map((_, i) => {
    const a = (i * Math.PI) / 12, r = i % 2 ? 80 : 100;
    return `${100 + r * Math.cos(a)},${100 + r * Math.sin(a)}`;
  }).join(' ');
  return (
    <div style={{position: 'relative', width: s, height: s}}>
      <svg width={s} height={s} viewBox="0 0 200 200"><polygon points={pts} fill={fill} {...st} /></svg>
      <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{children}</div>
    </div>
  );
};
