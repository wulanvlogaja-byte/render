import React from 'react';
import {AbsoluteFill, interpolate, random, useCurrentFrame} from 'remotion';
import {Background} from './Background';
import {Big, Bubble, Character, Confetti, Drop, Pop, Reveal, Sfx, Stamp, Tag, usePop, useSec} from './parts';
import * as I from './icons';
import * as J from './icons2';
import {C, GROUND, H, W, bangers, lilita} from './theme';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const money = (n: number) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');

const Card: React.FC<{w: number; h: number; bg?: string; children?: React.ReactNode}> = ({w, h, bg = '#fff', children}) => (
  <div
    style={{
      width: w, height: h, background: bg, border: `8px solid ${C.ink}`, borderRadius: 34, boxShadow: `0 10px 0 ${C.ink}`,
      boxSizing: 'border-box', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
      fontFamily: lilita, color: C.ink, textAlign: 'center', overflow: 'hidden',
    }}
  >
    {children}
  </div>
);

const Desk: React.FC = () => (
  <>
    <div style={{position: 'absolute', left: 0, top: 1130, width: W, height: H - 1130, background: 'linear-gradient(#b5763a,#8d5524)', borderTop: '14px solid #6b3f1d'}} />
    <div style={{position: 'absolute', left: 60, top: 1185, width: W - 120, height: 12, background: 'rgba(0,0,0,0.15)', borderRadius: 6}} />
  </>
);

const Slide: React.FC<{at: number; from?: number; children?: React.ReactNode}> = ({at, from = 600, children}) => {
  const p = usePop(at, 13);
  if (p <= 0.001) return null;
  return <div style={{position: 'absolute', inset: 0, transform: `translateX(${(1 - p) * from}px)`}}>{children}</div>;
};

/* 1. HOOK */
const S1: React.FC = () => (
  <AbsoluteFill>
    <Background kind="office" />
    <Character x={540} at={0.1} />
    <Desk />
    <Pop at={0.1} x={250} y={290} rot={-6}><Big size={220} color={C.red}>POV</Big></Pop>
    <Pop at={0.9} x={730} y={290}><Tag bg={C.navy} size={54} w={520}>{'MENTERI\nKEUANGAN'}</Tag></Pop>
    <Pop at={1.4} x={540} y={1250} rot={-1}>
      <div style={{background: '#f1c453', border: `6px solid ${C.ink}`, borderRadius: 14, padding: '8px 40px', fontFamily: bangers, fontSize: 70, color: C.ink, letterSpacing: 6, boxShadow: `0 8px 0 ${C.ink}`}}>MENKEU</div>
    </Pop>
    <Pop at={2.7} x={820} y={560} rot={14}><Big size={180} color={C.yellow}>?</Big></Pop>
    <Pop at={3.1} x={230} y={600} rot={-12}><Big size={150} color={C.orange}>?</Big></Pop>
    <Drop at={3.3} x={190} y={1130 - 110}><J.Calc s={220} text="ERROR" /></Drop>
    <Drop at={4.2} x={880} y={1130 - 70}><J.BillStack s={230} /></Drop>
    <Sfx at={0.1} f="pop" /><Sfx at={0.15} f="whoosh" /><Sfx at={0.9} f="pop" /><Sfx at={1.4} f="ding" vol={0.5} />
    <Sfx at={2.7} f="pop" /><Sfx at={3.1} f="pop" /><Sfx at={3.6} f="buzzer" vol={0.3} /><Sfx at={4.55} f="thud" vol={0.6} /><Sfx at={4.6} f="chaching" vol={0.6} />
  </AbsoluteFill>
);

/* 2. APBN = ATM, UTANG = PAYLATER */
const S2: React.FC = () => {
  const sec = useSec();
  const billT = sec > 1.0 ? (sec * 1.4) % 1 : 0;
  const filled = Math.max(0, Math.min(12, Math.floor((sec - 5.4) / 0.12) + 1));
  return (
    <AbsoluteFill>
      <Background kind="office" />
      <Character x={270} at={0.2} />
      <Pop at={0.4} x={810} y={1140}><J.Atm s={520} /></Pop>
      {sec > 1.0 && (
        <div style={{position: 'absolute', left: 810 - 100, top: 1330 + billT * 70, opacity: 1 - billT * 0.6, transform: 'rotate(-4deg)'}}><J.Bill s={200} /></div>
      )}
      <Pop at={0.3} x={540} y={260} until={2.5} rot={-2}><Tag bg={C.blue} size={56} w={900}>APBN = SALDO ATM?</Tag></Pop>
      <Pop at={2.6} x={540} y={260} rot={2}><Tag bg={C.orange} size={52} w={940}>UTANG NEGARA = PAYLATER?</Tag></Pop>
      <Pop at={3.0} x={290} y={530} rot={-4}>
        <Card w={400} h={220} bg="#ffe8cc"><div style={{fontSize: 34}}>BAYAR NANTI</div><Big size={92} color={C.orange} stroke={9} style={{textShadow: 'none'}}>PAYLATER</Big></Card>
      </Pop>
      <Pop at={5.2} x={790} y={560} rot={3}>
        <Card w={440} h={300} bg="#e7f5ff">
          <div style={{fontSize: 36, marginBottom: 6}}>CICIL 12 BULAN</div>
          <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 76px)', gap: 8}}>
            {Array.from({length: 12}).map((_, i) => (
              <div key={i} style={{height: 48, borderRadius: 10, border: `4px solid ${C.ink}`, background: i < filled ? C.green : '#fff', fontSize: 26, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{i + 1}</div>
            ))}
          </div>
        </Card>
      </Pop>
      <Sfx at={0.2} f="whoosh" /><Sfx at={0.3} f="pop" /><Sfx at={0.45} f="pop" /><Sfx at={1.0} f="chaching" vol={0.6} />
      <Sfx at={2.6} f="pop" /><Sfx at={3.0} f="pop" /><Sfx at={5.2} f="pop" /><Sfx at={5.4} f="ticks" vol={0.4} /><Sfx at={6.6} f="ding" vol={0.5} />
    </AbsoluteFill>
  );
};

/* 3. DEFISIT 500 TRILIUN */
const S3: React.FC = () => {
  const sec = useSec();
  const f = useCurrentFrame();
  const n = interpolate(sec, [3.0, 4.2], [0, 500], cl);
  return (
    <AbsoluteFill>
      <Background kind="office" />
      <Character x={290} at={0.1} />
      <Slide at={0.4}><J.Staff x={830} f={f} /></Slide>
      <Desk />
      <Pop at={2.0} x={620} y={470}><Bubble w={760} tailLeft="78%">BU, PAK... DEFISIT!</Bubble></Pop>
      <Pop at={3.0} x={270} y={560} rot={-4}>
        <Card w={430} h={230} bg="#fff5f5"><div style={{fontSize: 40}}>DEFISIT</div><Big size={92} color={C.red} stroke={9} style={{textShadow: 'none'}}>{`Rp${Math.round(n)} T`}</Big></Card>
      </Pop>
      <Stamp at={4.0} x={800} y={760} text="BOLONG!" color={C.red} size={80} rot={-10} />
      <Sfx at={0.1} f="whoosh" /><Sfx at={0.4} f="whoosh" vol={0.4} /><Sfx at={2.0} f="pop" /><Sfx at={3.0} f="pop" />
      <Sfx at={3.0} f="ticks" vol={0.4} /><Sfx at={4.0} f="thud" /><Sfx at={4.0} f="siren" vol={0.25} />
    </AbsoluteFill>
  );
};

/* 4. PRINT LAGI AJA */
const S4: React.FC = () => {
  const sec = useSec();
  return (
    <AbsoluteFill>
      <Background kind="office" />
      <Character x={290} enter={false} />
      <Desk />
      <Pop at={1.5} x={470} y={500}><Bubble w={640} tailLeft="22%" fill="#fff6dc">TENANG, PRINT LAGI AJA!</Bubble></Pop>
      <Pop at={3.4} x={810} y={1000} rot={-3}><Tag bg={C.blue} size={42} w={400}>PRINTER DI BAWAH</Tag></Pop>
      <Pop at={3.6} x={810} y={1290}><J.Printer s={320} /></Pop>
      {Array.from({length: 12}).map((_, i) => {
        const t = sec - (3.9 + i * 0.22);
        if (t < 0) return null;
        const vx = (random(`bv${i}`) - 0.5) * 380;
        const x = 810 + vx * t;
        const y = 1230 - 1050 * t + 900 * t * t;
        if (y > 1500) return null;
        return <div key={i} style={{position: 'absolute', left: x - 70, top: y, transform: `rotate(${t * 360 * (i % 2 ? 1 : -1)}deg)`}}><J.Bill s={140} /></div>;
      })}
      <Sfx at={1.5} f="pop" /><Sfx at={3.4} f="pop" /><Sfx at={3.6} f="boing" vol={0.5} /><Sfx at={3.8} f="printer" vol={0.7} />
    </AbsoluteFill>
  );
};

/* 5. STAF PUCAT, CABAI NAIK */
const S5: React.FC = () => {
  const sec = useSec();
  const f = useCurrentFrame();
  const bob = Math.sin(sec * 6) * 10;
  return (
    <AbsoluteFill>
      <Background kind="office" />
      <Character x={290} enter={false} />
      <J.Staff x={830} pale={sec > 1.4} f={f} />
      <Desk />
      <Pop at={1.4} x={830} y={620} rot={8}><Big size={120} color="#fff" stroke={12}>{'...'}</Big></Pop>
      <Pop at={3.0} x={290} y={520} rot={-3}>
        <Card w={430} h={290} bg="#fff5f5">
          <div style={{display: 'flex', alignItems: 'center', gap: 14, transform: `translateY(${bob}px)`}}>
            <J.Chili s={170} />
            <svg width={80} height={130} viewBox="0 0 80 130"><polygon points="40,6 74,56 52,56 52,124 28,124 28,56 6,56" fill={C.red} stroke={C.ink} strokeWidth={6} strokeLinejoin="round" /></svg>
          </div>
          <div style={{fontSize: 40}}>HARGA CABAI</div>
        </Card>
      </Pop>
      <Sfx at={1.4} f="fall" vol={0.5} /><Sfx at={1.4} f="pop" /><Sfx at={3.0} f="pop" /><Sfx at={3.2} f="rise" vol={0.5} />
    </AbsoluteFill>
  );
};

/* 6. BANSOS PAKAI FEELING, SUBSIDI = DISKON */
const S6: React.FC = () => {
  const sec = useSec();
  return (
    <AbsoluteFill>
      <Background kind="office" />
      <Character x={290} at={0.1} jump={8} />
      {Array.from({length: 6}).map((_, i) => {
        const t = sec - (0.4 + i * 0.35);
        if (t < 0) return null;
        const x = 400 + (200 + (i % 3) * 120) * t;
        const y = 1000 - 700 * t + 800 * t * t;
        if (y > 1420) return null;
        return <div key={i} style={{position: 'absolute', left: x - 70, top: y - 70, transform: `rotate(${t * 300}deg)`}}><J.Sack s={140} /></div>;
      })}
      <Pop at={1.3} x={700} y={420} until={2.6} rot={-6}><J.Heart s={220} /></Pop>
      <Pop at={1.5} x={700} y={620} until={2.6}><Tag bg={C.red} size={52}>PAKAI FEELING</Tag></Pop>
      <Pop at={2.6} x={780} y={440} rot={2}><Tag bg={C.blue} size={74} w={460}>SUBSIDI</Tag></Pop>
      <Stamp at={3.2} x={780} y={440} text="DIHAPUS" color={C.red} size={88} rot={-8} />
      <Pop at={3.9} x={880} y={690} rot={10}><J.Burst s={260}><Big size={56} color={C.ink} stroke={0} style={{textShadow: 'none'}}>{'DISKON\n?!'}</Big></J.Burst></Pop>
      <Sfx at={0.4} f="whoosh" vol={0.4} /><Sfx at={0.75} f="whoosh" vol={0.4} /><Sfx at={1.1} f="whoosh" vol={0.4} />
      <Sfx at={1.3} f="pop" /><Sfx at={1.5} f="boing" vol={0.5} /><Sfx at={2.6} f="pop" /><Sfx at={3.2} f="thud" /><Sfx at={3.9} f="pop" /><Sfx at={4.1} f="buzzer" vol={0.25} />
    </AbsoluteFill>
  );
};

/* 7. DOLLAR 25 RIBU, INVESTOR KABUR, BANGKRUT */
const S7: React.FC = () => {
  const sec = useSec();
  const f = useCurrentFrame();
  const ang = interpolate(sec, [0.9, 3.0], [5, 168], cl) + (sec > 3.0 ? Math.sin(f * 1.7) * 3 : 0);
  return (
    <AbsoluteFill>
      <Background kind="party" />
      <Character x={820} h={640} at={0.1} shake={sec > 3 ? 5 : 0} />
      <Pop at={0.9} x={540} y={470}><J.Gauge s={560} angle={ang} /></Pop>
      <Pop at={0.9} x={540} y={250} rot={-3}><Tag bg={C.navy} size={52}>DOLLAR NAIK!</Tag></Pop>
      <Pop at={3.0} x={330} y={760} rot={-5}><Big size={110} color={C.red}>Rp25.000</Big></Pop>
      {[0, 1, 2].map((i) => {
        const t = sec - (3.6 + i * 0.35);
        if (t < 0) return null;
        const x = 1250 - t * 520;
        if (x < -200) return null;
        return <div key={i} style={{position: 'absolute', left: x, top: GROUND - 330 - Math.abs(Math.sin(t * 10)) * 18}}>
          <J.Person s={320} body={['#868e96', '#5c7cfa', '#495057'][i]} item="case" run={t * 14} tie={C.yellow} />
        </div>;
      })}
      <Stamp at={4.6} x={560} y={1000} text="BANGKRUT!" color={C.red} size={130} rot={-8} />
      <Pop at={5.7} x={250} y={1010} rot={-5}><Card w={330} h={220} bg="#fff9db"><div style={{fontSize: 36}}>DALAM</div><Big size={86} color={C.orange} stroke={9} style={{textShadow: 'none'}}>3 BULAN</Big></Card></Pop>
      <Sfx at={0.9} f="pop" /><Sfx at={0.95} f="rise" /><Sfx at={3.0} f="siren" vol={0.4} /><Sfx at={3.0} f="pop" />
      <Sfx at={3.6} f="whoosh" /><Sfx at={3.95} f="whoosh" /><Sfx at={4.3} f="whoosh" /><Sfx at={4.6} f="thud" vol={0.9} /><Sfx at={5.7} f="pop" /><Sfx at={5.8} f="buzzer" vol={0.3} />
    </AbsoluteFill>
  );
};

/* 8. LEBIH CEPAT DARI TOKO ONLINE LO */
const S8: React.FC = () => {
  const sec = useSec();
  const p1 = interpolate(sec, [0.7, 1.7], [0, 1], cl);
  const p2 = interpolate(sec, [0.7, 3.4], [0, 0.55], cl);
  const Bar: React.FC<{y: number; label: string; p: number; color: string}> = ({y, label, p, color}) => (
    <div style={{position: 'absolute', left: 90, top: y, width: 900}}>
      <div style={{fontFamily: lilita, fontSize: 44, color: '#fff', WebkitTextStroke: `10px ${C.ink}`, paintOrder: 'stroke fill', marginBottom: 6}}>{label}</div>
      <div style={{height: 64, borderRadius: 32, border: `8px solid ${C.ink}`, background: '#fff', overflow: 'hidden'}}>
        <div style={{width: `${p * 100}%`, height: '100%', background: color}} />
      </div>
    </div>
  );
  return (
    <AbsoluteFill>
      <Background kind="dusk" />
      <Reveal at={0.2} style={{position: 'absolute', inset: 0}}>
        <Bar y={230} label="NEGARA BANGKRUT" p={p1} color={C.red} />
        <Bar y={440} label="TOKO ONLINE LO" p={p2} color={C.orange} />
      </Reveal>
      <Stamp at={1.75} x={800} y={380} text="SELESAI" color={C.red} size={70} rot={-8} />
      <Pop at={1.9} x={540} y={1010}><J.Shop s={520} closed={sec > 2.9} sway={Math.sin(sec * 8) * 8} /></Pop>
      <Sfx at={0.2} f="pop" /><Sfx at={0.7} f="ticks" vol={0.4} /><Sfx at={1.75} f="thud" /><Sfx at={1.9} f="pop" /><Sfx at={2.9} f="sadtrombone" vol={0.5} />
    </AbsoluteFill>
  );
};

/* 9. EH BENTAR BRO */
const S9: React.FC = () => (
  <AbsoluteFill>
    <Background kind="forest" />
    <Character x={540} at={0.05} />
    <Pop at={0.05} x={540} y={330} until={1.9} rot={-4}><Big size={200} color={C.red}>{'EH BENTAR\nBRO!'}</Big></Pop>
    <Pop at={2.4} x={540} y={300} until={4.5} rot={-2}><Tag bg={C.red} size={62}>NEGARA LO BANGKRUT</Tag></Pop>
    <Pop at={4.6} x={285} y={500} rot={-3}>
      <Card w={440} h={290} bg="#e7f5ff"><div style={{fontSize: 40}}>PILIH:</div><Big size={92} color={C.blue} stroke={9} style={{textShadow: 'none'}}>{'MINTA\nMAAF'}</Big></Card>
    </Pop>
    <Pop at={5.9} x={795} y={500} rot={3}>
      <Card w={440} h={290} bg="#fff9db"><J.Jet s={380} /><Big size={74} color={C.orange} stroke={9} style={{textShadow: 'none'}}>BOOKING JET</Big></Card>
    </Pop>
    <Sfx at={0.05} f="scratch" /><Sfx at={2.4} f="pop" /><Sfx at={4.6} f="pop" /><Sfx at={5.9} f="pop" /><Sfx at={6.1} f="seatbelt" vol={0.6} />
  </AbsoluteFill>
);

/* 10. LIKE & SUBSCRIBE */
const S10: React.FC = () => {
  const sec = useSec();
  const f = useCurrentFrame();
  const done = sec >= 1.95;
  const cx = interpolate(sec, [1.2, 1.9], [1000, 800], cl);
  const cy = interpolate(sec, [1.2, 1.9], [800, 590], cl);
  const press = sec > 1.8 && sec < 2.05 ? 0.9 : 1;
  const bell = sec >= 2.0 ? Math.sin(f * 1.1) * 22 * Math.max(0, 1 - (sec - 2.0) / 1.6) : 0;
  return (
    <AbsoluteFill>
      <Background kind="park" />
      <Character x={540} at={0.1} jump={14} />
      <Pop at={0.3} x={250} y={560} rot={-8}>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}><I.Thumb s={240} /><Big size={70} color="#fff" stroke={10}>LIKE</Big></div>
      </Pop>
      <Pop at={0.9} x={740} y={540}>
        <div style={{transform: `scale(${press})`, display: 'flex', alignItems: 'center', gap: 16, background: done ? '#868e96' : '#ff0033', border: `8px solid ${C.ink}`, borderRadius: 30, padding: '20px 34px', boxShadow: `0 10px 0 ${C.ink}`, fontFamily: lilita, fontSize: 54, color: '#fff'}}>
          {!done && <svg width={54} height={54} viewBox="0 0 54 54"><polygon points="8,4 50,27 8,50" fill="#fff" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /></svg>}
          {done ? 'SUBSCRIBED' : 'SUBSCRIBE'}
        </div>
      </Pop>
      {sec >= 1.2 && <div style={{position: 'absolute', left: cx, top: cy}}><I.Cursor s={100} /></div>}
      <Pop at={2.0} x={940} y={680}><I.Bell s={150} rot={bell} /></Pop>
      <Pop at={2.5} x={540} y={250}><Tag bg={C.red} size={50} w={940}>{'BIAR LO GAK JADI RAKYAT\nJELATA YANG KAGET'}</Tag></Pop>
      <Sfx at={0.3} f="pop" /><Sfx at={0.9} f="pop" /><Sfx at={1.2} f="whoosh" vol={0.35} /><Sfx at={1.95} f="click" />
      <Sfx at={2.0} f="ding" /><Sfx at={2.5} f="pop" /><Sfx at={2.7} f="sparkle" vol={0.5} />
    </AbsoluteFill>
  );
};

/* 11. LANJUT. PRIVATE JET */
const S11: React.FC = () => {
  const sec = useSec();
  const x = interpolate(sec, [1.2, 2.75], [-420, 540], cl);
  return (
    <AbsoluteFill>
      <Background kind="sky" />
      <Pop at={0.05} x={540} y={330} until={1.3} rot={-5}><Big size={220} color={C.yellow}>LANJUT.</Big></Pop>
      {sec >= 1.2 && (
        <div style={{position: 'absolute', left: x - 400, top: 620 + Math.sin(sec * 5) * 14}}>
          <J.Jet s={800} />
        </div>
      )}
      <Pop at={2.0} x={540} y={420}><Tag bg={C.navy} size={64}>PRIVATE JET</Tag></Pop>
      <Sfx at={0.05} f="whoosh" /><Sfx at={1.2} f="jet" vol={0.7} /><Sfx at={2.0} f="seatbelt" vol={0.6} /><Sfx at={2.0} f="pop" />
    </AbsoluteFill>
  );
};

/* 12. 40.000 KAKI, KOTA GELAP GULITA */
const S12: React.FC = () => {
  const sec = useSec();
  const ft = Math.round(interpolate(sec, [1.0, 2.4], [0, 40000], cl));
  const cloudOp = interpolate(sec, [3.0, 3.7], [1, 0], cl);
  const lights = Array.from({length: 170}).map((_, i) => ({
    x: 210 + random(`cx${i}`) * 660, y: 700 + random(`cy${i}`) * 470, r: 3 + random(`cr${i}`) * 3.5,
    off: 5.55 + random(`co${i}`) * 0.9, c: random(`cc${i}`) > 0.7 ? '#ffffff' : '#ffd166',
  }));
  return (
    <AbsoluteFill>
      <Background kind="cabin" />
      <svg width={W} height={H} viewBox={`0 0 ${W} ${H}`} style={{position: 'absolute', left: 0, top: 0}}>
        <defs>
          <clipPath id="port"><circle cx={540} cy={860} r={350} /></clipPath>
          <linearGradient id="pskyg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0b1026" /><stop offset="1" stopColor="#1d2456" /></linearGradient>
        </defs>
        <g clipPath="url(#port)">
          <rect x={190} y={510} width={700} height={700} fill="url(#pskyg)" />
          <rect x={190} y={690} width={700} height={520} fill="#0a0e24" />
          {lights.map((l, i) => sec < l.off && <circle key={i} cx={l.x} cy={l.y} r={l.r} fill={l.c} opacity={0.65 + 0.35 * Math.sin(sec * 6 + i)} />)}
          <g opacity={cloudOp}>
            {Array.from({length: 7}).map((_, i) => (
              <ellipse key={i} cx={((i * 260 + sec * 420) % 1100) - 100} cy={640 + (i % 4) * 150} rx={190} ry={70} fill="#e9ecff" />
            ))}
          </g>
        </g>
        <circle cx={540} cy={860} r={362} fill="none" stroke="#efe9dc" strokeWidth={34} />
        <circle cx={540} cy={860} r={380} fill="none" stroke={C.ink} strokeWidth={8} />
        <circle cx={540} cy={860} r={346} fill="none" stroke={C.ink} strokeWidth={6} />
      </svg>
      {sec >= 0.1 && (
        <Pop at={0.1} x={540} y={250}>
          <Card w={640} h={170} bg="#e7f5ff"><div style={{fontSize: 34}}>KETINGGIAN</div><Big size={84} color={C.blue} stroke={9} style={{textShadow: 'none'}}>{`${money(ft)} KAKI`}</Big></Card>
        </Pop>
      )}
      <Pop at={5.6} x={540} y={1290} rot={-3}><Big size={120} color={C.yellow}>GELAP GULITA</Big></Pop>
      <Sfx at={0.1} f="pop" /><Sfx at={1.0} f="rise" vol={0.5} /><Sfx at={1.0} f="ticks" vol={0.4} /><Sfx at={2.5} f="ding" vol={0.5} /><Sfx at={3.7} f="sparkle" vol={0.4} />
      <Sfx at={5.55} f="fall" vol={0.6} /><Sfx at={5.6} f="thud" /><Sfx at={5.6} f="pop" />
    </AbsoluteFill>
  );
};

/* 13. KACAMATA HITAM, "TERIMA KASIH PAJAKNYA" */
const S13: React.FC = () => {
  const sec = useSec();
  const shade = interpolate(sec, [0.6, 1.3], [0, 1], cl);
  return (
    <AbsoluteFill>
      <Background kind="cabin" />
      <div style={{position: 'absolute', left: 60, top: 430, width: 260, height: 360, borderRadius: '50%', border: `14px solid #fff`, boxShadow: `0 0 0 6px ${C.ink}`, overflow: 'hidden', background: 'linear-gradient(#0b1026,#2b2d6e)'}}>
        {Array.from({length: 14}).map((_, i) => <div key={i} style={{position: 'absolute', left: random(`wx${i}`) * 240, top: random(`wy${i}`) * 330, width: 5, height: 5, borderRadius: 3, background: '#fff', opacity: 0.4 + 0.6 * Math.abs(Math.sin(sec * 3 + i))}} />)}
        <div style={{position: 'absolute', left: 150, top: 40, width: 70, height: 70, borderRadius: '50%', background: '#fff6c9'}} />
        <div style={{position: 'absolute', left: 0, top: 0, width: '100%', height: `${(1 - shade) * 100}%`, background: '#e9dcc3', borderBottom: `8px solid ${C.ink}`}} />
      </div>
      <Character x={660} h={900} at={0.1} shades={1.7} />
      <Pop at={2.1} x={300} y={330} until={2.8} rot={-6}><Big size={90} color="#fff" stroke={10}>psst...</Big></Pop>
      <Pop at={2.9} x={600} y={330} until={4.3}><Bubble w={760} tailLeft="60%">Halo rakyat jelata,</Bubble></Pop>
      <Pop at={4.4} x={600} y={330}><Bubble w={880} tailLeft="60%">terima kasih pajaknya ya.</Bubble></Pop>
      <Pop at={6.0} x={190} y={1010} rot={-6}>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 6}}>
          <J.SwissFlag s={170} /><Tag bg={C.red} size={44}>SWISS</Tag>
        </div>
      </Pop>
      <Pop at={6.2} x={190} y={1260}><J.Mountain s={300} /></Pop>
      <Sfx at={0.6} f="whoosh" vol={0.4} /><Sfx at={1.7} f="pop" /><Sfx at={1.9} f="thud" vol={0.5} /><Sfx at={2.1} f="pop" vol={0.5} />
      <Sfx at={2.9} f="pop" /><Sfx at={4.4} f="pop" /><Sfx at={6.0} f="ding" /><Sfx at={6.2} f="sparkle" vol={0.5} />
    </AbsoluteFill>
  );
};

/* 14a. RAKYAT ANTRI BENSIN */
const S14a: React.FC = () => (
  <AbsoluteFill>
    <Background kind="dusk" />
    <Pop at={0.2} x={540} y={300} rot={-2}><Tag bg={C.red} size={62}>RAKYAT: ANTRI BENSIN</Tag></Pop>
    <Pop at={0.1} x={900} y={1230}><J.Pump s={340} /></Pop>
    {[740, 600, 460, 320, 180].map((x, i) => (
      <Pop key={i} at={0.4 + i * 0.35} x={x} y={1230}>
        <J.Person s={340} body={['#74c0fc', '#ffa94d', '#b197fc', '#69db7c', '#ff8787'][i]} item="jerry" hair={i % 2 ? '#111' : '#5c3b1e'} tie="#fff" />
      </Pop>
    ))}
    {[0, 1, 2, 3, 4].map((i) => <Sfx key={i} at={0.4 + i * 0.35} f="pop" vol={0.5} />)}
    <Sfx at={0.2} f="pop" /><Sfx at={2.0} f="buzzer" vol={0.25} />
  </AbsoluteFill>
);

/* 14b. LO ANTRI CHAMPAGNE */
const S14b: React.FC = () => {
  const sec = useSec();
  return (
    <AbsoluteFill>
      <Background kind="cabin" />
      <Pop at={0.1} x={540} y={300} rot={2}><Tag bg={C.yellow} color={C.ink} size={62}>LO: ANTRI CHAMPAGNE</Tag></Pop>
      <Pop at={0.2} x={140} y={1230}><J.Champagne s={300} /></Pop>
      <Character x={400} h={700} at={0.3} shades={0.35} />
      {[640, 790, 940].map((x, i) => (
        <Pop key={i} at={0.8 + i * 0.35} x={x} y={1230}>
          <J.Person s={340} body="#212529" item="flute" hair="#111" tie={C.yellow} />
        </Pop>
      ))}
      {sec > 1.0 && Array.from({length: 10}).map((_, i) => {
        const t = (sec - 1.0 + i * 0.2) % 2;
        return <div key={i} style={{position: 'absolute', left: 120 + (random(`bb${i}`) - 0.5) * 120, top: 1050 - t * 300, width: 16, height: 16, borderRadius: '50%', border: `3px solid #fff`, opacity: 1 - t / 2}} />;
      })}
      <Pop at={1.0} x={200} y={900} until={1.8} rot={-8}><Big size={110} color={C.yellow}>POP!</Big></Pop>
      <Stamp at={2.3} x={540} y={760} text="TAMAT" color={C.darkGreen} size={110} rot={-6} />
      <Sfx at={0.1} f="pop" /><Sfx at={0.35} f="pop" vol={0.5} /><Sfx at={0.8} f="pop" vol={0.5} /><Sfx at={1.15} f="pop" vol={0.5} /><Sfx at={1.5} f="pop" vol={0.5} />
      <Sfx at={1.0} f="cork" vol={0.9} /><Sfx at={1.1} f="sparkle" vol={0.5} /><Sfx at={2.3} f="thud" /><Sfx at={2.35} f="tada" vol={0.5} />
    </AbsoluteFill>
  );
};

export const SCENES: {s: number; C: React.FC; wipe?: string}[] = [
  {s: 0, C: S1},
  {s: 6.024, C: S2, wipe: '#ffd23f'},
  {s: 13.053, C: S3, wipe: '#ef476f'},
  {s: 17.873, C: S4, wipe: '#118ab2'},
  {s: 22.961, C: S5, wipe: '#ef476f'},
  {s: 27.111, C: S6, wipe: '#ffd23f'},
  {s: 32.065, C: S7, wipe: '#c1121f'},
  {s: 38.491, C: S8, wipe: '#2b2d6e'},
  {s: 41.905, C: S9, wipe: '#ef476f'},
  {s: 48.934, C: S10, wipe: '#06d6a0'},
  {s: 53.553, C: S11, wipe: '#ffd23f'},
  {s: 56.298, C: S12, wipe: '#0b1026'},
  {s: 62.791, C: S13, wipe: '#efe3d0'},
  {s: 70.623, C: S14a, wipe: '#2b2d6e'},
  {s: 73.0, C: S14b, wipe: '#ffd23f'},
];
