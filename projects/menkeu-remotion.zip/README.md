# POV Menkeu Bangkrut + Private Jet (Remotion, 9:16)

1080x1920, 30fps, 76.2 detik. Narasi = menterikeuangan.mp3, caption dari SRT
(koreksi "filling" -> "feeling" di caption).

    npm install
    npm run studio     # preview
    npm run render     # hasil: out/komedi.mp4

Karakter "lo" memakai public/grad.png (jubah wisuda). Tokoh lain (staf, investor,
antrean) adalah orang generik berbentuk SVG di src/icons2.tsx.
SFX + backsound ada di public/ (sintesis, bebas hak cipta); buat ulang: `npm run audio`.
Timing objek di src/scenes.tsx (`at={detik}` relatif awal scene).
