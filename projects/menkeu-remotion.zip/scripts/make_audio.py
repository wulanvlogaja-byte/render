"""Generate all SFX + BGM (synthesized, royalty-free). Needs numpy + ffmpeg.
Run from project root:  python3 scripts/make_audio.py
"""
import os, subprocess, wave
import numpy as np

SR = 44100
OUT = os.path.join(os.path.dirname(__file__), "..", "public")
os.makedirs(os.path.join(OUT, "sfx"), exist_ok=True)
rng = np.random.default_rng(11)


def t_(d):
    return np.arange(int(SR * d)) / SR


def env(n, a=0.005, r=0.1):
    e = np.ones(n)
    na, nr = int(a * SR), int(r * SR)
    if na: e[:na] = np.linspace(0, 1, na)
    if nr: e[-nr:] *= np.linspace(1, 0, nr)
    return e


def expd(t, k):
    return np.exp(-t * k)


def lp(x, alpha):
    y = np.zeros_like(x)
    a = np.broadcast_to(alpha, x.shape)
    s = 0.0
    for i in range(len(x)):
        s += a[i] * (x[i] - s)
        y[i] = s
    return y


def save(name, x, path="sfx", vol=0.9):
    x = x / (np.max(np.abs(x)) + 1e-9) * vol
    wav = os.path.join(OUT, path, name + ".wav")
    with wave.open(wav, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())
    mp3 = wav[:-4] + ".mp3"
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-b:a", "128k", mp3], check=True)
    os.remove(wav)


def sine(f, t): return np.sin(2 * np.pi * f * t)
def saw(f, t): return 2 * ((f * t) % 1) - 1
def tri(f, t): return 2 * np.abs(saw(f, t)) - 1
def sq(f, t): return np.sign(sine(f, t))


# ---- SFX ----
t = t_(0.18); f = 900 * expd(t, 9) + 250
save("pop", np.sin(2 * np.pi * np.cumsum(f) / SR) * expd(t, 22) * env(len(t), 0.001, 0.02))

t = t_(0.7); n = rng.standard_normal(len(t))
alpha = 0.02 + 0.5 * np.sin(np.pi * t / 0.7) ** 2
save("whoosh", lp(n, alpha) * np.sin(np.pi * t / 0.7) ** 1.5)

t = t_(1.2)
save("ding", (sine(1318.5, t) + 0.4 * sine(2637, t) + 0.15 * sine(3951, t)) * expd(t, 3.5) * env(len(t), 0.002, 0.05))

t = t_(0.4)
thud = sine(110 * expd(t, 6) + 38, t) * 0 + np.sin(2 * np.pi * np.cumsum(110 * expd(t, 9) + 40) / SR)
thud = thud * expd(t, 10) + rng.standard_normal(len(t)) * expd(t, 90) * 0.5
save("thud", thud)

t = t_(0.7)
f = 260 + 180 * np.sin(2 * np.pi * 9 * t) * expd(t, 3) - 120 * t
save("boing", np.sin(2 * np.pi * np.cumsum(f) / SR) * expd(t, 4) * env(len(t), 0.003, 0.05))

# sad trombone
notes = [(233.1, 0.55), (220.0, 0.55), (207.7, 0.55), (196.0, 1.5)]
parts = []
for i, (fr, d) in enumerate(notes):
    t = t_(d)
    vib = 1 + (0.025 * np.sin(2 * np.pi * 6 * t) if i == 3 else 0 * t)
    fr_t = fr * vib * ((1 - 0.06 * (t / d) ** 2) if i == 3 else np.ones(len(t)))
    ph = np.cumsum(fr_t) / SR
    w = 2 * (ph % 1) - 1
    w = lp(w, 0.12 + 0.1 * np.sin(np.pi * t / d))
    parts.append(w * env(len(t), 0.03, 0.12))
save("sadtrombone", np.concatenate(parts))

t = t_(0.5); n = rng.standard_normal(len(t))
f = 1800 * expd(t, 5) + 150
sc = np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.6 + lp(n, 0.4) * 0.5
save("scratch", sc * env(len(t), 0.002, 0.1))

# tada
parts = []
t = t_(1.4); out = np.zeros(len(t))
for st, fr in [(0, 523.3), (0.12, 659.3), (0.24, 784.0), (0.4, 1046.5)]:
    i0 = int(st * SR); tt = t[: len(t) - i0]
    out[i0:] += (tri(fr, tt) * 0.6 + saw(fr, tt) * 0.2) * expd(tt, 1.6 if st < 0.4 else 2.5)
for fr in (523.3, 659.3, 784.0):
    i0 = int(0.4 * SR); tt = t[: len(t) - i0]
    out[i0:] += tri(fr, tt) * 0.4 * expd(tt, 2.5)
save("tada", out * env(len(t), 0.002, 0.15))

t = t_(0.35)
save("notify", (sine(880, t) * (t < 0.12) + sine(1320, t) * (t >= 0.12) * expd(t - 0.12, 8)) * env(len(t), 0.002, 0.05))

t = t_(1.6); x = np.zeros(len(t))
for k in range(18):
    i0 = int(k * 0.085 * SR); tt = t_(0.02)
    x[i0:i0 + len(tt)] += sine(1500 + k * 80, tt) * expd(tt, 120)
save("ticks", x)

t = t_(0.12)
save("click", (sine(1800, t) * expd(t, 60) + rng.standard_normal(len(t)) * expd(t, 100) * 0.4))

t = t_(2.2); x = np.zeros(len(t))
for burst in (0.0, 0.6, 1.2):
    for k in range(4):
        i0 = int((burst + k * 0.1) * SR); tt = t_(0.07)
        x[i0:i0 + len(tt)] += sine(4600, tt) * np.sin(np.pi * tt / 0.07) * 0.8
save("crickets", x * 0.8)

t = t_(0.5)
save("buzzer", (sq(140, t) * 0.7 + sq(147, t) * 0.5) * env(len(t), 0.005, 0.08))

t = t_(0.6)
save("sparkle", sum(sine(2000 + 500 * i, t - 0.06 * i) * expd(np.clip(t - 0.06 * i, 0, None), 8) * (t > 0.06 * i) for i in range(5)))


# ---- SFX tambahan (tema keuangan / jet) ----
t = t_(0.7)
x = (sine(2093, t) + 0.5 * sine(3136, t)) * expd(t, 7) * env(len(t), 0.001, 0.02)
x2 = np.zeros(len(t)); i0 = int(0.12 * SR); tt = t[: len(t) - i0]
x2[i0:] = (sine(2637, tt) + 0.5 * sine(3951, tt)) * expd(tt, 6)
save("chaching", x + x2 + rng.standard_normal(len(t)) * expd(t, 120) * 0.2)

t = t_(1.8); n = rng.standard_normal(len(t))
gate = (np.sin(2 * np.pi * 13 * t) > -0.2).astype(float)
save("printer", lp(n, 0.25) * gate * 0.6 + sq(70, t) * 0.25 * gate)

t = t_(0.9)
save("rise", np.sin(2 * np.pi * np.cumsum(250 + 1400 * (t / 0.9) ** 2) / SR) * env(len(t), 0.01, 0.1))
save("fall", np.sin(2 * np.pi * np.cumsum(1500 - 1300 * (t / 0.9)) / SR) * env(len(t), 0.01, 0.1))

t = t_(2.6); n = rng.standard_normal(len(t))
sw = np.sin(np.pi * t / 2.6) ** 1.2
save("jet", lp(n, 0.02 + 0.25 * sw) * sw + 0.3 * lp(n, 0.01) * sw)

t = t_(0.9)
save("seatbelt", (sine(1046, t) * (t < 0.3) + sine(784, t) * (t >= 0.45) * (t < 0.8)) * env(len(t), 0.003, 0.05) * 0.9)

t = t_(1.0); n = rng.standard_normal(len(t))
cork = np.sin(2 * np.pi * np.cumsum(500 * expd(t, 30) + 120) / SR) * expd(t, 25)
save("cork", cork + lp(n, 0.6) * expd(t, 4) * 0.35 * (t > 0.05))

t = t_(1.4)
f = 750 + 170 * np.sign(np.sin(2 * np.pi * 1.4 * t)) * 0 + 170 * np.sin(2 * np.pi * 1.5 * t)
save("siren", np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.02, 0.15))

t = t_(0.35)
save("coin", (sine(1760, t) * (t < 0.08) + sine(2349, t) * (t >= 0.08) * expd(t - 0.08, 9)) * env(len(t), 0.001, 0.03))

# ---- BGM: playful loop, 8 bars @ 120 bpm, seamless ----
BPM = 112; beat = 60 / BPM; bar = 4 * beat; BARS = 8
total = int(SR * bar * BARS)
mix = np.zeros(total)


def add(x, start):
    i0 = int(start * SR)
    n = min(len(x), total - i0)
    if n > 0: mix[i0:i0 + n] += x[:n]


def pluck(fr, d=0.35, a=0.5):
    t = t_(d)
    return (sine(fr, t) + 0.35 * sine(fr * 2, t) + 0.12 * sine(fr * 3, t)) * expd(t, 9) * a * env(len(t), 0.002, 0.02)


def bassn(fr, d):
    t = t_(d)
    return tri(fr, t) * expd(t, 3.5) * 0.7 * env(len(t), 0.004, 0.03)


def hat(a=0.12):
    t = t_(0.05)
    return rng.standard_normal(len(t)) * expd(t, 70) * a


def kick():
    t = t_(0.2)
    return np.sin(2 * np.pi * np.cumsum(120 * expd(t, 25) + 45) / SR) * expd(t, 14) * 0.9


chords = [  # Am F C G (sedikit licik/komedik)
    (110.0, 130.8, 164.8), (87.3, 110.0, 130.8), (130.8, 164.8, 196.0), (98.0, 123.5, 146.8)]
pent = {0: [440.0, 523.3, 587.3, 659.3, 784.0], 1: [440.0, 523.3, 698.5, 880.0, 784.0],
        2: [523.3, 587.3, 659.3, 784.0, 880.0], 3: [392.0, 493.9, 587.3, 659.3, 784.0]}
for b in range(BARS):
    c = chords[b // 2]; st = b * bar
    for k in range(8):  # walking bass on 8ths-ish
        pat = [c[0], c[0] * 2, c[2], c[0] * 2][k % 4] if k % 2 == 0 else None
        if pat: add(bassn(pat, beat * 0.9), st + k * beat / 2 * 1)
    for k in range(4):
        add(kick(), st + k * beat)
        add(hat(0.14), st + k * beat + beat / 2)
        # off-beat chord stab
        for fr in (c[1] * 2, c[2] * 2, c[0] * 4):
            add(pluck(fr, 0.2, 0.12), st + k * beat + beat / 2)
    for k in range(8):  # melody on 8ths with rests
        if rng.random() < 0.62:
            add(pluck(rng.choice(pent[b // 2]), 0.3, 0.32), st + k * beat / 2)
mix = mix / np.max(np.abs(mix)) * 0.85
wav = os.path.join(OUT, "bgm.wav")
with wave.open(wav, "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((mix * 32767).astype(np.int16).tobytes())
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wav, "-b:a", "128k", os.path.join(OUT, "bgm.mp3")], check=True)
os.remove(wav)
print("done")
