import React from 'react';
import { theme } from './theme';
import { clamp, easeOut, back, enter, hash, wrap, cue } from './util';
import { Bg, T, Chip, Cloud, Ribbon, Star4, Stars, Char, Arrow, XMark, Floor, Hills, Sticker, Console } from './paper';

const c = theme.c;
type P = { t: number };
const pulse = (t: number, t0: number) => Math.max(0, 1 - Math.abs((t - t0 - 0.12) / 0.22));

export function Sweat({ x, y, t, n = 4, spread = 90 }: any) {
  return (
    <g>
      {Array.from({ length: n }, (_, i) => {
        const q = (t * 0.9 + i * 0.27) % 1;
        return <path key={i} d="M0,-6 Q5,2 0,6 Q-5,2 0,-6Z" fill={c.blue} opacity={1 - q}
          transform={`translate(${x + (hash(i + 3) - 0.5) * spread},${y + q * 44}) scale(1.3)`} />;
      })}
    </g>
  );
}

// ---------- S0: kalimat 0 ----------
const K0 = { kap: cue(0, 'kapolri'), akses: cue(0, 'akses'), canggih: cue(0, 'canggih') };
export const S0 = ({ t }: P) => (
  <g>
    <Bg fill={c.sky} />
    <Hills t={t} a={c.blueT2} b={c.tealT1} y={330} />
    <Floor t={t} a={c.yellowT1} b={c.yellowT2} f={c.blueT2} />
    <g filter="url(#ps)">
      <g transform="translate(275,336)">
        <circle r={46} fill={c.tealT1} />
        <circle r={32} fill="none" stroke={c.tealT2} strokeWidth={3} /><circle r={17} fill="none" stroke={c.tealT2} strokeWidth={3} />
        <path d="M0,0 L46,0 A46,46 0 0 0 40,-23Z" fill={c.teal} opacity={0.4} transform={`rotate(${t * 140})`} />
        <circle cx={14} cy={-20} r={4} fill={c.orange} opacity={0.5 + 0.5 * Math.sin(t * 5)} />
        <circle cx={-22} cy={12} r={4} fill={c.orange} opacity={0.5 + 0.5 * Math.sin(t * 5 + 2)} />
      </g>
    </g>
    <Sticker img="polisi" x={120} y={434 + Math.sin(t * 2) * 1.5} h={290} p={enter(t, 0.2, 0.6)} />
    <Sticker img="polri" x={284} y={178} h={90} rot={Math.sin(t * 1.6) * 4} anchor="center" p={enter(t, K0.kap, 0.5)} />
    <Chip x={180} y={98} text="POV: Jadi Kapolri" size={22} w={300} h={50} p={enter(t, 0.15, 0.6)} />
    <Chip x={275} y={262} text="Akses sadap" size={16} fill={c.yellow} rot={-4} p={enter(t, K0.akses, 0.4)} />
    <Chip x={258} y={405} text="Paling canggih!" size={15} fill={c.white} rot={3} p={enter(t, K0.canggih, 0.4)} />
  </g>
);

// ---------- S1: kalimat 1 ----------
const K1 = { iseng: cue(1, 'iseng'), pencet: cue(1, 'pencet'), tombol: cue(1, 'tombol'), pres: cue(1, 'presiden') };
export const S1 = ({ t }: P) => {
  const pr = pulse(t, K1.pencet);
  const on = t > K1.pencet;
  return (
    <g>
      <Bg fill={c.cream} />
      <Hills t={t} a={c.yellowT2} b={c.orangeT1} y={330} />
      <Floor t={t} a={c.orangeT1} b={c.yellowT2} f={c.blueT2} />
      {on && [0, 1, 2].map((i) => {
        const r = ((t - K1.pencet) * 70 + i * 30) % 90 + 24;
        return <circle key={i} cx={262} cy={348} r={r} fill="none" stroke={c.orange} strokeWidth={3} opacity={clamp(1 - (r - 24) / 90) * 0.8} />;
      })}
      <Sticker img="polisi" x={95} y={434} h={250} />
      <Console x={262} y={350} t={t} press={pr} lamp={on} />
      <Arrow x={262} y={238 + Math.sin(t * 6) * 5} s={1.2} o={enter(t, K1.tombol, 0.4) * (1 - 0.7 * (on ? 1 : 0))} />
      <Chip x={180} y={105} text="Iseng pencet..." size={22} fill={c.white} p={enter(t, K1.iseng, 0.5)} />
      <Chip x={262} y={196} text="Presiden" size={19} fill={c.yellow} rot={4} p={enter(t, K1.pres, 0.4)} />
    </g>
  );
};

// ---------- S2: kalimat 2 ----------
const K2 = { kira: cue(2, 'kira'), rahasia: cue(2, 'rahasia'), negara: cue(2, 'negara') };
export const S2 = ({ t }: P) => {
  const cp = back((t - K2.kira) / 0.5), fp = enter(t, K2.rahasia, 0.5);
  return (
    <g>
      <Bg fill={c.sky} />
      <Hills t={t} a={c.blueT2} b={c.tealT1} y={330} />
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <Sticker img="polisi" x={95} y={434} h={250} />
      {cp > 0.01 && (
        <g opacity={clamp(cp * 2)}>
          <circle cx={170} cy={262} r={4} fill={c.white} /><circle cx={186} cy={246} r={6} fill={c.white} />
          <g transform={`translate(246,176) scale(${clamp(cp, 0, 1.1) * 1.7}) translate(-246,-176)`}><Cloud x={246} y={176} s={1} /></g>
          <T x={242} y={181} size={34} fill={c.inkSoft}>{fp < 0.5 ? '?' : ''}</T>
          <T x={242} y={182} size={15}>{fp > 0.3 ? 'Rahasia negara' : ''}</T>
        </g>
      )}
      {fp > 0.01 && (
        <g filter="url(#ps)" opacity={clamp(fp * 2)}>
          <g transform={`translate(252,330) scale(${0.6 + 0.4 * fp})`}>
            <polygon points="-58,-38 -22,-38 -14,-50 -58,-50" fill={c.yellow} />
            <rect x={-58} y={-38} width={116} height={78} rx={8} fill={c.yellowT2} />
            <rect x={-12} y={-10} width={24} height={20} rx={4} fill={c.orange} />
            <path d="M-7,-10 V-17 A7,7 0 0 1 7,-17 V-10" fill="none" stroke={c.orange} strokeWidth={4} />
          </g>
        </g>
      )}
      <Chip x={252} y={332} text="TOP SECRET" size={17} fill={c.orangeT2} rot={-8} p={enter(t, K2.rahasia + 0.25, 0.35)} />
    </g>
  );
};

// ---------- S3: kalimat 3 ----------
const K3 = { pres: cue(3, 'presiden'), bingung: cue(3, 'bingung'), remote: cue(3, 'remote'), bilang: cue(3, 'bilang') };
export const S3 = ({ t }: P) => {
  const sway = Math.sin(t * 2) * 3;
  return (
    <g>
      <Bg fill={c.cream} />
      <Hills t={t} a={c.yellowT2} b={c.orangeT1} y={330} />
      <Floor t={t} a={c.orangeT1} b={c.yellowT2} f={c.blueT2} />
      <g filter="url(#ps)">
        <g transform="translate(250,142)">
          <rect x={-74} y={-24} width={148} height={48} rx={12} fill={c.white} />
          {[0, 1, 2].map((i) => <rect key={i} x={-30} y={-6 + i * 7} width={96} height={3} rx={1.5} fill={c.gray2} />)}
          <rect x={-64} y={-14} width={30} height={16} rx={4} fill={c.yellow} />
          <T x={-49} y={-6} size={11}>32°</T>
        </g>
      </g>
      {[0, 1, 2].map((i) => (
        <path key={i} d="M0,0 q5,-7 0,-14 t0,-14" fill="none" stroke={c.orange} strokeWidth={3} strokeLinecap="round"
          opacity={0.8} transform={`translate(${222 + i * 28 + Math.sin(t * 5 + i) * 3},${200 - ((t * 18 + i * 6) % 14)})`} />
      ))}
      <g filter="url(#ps)" opacity={enter(t, K3.remote, 0.4)}>
        <g transform={`translate(292,384) rotate(${Math.sin(t * 3) * 10})`}>
          <rect x={-10} y={-26} width={20} height={52} rx={6} fill={c.gray2} />
          <circle cx={0} cy={-14} r={4} fill={c.orange} /><circle cx={-4} cy={0} r={3} fill={c.teal} /><circle cx={4} cy={0} r={3} fill={c.yellow} />
        </g>
      </g>
      <Char x={100} y={434} t={t} sx={1.8} sy={1.8} shirt={c.blue} pants={c.blueT3} skin={c.skin2} mood="sad" armL={20} armR={165 + Math.sin(t * 4) * 8} rot={sway} seed={3} o={enter(t, K3.pres - 0.3, 0.3)} />
      <Chip x={100} y={292} text="Presiden" size={14} fill={c.white} p={enter(t, K3.pres, 0.4)} />
      <Chip x={104} y={252} text="Remote AC mana?" size={15} fill={c.yellow} rot={-3} p={enter(t, K3.remote, 0.4)} />
      <Chip x={180} y={218} text="Kok AC istana enggak dingin ya?" size={14} fill={c.white} p={enter(t, K3.bilang, 0.4)} />
    </g>
  );
};

// ---------- S4: kalimat 4 ----------
const K4 = { panik: cue(4, 'panik'), matiin: cue(4, 'matiin'), kepencet: cue(4, 'kepencet') };
export const S4 = ({ t }: P) => {
  const pr = Math.max(pulse(t, K4.matiin), pulse(t, K4.kepencet));
  const lamp = t < K4.matiin || t >= K4.kepencet;
  const jit = t > K4.panik ? Math.sin(t * 38) * 2.5 : 0;
  return (
    <g>
      <Bg fill={c.sky} />
      <Hills t={t} a={c.blueT2} b={c.tealT1} y={330} />
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <g transform={`translate(${jit},0)`}><Sticker img="polisi" x={95} y={434} h={250} pop={false} /></g>
      {t > K4.panik && <Sweat x={95} y={190} t={t} n={5} spread={120} />}
      <Console x={255} y={350} t={t} press={pr} lamp={lamp} />
      <Chip x={104} y={128} text="PANIK!" size={28} fill={c.orangeT2} rot={-6} p={enter(t, K4.panik, 0.3)} />
      <Chip x={255} y={240} text="Matiin" size={20} fill={c.white} p={enter(t, K4.matiin, 0.3)} />
      <Chip x={255} y={198} text="Eh, kepencet!" size={20} fill={c.yellow} rot={4} p={enter(t, K4.kepencet, 0.3)} />
    </g>
  );
};

// ---------- S5: kalimat 5 ----------
const K5 = { gor: cue(5, 'gorengan'), pedas: cue(5, 'pedas'), kacang: cue(5, 'kacang') };
export const S5 = ({ t }: P) => (
  <g>
    <Bg fill={c.cream} />
    <Hills t={t} a={c.yellowT2} b={c.orangeT1} y={330} />
    <Floor t={t} a={c.orangeT1} b={c.yellowT2} f={c.blueT2} />
    <Char x={85} y={434} t={t} sx={1.9} sy={1.9} shirt={c.blue} pants={c.blueT3} skin={c.skin2} armL={15} armR={150 + Math.sin(t * 6) * 10} seed={5} />
    <g filter="url(#ps)" opacity={enter(t, K5.gor - 0.2, 0.4)}>
      <g transform="translate(248,408)">
        <ellipse cx={0} cy={4} rx={72} ry={17} fill={c.white} />
        {[[-40, -4], [-12, -10], [18, -4], [44, -12], [-24, -22], [8, -24]].map(([x, y], i) => (
          <g key={i}><ellipse cx={x} cy={y} rx={21} ry={13} fill={i % 2 ? c.yellow : c.yellowT2} />
            <circle cx={x - 5} cy={y - 2} r={2.4} fill={c.orange} /><circle cx={x + 6} cy={y + 3} r={2.4} fill={c.orange} /></g>
        ))}
      </g>
    </g>
    <g filter="url(#ps)" opacity={enter(t, K5.kacang, 0.4)}>
      <g transform="translate(312,402)">
        <path d="M-24,0 A24,24 0 0 0 24,0Z" fill={c.orangeT2} />
        <ellipse cx={0} cy={0} rx={24} ry={6} fill={c.orange} />
        {[-12, -2, 9].map((x, i) => <circle key={i} cx={x} cy={-1} r={2.6} fill={c.yellowT2} />)}
      </g>
    </g>
    {[0, 1].map((i) => <path key={i} d="M0,0 q5,-7 0,-14 t0,-14" fill="none" stroke={c.gray2} strokeWidth={3} strokeLinecap="round" opacity={0.8} transform={`translate(${228 + i * 34 + Math.sin(t * 4 + i) * 3},${362 - ((t * 14 + i * 5) % 12)})`} />)}
    <Chip x={90} y={278} text="Yang pedas ya" size={16} fill={c.orangeT2} rot={-4} p={enter(t, K5.pedas, 0.4)} />
    <Chip x={250} y={330} text="Gorengan!" size={20} fill={c.yellow} rot={3} p={enter(t, K5.gor, 0.4)} />
    <Chip x={246} y={290} text="+ Sambal kacang" size={15} fill={c.white} rot={-3} p={enter(t, K5.kacang, 0.4)} />
  </g>
);

// ---------- S6: kalimat 6 ----------
const K6 = { ker: cue(6, 'keringat'), tahu: cue(6, 'ketahuan'), mut: cue(6, 'dimutasi'), park: cue(6, 'parkir'), pols: cue(6, 'polsek') };
export const S6 = ({ t }: P) => {
  const sp = back((t - K6.park) / 0.6);
  return (
    <g>
      <Bg fill={c.sky} />
      <Hills t={t} a={c.blueT2} b={c.tealT1} y={330} />
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <Sticker img="polisi" x={110} y={434} h={270} />
      {t > K6.ker && <Sweat x={110} y={185} t={t} n={6} spread={130} />}
      {sp > 0.01 && (
        <g transform={`translate(0,${(1 - clamp(sp, 0, 1)) * 140})`}>
          <rect x={282} y={250} width={6} height={180} fill={c.gray2} />
          <g filter="url(#ps)">
            <rect x={248} y={178} width={74} height={74} rx={12} fill={c.blueT2} />
            <rect x={248} y={178} width={74} height={74} rx={12} fill="none" stroke={c.blue} strokeWidth={5} />
            <T x={285} y={216} size={52}>P</T>
          </g>
        </g>
      )}
      <Chip x={110} y={105} text="Ketahuan?!" size={22} fill={c.white} p={enter(t, K6.tahu, 0.4)} />
      <Chip x={262} y={140} text="Dimutasi!" size={20} fill={c.orangeT2} rot={6} p={enter(t, K6.mut, 0.4)} />
      <Chip x={285} y={290} text="Polsek" size={16} fill={c.yellow} p={enter(t, K6.pols, 0.4)} />
    </g>
  );
};
