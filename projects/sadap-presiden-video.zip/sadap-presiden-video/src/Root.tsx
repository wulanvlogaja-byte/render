import React, { useEffect, useState } from 'react';
import { AbsoluteFill, Audio, Composition, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import { theme } from './theme';
import timing from './timing.json';
import { Video } from './Video';

loadFont('normal', { weights: ['700'] });

const ASSETS: Record<string, string> = {
  polisi: staticFile('img/polisi.png'),
  bakso: staticFile('img/bakso.png'),
  zoom: staticFile('img/zoom.png'),
  polri: staticFile('img/polri.png'),
};

const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const [handle] = useState(() => delayRender('memuat gambar aset'));
  useEffect(() => {
    // pastikan semua PNG sudah terunduh dan ter-decode sebelum frame dirender
    Promise.all(
      Object.values(ASSETS).map(
        (src) =>
          new Promise<void>((resolve) => {
            const im = new Image();
            im.onload = () => (im.decode ? im.decode().then(() => resolve(), () => resolve()) : resolve());
            im.onerror = () => resolve();
            im.src = src;
          })
      )
    ).then(() => continueRender(handle));
  }, [handle]);
  return (
    <AbsoluteFill>
      <Audio src={staticFile('narasi.mp3')} />
      <Video t={frame / fps} assets={ASSETS} />
    </AbsoluteFill>
  );
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="SadapPresiden"
    component={Main}
    durationInFrames={Math.ceil((timing.duration + theme.tail) * timing.fps)}
    fps={timing.fps}
    width={timing.width}
    height={timing.height}
  />
);
