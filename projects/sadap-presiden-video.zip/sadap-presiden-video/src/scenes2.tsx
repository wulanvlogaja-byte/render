import React from 'react';
import { theme } from './theme';
import { clamp, easeOut, back, enter, hash, wrap, lerp, cue } from './util';
import { Bg, T, Chip, Cloud, Ribbon, Star4, Char, Heart, XMark, Check, Floor, Hills, Sticker, Wifi, Istana } from './paper';

const c = theme.c;
type P = { t: number };

// ---------- S7a: kalimat 7 (pilihan) ----------
const K7 = { bentar: cue(7, 'bentar'), lanjut: cue(7, 'lanjut'), cabut: cue(7, 'cabut') };
export const S7a = ({ t }: P) => {
  const pl = back((t - (K7.lanjut - 0.3)) / 0.5), pk = back((t - (K7.cabut - 0.3)) / 0.5);
  const pulse = 1 + 0.025 * Math.sin(t * 5);
  return (
    <g>
      <Bg fill={c.cream} />
      <Hills t={t} a={c.yellowT2} b={c.orangeT1} y={340} />
      <Floor t={t} a={c.orangeT1} b={c.yellowT2} f={c.blueT2} />
      <Chip x={180} y={100} text="Lo pilih yang mana?" size={21} fill={c.white} p={enter(t, K7.bentar, 0.5)} />
      <g filter="url(#ps)" opacity={clamp(pl * 3)}>
        <g transform={`translate(100,212) scale(${clamp(pl, 0, 1.15) * pulse})`}>
          <rect x={-64} y={-76} width={128} height={152} rx={18} fill={c.white} />
          <g transform="translate(0,-14)" fill="none" stroke={c.blue} strokeWidth={7} strokeLinecap="round">
            <path d="M-26,8 A26,26 0 0 1 26,8" />
            <rect x={-35} y={4} width={14} height={26} rx={6} fill={c.teal} stroke="none" /><rect x={21} y={4} width={14} height={26} rx={6} fill={c.teal} stroke="none" />
          </g>
          <T x={0} y={36} size={18}>Lanjut</T><T x={0} y={56} size={18}>dengerin</T>
        </g>
      </g>
      <g filter="url(#ps)" opacity={clamp(pk * 3)}>
        <g transform={`translate(260,212) scale(${clamp(pk, 0, 1.15) * pulse})`}>
          <rect x={-64} y={-76} width={128} height={152} rx={18} fill={c.white} />
          <g transform="translate(0,-4)">
            <rect x={-16} y={-34} width={32} height={34} rx={8} fill={c.orange} />
            <rect x={-10} y={-50} width={6} height={18} rx={2} fill={c.gray2} /><rect x={4} y={-50} width={6} height={18} rx={2} fill={c.gray2} />
            <path d="M0,0 q-14,10 0,20 t0,20" fill="none" stroke={c.gray2} strokeWidth={5} strokeLinecap="round" />
          </g>
          <T x={0} y={36} size={18}>Cabut</T><T x={0} y={56} size={18}>kabelnya</T>
        </g>
      </g>
      <Sticker img="polisi" x={180} y={440} h={150} p={enter(t, K7.bentar, 0.4)} />
    </g>
  );
};

// ---------- S7b: kalimat 7 (like & subscribe) ----------
const K7b = { like: cue(7, 'like'), sub: cue(7, 'subscribe'), intel: cue(7, 'intel') };
export const S7b = ({ t }: P) => {
  const hp = enter(t, K7b.like, 0.5), sp = enter(t, K7b.sub, 0.5);
  return (
    <g>
      <Bg fill={c.sky} />
      <Hills t={t} a={c.blueT2} b={c.tealT1} y={340} />
      <Floor t={t} a={c.tealT1} b={c.blueT1} f={c.yellowT2} />
      <Chip x={180} y={105} text="Like & Subscribe" size={22} fill={c.white} p={hp} />
      {hp > 0.01 && <g transform={`translate(100,205) scale(${1.7 * hp * (1 + 0.08 * Math.sin(t * 6))}) translate(-100,-205)`}><Heart x={100} y={205} s={1} /></g>}
      <Chip x={100} y={270} text="Like" size={20} fill={c.yellow} p={hp} />
      {sp > 0.01 && (
        <g filter="url(#ps)" opacity={clamp(sp * 2)}>
          <g transform={`translate(250,208) scale(${0.6 + 0.4 * sp})`}>
            <rect x={-66} y={-23} width={132} height={46} rx={14} fill={c.yellow} />
            <T x={0} y={0} size={19}>Subscribe</T>
          </g>
        </g>
      )}
      {sp > 0.01 && (
        <g transform={`translate(250,150) rotate(${Math.sin(t * 10) * 14 * Math.max(0, 1 - (t - K7b.sub) / 2)})`}>
          <g filter="url(#ps)">
            <path d="M0,-20 C-14,-20 -16,-4 -16,6 L-20,14 L20,14 L16,6 C16,-4 14,-20 0,-20Z" fill={c.orange} />
            <circle cx={0} cy={18} r={4.5} fill={c.orange} />
          </g>
        </g>
      )}
      <Char x={300} y={434 + Math.sin(t * 3) * 1.5} t={t} sx={1.3} sy={1.3} shades shirt={c.blueT3} pants={c.gray2} armL={20} armR={20} seed={7} o={enter(t, K7b.intel - 0.3, 0.4)} />
      <Chip x={150} y={338} text="Biar enggak ketahuan intel" size={15} fill={c.tealT2} rot={-2} p={enter(t, K7b.intel, 0.5)} />
    </g>
  );
};

// ---------- S8: kalimat 8 (salah cabut) ----------
const K8 = { lanjut: cue(8, 'lanjut'), cabut: cue(8, 'cabut'), salah: cue(8, 'salah') };
export const S8 = ({ t }: P) => {
  const pull = enter(t, K8.cabut, 0.5);
  const wob = Math.sin(t * 3) * 3;
  const cables = [
    { y: 316, col: c.teal }, { y: 346, col: c.yellow }, { y: 376, col: c.orange },
  ];
  return (
    <g>
      <Bg fill={c.cream} />
      <Hills t={t} a={c.yellowT2} b={c.orangeT1} y={330} />
      <Floor t={t} a={c.orangeT1} b={c.yellowT2} f={c.blueT2} />
      <g filter="url(#ps)"><rect x={268} y={288} width={84} height={120} rx={14} fill={c.white} />
        {cables.map((cb, i) => <circle key={i} cx={282} cy={cb.y} r={7} fill={c.gray2} />)}</g>
      {cables.map((cb, i) => {
        const x0 = i === 2 ? 282 - pull * 72 : 282;
        const y1 = cb.y + 8 + wob * (i === 2 ? pull : 0.3);
        return (
          <g key={i}>
            <path d={`M${x0},${cb.y} C${x0 - 40},${cb.y + 36} ${x0 - 70},${y1 - 28} 150,${y1}`} fill="none" stroke={cb.col} strokeWidth={7} strokeLinecap="round" />
            <rect x={x0 - 9} y={cb.y - 6} width={14} height={12} rx={3} fill={c.ink} />
          </g>
        );
      })}
      <Sticker img="polisi" x={88 - pull * 6} y={434} h={250} pop={false} />
      <Chip x={95} y={118} text="Lanjut!" size={24} fill={c.yellow} rot={-5} p={enter(t, K8.lanjut, 0.4)} />
      <Chip x={228} y={255} text="Wi-Fi" size={17} fill={c.white} rot={-4} p={enter(t, K8.salah, 0.4)} />
      <Chip x={228} y={216} text="Salah cabut!" size={20} fill={c.orangeT2} rot={4} p={enter(t, K8.salah, 0.4)} />
    </g>
  );
};

// ---------- S9a: kalimat 9 awal (Wi-Fi istana offline) ----------
const K9 = { kecabut: cue(9, 'kecabut'), wifi: cue(9, 'wifi'), off: cue(9, 'offline'), semua: cue(9, 'semua'), menteri: cue(9, 'menteri'), enggak: cue(9, 'enggak'), zoom: cue(9, 'zoom') };
export const S9a = ({ t }: P) => {
  const wp = enter(t, K9.wifi, 0.5), off = t >= K9.off;
  return (
    <g>
      <Bg fill={c.sky} />
      <Hills t={t} a={c.blueT2} b={c.tealT1} y={340} />
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <Istana x={180} y={386} s={1.1} />
      {wp > 0.01 && <g transform={`translate(180,${196 + (1 - wp) * 20})`} opacity={clamp(wp * 2)}><Wifi x={0} y={0} s={1.5} fill={off ? c.gray2 : c.teal} /></g>}
      {off && <XMark x={180} y={206} r={20} p={enter(t, K9.off, 0.3)} />}
      <path d="M320,150 C335,210 300,250 322,300" fill="none" stroke={c.orange} strokeWidth={6} strokeLinecap="round" opacity={enter(t, K9.kecabut, 0.4)} transform={`rotate(${Math.sin(t * 3) * 3} 320 150)`} />
      <Star4 x={322} y={304} r={9 + 3 * Math.sin(t * 12)} fill={c.yellow} o={enter(t, K9.kecabut, 0.3)} />
      <Chip x={180} y={105} text="OFFLINE" size={30} w={200} h={54} fill={c.orangeT2} rot={-3} p={enter(t, K9.off, 0.4)} />
    </g>
  );
};

// ---------- S9b: kalimat 9 akhir (menteri enggak bisa zoom) ----------
export const S9b = ({ t }: P) => {
  const shirts = [c.blue, c.teal, c.orange, c.yellow, c.blueT3];
  const zp = enter(t, K9.zoom - 0.2, 0.5);
  return (
    <g>
      <Bg fill={c.cream} />
      <Hills t={t} a={c.yellowT2} b={c.orangeT1} y={340} />
      <Floor t={t} a={c.orangeT1} b={c.yellowT2} f={c.blueT2} />
      <Chip x={180} y={100} text="Semua menteri" size={22} fill={c.white} p={enter(t, K9.semua, 0.4)} />
      <Sticker img="zoom" x={180} y={228} h={140} anchor="center" p={zp} />
      {t > K9.zoom + 0.1 && <XMark x={236} y={172} r={26} p={enter(t, K9.zoom + 0.1, 0.3)} />}
      {[48, 114, 180, 246, 312].map((x, i) => (
        <Char key={i} x={x} y={434} t={t} sx={1.15} sy={1.15} mood="shock" shirt={shirts[i]} pants={c.blueT3} skin={i % 2 ? c.skin2 : c.skin}
          armL={150 + Math.sin(t * 7 + i) * 12} armR={150 + Math.cos(t * 7 + i) * 12} seed={i} o={enter(t, K9.menteri + i * 0.1, 0.3)} />
      ))}
      <Chip x={180} y={314} text="Enggak bisa zoom" size={18} fill={c.yellow} p={enter(t, K9.enggak, 0.4)} />
    </g>
  );
};

// ---------- S10: kalimat 10 (bawa tangga) ----------
const K10 = { dis: cue(10, 'disuruh'), ben: cue(10, 'benerin'), ist: cue(10, 'istana'), tgg: cue(10, 'tangga') };
export const S10 = ({ t }: P) => {
  const lp = enter(t, K10.tgg - 0.2, 0.6);
  return (
    <g>
      <Bg fill={c.sky} />
      <Hills t={t} a={c.blueT2} b={c.tealT1} y={340} />
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <Istana x={258} y={404} s={0.75} />
      <g filter="url(#ps)" opacity={enter(t, K10.ben, 0.4)}>
        <g transform="translate(258,298)">
          <rect x={-16} y={-8} width={32} height={14} rx={4} fill={c.teal} />
          <rect x={-12} y={-24} width={3} height={16} fill={c.teal} /><rect x={9} y={-24} width={3} height={16} fill={c.teal} />
          <circle cx={0} cy={-1} r={3} fill={c.orange} opacity={0.5 + 0.5 * Math.sin(t * 8)} />
        </g>
      </g>
      <Sticker img="polisi" x={86} y={434 - Math.abs(Math.sin(t * 5)) * 3} h={260} p={enter(t, K10.dis - 0.3, 0.4)} pop={false} />
      <g filter="url(#ps)" opacity={clamp(lp * 2)}>
        <g transform={`translate(${165 + (1 - lp) * -30},${434 - 250 + (1 - lp) * 60}) rotate(14)`}>
          <rect x={0} y={0} width={7} height={252} rx={3} fill={c.orange} /><rect x={38} y={0} width={7} height={252} rx={3} fill={c.orange} />
          {Array.from({ length: 9 }, (_, i) => <rect key={i} x={7} y={14 + i * 27} width={31} height={6} rx={3} fill={c.yellow} />)}
        </g>
      </g>
      <Chip x={180} y={105} text="Disuruh benerin" size={21} fill={c.white} p={enter(t, K10.dis, 0.4)} />
      <Chip x={92} y={148} text="Bawa tangga" size={17} fill={c.yellow} rot={-4} p={enter(t, K10.tgg, 0.4)} />
    </g>
  );
};

// ---------- S11: kalimat 11 (OB prank) ----------
const K11 = { bukan: cue(11, 'bukan'), ob: cue(11, 'ob'), niru: cue(11, 'niru'), prank: cue(11, 'prank') };
export const S11 = ({ t }: P) => {
  const colors = [c.yellow, c.orange, c.teal, c.blue];
  return (
    <g>
      <Bg fill={c.sky} />
      <Hills t={t} a={c.blueT2} b={c.tealT1} y={340} />
      <Floor t={t} a={c.blueT1} b={c.tealT1} f={c.yellowT2} />
      <Sticker img="polisi" x={70} y={434} h={205} pop={false} />
      <rect x={313} y={308} width={5} height={124} rx={2} fill={c.gray2} />
      <g filter="url(#ps)"><ellipse cx={316} cy={434} rx={19} ry={8} fill={c.yellow} /></g>
      {t > K11.niru - 0.2 && [0, 1, 2].map((i) => {
        const r = ((t - K11.niru) * 50 + i * 20) % 60 + 14;
        return <path key={i} d={`M${226 - r},${326 - r * 0.7} A${r},${r} 0 0 0 ${226 - r},${326 + r * 0.7}`} fill="none" stroke={c.orange} strokeWidth={3} strokeLinecap="round" opacity={clamp(1 - (r - 14) / 60) * 0.9} />;
      })}
      <Char x={252} y={434} t={t} sx={2.2} sy={2.2} shirt={c.teal} pants={c.blueT3} skin={c.skin2} armL={20} armR={t > K11.niru ? 125 + Math.sin(t * 9) * 8 : 20} seed={11} o={enter(t, K11.ob - 0.3, 0.3)} />
      <Chip x={160} y={108} text="Presiden?" size={24} fill={c.white} w={170} h={48} p={enter(t, K11.bukan - 0.4, 0.4)} />
      {t > K11.bukan && <XMark x={262} y={108} r={20} p={enter(t, K11.bukan, 0.3)} />}
      <Chip x={250} y={248} text="OB istana" size={18} fill={c.tealT2} rot={3} p={enter(t, K11.ob, 0.4)} />
      <Chip x={180} y={172} text="PRANK!" size={34} fill={c.yellow} rot={-6} w={170} h={58} p={enter(t, K11.prank, 0.3)} />
      {t > K11.prank && Array.from({ length: 16 }, (_, k) => {
        const x0 = hash(k) * 340 + 10, sp = 60 + hash(k + 9) * 50;
        const y = wrap(60 + (t - K11.prank) * sp, 60, 430);
        return <rect key={k} x={x0 + Math.sin(t * 2 + k) * 8} y={y} width={7} height={4} fill={colors[k % 4]} transform={`rotate(${t * 120 + k * 40} ${x0} ${y})`} opacity={enter(t, K11.prank, 0.3)} />;
      })}
    </g>
  );
};

// ---------- S12: kalimat 12 (tukang bakso) ----------
const K12 = { sel: cue(12, 'selamat'), bes: cue(12, 'besok'), nya: cue(12, 'nyadap'), bak: cue(12, 'bakso'), mab: cue(12, 'mabes') };
export const S12 = ({ t }: P) => (
  <g>
    <Bg fill={c.sky} />
    <Hills t={t} a={c.blueT2} b={c.tealT1} y={330} />
    <Floor t={t} a={c.yellowT1} b={c.yellowT2} f={c.blueT2} />
    <Sticker img="polri" x={180} y={176} h={92} rot={Math.sin(t * 1.6) * 3} anchor="center" p={enter(t, K12.mab - 0.3, 0.5)} />
    <Sticker img="polisi" x={85} y={434 + Math.sin(t * 2) * 1.5} h={270} pop={false} />
    <Sticker img="bakso" x={274} y={434} h={130} p={enter(t, K12.bak - 0.3, 0.5)} />
    {t > K12.nya && [0, 1, 2].map((i) => {
      const r = ((t - K12.nya) * 40 + i * 14) % 44 + 10;
      return <path key={i} d={`M${232 - r * 0.3},${352 - r} A${r},${r} 0 0 1 ${232 - r * 0.3},${352 + r}`} fill="none" stroke={c.orange} strokeWidth={3} strokeLinecap="round" opacity={clamp(1 - (r - 10) / 44)} />;
    })}
    <Chip x={180} y={98} text="Akhirnya selamat!" size={22} fill={c.yellow} p={enter(t, K12.sel, 0.4)} />
    <Check x={308} y={180} r={24} p={enter(t, K12.sel + 0.2, 0.5)} />
    <Chip x={258} y={238} text="Depan Mabes" size={16} fill={c.white} rot={3} p={enter(t, K12.mab, 0.4)} />
    <Chip x={252} y={278} text="Nyadap tukang bakso" size={14} fill={c.orangeT2} rot={-3} p={enter(t, K12.bak, 0.4)} />
  </g>
);
