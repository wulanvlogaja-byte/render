import React from 'react';
import { theme } from './theme';
import { easeOut, cue, sentenceStart, timing } from './util';
import { Defs, Star4, AssetsCtx } from './paper';
import { S0, S1, S2, S3, S4, S5, S6 } from './scenes1';
import { S7a, S7b, S8, S9a, S9b, S10, S11, S12 } from './scenes2';

const c = theme.c;
const cap = theme.caption;
const wm = theme.watermark;

// Awal tiap adegan = awal kalimat dikurangi sedikit (transisi terjadi di jeda napas)
const pre = (si: number) => Math.max(0, sentenceStart(si) - 0.4);
const SC = [
  { start: 0, C: S0 },
  { start: pre(1), C: S1 },
  { start: pre(2), C: S2 },
  { start: pre(3), C: S3 },
  { start: pre(4), C: S4 },
  { start: pre(5), C: S5 },
  { start: pre(6), C: S6 },
  { start: pre(7), C: S7a },
  { start: cue(7, 'like') - 0.3, C: S7b },
  { start: pre(8), C: S8 },
  { start: pre(9), C: S9a },
  { start: cue(9, 'semua') - 0.3, C: S9b },
  { start: pre(10), C: S10 },
  { start: pre(11), C: S11 },
  { start: pre(12), C: S12 },
];
SC.forEach((s, i) => {
  if (i > 0 && s.start < SC[i - 1].start + theme.trans + 0.2) throw new Error(`adegan ${i} terlalu dekat dengan adegan sebelumnya`);
});

// Potong narasi jadi potongan pendek (maks ~2 baris) untuk caption
type W = { w: string; start: number; end: number };
const chunks: W[][] = [];
(timing as any).sentences.forEach((s: any) => {
  const total = s.words.reduce((a: number, w: W) => a + w.w.length + 1, 0);
  const n = Math.max(1, Math.ceil(total / cap.maxChars));
  const target = total / n;
  let cur: W[] = [], len = 0, made = 0;
  s.words.forEach((w: W, i: number) => {
    cur.push(w); len += w.w.length + 1;
    const left = s.words.length - 1 - i;
    if (len >= target * 0.9 && made < n - 1 && left > 0) { chunks.push(cur); cur = []; len = 0; made++; }
  });
  if (cur.length) chunks.push(cur);
});

function Caption({ t }: { t: number }) {
  let k = 0;
  chunks.forEach((ch, i) => { if (t >= ch[0].start) k = i; });
  const ch = chunks[k];
  let cur = 0;
  ch.forEach((w, i) => { if (t >= w.start) cur = i; });
  return (
    <div style={{
      position: 'absolute', left: cap.side, right: cap.side, top: cap.top, height: cap.height, boxSizing: 'border-box',
      display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 26px',
      background: c.white, borderRadius: cap.radius, boxShadow: cap.panelShadow,
    }}>
      <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignContent: 'center', fontFamily: theme.font, fontWeight: 700, fontSize: cap.font, lineHeight: 1.2 }}>
        {ch.map((w, i) => (
          <span key={i} style={{
            padding: '3px 14px', margin: '3px 2px', borderRadius: 30,
            background: i === cur ? c.yellow : 'transparent', color: i <= cur ? c.ink : c.inkSoft,
          }}>{w.w}</span>
        ))}
      </div>
    </div>
  );
}

function Watermark() {
  return (
    <div style={{
      position: 'absolute', left: wm.left, top: wm.top, display: 'flex', alignItems: 'center', gap: 12,
      padding: '10px 26px 10px 16px', borderRadius: 999, background: wm.bg, boxShadow: wm.shadow, opacity: wm.opacity,
      fontFamily: theme.font, fontWeight: 700, fontSize: wm.font, color: c.ink, lineHeight: 1,
    }}>
      <svg width={36} height={36} viewBox="-12 -12 24 24"><Star4 x={0} y={0} r={11} fill={c.yellow} /></svg>
      <span>{wm.text}</span>
    </div>
  );
}

/** assets = peta nama -> URL gambar (Root mengisinya dengan staticFile). Tetap fungsi murni dari t. */
export function Video({ t, assets = {} }: { t: number; assets?: Record<string, string> }) {
  const TR = theme.trans;
  let b = 0, a = 0;
  SC.forEach((s, i) => { if (t >= s.start) b = i; if (t >= s.start + TR) a = i; });
  const list: number[] = [];
  for (let i = a; i <= b; i++) list.push(i);
  return (
    <AssetsCtx.Provider value={assets}>
    <div style={{ position: 'relative', width: 1080, height: 1920, overflow: 'hidden', background: c.sky }}>
      <svg width={1080} height={1920} viewBox={`0 0 ${theme.canvas.w} ${theme.canvas.h}`} style={{ position: 'absolute', left: 0, top: 0 }}>
        <Defs />
        {list.map((i) => {
          const Sc = SC[i].C;
          const slide = i === b && b !== a ? (1 - easeOut((t - SC[i].start) / TR)) * theme.canvas.w : 0;
          return <g key={i} transform={`translate(${slide},0)`}><Sc t={t} /></g>;
        })}
      </svg>
      <Caption t={t} />
      <Watermark />
    </div>
    </AssetsCtx.Provider>
  );
}
