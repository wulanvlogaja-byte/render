import React from 'react';
import { theme } from './theme';
import { clamp, easeOut, hash } from './util';

const c = theme.c;
export const F = theme.font;

export const Defs = () => {
  const s = theme.shadow;
  return (
    <defs>
      <filter id="ps" x="-25%" y="-25%" width="150%" height="165%">
        <feDropShadow dx={0} dy={s.dy} stdDeviation={s.blur} floodColor={c.ink} floodOpacity={s.opacity} />
      </filter>
      <filter id="pu" x="-5%" y="-30%" width="110%" height="140%">
        <feDropShadow dx={0} dy={-s.dy} stdDeviation={s.blur} floodColor={c.ink} floodOpacity={s.opacity} />
      </filter>
      <filter id="stk" x="-8%" y="-6%" width="116%" height="112%" colorInterpolationFilters="sRGB">
        <feMorphology in="SourceAlpha" operator="dilate" radius={2.4} result="d" />
        <feFlood floodColor={c.white} result="w" />
        <feComposite in="w" in2="d" operator="in" result="o" />
        <feDropShadow in="o" dx={0} dy={s.dy} stdDeviation={s.blur} floodColor={c.ink} floodOpacity={s.opacity} result="os" />
        <feMerge><feMergeNode in="os" /><feMergeNode in="SourceGraphic" /></feMerge>
      </filter>
    </defs>
  );
};

export const Bg = ({ fill = c.sky }: any) => <rect x={-5} y={-5} width={370} height={650} fill={fill} />;

export const T = ({ x, y, size = 16, children, fill = c.ink, anchor = 'middle', rot = 0 }: any) => (
  <text x={x} y={y} dy="0.35em" fontFamily={F} fontWeight={700} fontSize={size} fill={fill} textAnchor={anchor}
    transform={rot ? `rotate(${rot} ${x} ${y})` : undefined}>{children}</text>
);

/** kartu kertas bertuliskan teks */
export function Chip({ x, y, text, size = 16, fill = c.white, rot = 0, p = 1, w, h, tcolor = c.ink }: any) {
  if (p <= 0.001) return null;
  const ww = w ?? text.length * size * 0.6 + 28;
  const hh = h ?? size * 1.95;
  const k = 0.6 + 0.4 * easeOut(p);
  return (
    <g filter="url(#ps)" opacity={clamp(p * 1.6)}>
      <g transform={`translate(${x},${y}) rotate(${rot}) scale(${k})`}>
        <rect x={-ww / 2} y={-hh / 2} width={ww} height={hh} rx={hh * 0.32} fill={fill} />
        <T x={0} y={0} size={size} fill={tcolor}>{text}</T>
      </g>
    </g>
  );
}

export function Cloud({ x, y, s = 1, fill = c.white, o = 1 }: any) {
  return (
    <g filter="url(#ps)" opacity={o}>
      <g transform={`translate(${x},${y}) scale(${s})`} fill={fill}>
        <circle cx={-26} cy={0} r={20} /><circle cx={-4} cy={-12} r={26} />
        <circle cx={22} cy={-4} r={22} /><circle cx={42} cy={5} r={15} />
        <rect x={-46} y={4} width={104} height={20} rx={10} />
      </g>
    </g>
  );
}

/** pita bergelombang (periode 60), bergeser horizontal tanpa putus */
export function Ribbon({ y, fill, t, speed = 10, amp = 10, phase = 0, filt = 'pu' }: any) {
  const dx = -((t * speed + phase) % 60);
  const bob = Math.sin(t * 0.8 + phase) * 1.5;
  let d = `M-90 ${y} q15 ${-amp} 30 0`;
  for (let i = 0; i < 17; i++) d += ' t30 0';
  d += ' L450 700 L-90 700 Z';
  return <g filter={`url(#${filt})`}><path d={d} fill={fill} transform={`translate(${dx},${bob})`} /></g>;
}

export const Star4 = ({ x, y, r, fill = c.yellow, o = 1 }: any) => (
  <path d={`M${x},${y - r} Q${x},${y} ${x + r},${y} Q${x},${y} ${x},${y + r} Q${x},${y} ${x - r},${y} Q${x},${y} ${x},${y - r}Z`} fill={fill} opacity={o} />
);

export function Stars({ t, n = 14, seed = 0, y0 = 20, y1 = 400, fill = c.yellow, o = 1 }: any) {
  return (
    <g opacity={o}>
      {Array.from({ length: n }, (_, i) => {
        const x = hash(i * 3 + seed) * 340 + 10, y = y0 + hash(i * 5 + seed + 1) * (y1 - y0);
        const r = 3 + hash(i + seed + 7) * 5;
        return <Star4 key={i} x={x} y={y} r={r} fill={fill} o={0.55 + 0.45 * Math.sin(t * 2 + hash(i + seed) * 6)} />;
      })}
    </g>
  );
}

export function Sun({ x, y, r = 34, p = 1 }: any) {
  if (p <= 0.001) return null;
  const k = easeOut(p);
  return (
    <g opacity={k} transform={`translate(0,${(1 - k) * 40})`}>
      <g filter="url(#ps)"><circle cx={x} cy={y} r={r * 1.5} fill={c.orangeT2} /></g>
      <g filter="url(#ps)"><circle cx={x} cy={y} r={r * 1.1} fill={c.yellowT2} /></g>
      <g filter="url(#ps)"><circle cx={x} cy={y} r={r * 0.7} fill={c.yellow} /></g>
    </g>
  );
}

export function Moon({ x, y, r = 50 }: any) {
  return (
    <g filter="url(#ps)">
      <circle cx={x} cy={y} r={r} fill={c.yellowT1} />
      <circle cx={x - r * 0.3} cy={y - r * 0.25} r={r * 0.2} fill={c.yellowT2} />
      <circle cx={x + r * 0.35} cy={y + r * 0.1} r={r * 0.28} fill={c.yellowT2} />
      <circle cx={x - r * 0.1} cy={y + r * 0.45} r={r * 0.14} fill={c.yellowT2} />
    </g>
  );
}

export function Earth({ x, y, R, t = 0 }: any) {
  return (
    <g filter="url(#ps)">
      <circle cx={x} cy={y} r={R} fill={c.blue} />
      <g transform={`rotate(${t * 6} ${x} ${y})`}>
        <circle cx={x - R * 0.32} cy={y - R * 0.22} r={R * 0.26} fill={c.teal} />
        <circle cx={x + R * 0.28} cy={y + R * 0.1} r={R * 0.22} fill={c.teal} />
        <circle cx={x - R * 0.1} cy={y + R * 0.38} r={R * 0.18} fill={c.teal} />
        <circle cx={x + R * 0.35} cy={y - R * 0.4} r={R * 0.12} fill={c.teal} />
        <ellipse cx={x - R * 0.15} cy={y - R * 0.55} rx={R * 0.3} ry={R * 0.06} fill={c.white} opacity={0.85} />
        <ellipse cx={x + R * 0.1} cy={y + R * 0.62} rx={R * 0.28} ry={R * 0.06} fill={c.white} opacity={0.85} />
      </g>
    </g>
  );
}

export function Rocket({ x, y, s = 1, flame = 0, t = 0 }: any) {
  const fl = 1 + 0.18 * Math.sin(t * 40);
  return (
    <g filter="url(#ps)">
      <g transform={`translate(${x},${y}) scale(${s})`}>
        {flame > 0.01 && (
          <g transform={`scale(${flame},${flame * fl})`}>
            <path d="M-10,0 Q0,46 10,0Z" fill={c.orange} />
            <path d="M-5,0 Q0,28 5,0Z" fill={c.yellow} />
          </g>
        )}
        <path d="M-14,-18 L-28,6 L-14,-2Z" fill={c.orange} />
        <path d="M14,-18 L28,6 L14,-2Z" fill={c.orange} />
        <path d="M0,-64 C18,-46 17,-12 14,0 L-14,0 C-17,-12 -18,-46 0,-64Z" fill={c.white} />
        <path d="M0,-64 C7,-58 12,-52 14,-46 L-14,-46 C-12,-52 -7,-58 0,-64Z" fill={c.orange} />
        <rect x={-15} y={-14} width={30} height={7} fill={c.teal} />
        <circle cx={0} cy={-32} r={8} fill={c.yellow} /><circle cx={0} cy={-32} r={5} fill={c.blue} />
      </g>
    </g>
  );
}

type CharP = {
  x: number; y: number; t?: number; rot?: number; sx?: number; sy?: number;
  armL?: number; armR?: number; legL?: number; legR?: number;
  mood?: string; shades?: boolean; skin?: string; shirt?: string; pants?: string; suit?: boolean; helmet?: number; seed?: number; o?: number;
};
/** karakter kertas; titik tumpu di kaki. arm 0 = turun, 180 = lurus ke atas. */
export function Char(p: CharP) {
  const { shades = false, x, y, t = 0, rot = 0, sx = 1, sy = 1, armL = 10, armR = 10, legL = 0, legR = 0, mood = 'happy',
    skin = c.skin, suit = false, helmet = 0, seed = 0, o = 1 } = p;
  const shirt = p.shirt ?? (suit ? c.white : c.orange);
  const pants = p.pants ?? (suit ? c.white : c.blue);
  const blink = ((t / 3.4 + seed * 0.37) % 1) > 0.96;
  const eyeRy = blink || mood === 'sleep' ? 0.4 : mood === 'shock' ? 2.6 : 1.9;
  const stroke = { stroke: c.ink, strokeWidth: 1.8, fill: 'none', strokeLinecap: 'round' as const };
  const sweat = mood === 'tired' || mood === 'strain';
  return (
    <g filter="url(#ps)" opacity={o}>
      <g transform={`translate(${x},${y}) rotate(${rot}) scale(${sx},${sy})`}>
        <g transform={`rotate(${legL} -6 -14)`}><rect x={-9} y={-14} width={7} height={14} rx={3} fill={pants} /></g>
        <g transform={`rotate(${legR} 6 -14)`}><rect x={2} y={-14} width={7} height={14} rx={3} fill={pants} /></g>
        <rect x={-11} y={-46} width={22} height={34} rx={9} fill={shirt} />
        {suit && <><rect x={-11} y={-26} width={22} height={4} fill={c.yellow} /><circle cx={0} cy={-36} r={3.5} fill={c.teal} /></>}
        <g transform={`rotate(${armL} -11 -42)`}><rect x={-14} y={-42} width={6} height={22} rx={3} fill={shirt} /><circle cx={-11} cy={-19} r={3.6} fill={skin} /></g>
        <g transform={`rotate(${-armR} 11 -42)`}><rect x={8} y={-42} width={6} height={22} rx={3} fill={shirt} /><circle cx={11} cy={-19} r={3.6} fill={skin} /></g>
        <circle cx={0} cy={-58} r={13} fill={skin} />
        <path d="M-13,-60 A13,13 0 0 1 13,-60 Q0,-67 -13,-60Z" fill={c.hair} />
        <ellipse cx={-5} cy={-57} rx={1.8} ry={eyeRy} fill={c.ink} />
        <ellipse cx={5} cy={-57} rx={1.8} ry={eyeRy} fill={c.ink} />
        {mood === 'happy' && <path d="M-5,-52 Q0,-47 5,-52" {...stroke} />}
        {mood === 'shock' && <ellipse cx={0} cy={-50.5} rx={2.6} ry={3.2} fill={c.ink} />}
        {mood === 'sad' && <><path d="M-5,-49.5 Q0,-54 5,-49.5" {...stroke} /><path d="M-9,-63 L-3,-61 M9,-63 L3,-61" {...stroke} strokeWidth={1.4} /></>}
        {mood === 'sleep' && <><path d="M-8,-57 q3,2.5 6,0 M2,-57 q3,2.5 6,0" {...stroke} strokeWidth={1.4} /><circle cx={0} cy={-51} r={1.8} fill={c.ink} /></>}
        {mood === 'sick' && <path d="M-6,-51 q3,-3 6,0 t6,0" {...stroke} />}
        {mood === 'tired' && <ellipse cx={0} cy={-50.5} rx={3.2} ry={2.4} fill={c.ink} />}
        {mood === 'strain' && <><path d="M-5,-51 h10" {...stroke} strokeWidth={2.4} /><path d="M-9,-63 L-3,-61 M9,-63 L3,-61" {...stroke} strokeWidth={1.4} /></>}
        {sweat && [0, 1].map((i) => {
          const q = (t * 1.2 + i * 0.5) % 1;
          return <path key={i} d="M0,-4 Q4,2 0,5 Q-4,2 0,-4Z" fill={c.blue} opacity={1 - q}
            transform={`translate(${i ? 17 : -17},${-70 + q * 18})`} />;
        })}
        {shades && <g fill={c.ink}><rect x={-10} y={-60} width={9} height={6} rx={2} /><rect x={1} y={-60} width={9} height={6} rx={2} /><rect x={-2} y={-59} width={4} height={1.6} /></g>}
        {helmet > 0.01 && (
          <g transform={`translate(0,-58) scale(${helmet})`}>
            <circle r={19} fill={c.white} opacity={0.5} />
            <circle r={19} fill="none" stroke={c.yellow} strokeWidth={3} />
            <path d="M-11,-8 A14,14 0 0 1 -3,-13" stroke={c.white} strokeWidth={2.4} fill="none" strokeLinecap="round" />
          </g>
        )}
      </g>
    </g>
  );
}

export const Heart = ({ x, y, s = 1, fill = c.orange }: any) => (
  <g filter="url(#ps)">
    <path transform={`translate(${x},${y}) scale(${s})`} fill={fill}
      d="M0,-8 C-4,-22 -26,-22 -26,-4 C-26,12 -6,22 0,30 C6,22 26,12 26,-4 C26,-22 4,-22 0,-8Z" />
  </g>
);

export const XMark = ({ x, y, r = 10, p = 1 }: any) => (
  <g opacity={clamp(p * 2)} transform={`translate(${x},${y}) scale(${0.5 + 0.5 * easeOut(p)})`}>
    <circle r={r} fill={c.orange} />
    <path d={`M${-r * 0.4},${-r * 0.4} L${r * 0.4},${r * 0.4} M${r * 0.4},${-r * 0.4} L${-r * 0.4},${r * 0.4}`} stroke={c.ink} strokeWidth={2.4} strokeLinecap="round" />
  </g>
);

export const Check = ({ x, y, r = 22, p = 1 }: any) => (
  <g filter="url(#ps)" opacity={clamp(p * 2)}>
    <g transform={`translate(${x},${y}) scale(${0.4 + 0.6 * easeOut(p)})`}>
      <circle r={r} fill={c.teal} />
      <path d={`M${-r * 0.45},0 L${-r * 0.1},${r * 0.35} L${r * 0.5},${-r * 0.35}`} stroke={c.ink} strokeWidth={4} fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </g>
  </g>
);

export const Arrow = ({ x, y, s = 1, fill = c.orange, o = 1 }: any) => (
  <g opacity={o}>
    <path transform={`translate(${x},${y}) scale(${s})`} fill={fill} d="M-8,-22 H8 V2 H18 L0,24 L-18,2 H-8Z" />
  </g>
);

/** semua ribbon lantai standar di bagian bawah adegan */
export function Floor({ t, a = c.yellowT2, b = c.orangeT1, f = c.blueT2, y = 428 }: any) {
  return (
    <>
      <Ribbon y={y} fill={a} t={t} speed={6} amp={8} />
      <Ribbon y={y + 28} fill={b} t={t} speed={10} amp={10} phase={20} />
      <Ribbon y={y + 150} fill={f} t={t} speed={14} amp={10} phase={40} />
    </>
  );
}

/** dua lapis bukit kertas di belakang subjek (mengisi bagian tengah adegan) */
export function Hills({ t, a = c.blueT2, b = c.tealT1, y = 340 }: any) {
  return (
    <>
      <Ribbon y={y} fill={a} t={t} speed={4} amp={16} phase={10} />
      <Ribbon y={y + 46} fill={b} t={t} speed={7} amp={12} phase={30} />
    </>
  );
}

// ---------- stiker gambar (PNG dari pengguna) ----------
export const AssetsCtx = React.createContext<Record<string, string>>({});
export const ASSET_RATIO: Record<string, number> = { polisi: 640 / 960, bakso: 640 / 585, zoom: 360 / 359, polri: 360 / 341 };

/** gambar PNG dipotong ala kertas: tepi putih + bayangan lembut. x,y = tengah-bawah (anchor 'bottom') atau tengah. */
export function Sticker({ img, x, y, h, rot = 0, p = 1, flip = false, anchor = 'bottom', pop = true }: any) {
  const A = React.useContext(AssetsCtx);
  if (p <= 0.001) return null;
  const w = h * ASSET_RATIO[img];
  const k = pop ? 0.7 + 0.3 * easeOut(p) : 1;
  return (
    <g filter="url(#stk)" opacity={clamp(p * 2)}>
      <g transform={`translate(${x},${y}) rotate(${rot}) scale(${flip ? -k : k},${k})`}>
        <image href={A[img]} x={-w / 2} y={anchor === 'bottom' ? -h : -h / 2} width={w} height={h} preserveAspectRatio="none" />
      </g>
    </g>
  );
}

/** panel konsol sadap: tombol oranye besar + lampu. press 0..1 */
export function Console({ x, y, t = 0, press = 0, lamp = false, w = 150 }: any) {
  const k = 1 - 0.14 * press;
  return (
    <g filter="url(#ps)">
      <g transform={`translate(${x},${y})`}>
        <rect x={-w / 2} y={-62} width={w} height={124} rx={16} fill={c.white} />
        <rect x={-w / 2} y={-62} width={w} height={22} rx={12} fill={c.blueT2} />
        <circle cx={-w / 2 + 16} cy={-51} r={5} fill={lamp ? c.orange : c.gray2} />
        <rect x={-w / 2 + 30} y={-54} width={34} height={6} rx={3} fill={c.white} />
        <circle cx={0} cy={14} r={40} fill={c.gray1} />
        <circle cx={0} cy={14 + 3 * press} r={34 * k} fill={c.orange} />
        <T x={0} y={14 + 3 * press} size={15}>SADAP</T>
      </g>
    </g>
  );
}

export function Wifi({ x, y, s = 1, fill = c.teal, o = 1 }: any) {
  const arc = (r: number) => `M${-r * 0.8},${-r * 0.6} A${r},${r} 0 0 1 ${r * 0.8},${-r * 0.6}`;
  return (
    <g transform={`translate(${x},${y}) scale(${s})`} opacity={o} fill="none" stroke={fill} strokeWidth={7} strokeLinecap="round">
      <path d={arc(44)} /><path d={arc(30)} /><path d={arc(16)} />
      <circle cx={0} cy={4} r={5} fill={fill} stroke="none" />
    </g>
  );
}

export function Istana({ x, y, s = 1 }: any) {
  return (
    <g filter="url(#ps)">
      <g transform={`translate(${x},${y}) scale(${s})`}>
        <polygon points="-110,-70 110,-70 0,-120" fill={c.blueT2} />
        <circle cx={0} cy={-92} r={9} fill={c.yellow} />
        <rect x={-120} y={-70} width={240} height={14} fill={c.yellowT2} />
        {[-96, -58, -20, 20, 58, 96].map((cx, i) => <rect key={i} x={cx - 8} y={-56} width={16} height={56} fill={c.white} />)}
        <rect x={-126} y={0} width={252} height={14} rx={3} fill={c.gray1} />
        <rect x={-14} y={-30} width={28} height={30} rx={14} fill={c.blueT1} />
      </g>
    </g>
  );
}
