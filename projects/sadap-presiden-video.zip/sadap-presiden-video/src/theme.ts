// SEMUA warna dan ukuran didefinisikan di sini (satu-satunya tempat yang boleh berisi hex).
export const theme = {
  font: "'Fredoka', 'Arial Rounded MT Bold', 'Trebuchet MS', sans-serif",
  tail: 0.9, // detik hening setelah narasi selesai
  trans: 0.5, // durasi transisi antar adegan (detik)
  c: {
    // dasar terang
    bg: '#F7FAFC', sky: '#EAF6FF', cream: '#FFF4DC', white: '#FFFFFF',
    // teks
    ink: '#1B2A3A', inkSoft: '#445566',
    // 4 aksen jenuh
    blue: '#2D9CDB', teal: '#00BFA6', yellow: '#FFC93C', orange: '#FF8A3D',
    // tint terang dari aksen
    blueT1: '#DCF1FC', blueT2: '#B5E1F7', blueT3: '#86CBF0',
    tealT1: '#D5F5F0', tealT2: '#9FE6DA',
    yellowT1: '#FFF4DC', yellowT2: '#FFE7A8',
    orangeT1: '#FFE6D3', orangeT2: '#FFC7A0',
    // netral
    skin: '#F6CFAE', skin2: '#E7B28A', hair: '#3A2E2A', gray1: '#E3EAF0', gray2: '#C4CFD9',
  },
  // bayangan kertas (dipakai filter ps dan pu)
  shadow: { dy: 3.5, blur: 2.6, opacity: 0.28 },
  canvas: { w: 360, h: 640 }, // viewBox, diskalakan 3x ke 1080x1920
  caption: {
    top: 1335, height: 290, side: 54, font: 56, maxChars: 44,
    panelShadow: '0 12px 28px rgba(27,42,58,0.22)',
    radius: 56,
  },
  // WATERMARK: ubah posisi/ukuran di sini saja
  watermark: {
    text: 'Idin Riset',
    left: 42, top: 108, // px pada kanvas 1080x1920 (pojok kiri atas, aman dari UI TikTok/Reels)
    font: 38, opacity: 0.88,
    bg: 'rgba(255,255,255,0.80)',
    shadow: '0 6px 16px rgba(27,42,58,0.18)',
  },
};
export type Theme = typeof theme;
