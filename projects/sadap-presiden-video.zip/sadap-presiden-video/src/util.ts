import timing from './timing.json';

export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const easeOut = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
export const back = (x: number) => {
  const v = clamp(x), c1 = 1.70158, c3 = c1 + 1;
  return 1 + c3 * Math.pow(v - 1, 3) + c1 * Math.pow(v - 1, 2);
};
export const enter = (t: number, t0: number, d = 0.7) => easeOut((t - t0) / d);
export const fract = (x: number) => x - Math.floor(x);
export const hash = (n: number) => fract(Math.sin(n * 127.1 + 311.7) * 43758.5453);
export const wrap = (x: number, a: number, b: number) => a + ((((x - a) % (b - a)) + (b - a)) % (b - a));
export const lerp = (a: number, b: number, k: number) => a + (b - a) * k;

const norm = (w: string) => w.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');

/** Waktu (detik) mulai kata ke-n pada kalimat si (0-based). Lempar error jelas kalau tidak ada. */
export function cue(si: number, word: string, n = 0): number {
  const s = (timing as any).sentences[si];
  if (!s) throw new Error(`cue: kalimat ${si} tidak ada`);
  let k = 0;
  for (const w of s.words) {
    if (norm(w.w) === norm(word)) {
      if (k === n) return w.start;
      k++;
    }
  }
  throw new Error(`cue tidak ditemukan: kalimat ${si}, kata "${word}" ke-${n}`);
}
export const sentenceStart = (si: number): number => (timing as any).sentences[si].start;
export { timing };
