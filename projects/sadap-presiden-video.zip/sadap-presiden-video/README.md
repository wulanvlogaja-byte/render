# sadap-presiden-video (Remotion, 9:16, 30 fps)

Video "POV: Kapolri Sadap Presiden" bergaya paper-cut, disinkronkan per kata dengan `public/narasi.mp3`.
Watermark teks **"Idin Riset"** di pojok kiri atas. Composition id: `SadapPresiden`.

## Struktur
```
sadap-presiden-video/
  public/narasi.mp3        audio narasi
  public/img/*.png         polisi, bakso, zoom, polri (diperkecil dari gambar unggahan)
  narasi.txt / narasi.srt  teks narasi (SRT hanya pembanding)
  timing.cjs               hitung timing dari audio -> src/timing.json
  src/theme.ts             SEMUA warna/ukuran/watermark/caption
  src/timing.json          waktu tiap kalimat dan kata
  src/util.ts              easing, hash deterministik, cue(kalimat, kata)
  src/paper.tsx            komponen kertas + Sticker (PNG berbingkai putih ala potongan kertas)
  src/scenes1.tsx          adegan 0-6       src/scenes2.tsx  adegan 7-12
  src/Video.tsx            komposisi murni Video({ t, assets }) + transisi + caption + watermark
  src/Root.tsx             pembungkus Remotion (frame -> t, <Audio>, tunggu gambar ter-decode)
```

## Render di GitHub Actions
1. `actions/checkout` + `actions/setup-node` (Node 20+)
2. `npm install` (tanpa lockfile, jadi bukan `npm ci`)
3. `npm run render` -> `out/video.mp4`
4. `actions/upload-artifact` untuk `out/video.mp4`

Pastikan working-directory job menunjuk ke folder `sadap-presiden-video`.

## Ubah watermark
Edit `theme.watermark` di `src/theme.ts` (`text`, `left`, `top`, `font`, `opacity`).

## Ganti audio / teks
Ganti `public/narasi.mp3` dan `narasi.txt`, jalankan `node timing.cjs` (butuh ffmpeg). Cue visual diambil dari kata
(`cue(kalimat, kata)`), jadi kalau kata cue hilang dari narasi baru, build error dengan pesan jelas.

Remotion di-pin `4.0.250` (semua paket remotion/@remotion/* satu versi). Font: Fredoka 700 via `@remotion/google-fonts`.
