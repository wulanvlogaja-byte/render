// Hitung timing narasi dari audio: node timing.cjs  (butuh ffmpeg + ffprobe)
// Env: FPS (default 30), W (1080), H (1920)
const { execSync, spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const FPS = +(process.env.FPS || 30);
const W = +(process.env.W || 1080);
const H = +(process.env.H || 1920);
const AUDIO = path.join(__dirname, 'public/narasi.mp3');
const TXT = path.join(__dirname, 'narasi.txt');
const SRT = path.join(__dirname, 'narasi.srt');

const duration = parseFloat(
  execSync(`ffprobe -v error -show_entries format=duration -of csv=p=0 "${AUDIO}"`).toString()
);
const r = spawnSync('ffmpeg', ['-i', AUDIO, '-af', 'silencedetect=noise=-35dB:d=0.25', '-f', 'null', '-'], { encoding: 'utf8' });
const log = r.stderr;
const sil = [];
let cur = null;
for (const line of log.split('\n')) {
  let m = line.match(/silence_start: ([\d.]+)/);
  if (m) cur = { s: +m[1] };
  m = line.match(/silence_end: ([\d.]+)/);
  if (m && cur) { cur.e = +m[1]; sil.push(cur); cur = null; }
}
// komplemen jeda = segmen bicara
const segs = [];
let p = 0;
for (const s of sil) { if (s.s - p > 0.05) segs.push({ s: p, e: s.s }); p = s.e; }
if (duration - p > 0.05) segs.push({ s: p, e: duration });

const sentences = fs.readFileSync(TXT, 'utf8').split('\n').map(x => x.trim()).filter(Boolean);
const N = sentences.length, M = segs.length;
const clen = sentences.map(t => t.replace(/[^\p{L}\p{N}]/gu, '').length);
const segdur = segs.map(x => x.e - x.s);
const cum = [0]; segdur.forEach(d => cum.push(cum[cum.length - 1] + d));

function align(med) {
  // dp[i][j]: kalimat 0..i-1 memakai segmen 0..j-1 (semua terpakai, monoton)
  const INF = 1e9;
  const dp = Array.from({ length: N + 1 }, () => new Array(M + 1).fill(INF));
  const bk = Array.from({ length: N + 1 }, () => new Array(M + 1).fill(-1));
  dp[0][0] = 0;
  for (let i = 1; i <= N; i++)
    for (let j = i; j <= M; j++)
      for (let k = i - 1; k < j; k++) {
        if (dp[i - 1][k] >= INF) continue;
        const d = cum[j] - cum[k];
        const rate = clen[i - 1] / d;
        const c = dp[i - 1][k] + Math.abs(Math.log(rate / med)) + 0.05 * (j - k - 1);
        if (c < dp[i][j]) { dp[i][j] = c; bk[i][j] = k; }
      }
  const out = []; let j = M;
  for (let i = N; i >= 1; i--) { const k = bk[i][j]; out.unshift([k, j]); j = k; }
  return out;
}
let med = clen.reduce((a, b) => a + b, 0) / (cum[M]);
let ranges;
for (let it = 0; it < 6; it++) {
  ranges = align(med);
  const rates = ranges.map(([a, b], i) => clen[i] / (cum[b] - cum[a])).sort((x, y) => x - y);
  med = rates[Math.floor(rates.length / 2)];
}

const norm = w => w.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');
const out = ranges.map(([a, b], i) => {
  const ss = segs.slice(a, b);
  const total = ss.reduce((x, y) => x + (y.e - y.s), 0);
  const words = sentences[i].split(/\s+/);
  const wt = words.map(w => norm(w).length + 1.5);
  const wsum = wt.reduce((x, y) => x + y, 0);
  const toTime = pos => { // pos detik di timeline bicara -> waktu nyata
    let acc = 0;
    for (const s of ss) { const d = s.e - s.s; if (pos <= acc + d + 1e-9) return s.s + (pos - acc); acc += d; }
    return ss[ss.length - 1].e;
  };
  let pos = 0;
  const ws = words.map((w, k) => {
    const st = toTime(pos);
    pos += (wt[k] / wsum) * total;
    return { w, start: +st.toFixed(3), end: +toTime(pos).toFixed(3) };
  });
  return {
    text: sentences[i],
    start: +ss[0].s.toFixed(3),
    end: +ss[ss.length - 1].e.toFixed(3),
    rate: +(clen[i] / total).toFixed(2),
    words: ws,
  };
});

// pembanding SRT
let srtInfo = [];
if (fs.existsSync(SRT)) {
  const blocks = fs.readFileSync(SRT, 'utf8').trim().split(/\n\s*\n/);
  const ts = s => { const m = s.match(/(\d+):(\d+):(\d+),(\d+)/); return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000; };
  srtInfo = blocks.map(b => { const l = b.split('\n'); const [a, c] = l[1].split(' --> '); return { start: ts(a), end: ts(c) }; });
}
const rates = out.map(x => x.rate).sort((a, b) => a - b);
const median = rates[Math.floor(rates.length / 2)];
out.forEach((s, i) => {
  const flag = s.rate / median < 0.6 || s.rate / median > 1.6 ? '  <-- LAJU ANEH' : '';
  const d = srtInfo[i] ? `  | SRT ${srtInfo[i].start.toFixed(2)} (selisih ${(s.start - srtInfo[i].start).toFixed(2)}s)` : '';
  console.log(`${String(i + 1).padStart(2)}. ${s.start.toFixed(2)}-${s.end.toFixed(2)} rate ${s.rate}${flag}${d}`);
});
fs.writeFileSync(path.join(__dirname, 'src/timing.json'), JSON.stringify({ duration, fps: FPS, width: W, height: H, sentences: out }, null, 1));
console.log('OK duration', duration.toFixed(2), 'median rate', median.toFixed(2));
