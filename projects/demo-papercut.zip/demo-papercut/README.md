# demo-papercut

Demo gaya paper-cut (lapisan kertas + bayangan lembut): kapal pinisi saat matahari terbit.
9:16 (1080x1920), 30 fps, 8 detik, tanpa audio. Komposisi: `PapercutDemo`.

## Struktur

```
demo-papercut/
├── package.json      # remotion & @remotion/* dipin 4.0.250, skrip "render"
├── tsconfig.json
└── src/
    ├── index.ts      # registerRoot
    ├── Root.tsx      # pembungkus Remotion: frame -> t = frame/fps -> <Video t={t} />
    ├── Video.tsx     # komposisi inti React murni: Video({ t })
    └── theme.ts      # semua warna, ukuran, bayangan, dan cue waktu (ubah di sini)
```

## Menjalankan di GitHub Actions (render-remotion.yml, workflow_dispatch)

1. `actions/checkout`, `actions/setup-node` (Node 18+ atau 20).
2. `working-directory: demo-papercut`, lalu `npm install` (tidak ada package-lock.json; jangan pakai `npm ci`).
3. `npm run render` -> `demo-papercut/out/video.mp4`.
4. `actions/upload-artifact` untuk `demo-papercut/out/video.mp4`.

Sesuaikan nama folder di workflow-mu bila berbeda.

## Cara kerja gaya paper-cut

- Tiap lapisan (matahari, awan, pulau, ombak, kapal) dibungkus `<g filter="url(#ps)">` dengan `feDropShadow`, jadi satu bayangan per lapisan, bukan per bentuk (lebih ringan saat render).
- Ombak memakai bayangan ke atas (`#pu`) supaya terlihat menumpuk di atas lapisan di belakangnya.
- Semua gerak adalah fungsi dari `t`: kertas masuk berurutan (cue di `theme.timeline`), ombak bergeser dengan loop mulus, kapal bergoyang, layar berayun, awan melayang, burung mengepak. Variasi acak memakai hash deterministik.

## Catatan

- Samakan versi Remotion dengan repo-mu (`4.0.250` di package.json; semua paket `remotion` / `@remotion/*` satu versi).
- Font Fredoka dimuat lewat `@remotion/google-fonts` (perlu internet di runner; aman di GitHub Actions).
- Demo ini tanpa narasi, jadi tidak ada `timing.json`/`timing.cjs`. Cue animasi berupa detik di `theme.timeline`.
