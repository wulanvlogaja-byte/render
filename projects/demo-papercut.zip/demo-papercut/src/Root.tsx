import React from 'react';
import { Composition, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import { Video } from './Video';
import { theme } from './theme';

const { fontFamily } = loadFont('normal', { weights: ['700'], subsets: ['latin'] });

const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return <Video t={frame / fps} fontFamily={`${fontFamily}, sans-serif`} />;
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="PapercutDemo"
    component={Main}
    durationInFrames={Math.round(theme.duration * theme.fps)}
    fps={theme.fps}
    width={theme.canvas.width}
    height={theme.canvas.height}
  />
);
