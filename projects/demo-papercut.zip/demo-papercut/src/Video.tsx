import React from 'react';
import { theme } from './theme';

const C = theme.color;
const TL = theme.timeline;
const V = theme.canvas;

// ---------- util murni ----------
const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const prog = (t: number, t0: number, d: number) => clamp((t - t0) / d);
const eOut = (k: number) => 1 - Math.pow(1 - clamp(k), 3);
const eBack = (k: number) => { k = clamp(k); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };
const enter = (t: number, t0: number, d = 0.7) => eOut(prog(t, t0, d));
const hash = (n: number) => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
const wrap = (x: number, a: number, b: number) => ((((x - a) % (b - a)) + (b - a)) % (b - a)) + a;

// ---------- bentuk dasar ----------
const wavePath = (y: number) => `M-60 ${y} q15 -12 30 0${' t30 0'.repeat(17)} L480 700 L-60 700Z`;

const Cloud: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill={C.white}>
    <circle r={20} /><circle cx={26} cy={-12} r={26} /><circle cx={54} cy={-2} r={22} />
    <rect x={-20} y={-4} width={96} height={24} rx={12} />
  </g>
);

const Band: React.FC<{ t: number; y: number; fill: string; speed: number; phase: number; t0: number; glints?: number[] }> = ({ t, y, fill, speed, phase, t0, glints = [] }) => {
  const e = enter(t, t0);
  const dx = (t * speed) % 60;
  const bob = Math.sin(t * 1.2 + phase) * 3;
  return (
    <g filter="url(#pu)" opacity={clamp(e * 2)} transform={`translate(0 ${(1 - e) * 70 + bob})`}>
      <g transform={`translate(${dx} 0)`}>
        <path d={wavePath(y)} fill={fill} />
        {glints.map((gx, i) => <path key={i} d={`M${gx} ${y + 16 + (i % 3) * 9} q6 -4 12 0`} stroke={C.white} strokeWidth={2.6} fill="none" strokeLinecap="round" opacity={0.7} />)}
      </g>
    </g>
  );
};

const Sail: React.FC<{ pts: string; inner: string; mx: number; k: number; sway: number }> = ({ pts, inner, mx, k, sway }) => (
  <g transform={`translate(${mx} 372) rotate(${sway}) scale(1 ${Math.max(0.001, k)}) translate(${-mx} -372)`}>
    <polygon points={pts} fill={C.white} />
    <polygon points={inner} fill={C.sailShade} />
  </g>
);

const Ship: React.FC<{ t: number }> = ({ t }) => {
  const e = enter(t, TL.ship, 0.9);
  const bob = Math.sin(t * 1.3) * 2.5, rock = Math.sin(t * 1.1 + 0.5) * 1.6;
  const sk = (i: number) => eBack(prog(t, TL.sails + i * 0.14, 0.6));
  const sw = (i: number) => Math.sin(t * 1.7 + i * 1.3) * 1.4;
  return (
    <g filter="url(#ps)" opacity={clamp(e * 2)} transform={`translate(-10 0) translate(0 ${(1 - e) * 50 + bob}) rotate(${rock} 190 430)`}>
      <path d="M95 380 L285 380 L262 430 L118 430Z" fill={C.red} />
      <path d="M102 392 L278 392 L274 400 L106 400Z" fill={C.bg} />
      <rect x={176} y={360} width={50} height={20} rx={3} fill={C.yellow} />
      <rect x={188} y={365} width={9} height={9} rx={2} fill={C.window} />
      <rect x={206} y={365} width={9} height={9} rx={2} fill={C.window} />
      <path d="M285 380 L334 350" stroke={C.ink} strokeWidth={4} strokeLinecap="round" />
      <rect x={140} y={272} width={5} height={108} fill={C.ink} />
      <rect x={188} y={252} width={5} height={128} fill={C.ink} />
      <rect x={236} y={282} width={5} height={98} fill={C.ink} />
      <Sail pts="139,278 139,372 98,372" inner="139,300 139,372 118,372" mx={142} k={sk(0)} sway={sw(0)} />
      <Sail pts="187,258 187,372 146,372" inner="187,284 187,372 165,372" mx={190} k={sk(1)} sway={sw(1)} />
      <Sail pts="235,288 235,372 194,372" inner="235,310 235,372 214,372" mx={238} k={sk(2)} sway={sw(2)} />
      <Sail pts="244,296 244,374 300,374" inner="244,326 244,374 272,374" mx={246} k={sk(3)} sway={sw(3)} />
      <polygon points={`191,252 ${214 + Math.sin(t * 6) * 2},${259 + Math.sin(t * 5) * 1.5} 191,266`} fill={C.red} />
      <polygon points={`143,272 ${160 + Math.sin(t * 6 + 1) * 2},${277 + Math.sin(t * 5 + 1) * 1.5} 143,282`} fill={C.red} />
    </g>
  );
};

const Palm: React.FC<{ x: number; y: number; h: number; w: number; t: number; ph: number }> = ({ x, y, h, w, t, ph }) => {
  const tx = x + w * 0.4, ty = y - h;
  const sway = Math.sin(t * 1.5 + ph) * 2.5;
  return (
    <g stroke={C.ink} strokeWidth={3.4} fill="none" strokeLinecap="round">
      <path d={`M${x} ${y} Q${x + 4} ${y - h * 0.5} ${tx} ${ty}`} />
      <g transform={`rotate(${sway} ${tx} ${ty})`}>
        <path d={`M${tx} ${ty} q-14 -10 -28 -2 M${tx} ${ty} q-6 -16 -22 -18 M${tx} ${ty} q8 -14 24 -14 M${tx} ${ty} q16 -4 24 8`} />
      </g>
    </g>
  );
};

const Bird: React.FC<{ x: number; y: number; t: number; ph: number }> = ({ x, y, t, ph }) => {
  const a = 4 + 5 * Math.sin(t * 9 + ph);
  return <path d={`M${x} ${y} Q${x + 9} ${y - a - 4} ${x + 18} ${y - 1} Q${x + 27} ${y - a - 4} ${x + 36} ${y}`} stroke={C.ink} strokeWidth={3} fill="none" strokeLinecap="round" strokeLinejoin="round" />;
};

const Sparkle: React.FC<{ x: number; y: number; r: number; o: number }> = ({ x, y, r, o }) => (
  <path d={`M${x} ${y - r} L${x + r * 0.28} ${y - r * 0.28} L${x + r} ${y} L${x + r * 0.28} ${y + r * 0.28} L${x} ${y + r} L${x - r * 0.28} ${y + r * 0.28} L${x - r} ${y} L${x - r * 0.28} ${y - r * 0.28}Z`} fill={C.yellow} opacity={o} />
);

// ---------- komposisi inti ----------
export function Video({ t, fontFamily }: { t: number; fontFamily?: string }) {
  const sunE = enter(t, TL.sun, 0.8);
  const sunY = lerp(420, 214, eOut(prog(t, TL.sun, 2.4)));
  const pulse = 1 + Math.sin(t * 1.6) * 0.025;
  const isl = enter(t, TL.island);
  const cl = enter(t, TL.clouds, 0.9);
  const ti = enter(t, TL.title, 0.6);
  const bi = enter(t, TL.birds, 0.6);

  const skyClouds = [{ x: 20, y: 124, s: 1, v: 5 }, { x: 230, y: 156, s: 0.8, v: 7 }, { x: 120, y: 292, s: 0.7, v: 4 }];
  const frontClouds = [{ x: 24, y: 598, s: 1.5, ph: 0 }, { x: 226, y: 608, s: 1.4, ph: 2 }];
  const birds = [{ x0: 40, y: 150, v: 18, ph: 0 }, { x0: 120, y: 182, v: 14, ph: 1.3 }, { x0: 200, y: 134, v: 22, ph: 2.1 }];

  return (
    <div style={{ position: 'absolute', left: 0, top: 0, width: V.width, height: V.height, overflow: 'hidden', background: C.bg, fontFamily: fontFamily || theme.fontFallback }}>
      <svg width={V.width} height={V.height} viewBox={`0 0 ${V.vbW} ${V.vbH}`} role="img">
        <defs>
          <filter id="ps" x="-15%" y="-15%" width="130%" height="135%"><feDropShadow dx="0" dy={theme.shadow.dy} stdDeviation={theme.shadow.blur} floodColor={C.ink} floodOpacity={theme.shadow.opacity} /></filter>
          <filter id="pu" x="-5%" y="-10%" width="110%" height="120%"><feDropShadow dx="0" dy={-theme.shadow.dy} stdDeviation={theme.shadow.blur} floodColor={C.ink} floodOpacity={theme.shadow.opacity} /></filter>
        </defs>
        <rect width={V.vbW} height={V.vbH} fill={C.bg} />

        {[0, 1, 2, 3, 4, 5].map((i) => <Sparkle key={i} x={30 + hash(i + 1) * 300} y={60 + hash(i + 9) * 150} r={5 + hash(i + 4) * 4} o={sunE * (0.35 + 0.65 * Math.abs(Math.sin(t * 2 + i * 1.7)))} />)}

        <g transform={`translate(0 ${(1 - sunE) * 30})`} opacity={clamp(sunE * 2)}>
          <g filter="url(#ps)"><circle cx={180} cy={sunY} r={124 * pulse} fill={C.sunOuter} /></g>
          <g filter="url(#ps)"><circle cx={180} cy={sunY} r={94 * pulse} fill={C.sunMid} /></g>
          <g filter="url(#ps)"><circle cx={180} cy={sunY} r={64 * pulse} fill={C.yellow} /></g>
        </g>

        <g filter="url(#ps)" opacity={clamp(cl * 2)} transform={`translate(0 ${(1 - cl) * -40})`}>
          {skyClouds.map((c, i) => <Cloud key={i} x={wrap(c.x + t * c.v, -160, 520)} y={c.y} s={c.s} />)}
        </g>

        <g filter="url(#ps)" opacity={clamp(isl * 2)} transform={`translate(${(1 - isl) * -80} 0)`}>
          <path d="M-10 340 Q18 296 58 322 Q80 330 102 340Z" fill={C.teal} />
          <Palm x={30} y={318} h={34} w={12} t={t} ph={0} />
          <Palm x={68} y={324} h={26} w={8} t={t} ph={1.7} />
        </g>

        <Band t={t} y={330} fill={C.sea1} speed={8} phase={0} t0={TL.sea1} glints={[20, 130, 250, 330]} />
        <Band t={t} y={368} fill={C.sea2} speed={12} phase={1.2} t0={TL.sea2} glints={[60, 170, 290]} />
        <Ship t={t} />
        <Band t={t} y={424} fill={C.sea3} speed={18} phase={2.4} t0={TL.sea3} glints={[30, 150, 270, 360]} />
        <Band t={t} y={490} fill={C.sea4} speed={26} phase={3.6} t0={TL.sea4} glints={[80, 200, 320]} />

        <g filter="url(#ps)" opacity={clamp(cl * 2)} transform={`translate(0 ${(1 - cl) * 60})`}>
          {frontClouds.map((c, i) => <Cloud key={i} x={c.x + Math.sin(t * 0.5 + c.ph) * 8} y={c.y + Math.sin(t * 0.8 + c.ph) * 3} s={c.s} />)}
        </g>

        <g opacity={clamp(bi * 2)}>
          {birds.map((b, i) => <Bird key={i} x={wrap(b.x0 + t * b.v, -40, 400)} y={b.y + Math.sin(t * 1.3 + b.ph) * 6} t={t} ph={b.ph} />)}
        </g>

        <g transform={`translate(180 ${50 - (1 - ti) * 40}) scale(${ti})`} opacity={clamp(ti * 2)}>
          <g filter="url(#ps)"><rect x={-96} y={-28} width={192} height={56} rx={16} fill={C.white} /></g>
          <text x={0} y={11} textAnchor="middle" fontSize={32} fontWeight={700} fill={C.ink}>Layar Pagi</text>
        </g>
      </svg>
    </div>
  );
}
