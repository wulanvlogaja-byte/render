// Satu-satunya sumber warna, ukuran, dan cue waktu. Ganti di sini untuk mengubah seluruh tampilan.
export const theme = {
  canvas: { width: 1080, height: 1920, vbW: 360, vbH: 640 }, // viewBox 360x640 => skala 3x
  fps: 30,
  duration: 8, // detik
  color: {
    bg: '#FFF4DC', // krem terang
    ink: '#1B2A3A',
    white: '#FFFFFF',
    // 4 aksen jenuh
    blue: '#2D9CDB',
    teal: '#00BFA6',
    yellow: '#FFC93C',
    red: '#FF5D5D',
    // tint terang dari aksen
    sunOuter: '#FFEDB8',
    sunMid: '#FFD966',
    sailShade: '#FFE9A8',
    sea1: '#CDEEFB',
    sea2: '#9ADCF5',
    sea3: '#5CC0EC',
    sea4: '#2D9CDB',
    window: '#9ADCF5',
  },
  shadow: { dy: 3.5, blur: 2.6, opacity: 0.28 }, // bayangan kertas (feDropShadow)
  timeline: { // detik: kapan tiap lapisan kertas "masuk"
    sun: 0, island: 0.3, sea1: 0.5, sea2: 0.7, ship: 0.9, sails: 1.3,
    sea3: 1.2, sea4: 1.4, clouds: 1.0, title: 1.8, birds: 2.2,
  },
  fontFallback: "'Fredoka','Baloo 2','Arial Rounded MT Bold','Trebuchet MS',sans-serif",
};
export type Theme = typeof theme;
