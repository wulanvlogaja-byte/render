import React from 'react';
import { Composition, OffthreadVideo, Sequence, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import timing from './timing.json';
import { Video } from './Video';
import { theme } from './theme';

const { fontFamily } = loadFont('normal', { weights: ['700'], subsets: ['latin'] });

// Footage diputar per potongan (jump cut): tiap potongan = satu Sequence yang mulai dari waktu sumbernya.
const Footage: React.FC = () => {
  const { fps } = useVideoConfig();
  return (
    <>
      {timing.cuts.map((c, i) => {
        const from = Math.round(c.out0 * fps);
        const dur = Math.max(1, Math.round(c.out1 * fps) - from);
        return (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <OffthreadVideo src={staticFile(timing.footage)} startFrom={Math.round(c.src0 * fps)} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          </Sequence>
        );
      })}
    </>
  );
};

const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return <Video t={frame / fps} fontFamily={`${fontFamily}, sans-serif`} footage={<Footage />} />;
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="EditDemoBuruh"
    component={Main}
    durationInFrames={Math.ceil((timing.duration + theme.tail) * timing.fps)}
    fps={timing.fps}
    width={timing.width}
    height={timing.height}
  />
);
