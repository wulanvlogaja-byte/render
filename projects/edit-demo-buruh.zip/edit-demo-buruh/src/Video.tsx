import React from 'react';
import { theme } from './theme';
import timing from './timing.json';

const C = theme.color;
const L = theme.layout;
const TX = theme.text;

// ---------- util murni (fungsi dari t, tanpa state/timer/random) ----------
const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const prog = (t: number, t0: number, d: number) => clamp((t - t0) / d);
const eOut = (k: number) => 1 - Math.pow(1 - clamp(k), 3);
const eBack = (k: number) => { k = clamp(k); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };
const hash = (n: number) => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };

// ---------- cue dari kata di timing.json ----------
type W = { w: string; start: number; end: number; unit: number };
type Cut = { src0: number; src1: number; out0: number; out1: number };
const WORDS = timing.words as W[];
const CUTS = timing.cuts as Cut[];
const norm = (w: string) => w.toLowerCase().replace(/[^a-z0-9]/g, '');
const cue = (word: string, n = 0): number => {
  let c = 0;
  for (const w of WORDS) if (norm(w.w) === word) { if (c === n) return w.start; c++; }
  throw new Error(`cue "${word}" (ke-${n}) tidak ada di timing.json`);
};
const END = timing.duration;
const T = {
  dua: cue('dua'), demo: cue('demo'), hi: cue('hi'), istana: cue('istana'), polri: cue('polri'),
  selidik: cue('diselidiki'), tujuan: cue('tujuan'), tujuan2: cue('tujuan', 1), turun: cue('turun'), skenario: cue('skenario'),
  dilacak: cue('dilacak'), saya: cue('saya'), tersandera: cue('tersandera'), tepat: cue('tepat'),
};

// ---------- bentuk kertas ----------
const Chip: React.FC<{ x: number; y: number; w: number; text: string; fill: string; k: number; fs?: number }> = ({ x, y, w, text, fill, k, fs = 11 }) => (
  <g transform={`translate(${x} ${y}) scale(${k})`} opacity={clamp(k * 2)}>
    <g filter="url(#ps)"><rect x={-w / 2} y={-10} width={w} height={20} rx={10} fill={fill} /></g>
    <text y={4.2} textAnchor="middle" fontSize={fs} fontWeight={700} fill={C.ink}>{text}</text>
  </g>
);
const Person: React.FC<{ x: number; y: number; s: number; fill: string; t: number; ph: number; banner?: string; lean?: number }> = ({ x, y, s, fill, t, ph, banner, lean = 0 }) => {
  const bob = Math.abs(Math.sin(t * 5 + ph)) * 2.2;
  return (
    <g transform={`translate(${x} ${y - bob}) scale(${s}) rotate(${lean})`}>
      {banner && <g><rect x={7} y={-46} width={3} height={36} fill={C.ink} /><rect x={-2} y={-62} width={26} height={17} rx={3} fill={banner} /></g>}
      <rect x={-7} y={-22} width={14} height={22} rx={6} fill={fill} />
      <circle cx={0} cy={-29} r={7.5} fill={C.skin} />
    </g>
  );
};
const Magnifier: React.FC<{ x: number; y: number; r: number }> = ({ x, y, r }) => (
  <g transform={`translate(${x} ${y})`}>
    <line x1={r * 0.72} y1={r * 0.72} x2={r * 1.7} y2={r * 1.7} stroke={C.ink} strokeWidth={r * 0.26} strokeLinecap="round" />
    <circle r={r} fill={C.blueSoft} fillOpacity={0.75} stroke={C.ink} strokeWidth={r * 0.16} />
  </g>
);

// ---------- jendela waktu adegan stage ----------
const win = (t: number, a: number, b: number) => {
  const en = eBack(prog(t, a, 0.55)), ex = prog(t, b, 0.35);
  const vis = t >= a - 0.01 && t <= b + 0.4;
  return { vis, en, ex, op: clamp(en * 2) * (1 - ex), dy: (1 - en) * 34 - ex * 18 };
};

const Stage: React.FC<{ t: number }> = ({ t }) => {
  const sc = {
    intro: win(t, 0, T.dua - 0.1),
    cal: win(t, T.dua - 0.15, T.demo - 0.1),
    aksi: win(t, T.demo - 0.15, T.polri - 0.15),
    polri: win(t, T.polri - 0.15, T.skenario - 0.15),
    scroll: win(t, T.skenario - 0.15, T.dilacak - 0.15),
    cari: win(t, T.dilacak - 0.15, T.tersandera - 0.15),
    lock: win(t, T.tersandera - 0.15, END + 1),
  };
  const g = (s: ReturnType<typeof win>) => ({ opacity: s.op, transform: `translate(0 ${s.dy})` });
  const dx = (t * 6) % 60;
  const wave = (y: number) => `M-60 ${y} q15 -10 30 0${' t30 0'.repeat(17)} L480 260 L-60 260Z`;
  return (
    <svg x={0} y={0} width={1080} height={L.stage.h} viewBox={`0 0 ${L.stage.vbW} ${L.stage.vbH}`} style={{ position: 'absolute', left: 0, top: L.stage.y }}>
      <g filter="url(#pu)"><g transform={`translate(${dx} 0)`}><path d={wave(150)} fill={C.blueMid} /></g></g>
      <g filter="url(#pu)"><g transform={`translate(${-dx * 0.7} 0)`}><path d={wave(176)} fill={C.tealSoft} /></g></g>

      {sc.intro.vis && (
        <g {...(g(sc.intro) as object)}>
          <g filter="url(#ps)">
            <rect x={160} y={44} width={40} height={70} rx={20} fill={C.blue} />
            <path d="M146 92 q0 38 34 38 q34 0 34 -38" stroke={C.ink} strokeWidth={5} fill="none" strokeLinecap="round" />
            <rect x={174} y={128} width={12} height={22} fill={C.ink} /><rect x={154} y={148} width={52} height={8} rx={4} fill={C.ink} />
          </g>
          {[0, 1, 2, 3, 4, 5].map((i) => { const h = 12 + 16 * Math.abs(Math.sin(t * 6 + i * 1.3)); const x = i < 3 ? 100 + i * 14 : 236 + (i - 3) * 14; return <rect key={i} x={x} y={80 - h / 2} width={8} height={h} rx={4} fill={[C.yellow, C.teal, C.red][i % 3]} />; })}
          <Chip x={180} y={176} w={96} text="Podcast" fill={C.yellow} k={sc.intro.en} fs={13} />
        </g>
      )}

      {sc.cal.vis && (
        <g {...(g(sc.cal) as object)}>
          <g filter="url(#ps)" transform={`rotate(${Math.sin(t * 2) * 1.5} 180 100)`}>
            <rect x={120} y={26} width={120} height={134} rx={14} fill={C.white} />
            <path d="M120 40 a14 14 0 0 1 14 -14 h92 a14 14 0 0 1 14 14 v22 h-120Z" fill={C.red} />
            <circle cx={148} cy={26} r={6} fill={C.ink} /><circle cx={212} cy={26} r={6} fill={C.ink} />
            <text x={180} y={54} textAnchor="middle" fontSize={20} fontWeight={700} fill={C.ink}>OKT</text>
            <text x={180} y={132} textAnchor="middle" fontSize={62} fontWeight={700} fill={C.ink}>20</text>
          </g>
        </g>
      )}

      {sc.aksi.vis && (
        <g {...(g(sc.aksi) as object)}>
          <g filter="url(#ps)">
            <polygon points="226,70 278,40 330,70" fill={C.sunOuter} />
            <rect x={226} y={70} width={104} height={8} fill={C.white} />
            {[0, 1, 2, 3, 4].map((i) => <rect key={i} x={234 + i * 20} y={78} width={10} height={62} fill={C.white} />)}
            <rect x={222} y={140} width={112} height={10} rx={3} fill={C.white} />
            <rect x={277} y={22} width={3} height={20} fill={C.ink} /><rect x={280} y={22} width={18} height={6} fill={C.red} /><rect x={280} y={28} width={18} height={6} fill={C.white} />
          </g>
          <g filter="url(#ps)"><circle cx={34} cy={96} r={22} fill={C.blue} /><rect x={32} y={116} width={4} height={34} fill={C.ink} /></g>
          <text x={34} y={103} textAnchor="middle" fontSize={20} fontWeight={700} fill={C.ink}>HI</text>
          <g filter="url(#ps)">
            {Array.from({ length: 9 }, (_, i) => {
              const e = eOut(prog(t, T.demo + i * 0.12, 1.6));
              const tx = 70 + i * 17 + (i % 2) * 3, sx = -40 - i * 8;
              return <Person key={i} x={lerp(sx, tx, e)} y={158 + (i % 3) * 3} s={1.12} fill={[C.yellow, C.teal, C.red, C.blue][i % 4]} t={t} ph={i * 0.9} banner={i % 3 === 0 ? [C.red, C.yellow, C.teal][(i / 3) | 0] : undefined} lean={(1 - e) * 6} />;
            })}
          </g>
          <Chip x={34} y={170} w={36} text="HI" fill={C.yellow} k={eBack(prog(t, T.hi, 0.4))} fs={12} />
          <Chip x={278} y={172} w={68} text="Istana" fill={C.yellow} k={eBack(prog(t, T.istana, 0.4))} fs={13} />
        </g>
      )}

      {sc.polri.vis && (
        <g {...(g(sc.polri) as object)}>
          <g filter="url(#ps)" transform={`rotate(${Math.sin(t * 1.4) * 2} 70 90)`}>
            <path d="M40 52 L100 52 L100 92 Q100 124 70 140 Q40 124 40 92Z" fill={C.blue} />
            <path d="M70 72 l5 11 12 1 -9 8 3 12 -11 -6 -11 6 3 -12 -9 -8 12 -1Z" fill={C.yellow} />
          </g>
          <g filter="url(#ps)"><Magnifier x={140 + Math.sin(t * 1.6) * 16} y={72 + Math.cos(t * 1.2) * 6} r={26} /></g>
          <Chip x={70} y={166} w={62} text="Polri" fill={C.yellow} k={eBack(prog(t, T.polri, 0.4))} fs={13} />
          <Chip x={262} y={30} w={92} text="diselidiki" fill={C.tealSoft} k={eBack(prog(t, T.selidik, 0.4))} fs={13} />
          <Chip x={262} y={56} w={112} text="tujuannya apa?" fill={C.redSoft} k={eBack(prog(t, T.tujuan, 0.4))} fs={12} />
          <g filter="url(#ps)" opacity={clamp(prog(t, T.turun - 0.1, 0.4))}>
            {[0, 1, 2, 3].map((i) => <Person key={i} x={240 + i * 20} y={lerp(100, 156, eOut(prog(t, T.turun + i * 0.1, 0.8)))} s={1.1} fill={[C.yellow, C.teal, C.red, C.blue][i]} t={t} ph={i} />)}
          </g>
          <Chip x={270} y={178} w={86} text="buruh turun" fill={C.yellow} k={eBack(prog(t, T.turun, 0.4))} fs={11} />
        </g>
      )}

      {sc.scroll.vis && (
        <g {...(g(sc.scroll) as object)}>
          <g filter="url(#ps)">
            <rect x={96} y={46} width={168} height={104} rx={8} fill={C.white} />
            <rect x={86} y={40} width={16} height={116} rx={8} fill={C.sunMid} /><rect x={258} y={40} width={16} height={116} rx={8} fill={C.sunMid} />
            <text x={180} y={90} textAnchor="middle" fontSize={24} fontWeight={700} fill={C.ink}>SKENARIO</text>
            <text x={180} y={134} textAnchor="middle" fontSize={40} fontWeight={700} fill={C.red}>?</text>
          </g>
          {[0, 1, 2].map((i) => <text key={i} x={70 + i * 110} y={44 + Math.sin(t * 3 + i) * 5} textAnchor="middle" fontSize={26} fontWeight={700} fill={C.yellow}>?</text>)}
        </g>
      )}

      {sc.cari.vis && (
        <g {...(g(sc.cari) as object)}>
          {t < T.saya ? (
            <g>
              <g filter="url(#ps)"><rect x={130} y={56} width={100} height={78} rx={10} fill={C.white} /><text x={180} y={110} textAnchor="middle" fontSize={46} fontWeight={700} fill={C.red}>?</text></g>
              <g filter="url(#ps)"><Magnifier x={166 + Math.sin(t * 1.8) * 22} y={78 + Math.cos(t * 1.3) * 8} r={30} /></g>
              <Chip x={90} y={168} w={72} text="dilacak" fill={C.tealSoft} k={eBack(prog(t, T.dilacak, 0.4))} fs={13} />
              <Chip x={270} y={168} w={96} text="tujuan apa?" fill={C.redSoft} k={eBack(prog(t, T.tujuan2, 0.4))} fs={13} />
            </g>
          ) : (
            <g transform={`scale(${eBack(prog(t, T.saya, 0.5))}) `} style={{ transformOrigin: '180px 100px' }}>
              <g filter="url(#ps)">
                <rect x={110} y={40} width={140} height={92} rx={28} fill={C.white} />
                <path d="M150 130 l-10 24 l32 -24Z" fill={C.white} />
                <text x={180} y={112} textAnchor="middle" fontSize={78} fontWeight={700} fill={C.blue}>“”</text>
              </g>
            </g>
          )}
        </g>
      )}

      {sc.lock.vis && (
        <g {...(g(sc.lock) as object)}>
          <g filter="url(#ps)" transform={`rotate(${Math.sin(t * 2.4) * 2.5} 160 100)`}>
            {[0, 1, 2].map((i) => <ellipse key={i} cx={58 + i * 22} cy={110 + (i % 2) * 6} rx={14} ry={8} fill="none" stroke={C.ink} strokeWidth={5} />)}
            <path d="M130 84 v-18 a30 30 0 0 1 60 0 v18" stroke={C.ink} strokeWidth={9} fill="none" strokeLinecap="round" />
            <rect x={116} y={82} width={88} height={64} rx={14} fill={C.yellow} />
            <circle cx={160} cy={108} r={8} fill={C.ink} /><rect x={157} y={110} width={6} height={20} rx={3} fill={C.ink} />
          </g>
          <g transform={`translate(262 96) scale(${eBack(prog(t, T.tepat, 0.5))})`} opacity={clamp(prog(t, T.tepat, 0.2))}>
            <g filter="url(#ps)"><circle r={40} fill={C.teal} /><path d="M-18 2 L-5 16 L20 -14" stroke={C.ink} strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" /></g>
          </g>
          <Chip x={160} y={172} w={90} text="tersandera" fill={C.yellow} k={eBack(prog(t, T.tersandera, 0.4))} fs={13} />
          <Chip x={262} y={150} w={80} text="sudah tepat" fill={C.tealSoft} k={eBack(prog(t, T.tepat, 0.4))} fs={12} />
        </g>
      )}
    </svg>
  );
};

// ---------- caption ----------
const CHUNKS: W[][] = (() => {
  const out: W[][] = []; let cur: W[] = [];
  for (const w of WORDS) {
    cur.push(w);
    const brk = /[.,?!]$/.test(w.w) && cur.length >= 3;
    if (cur.length >= 7 || brk) { out.push(cur); cur = []; }
  }
  if (cur.length) out.push(cur);
  return out;
})();
const Caption: React.FC<{ t: number }> = ({ t }) => {
  let idx = 0;
  for (let i = 0; i < CHUNKS.length; i++) if (CHUNKS[i][0].start <= t + 0.05) idx = i;
  const ch = CHUNKS[idx]; const cp = L.caption;
  return (
    <div style={{ position: 'absolute', left: 0, top: cp.y, width: 1080, height: cp.h, background: C.white, borderTopLeftRadius: cp.radius, borderTopRightRadius: cp.radius, filter: theme.cardShadowCss }}>
      <div style={{ position: 'absolute', left: cp.pad, top: 24, width: 1080 - cp.pad * 2, height: cp.h - 48, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignContent: 'center', gap: '6px 16px' }}>
        {ch.map((w, k) => {
          const on = t >= w.start && t < w.end + 0.05, done = t >= w.end + 0.05;
          const kk = on ? 1 + 0.1 * Math.sin(clamp((t - w.start) / Math.max(0.12, w.end - w.start)) * Math.PI) : 1;
          return <span key={k} style={{ fontSize: cp.font, lineHeight: `${cp.lineH}px`, fontWeight: 700, color: done || on ? C.ink : C.inkSoft, background: on ? C.yellow : 'transparent', borderRadius: 22, padding: '0 14px', display: 'inline-block', transform: `scale(${kk})` }}>{w.w}</span>;
        })}
      </div>
    </div>
  );
};

// ---------- komposisi inti ----------
export function Video({ t, fontFamily, footage }: { t: number; fontFamily?: string; footage?: React.ReactNode }) {
  const cd = L.card;
  let ci = 0;
  for (let i = 0; i < CUTS.length; i++) if (t >= CUTS[i].out0) ci = i;
  const cut = CUTS[ci];
  const p = clamp((t - cut.out0) / Math.max(0.01, cut.out1 - cut.out0));
  const zoom = (ci % 2 === 0 ? theme.edit.zoomA : theme.edit.zoomB) * (1 + theme.edit.push * p);
  const calK = eBack(prog(t, T.dua, 0.5)) * (1 - prog(t, T.polri, 0.3));
  const attrOn = theme.text.attribution && t >= T.skenario;
  const attrText = t >= T.saya ? TX.attrOpinion : TX.attrClaim;
  const attrK = eBack(prog(t, attrOn ? (t >= T.saya ? T.saya : T.skenario) : 1e9, 0.4));
  const intro = eBack(prog(t, 0.1, 0.6));
  return (
    <div style={{ position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, overflow: 'hidden', background: C.bg, fontFamily: fontFamily || theme.fontFallback }}>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{ position: 'absolute', left: 0, top: 0 }}>
        <defs>
          <filter id="ps" x="-15%" y="-15%" width="130%" height="135%"><feDropShadow dx="0" dy={theme.shadow.dy} stdDeviation={theme.shadow.blur} floodColor={C.ink} floodOpacity={theme.shadow.opacity} /></filter>
          <filter id="pu" x="-5%" y="-10%" width="110%" height="120%"><feDropShadow dx="0" dy={-theme.shadow.dy} stdDeviation={theme.shadow.blur} floodColor={C.ink} floodOpacity={theme.shadow.opacity} /></filter>
        </defs>
        <rect width={1080} height={1920} fill={C.bg} />
        <circle cx={960} cy={150} r={200} fill={C.sunOuter} style={{ filter: theme.cardShadowCss }} />
        <circle cx={960} cy={150} r={140} fill={C.sunMid} style={{ filter: theme.cardShadowCss }} />
      </svg>

      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{ position: 'absolute', left: 0, top: 0 }}>
        <g transform={`translate(${L.brand.x} ${L.brand.y}) scale(${intro})`} opacity={clamp(intro * 2)} style={{ filter: theme.cardShadowCss }}>
          <rect width={TX.brand.length * 26 + 80} height={L.brand.h} rx={26} fill={C.white} />
          <circle cx={30} cy={26} r={9} fill={C.yellow} />
          <text x={52} y={36} fontSize={28} fontWeight={700} fill={C.ink}>{TX.brand}</text>
        </g>
        <g transform={`translate(${L.title.x + L.title.w / 2} ${L.title.y + L.title.h / 2}) scale(${intro})`} opacity={clamp(intro * 2)} style={{ filter: theme.cardShadowCss }}>
          <rect x={-L.title.w / 2} y={-L.title.h / 2} width={L.title.w} height={L.title.h} rx={32} fill={C.white} />
          <text y={L.title.font * 0.35} textAnchor="middle" fontSize={L.title.font} fontWeight={700} fill={C.ink}>{TX.title}</text>
        </g>
      </svg>

      <Stage t={t} />

      <div style={{ position: 'absolute', left: cd.x, top: cd.y, width: cd.w, height: cd.h, filter: theme.cardShadowCss }}>
        <div style={{ position: 'absolute', inset: 0, background: C.white, borderRadius: cd.radius, padding: cd.pad }}>
          <div style={{ position: 'relative', width: '100%', height: '100%', borderRadius: cd.radius - cd.pad, overflow: 'hidden', background: C.blueSoft }}>
            <div style={{ position: 'absolute', inset: 0, transform: `scale(${zoom})`, transformOrigin: '50% 40%' }}>{footage}</div>
          </div>
        </div>
      </div>

      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{ position: 'absolute', left: 0, top: 0, pointerEvents: 'none' }}>
        <g transform={`translate(${cd.x + 40} ${cd.y + 18}) scale(1)`} opacity={clamp(intro * 2)} style={{ filter: theme.cardShadowCss }}>
          <rect width={TX.sourceLabel.length * 15 + 40} height={38} rx={19} fill={C.white} />
          <text x={20} y={26} fontSize={22} fontWeight={700} fill={C.ink}>{TX.sourceLabel}</text>
        </g>
        <g transform={`translate(${cd.x + cd.w - 120} ${cd.y + 40}) rotate(8) scale(${calK})`} opacity={clamp(calK * 2)} style={{ filter: theme.cardShadowCss }}>
          <rect x={-70} y={-70} width={140} height={150} rx={20} fill={C.white} />
          <path d="M-70 -50 a20 20 0 0 1 20 -20 h100 a20 20 0 0 1 20 20 v28 h-140Z" fill={C.red} />
          <text y={-34} textAnchor="middle" fontSize={26} fontWeight={700} fill={C.ink}>OKT</text>
          <text y={52} textAnchor="middle" fontSize={68} fontWeight={700} fill={C.ink}>20</text>
        </g>
        {attrOn && (
          <g transform={`translate(${cd.x + 24} ${cd.y + cd.h - 30}) scale(${attrK})`} opacity={clamp(attrK * 2)} style={{ filter: theme.cardShadowCss }}>
            <rect width={attrText.length * 17 + 56} height={52} rx={26} fill={C.yellow} />
            <text x={28} y={35} fontSize={28} fontWeight={700} fill={C.ink}>{attrText}</text>
          </g>
        )}
      </svg>

      <Caption t={t} />
    </div>
  );
}
