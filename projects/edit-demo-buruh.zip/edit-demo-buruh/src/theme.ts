// Satu-satunya sumber warna, ukuran, dan teks tetap. Ganti di sini untuk mengubah seluruh tampilan.
// Aturan: latar terang, teks gelap kontras tinggi, 1 warna dasar terang + 4 aksen jenuh (+ tint terangnya).
export const theme = {
  canvas: { width: 1080, height: 1920 },
  fps: 30,
  tail: 0.5, // jeda setelah footage selesai (detik)
  color: {
    bg: '#FFF4DC',
    ink: '#1B2A3A',
    inkSoft: '#5B6B7B',
    white: '#FFFFFF',
    // 4 aksen jenuh
    blue: '#2D9CDB',
    teal: '#00BFA6',
    yellow: '#FFC93C',
    red: '#FF5D5D',
    // tint terang dari aksen
    sunOuter: '#FFEDB8',
    sunMid: '#FFD966',
    blueSoft: '#CDEEFB',
    blueMid: '#9ADCF5',
    tealSoft: '#CFF3EC',
    redSoft: '#FFDAD8',
    skin: '#FFD9B8',
  },
  shadow: { dy: 3.5, blur: 2.6, opacity: 0.28 }, // bayangan kertas di stage (unit SVG)
  cardShadowCss: 'drop-shadow(0 12px 14px rgba(27,42,58,0.28))', // bayangan kartu footage & panel
  layout: {
    brand: { x: 60, y: 28, h: 52 },
    title: { x: 60, y: 92, w: 960, h: 96, font: 58 },
    card: { x: 60, y: 224, w: 960, h: 660, pad: 12, radius: 52 },
    stage: { y: 904, h: 630, vbW: 360, vbH: 210 }, // viewBox 360x210 diskalakan 3x
    caption: { y: 1560, h: 360, font: 64, lineH: 80, radius: 56, pad: 60 },
  },
  text: {
    brand: 'Idin Riset', // nama channel (hapus bila tidak dipakai)
    title: 'Demo Buruh 20 Oktober',
    sourceLabel: 'Cuplikan podcast',
    attribution: true, // tampilkan penanda "menurut narasumber" pada bagian klaim/opini
    attrClaim: 'Skenario menurut narasumber',
    attrOpinion: 'Pendapat narasumber',
  },
  edit: {
    zoomA: 1.0, // zoom dasar potongan genap
    zoomB: 1.09, // zoom dasar potongan ganjil (efek jump cut)
    push: 0.035, // dorongan zoom pelan selama satu potongan
  },
  fontFallback: "'Fredoka','Baloo 2','Arial Rounded MT Bold','Trebuchet MS',sans-serif",
};
export type Theme = typeof theme;
