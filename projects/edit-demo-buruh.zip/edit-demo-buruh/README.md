# edit-demo-buruh

Edit podcast gaya talking head + visual paper-cut. 9:16 (1080x1920), 30 fps, ±50 detik (dari footage 57,6 detik).
Komposisi: `EditDemoBuruh`. Footage dipotong otomatis (jump cut) dan diberi caption per kata + ilustrasi yang muncul tepat saat kata kuncinya diucapkan.

## Struktur

```
edit-demo-buruh/
├── package.json        # remotion & @remotion/* dipin 4.0.250, skrip "render"
├── tsconfig.json
├── timing.cjs          # membuat src/timing.json (silencedetect + DP ke kalimat SRT + rencana potong)
├── input/podcast.srt   # SRT sumber teks
├── public/footage.mp4  # footage mentah (diputar per potongan oleh Remotion)
└── src/
    ├── index.ts        # registerRoot
    ├── Root.tsx        # frame -> t, satu <Sequence>+<OffthreadVideo> per potongan
    ├── Video.tsx       # komposisi inti React murni: Video({ t, footage })
    ├── theme.ts        # semua warna, ukuran, teks (judul, nama channel, penanda narasumber)
    └── timing.json     # durasi, daftar potongan, waktu tiap kata (waktu hasil edit)
```

## Menjalankan di GitHub Actions (render-remotion.yml, workflow_dispatch)

1. `actions/checkout`, `actions/setup-node` (Node 18+ atau 20).
2. `working-directory: edit-demo-buruh`, lalu `npm install` (tanpa lockfile; jangan `npm ci`).
3. `npm run render` -> `edit-demo-buruh/out/video.mp4`.
4. `actions/upload-artifact` untuk `edit-demo-buruh/out/video.mp4`.

## Yang bisa diubah di `src/theme.ts`

- `text.title`, `text.brand` (nama channel; kosongkan bila tidak dipakai), `text.sourceLabel`.
- `text.attribution`: `true` menampilkan penanda "Skenario menurut narasumber" / "Pendapat narasumber" pada bagian klaim dan opini; `false` untuk mematikan.
- `edit.zoomA/zoomB/push`: kekuatan zoom jump cut.
- Warna, bayangan, dan tata letak (kartu footage, stage, caption).

## Membuat ulang timing / potongan

Ganti `public/footage.mp4` dan `input/podcast.srt`, lalu `node timing.cjs` (butuh `ffmpeg`/`ffprobe`). Jeda > 0,45 detik dipangkas (sisa 0,1 detik tiap sisi); jeda pendek dipertahankan. Cue ilustrasi dibaca dari kata di timing.json lewat `cue('kata')` di `Video.tsx`; jika teks SRT berubah, sesuaikan kata cue-nya (cue yang hilang membuat render gagal dengan pesan jelas).

## Catatan

- Samakan versi Remotion dengan repo-mu (`4.0.250`).
- Font Fredoka lewat `@remotion/google-fonts` (perlu internet di runner).
- Ini cuplikan dari podcast pihak lain: pastikan hak/izin pemakaiannya sebelum diunggah, dan pertimbangkan mencantumkan kredit sumber.
