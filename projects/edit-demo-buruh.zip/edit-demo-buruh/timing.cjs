#!/usr/bin/env node
// Timing + rencana potong dari footage:
//   ffmpeg silencedetect -> DP monoton ke kalimat (SRT) -> waktu per kata -> daftar potongan (jump cut)
// Pakai: node timing.cjs [footage] [srt] [out]    env: FPS (30), W (1080), H (1920)
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const footage = process.argv[2] || path.join(__dirname, 'public', 'footage.mp4');
const srtFile = process.argv[3] || path.join(__dirname, 'input', 'podcast.srt');
const out = process.argv[4] || path.join(__dirname, 'src', 'timing.json');
const FPS = +(process.env.FPS || 30), W = +(process.env.W || 1080), H = +(process.env.H || 1920);
const NOISE = '-35dB', MIN_SIL = 0.25, MIN_SEG = 0.05;
const PAD = 0.10;        // sisa jeda di tiap sisi potongan (detik)
const KEEP_GAP = 0.45;   // jeda <= ini dipertahankan utuh; lebih panjang dipotong
const r3 = (x) => Math.round(x * 1000) / 1000;

const dur = parseFloat(spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', footage], { encoding: 'utf8' }).stdout);
if (!(dur > 0)) throw new Error('ffprobe gagal membaca durasi footage');

// 1. jeda -> segmen bicara
const sd = spawnSync('ffmpeg', ['-hide_banner', '-nostats', '-i', footage, '-vn', '-af', `silencedetect=noise=${NOISE}:d=${MIN_SIL}`, '-f', 'null', '-'], { encoding: 'utf8' });
const sil = []; let open = null;
for (const line of sd.stderr.split(/[\r\n]+/)) {
  let m;
  if ((m = line.match(/silence_start:\s*(-?[\d.]+)/))) open = Math.max(0, parseFloat(m[1]));
  else if ((m = line.match(/silence_end:\s*(-?[\d.]+)/)) && open !== null) { sil.push([open, parseFloat(m[1])]); open = null; }
}
if (open !== null) sil.push([open, dur]);
const segs = []; let cur = 0;
for (const [a, b] of sil) { if (a - cur > MIN_SEG) segs.push({ a: cur, b: a }); cur = Math.max(cur, b); }
if (dur - cur > MIN_SEG) segs.push({ a: cur, b: dur });

// 2. SRT -> unit kalimat (dipecah di . ? !), dengan perkiraan awal dari waktu cue SRT
const ts = (s) => { const m = s.match(/(\d+):(\d+):(\d+)[,.](\d+)/); return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000; };
const cues = fs.readFileSync(srtFile, 'utf8').replace(/\r/g, '').trim().split(/\n\s*\n/).map((b) => {
  const l = b.split('\n'); const t = l.find((x) => x.includes('-->')); const [s, e] = t.split('-->').map(ts);
  return { s, e, text: l.slice(l.indexOf(t) + 1).join(' ').trim() };
});
const units = [];
for (const c of cues) {
  const parts = c.text.split(/(?<=[.?!])\s+/).filter(Boolean);
  const tot = parts.reduce((a, p) => a + p.length, 0); let acc = 0;
  for (const p of parts) { units.push({ text: p, prior: c.s + ((c.e - c.s) * acc) / tot }); acc += p.length; }
}
const chars = units.map((u) => u.text.replace(/[^\p{L}\p{N}]/gu, '').length);
const N = units.length, M = segs.length;
if (M < N) throw new Error(`segmen bicara (${M}) < kalimat (${N})`);

// 3. DP monoton: biaya = penyimpangan laju bicara + jarak ke perkiraan SRT + penalti gabung segmen
const median = (xs) => { const s = [...xs].sort((a, b) => a - b); return s[Math.floor(s.length / 2)]; };
let r0 = chars.reduce((a, b) => a + b, 0) / segs.reduce((a, s) => a + (s.b - s.a), 0);
let assign;
for (let it = 0; it < 4; it++) {
  const INF = 1e18;
  const dp = Array.from({ length: N + 1 }, () => new Array(M + 1).fill(INF));
  const bp = Array.from({ length: N + 1 }, () => new Array(M + 1).fill(-1));
  dp[0][0] = 0;
  for (let i = 1; i <= N; i++) for (let j = i; j <= M; j++) for (let a = i - 1; a < j; a++) {
    if (dp[i - 1][a] >= INF) continue;
    const span = segs[j - 1].b - segs[a].a;
    const c = Math.abs(Math.log(chars[i - 1] / span / r0)) + 0.25 * Math.abs(segs[a].a - units[i - 1].prior) + 0.05 * (j - a - 1);
    if (dp[i - 1][a] + c < dp[i][j]) { dp[i][j] = dp[i - 1][a] + c; bp[i][j] = a; }
  }
  if (dp[N][M] >= INF) throw new Error('DP gagal');
  assign = new Array(N);
  for (let i = N, j = M; i > 0; i--) { const a = bp[i][j]; assign[i - 1] = [a, j]; j = a; }
  r0 = median(assign.map(([a, b], i) => chars[i] / (segs[b - 1].b - segs[a].a)));
}

// 4. waktu tiap kata (waktu sumber), melompati jeda di dalam kalimat
const unitsOut = units.map((u, i) => {
  const [a, b] = assign[i]; const ss = segs.slice(a, b);
  const total = ss.reduce((acc, s) => acc + (s.b - s.a), 0);
  const words = u.text.split(/\s+/);
  const wt = words.map((w) => w.replace(/[^\p{L}\p{N}]/gu, '').length + 1.2);
  const sum = wt.reduce((x, y) => x + y, 0);
  const at = (f) => { let rest = f * total; for (const s of ss) { const d = s.b - s.a; if (rest <= d) return s.a + rest; rest -= d; } return ss[ss.length - 1].b; };
  let acc = 0;
  const ws = words.map((w, k) => { const s = at(acc / sum); acc += wt[k]; return { w, s, e: at(acc / sum) }; });
  return { text: u.text, s: ss[0].a, e: ss[ss.length - 1].b, chars: chars[i], words: ws };
});

// 5. rencana potong (jump cut): jeda panjang dipangkas, jeda pendek dipertahankan
const used = []; for (const [a, b] of assign) for (let k = a; k < b; k++) used.push(segs[k]);
const iv = [];
for (const s of used) {
  const lo = Math.max(0, s.a - PAD), hi = Math.min(dur, s.b + PAD);
  const last = iv[iv.length - 1];
  if (last && s.a - last.speechEnd <= KEEP_GAP) { last.hi = hi; last.speechEnd = s.b; } else iv.push({ lo, hi, speechEnd: s.b });
}
let o = 0;
const cuts = iv.map((x) => { const c = { src0: r3(x.lo), src1: r3(x.hi), out0: r3(o), out1: r3(o + (x.hi - x.lo)) }; o += x.hi - x.lo; return c; });
const mapT = (s) => {
  for (const c of cuts) if (s >= c.src0 - 1e-6 && s <= c.src1 + 1e-6) return c.out0 + (s - c.src0);
  for (const c of cuts) if (s < c.src0) return c.out0;
  return cuts[cuts.length - 1].out1;
};

// 6. laporan laju bicara + keluaran
const rates = unitsOut.map((u) => u.chars / (u.e - u.s)); const med = median(rates);
unitsOut.forEach((u, i) => { const x = rates[i] / med; console.log(`${String(i).padStart(2)} src ${u.s.toFixed(2).padStart(6)}-${u.e.toFixed(2).padStart(6)}  ${rates[i].toFixed(1).padStart(5)} c/s x${x.toFixed(2)}${x < 0.6 || x > 1.6 ? '  <-- LAJU ANEH' : ''}  ${u.text.slice(0, 44)}`); });
const words = [];
const units2 = unitsOut.map((u, i) => {
  const ws = u.words.map((w) => ({ w: w.w, start: r3(mapT(w.s)), end: r3(mapT(w.e)), unit: i }));
  words.push(...ws);
  return { i, text: u.text, start: r3(mapT(u.s)), end: r3(mapT(u.e)) };
});
const outDur = cuts[cuts.length - 1].out1;
console.log(`sumber ${dur.toFixed(2)}s -> hasil ${outDur.toFixed(2)}s, ${cuts.length} potongan, ${words.length} kata`);
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, JSON.stringify({ footage: 'footage.mp4', srcDuration: r3(dur), duration: r3(outDur), fps: FPS, width: W, height: H, noise: NOISE, minSilence: MIN_SIL, cuts, units: units2, words }, null, 1));
console.log('tulis', out);
