import React from 'react';
import { Audio, Composition, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { Video } from './Video';
import timing from './timing.json';

const WrappedVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  return <><Video t={frame / fps} /><Audio src={staticFile('narasi.mp3')} /></>;
};

export const RemotionRoot: React.FC = () => (
  <Composition
    id="SadapPresiden"
    component={WrappedVideo}
    durationInFrames={Math.ceil((timing.duration + 0.15) * timing.fps)}
    fps={timing.fps}
    width={timing.width}
    height={timing.height}
  />
);
