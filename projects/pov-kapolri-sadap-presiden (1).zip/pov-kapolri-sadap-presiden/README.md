# POV Kapolri Sadap Presiden

Project Remotion 4.0.250 untuk video narasi vertikal 9:16, 1080x1920, 30 fps. Composition ID adalah `SadapPresiden`; render dilakukan melalui workflow `render-remotion.yml` milik pengguna.

## Isi project

- `public/narasi.mp3`: audio narasi.
- `narasi.srt` dan `narasi.txt`: subtitle dan teks sumber.
- `src/timing.json`: timing kalimat dan kata.
- `timing.cjs`: skrip reproduksi timing.
- `src/Video.tsx`: komposisi visual murni berbasis `t`.
- `src/theme.ts`: satu sumber warna, ukuran, shadow, dan timeline.
- `public/assets/`: karakter polisi, logo POLRI, ikon Zoom, dan gerobak bakso.

## GitHub Actions

Workflow pengguna perlu melakukan checkout, setup Node, menjalankan `npm install`, menjalankan `npm run render`, lalu mengunggah `out/video.mp4` sebagai artifact. Karena tidak disertakan lockfile, gunakan `npm install`, bukan `npm ci`.

Secara lokal setelah dependency tersedia:

```bash
npm install
npm run render
```

Versi Remotion dipatok ke `4.0.250`; semua paket `remotion` dan `@remotion/*`, termasuk `@remotion/cli`, harus tetap satu versi. `@remotion/cli` wajib ada karena workflow memanggil `npx remotion browser ensure` sebelum render.
