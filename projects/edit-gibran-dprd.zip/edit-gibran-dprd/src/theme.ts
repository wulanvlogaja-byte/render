// Semua warna, ukuran, dan teks yang bisa diubah ada di sini.
export const theme = {
  color: {
    bg: '#F4F8FC',
    white: '#FFFFFF',
    ink: '#1B2A3A',
    inkSoft: '#46566A',
    blue: '#2D9CDB',
    blueTint: '#D6ECFA',
    teal: '#00BFA6',
    tealTint: '#CFF3EE',
    yellow: '#FFC93C',
    yellowTint: '#FFF1C7',
    red: '#FF5D5D',
    redTint: '#FFDCDC',
    shadow: 'rgba(27,42,58,0.30)',
    shadowFlood: '#1B2A3A',
  },
  text: {
    // Kosongkan channel untuk menyembunyikan chip nama channel.
    channel: '',
    title: 'Foto Wapres Diturunkan di DPRD DIY',
    sticker: 'Cuplikan video',
    // Kosongkan string ini untuk mematikan chip atribusi.
    attribution: 'Dugaan dalam narasi',
  },
  audio: {
    narasi: 1,
    footage: 0.18, // suara asli footage dipelankan di bawah narasi
  },
  layout: {
    headerTop: 28,
    footageTop: 224,
    footageW: 960,
    footageH: 660,
    stageTop: 904,
    captionTop: 1560,
    captionH: 360,
    captionFont: 64,
  },
  zoom: { a: 1.0, b: 1.09, drift: 0.035 },
  waves: { speed: 8 },
};
