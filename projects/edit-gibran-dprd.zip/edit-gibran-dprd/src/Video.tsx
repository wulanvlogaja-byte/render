import React from 'react';
import { theme as T } from './theme';
import timing from './timing.json';

type Word = { w: string; start: number; end: number; unit: number };
type Cut = { src0: number; src1: number; out0: number; out1: number };
const WORDS = timing.words as Word[];
const CUTS = timing.cuts as Cut[];
const END = timing.duration + timing.tail;
const C = T.color;

// ---------- util ----------
const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const easeOut = (x: number) => 1 - Math.pow(1 - clamp(x), 3);
const easeInOut = (x: number) => { const k = clamp(x); return k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2; };
const easeBack = (x: number) => { const k = clamp(x); const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };
const hash = (n: number) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

// ---------- cue dari kata ----------
const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9\u00c0-\u024f]/g, '');
const CUE_INDEX: Record<string, number[]> = {};
WORDS.forEach((w) => { const k = norm(w.w); (CUE_INDEX[k] = CUE_INDEX[k] || []).push(w.start); });
export const cue = (kata: string, n = 0): number => {
  const l = CUE_INDEX[norm(kata)];
  if (!l || l[n] === undefined) throw new Error(`cue tidak ditemukan: "${kata}" #${n}`);
  return l[n];
};

// ---------- jendela adegan ----------
const LEAD = 0.15;
const SC = {
  s1: [-0.6, cue('momen') - LEAD],
  s2: [cue('momen') - LEAD, cue('seperti') - LEAD],
  s3: [cue('seperti') - LEAD, cue('dinding', 1) - LEAD],
  s4: [cue('dinding', 1) - LEAD, cue('massa', 1) - LEAD],
  s5: [cue('massa', 1) - LEAD, cue('terdengar') - LEAD],
  s6: [cue('terdengar') - LEAD, cue('saat') - LEAD],
  s7: [cue('saat') - LEAD, cue('aksi') - LEAD],
  s8: [cue('aksi') - LEAD, cue('pascaputusan') - LEAD],
  s9: [cue('pascaputusan') - LEAD, END + 1],
};

const FF = React.createContext('sans-serif');

// ---------- elemen SVG ----------
function Scene({ t, w, children }: { t: number; w: number[]; children: React.ReactNode }) {
  const [a, b] = w;
  if (t < a - 0.05 || t > b + 0.4) return null;
  const inn = easeBack((t - a) / 0.5);
  const out = clamp((t - b) / 0.3);
  const op = clamp((t - a) / 0.2) * (1 - out);
  const sc = 0.86 + 0.14 * inn;
  const dy = (1 - inn) * 14 - out * 10;
  return <g opacity={op} transform={`translate(180 105) scale(${sc}) translate(-180 ${-105 + dy})`}>{children}</g>;
}

function Chip({ t, x, y, text, t0, dur = 2.4, fill = C.yellowTint }: { t: number; x: number; y: number; text: string; t0: number; dur?: number; fill?: string }) {
  const ff = React.useContext(FF);
  if (t < t0 || t > t0 + dur + 0.3) return null;
  const k = easeBack((t - t0) / 0.35);
  const fade = 1 - clamp((t - (t0 + dur)) / 0.3);
  const w = text.length * 7.9 + 24;
  return (
    <g transform={`translate(${x} ${y}) scale(${0.6 + 0.4 * k})`} opacity={clamp((t - t0) / 0.15) * fade}>
      <rect x={-w / 2} y={-13} width={w} height={26} rx={13} fill={fill} filter="url(#ps)" />
      <text textAnchor="middle" y={5} fontSize={13.5} fontWeight={700} fill={C.ink} style={{ fontFamily: ff }}>{text}</text>
    </g>
  );
}

const PCOL = [C.blue, C.teal, C.red, C.yellow];

function Person({ x, y, s = 1, c, arms = false, t = 0, ph = 0 }: { x: number; y: number; s?: number; c: string; arms?: boolean; t?: number; ph?: number }) {
  const lift = arms ? Math.sin(t * 5 + ph) * 2 : 0;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      {arms && (
        <>
          <path d={`M-6 -14 L-12 ${-31 + lift}`} stroke={c} strokeWidth={3.6} strokeLinecap="round" fill="none" />
          <path d={`M6 -14 L12 ${-31 - lift}`} stroke={c} strokeWidth={3.6} strokeLinecap="round" fill="none" />
        </>
      )}
      <path d="M-9 0 L-9 -12 Q-9 -19 0 -19 Q9 -19 9 -12 L9 0 Z" fill={c} />
      <circle cx={0} cy={-26} r={6.2} fill={c} />
    </g>
  );
}

function Frame({ x, y, w, h, rot = 0, tint, fg }: { x: number; y: number; w: number; h: number; rot?: number; tint: string; fg: string }) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot})`}>
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={2.5} fill={C.white} />
      <rect x={-w / 2 + 3.5} y={-h / 2 + 3.5} width={w - 7} height={h - 7} rx={1.5} fill={tint} />
      <circle cx={0} cy={-h * 0.1} r={w * 0.16} fill={fg} />
      <path d={`M${-w * 0.3} ${h / 2 - 3.5} Q${-w * 0.3} ${h * 0.08} 0 ${h * 0.08} Q${w * 0.3} ${h * 0.08} ${w * 0.3} ${h / 2 - 3.5} Z`} fill={fg} />
    </g>
  );
}

const Wall = ({ x = 50, y = 12, w = 260, h = 146 }: { x?: number; y?: number; w?: number; h?: number }) => (
  <rect x={x} y={y} width={w} height={h} rx={10} fill={C.blueTint} />
);

function Hand({ x, y }: { x: number; y: number }) {
  return <circle cx={x} cy={y} r={5.5} fill={C.yellow} />;
}

function Building({ x, y, color, s = 1 }: { x: number; y: number; color: string; s?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <path d="M-40 -52 L0 -80 L40 -52 Z" fill={color} />
      <rect x={-6} y={-70} width={12} height={14} rx={1.5} fill={C.white} />
      <rect x={-36} y={-52} width={72} height={52} fill={C.white} />
      {[-27, -9, 9, 27].map((cx) => <rect key={cx} x={cx - 3.5} y={-47} width={7} height={42} rx={1.5} fill={C.blueTint} />)}
      <rect x={-42} y={-4} width={84} height={6} rx={2} fill={C.white} />
    </g>
  );
}

function wavePath(y0: number, amp: number, p: number) {
  let d = `M-90 ${y0}`;
  for (let x = -90; x < 450; x += p) d += ` q${p / 4} ${-amp} ${p / 2} 0 t${p / 2} 0`;
  return d + ' L450 210 L-90 210 Z';
}

// ---------- adegan ----------
function S1({ t }: { t: number }) {
  const sway = Math.sin(t * 1.6) * 1.4;
  return (
    <g>
      <Wall x={80} y={10} w={200} h={150} />
      <g filter="url(#ps)">
        <g transform={`rotate(${sway} 180 22)`}>
          <path d="M180 22 L152 52 M180 22 L208 52" stroke={C.inkSoft} strokeWidth={1.4} fill="none" />
          <Frame x={180} y={92} w={80} h={100} tint={C.yellowTint} fg={C.blue} />
        </g>
        <circle cx={180} cy={22} r={3.6} fill={C.red} />
      </g>
      <Chip t={t} x={78} y={46} text="foto resmi" t0={cue('foto')} />
      <Chip t={t} x={282} y={136} text="Yogyakarta" t0={cue('yogyakarta')} fill={C.tealTint} />
      <Chip t={t} x={282} y={46} text="DPRD" t0={cue('dprd')} fill={C.blueTint} />
    </g>
  );
}

function S2({ t }: { t: number }) {
  const t0 = cue('empat');
  const ring = easeOut((t - t0) / 0.5);
  return (
    <g>
      <g filter="url(#ps)">
        <rect x={125} y={14} width={110} height={132} rx={12} fill={C.white} />
        <path d="M125 26 Q125 14 137 14 L223 14 Q235 14 235 26 L235 48 L125 48 Z" fill={C.yellow} />
        {[152, 208].map((cx) => <circle key={cx} cx={cx} cy={14} r={5} fill={C.white} stroke={C.inkSoft} strokeWidth={1.6} />)}
        <text x={180} y={38} textAnchor="middle" fontSize={15} fontWeight={700} fill={C.ink} style={{ fontFamily: React.useContext(FF) }}>NOV 2026</text>
        <text x={180} y={118} textAnchor="middle" fontSize={62} fontWeight={700} fill={C.ink} style={{ fontFamily: React.useContext(FF) }}>4</text>
      </g>
      <circle cx={180} cy={96} r={34} fill="none" stroke={C.red} strokeWidth={4} strokeLinecap="round" strokeDasharray={`${214 * ring} 214`} transform="rotate(-90 180 96)" />
      <Chip t={t} x={180} y={162} text="4 November 2026" t0={t0} />
    </g>
  );
}

function S3({ t }: { t: number }) {
  const [a, b] = SC.s3;
  const p = easeInOut((t - a) / (b - a));
  return (
    <g>
      <Wall x={205} y={10} w={140} h={148} />
      <g filter="url(#ps)">
        <Frame x={276} y={70} w={42} h={54} tint={C.yellowTint} fg={C.teal} />
        {Array.from({ length: 8 }).map((_, i) => (
          <Person key={i} x={22 + i * 22 + 36 * p + (hash(i) - 0.5) * 6} y={164 - (i % 2) * 6} s={1.35} c={PCOL[i % 4]} t={t} ph={i} arms={i % 3 === 0} />
        ))}
        <path d="M104 92 L190 92" stroke={C.red} strokeWidth={3} strokeDasharray="7 6" strokeDashoffset={-t * 22} fill="none" />
        <path d="M190 84 L204 92 L190 100 Z" fill={C.red} />
      </g>
      <Chip t={t} x={86} y={30} text="puluhan massa" t0={cue('puluhan')} fill={C.redTint} />
      <Chip t={t} x={86} y={62} text="audiensi" t0={cue('audiensi')} fill={C.blueTint} />
    </g>
  );
}

function S4({ t }: { t: number }) {
  return (
    <g>
      <Wall x={40} y={12} w={280} h={146} />
      <g filter="url(#ps)">
        <path d="M118 22 L98 58 M118 22 L138 58" stroke={C.inkSoft} strokeWidth={1.3} fill="none" />
        <path d="M242 22 L222 58 M242 22 L262 58" stroke={C.inkSoft} strokeWidth={1.3} fill="none" />
        <Frame x={118} y={96} w={62} h={80} tint={C.yellowTint} fg={C.blue} />
        <Frame x={242} y={96} w={62} h={80} tint={C.tealTint} fg={C.teal} />
        <circle cx={118} cy={22} r={3.2} fill={C.red} />
        <circle cx={242} cy={22} r={3.2} fill={C.red} />
      </g>
      <Chip t={t} x={60} y={34} text="presiden" t0={cue('presiden', 1)} fill={C.blueTint} dur={2.0} />
      <Chip t={t} x={300} y={34} text="wapres" t0={cue('presiden', 2)} fill={C.tealTint} dur={2.0} />
    </g>
  );
}

function S5({ t }: { t: number }) {
  const [a, b] = SC.s5;
  const p = easeInOut((t - a - 0.3) / (b - a - 0.6));
  const fy = 66 + 44 * p;
  return (
    <g>
      <Wall x={60} y={12} w={240} h={146} />
      <g filter="url(#ps)">
        {[40, 72, 104].map((x, i) => <Person key={x} x={x} y={164} s={1.5} c={PCOL[i]} t={t} ph={i * 2} arms />)}
        {[256, 288, 320].map((x, i) => <Person key={x} x={x} y={164} s={1.5} c={PCOL[(i + 2) % 4]} t={t} ph={i * 3} arms />)}
        <Frame x={180} y={fy} w={56} h={72} tint={C.yellowTint} fg={C.blue} />
        <Hand x={149} y={fy - 18} />
        <Hand x={211} y={fy - 18} />
      </g>
      <Chip t={t} x={104} y={26} text="bersama-sama" t0={cue('bersama-sama')} fill={C.tealTint} />
      <Chip t={t} x={262} y={26} text="menurunkan" t0={cue('menurunkan')} fill={C.redTint} />
    </g>
  );
}

function S6({ t }: { t: number }) {
  const bump = (t0: number) => { const d = t - t0; return d >= 0 && d < 0.4 ? Math.sin((d / 0.4) * Math.PI) : 0; };
  const b = Math.max(bump(cue('jangan', 0)), bump(cue('jangan', 1)));
  const ff = React.useContext(FF);
  return (
    <g>
      <g filter="url(#ps)">
        {[44, 76, 108, 140, 172].map((x, i) => <Person key={x} x={x} y={166} s={1.35} c={PCOL[i % 4]} t={t} ph={i} arms={i % 2 === 0} />)}
        <g transform={`translate(190 70) scale(${1 + 0.07 * b}) translate(-190 -70)`}>
          <rect x={80} y={14} width={220} height={100} rx={26} fill={C.white} stroke={C.red} strokeWidth={3.5} />
          <path d="M118 112 L100 142 L146 112 Z" fill={C.white} stroke={C.red} strokeWidth={3.5} strokeLinejoin="round" />
          <rect x={116} y={108} width={32} height={8} fill={C.white} />
          <text x={190} y={55} textAnchor="middle" fontSize={34} fontWeight={700} fill={C.ink} style={{ fontFamily: ff }}>Jangan</text>
          <text x={190} y={95} textAnchor="middle" fontSize={34} fontWeight={700} fill={C.ink} style={{ fontFamily: ff }}>dirusak!</text>
        </g>
      </g>
      {[0, 1, 2].map((i) => (
        <path key={i} d={`M${312 + i * 9} ${44 - i * 7} Q${324 + i * 9} 64 ${312 + i * 9} ${84 + i * 7}`} stroke={C.red} strokeWidth={3} fill="none" strokeLinecap="round" opacity={0.35 + 0.65 * Math.abs(Math.sin(t * 6 - i))} />
      ))}
      <Chip t={t} x={282} y={144} text="teriakan" t0={cue('teriakan')} fill={C.redTint} />
    </g>
  );
}

function S7({ t }: { t: number }) {
  const sw = Math.sin(t * 2.2) * 3;
  return (
    <g>
      <Wall x={40} y={12} w={280} h={146} />
      <rect x={82} y={40} width={62} height={80} rx={3} fill="none" stroke={C.inkSoft} strokeWidth={1.8} strokeDasharray="5 4" />
      <g filter="url(#ps)">
        <Person x={50} y={164} s={1.45} c={C.teal} t={t} arms />
        <Person x={316} y={164} s={1.45} c={C.red} t={t} ph={2} arms />
        <g transform={`translate(0 ${Math.sin(t * 2) * 2})`}>
          <Frame x={226} y={102} w={62} h={80} rot={-8 + sw} tint={C.yellowTint} fg={C.blue} />
          <Hand x={196} y={84} />
          <Hand x={254} y={72} />
        </g>
      </g>
      <Chip t={t} x={113} y={30} text="dilepas" t0={cue('dilepas')} fill={C.yellowTint} />
    </g>
  );
}

function S8({ t }: { t: number }) {
  const cols = [C.blue, C.teal, C.red];
  return (
    <g>
      {[0, 1, 2].map((i) => {
        const ph = ((t * 0.5 + i / 3) % 1);
        return <circle key={i} cx={180} cy={92} r={14 + 66 * ph} fill="none" stroke={C.teal} strokeWidth={3} opacity={(1 - ph) * 0.8} />;
      })}
      <g filter="url(#ps)">
        {[70, 180, 290].map((x, i) => (
          <g key={x}>
            <Building x={x} y={156} color={cols[i]} s={0.95} />
            <Frame x={x} y={118} w={12} h={15} tint={C.yellowTint} fg={C.blue} />
          </g>
        ))}
      </g>
      <Chip t={t} x={86} y={24} text="gelombang" t0={cue('gelombang')} fill={C.tealTint} />
      <Chip t={t} x={274} y={24} text="instansi" t0={cue('instansi')} fill={C.blueTint} />
    </g>
  );
}

function S9({ t }: { t: number }) {
  const pop = easeBack((t - cue('pendidikan')) / 0.5);
  const tap = Math.max(0, Math.sin(t * 3)) * 8;
  return (
    <g>
      <g filter="url(#ps)">
        <Building x={180} y={158} color={C.blue} s={1.25} />
        {/* gulungan */}
        <g transform="translate(60 112)">
          <rect x={-24} y={-34} width={48} height={68} rx={3} fill={C.white} />
          {[-18, -6, 6, 18].map((y) => <rect key={y} x={-15} y={y - 2} width={30} height={3.4} rx={1.7} fill={C.blueTint} />)}
          <rect x={-28} y={-38} width={56} height={9} rx={4.5} fill={C.yellow} />
          <rect x={-28} y={29} width={56} height={9} rx={4.5} fill={C.yellow} />
        </g>
        {/* palu */}
        <g transform={`translate(302 132) rotate(${-28 + tap})`}>
          <rect x={-6} y={-4} width={12} height={52} rx={5} fill={C.yellow} />
          <rect x={-26} y={-26} width={52} height={24} rx={7} fill={C.red} />
        </g>
        <ellipse cx={302} cy={162} rx={34} ry={7} fill={C.white} />
      </g>
      {pop > 0 && (
        <g transform={`translate(302 62) scale(${0.9 * clamp(pop, 0, 1.2)})`} filter="url(#ps)" opacity={clamp((t - cue('pendidikan')) / 0.15)}>
          <path d="M-30 4 L0 -10 L30 4 L0 18 Z" fill={C.teal} />
          <path d="M-16 12 L-16 26 Q0 34 16 26 L16 12 L0 19 Z" fill={C.teal} />
          <path d="M26 6 L26 24" stroke={C.yellow} strokeWidth={2.6} strokeLinecap="round" />
          <circle cx={26} cy={27} r={3.4} fill={C.yellow} />
        </g>
      )}
      <Chip t={t} x={112} y={26} text="Mahkamah Konstitusi" t0={cue('mahkamah')} fill={C.blueTint} dur={3.2} />
      <Chip t={t} x={60} y={66} text="Oktober" t0={cue('oktober')} fill={C.yellowTint} dur={3.0} />
      <Chip t={t} x={290} y={26} text="pendidikan" t0={cue('pendidikan')} fill={C.tealTint} dur={3.0} />
    </g>
  );
}

function Stage({ t }: { t: number }) {
  const ws = (t * T.waves.speed) % 90;
  return (
    <svg viewBox="0 0 360 210" width={1080} height={630} style={{ position: 'absolute', left: 0, top: T.layout.stageTop }}>
      <defs>
        <filter id="ps" x="-20%" y="-20%" width="140%" height="150%">
          <feDropShadow dx={0} dy={2.4} stdDeviation={1.7} floodColor={C.shadowFlood} floodOpacity={0.32} />
        </filter>
        <filter id="pu" x="-5%" y="-40%" width="110%" height="180%">
          <feDropShadow dx={0} dy={-2.2} stdDeviation={1.8} floodColor={C.shadowFlood} floodOpacity={0.25} />
        </filter>
      </defs>
      <Scene t={t} w={SC.s1}><S1 t={t} /></Scene>
      <Scene t={t} w={SC.s2}><S2 t={t} /></Scene>
      <Scene t={t} w={SC.s3}><S3 t={t} /></Scene>
      <Scene t={t} w={SC.s4}><S4 t={t} /></Scene>
      <Scene t={t} w={SC.s5}><S5 t={t} /></Scene>
      <Scene t={t} w={SC.s6}><S6 t={t} /></Scene>
      <Scene t={t} w={SC.s7}><S7 t={t} /></Scene>
      <Scene t={t} w={SC.s8}><S8 t={t} /></Scene>
      <Scene t={t} w={SC.s9}><S9 t={t} /></Scene>
      <g filter="url(#pu)">
        <path d={wavePath(176, 7, 90)} fill={C.tealTint} transform={`translate(${-ws * 0.7} 0)`} />
        <path d={wavePath(190, 6, 90)} fill={C.blueTint} transform={`translate(${-(90 - ws) * 0.9} 0)`} />
      </g>
    </svg>
  );
}

// ---------- caption ----------
type Chunk = { from: number; to: number; words: Word[] };
const CHUNKS: Chunk[] = (() => {
  const raw: Word[][] = [];
  const units = Array.from(new Set(WORDS.map((w) => w.unit)));
  units.forEach((u) => {
    const ws = WORDS.filter((w) => w.unit === u);
    const parts: Word[][] = [];
    let cur: Word[] = [];
    ws.forEach((w) => {
      cur.push(w);
      if (cur.length >= 7 || (cur.length >= 3 && /[,.;:!?]$/.test(w.w))) { parts.push(cur); cur = []; }
    });
    if (cur.length) parts.push(cur);
    const n = parts.length;
    if (n >= 2 && parts[n - 1].length < 3) {
      const all = parts[n - 2].concat(parts[n - 1]);
      const k = Math.ceil(all.length / 2);
      parts.splice(n - 2, 2, all.slice(0, k), all.slice(k));
    }
    parts.forEach((p) => raw.push(p));
  });
  return raw.map((words, i) => ({
    words,
    from: words[0].start - 0.05,
    to: i + 1 < raw.length ? raw[i + 1][0].start - 0.05 : END,
  }));
})();

function Caption({ t }: { t: number }) {
  const ch = CHUNKS.find((c) => t >= c.from && t < c.to) || (t < CHUNKS[0].from ? CHUNKS[0] : CHUNKS[CHUNKS.length - 1]);
  return (
    <div style={{
      position: 'absolute', left: 0, top: T.layout.captionTop, width: 1080, height: T.layout.captionH,
      background: C.white, borderTopLeftRadius: 64, borderTopRightRadius: 64,
      boxShadow: `0 -10px 30px ${C.shadow}`, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '24px 44px 40px',
      boxSizing: 'border-box',
    }}>
      <div style={{ textAlign: 'center', fontSize: T.layout.captionFont, lineHeight: 1.3, fontWeight: 700 }}>
        {ch.words.map((w, i) => {
          const active = w.start <= t && t < w.end;
          const past = t >= w.end;
          return (
            <span key={i} style={{
              display: 'inline-block', padding: '0 14px', margin: '2px 2px', borderRadius: 20,
              background: active ? C.yellow : 'transparent', color: active || past ? C.ink : C.inkSoft,
            }}>{w.w}</span>
          );
        })}
      </div>
    </div>
  );
}

// ---------- komposisi ----------
export function Video({ t, fontFamily, footage }: { t: number; fontFamily: string; footage: React.ReactNode }) {
  const L = T.layout;
  let idx = CUTS.findIndex((c) => t >= c.out0 && t < c.out1);
  if (idx < 0) idx = t < 0 ? 0 : CUTS.length - 1;
  const cut = CUTS[idx];
  const prog = clamp((t - cut.out0) / (cut.out1 - cut.out0));
  const zoom = (idx % 2 === 0 ? T.zoom.a : T.zoom.b) * (1 + T.zoom.drift * prog);
  const hasCh = !!T.text.channel;
  const cardY = hasCh ? 84 : 44;
  const showAttr = !!T.text.attribution && t >= SC.s8[0] && t <= END + 1;

  return (
    <FF.Provider value={fontFamily}>
      <div style={{ position: 'absolute', left: 0, top: 0, width: 1080, height: 1920, background: C.bg, overflow: 'hidden', fontFamily }}>
        {hasCh && (
          <div style={{ position: 'absolute', left: 60, top: L.headerTop, height: 48, padding: '0 28px', borderRadius: 24, background: C.blue, color: C.ink, fontSize: 28, fontWeight: 700, display: 'flex', alignItems: 'center' }}>{T.text.channel}</div>
        )}
        <div style={{ position: 'absolute', left: 60, top: cardY, width: 960, height: 188 - cardY + 8, boxSizing: 'border-box', background: C.white, borderRadius: 36, boxShadow: `0 10px 24px ${C.shadow}`, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '0 36px', textAlign: 'center', fontSize: 44, lineHeight: 1.12, fontWeight: 700, color: C.ink, textWrap: 'balance' as any }}>
          {T.text.title}
        </div>

        <div style={{ position: 'absolute', left: 60, top: L.footageTop, width: L.footageW, height: L.footageH, background: C.white, borderRadius: 48, boxShadow: `0 16px 32px ${C.shadow}` }}>
          <div style={{ position: 'absolute', left: 12, top: 12, width: L.footageW - 24, height: L.footageH - 24, borderRadius: 38, overflow: 'hidden', background: C.blueTint }}>
            <div style={{ position: 'absolute', inset: 0, transform: `scale(${zoom})`, transformOrigin: '50% 40%' }}>{footage}</div>
          </div>
          {!!T.text.sticker && (
            <div style={{ position: 'absolute', left: 22, top: -26, padding: '8px 24px', borderRadius: 22, background: C.yellow, color: C.ink, fontSize: 28, fontWeight: 700, transform: 'rotate(-4deg)', boxShadow: `0 6px 14px ${C.shadow}` }}>{T.text.sticker}</div>
          )}
          {showAttr && (
            <div style={{ position: 'absolute', left: '50%', bottom: -28, transform: 'translateX(-50%)', padding: '8px 30px', borderRadius: 30, background: C.white, border: `4px solid ${C.red}`, color: C.ink, fontSize: 30, fontWeight: 700, whiteSpace: 'nowrap', boxShadow: `0 6px 14px ${C.shadow}` }}>{T.text.attribution}</div>
          )}
        </div>

        <Stage t={t} />
        <Caption t={t} />
      </div>
    </FF.Provider>
  );
}
