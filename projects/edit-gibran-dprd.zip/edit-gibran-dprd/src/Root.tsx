import React from 'react';
import { Audio, Composition, OffthreadVideo, Sequence, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import timing from './timing.json';
import { theme } from './theme';
import { Video } from './Video';

const { fontFamily } = loadFont('normal', { weights: ['700'] });
const TOTAL = Math.ceil((timing.duration + timing.tail) * timing.fps);

const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const t = frame / fps;
  const last = timing.cuts.length - 1;
  const footage = (
    <>
      {timing.cuts.map((c, i) => {
        const from = Math.round(c.out0 * fps);
        const end = i === last ? TOTAL : Math.round(c.out1 * fps);
        return (
          <Sequence key={i} from={from} durationInFrames={end - from}>
            <OffthreadVideo
              src={staticFile(timing.footage)}
              startFrom={Math.round(c.src0 * fps)}
              volume={theme.audio.footage}
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
            />
          </Sequence>
        );
      })}
    </>
  );
  return (
    <>
      <Video t={t} fontFamily={fontFamily} footage={footage} />
      <Audio src={staticFile(timing.narasi)} volume={theme.audio.narasi} />
    </>
  );
};

export const RemotionRoot: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL} fps={timing.fps} width={timing.width} height={timing.height} />
);
