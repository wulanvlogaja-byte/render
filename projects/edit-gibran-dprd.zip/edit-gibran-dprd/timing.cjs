// timing.cjs -> src/timing.json
// Narasi (mp3) + SRT -> waktu kata; footage dipotong mengikuti jeda narasi.
// Env: FPS (30), W (1080), H (1920). Dijalankan: node timing.cjs
const fs = require('fs');
const path = require('path');
const cp = require('child_process');

const FPS = +process.env.FPS || 30;
const W = +process.env.W || 1080;
const H = +process.env.H || 1920;
const TAIL = 0.6;
const FOOTAGE = 'footage.mp4';
const NARASI = 'narasi.mp3';
const PAD_MIN_SEG = 0.12;

// Offset footage per kalimat narasi: waktu_sumber = waktu_hasil + offset.
// Ubah angka ini untuk menggeser adegan footage terhadap narasi.
// Kalimat 5-8 digeser +1.8 dtk supaya "menurunkan bingkai" jatuh pada momen foto diangkat.
const OFFSETS = [0, 0, 0, 0, 1.8, 1.8, 1.8, 1.8];

const root = __dirname;
const sh = (c) => cp.execSync(c, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] });

function probeDur(file) {
  return parseFloat(sh(`ffprobe -v error -show_entries format=duration -of csv=p=0 "${file}"`));
}

function getSilences() {
  const cache = path.join(root, 'data/silences.json');
  try {
    const f = path.join(root, 'public', NARASI);
    const dur = probeDur(f);
    const out = cp.spawnSync('ffmpeg', ['-hide_banner', '-i', f, '-af', 'silencedetect=noise=-35dB:d=0.2', '-f', 'null', '-'], { encoding: 'utf8' }).stderr;
    const st = [...out.matchAll(/silence_start: ([\d.]+)/g)].map((m) => +m[1]);
    const en = [...out.matchAll(/silence_end: ([\d.]+)/g)].map((m) => +m[1]);
    const sil = st.map((s, i) => [s, en[i] !== undefined ? en[i] : dur]);
    const data = { duration: dur, silences: sil };
    fs.writeFileSync(cache, JSON.stringify(data, null, 1));
    return data;
  } catch (e) {
    console.log('ffmpeg tidak tersedia, pakai data/silences.json');
    return JSON.parse(fs.readFileSync(cache, 'utf8'));
  }
}

function parseSrt(txt) {
  const tc = (s) => { const m = s.match(/(\d+):(\d+):(\d+)[,.](\d+)/); return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000; };
  return txt.replace(/\r/g, '').trim().split(/\n\n+/).map((b) => {
    const l = b.split('\n');
    const [a, c] = l[1].split('-->');
    return { start: tc(a), end: tc(c), text: l.slice(2).join(' ').trim() };
  });
}

const letters = (s) => (s.match(/[A-Za-z0-9\u00C0-\u024F]/g) || []).length;

// 1. unit kalimat + perkiraan awal dari SRT
const cues = parseSrt(fs.readFileSync(path.join(root, 'narasi.srt'), 'utf8'));
const units = [];
for (const c of cues) {
  const sents = c.text.split(/(?<=[.?!])\s+/).filter(Boolean);
  const tot = sents.reduce((a, s) => a + letters(s), 0) || 1;
  let acc = 0;
  for (const s of sents) {
    units.push({ text: s, est: c.start + ((c.end - c.start) * acc) / tot, chars: letters(s) });
    acc += letters(s);
  }
}
if (units.length !== OFFSETS.length) throw new Error(`Jumlah kalimat ${units.length} != OFFSETS ${OFFSETS.length}`);

// 2. segmen bicara dari jeda mp3
const { duration: audioDur, silences } = getSilences();
let segs = [];
let cur = 0;
for (const [s, e] of silences) { if (s > cur) segs.push({ s: cur, e: s }); cur = e; }
if (cur < audioDur - 0.05) segs.push({ s: cur, e: audioDur });
segs = segs.filter((g) => g.e - g.s >= PAD_MIN_SEG);

// 3. DP monoton unit -> rentang segmen
function assign(median) {
  const n = units.length, m = segs.length, INF = 1e9;
  const best = Array.from({ length: n + 1 }, () => Array(m + 1).fill(INF));
  const back = Array.from({ length: n + 1 }, () => Array(m + 1).fill(null));
  best[0][0] = 0;
  for (let i = 0; i < n; i++) for (let j = 0; j < m; j++) {
    if (best[i][j] >= INF) continue;
    let dur = 0;
    for (let k = j; k < m; k++) {
      dur += segs[k].e - segs[k].s;
      const rate = units[i].chars / dur;
      const cost = Math.abs(Math.log(rate / median)) + 0.25 * Math.abs(segs[j].s - units[i].est) + 0.05 * (k - j);
      if (best[i][j] + cost < best[i + 1][k + 1]) { best[i + 1][k + 1] = best[i][j] + cost; back[i + 1][k + 1] = j; }
    }
  }
  const out = []; let k = m;
  for (let i = n; i > 0; i--) { const j = back[i][k]; out[i - 1] = [j, k - 1]; k = j; }
  return out;
}
const totalSpeech = segs.reduce((a, g) => a + g.e - g.s, 0);
let median = units.reduce((a, u) => a + u.chars, 0) / totalSpeech;
let rng;
for (let it = 0; it < 5; it++) {
  rng = assign(median);
  const rates = rng.map(([a, b], i) => units[i].chars / segs.slice(a, b + 1).reduce((x, g) => x + g.e - g.s, 0)).sort((x, y) => x - y);
  median = rates[Math.floor(rates.length / 2)];
}
units.forEach((u, i) => {
  const [a, b] = rng[i];
  u.segs = segs.slice(a, b + 1);
  u.start = u.segs[0].s;
  u.end = u.segs[u.segs.length - 1].e;
  const d = u.segs.reduce((x, g) => x + g.e - g.s, 0);
  u.rate = u.chars / d;
  u.flag = u.rate < median * 0.6 || u.rate > median * 1.6;
});
console.log('median laju (huruf/dtk):', median.toFixed(2));
units.forEach((u, i) => console.log(i + 1, u.start.toFixed(2), u.end.toFixed(2), 'laju', u.rate.toFixed(1), u.flag ? 'DI LUAR 0.6-1.6x' : ''));

// 4. waktu kata
const words = [];
units.forEach((u, ui) => {
  const toks = u.text.split(/\s+/).filter(Boolean);
  const wt = toks.map((t) => letters(t) + 1.2);
  const sum = wt.reduce((a, b) => a + b, 0);
  const L = u.segs.reduce((a, g) => a + g.e - g.s, 0);
  const at = (p) => { // posisi bicara -> waktu hasil
    let r = Math.min(Math.max(p, 0), L);
    for (const g of u.segs) { const d = g.e - g.s; if (r <= d + 1e-9) return g.s + r; r -= d; }
    return u.end;
  };
  let acc = 0;
  toks.forEach((t, i) => {
    const p0 = (acc / sum) * L; acc += wt[i]; const p1 = (acc / sum) * L;
    words.push({ w: t, start: +at(p0).toFixed(3), end: +at(p1).toFixed(3), unit: ui });
  });
});

// 5. rencana potong footage (batas di tengah jeda antar kalimat)
function probeDurSafe(f) { try { return probeDur(f); } catch (e) { return 69.7; } }
const srcDur = probeDurSafe(path.join(root, 'public', FOOTAGE));
const duration = +audioDur.toFixed(3);
const total = +(duration + TAIL).toFixed(3);
const bounds = [0];
for (let i = 0; i < units.length - 1; i++) bounds.push(+((units[i].end + units[i + 1].start) / 2).toFixed(3));
bounds.push(total);
const cuts = units.map((_, i) => {
  const out0 = bounds[i], out1 = bounds[i + 1];
  return { src0: +(out0 + OFFSETS[i]).toFixed(3), src1: +(out1 + OFFSETS[i]).toFixed(3), out0, out1 };
});
if (cuts[cuts.length - 1].src1 > srcDur) throw new Error('Footage kurang panjang untuk offset ini');

const result = {
  footage: FOOTAGE, narasi: NARASI, srcDuration: +srcDur.toFixed(3), audioDuration: duration,
  duration, tail: TAIL, fps: FPS, width: W, height: H,
  cuts, units: units.map((u, i) => ({ i, text: u.text, start: +u.start.toFixed(3), end: +u.end.toFixed(3) })), words,
};
fs.writeFileSync(path.join(root, 'src/timing.json'), JSON.stringify(result, null, 1));
console.log('cuts:', cuts.map((c) => `${c.out0}-${c.out1}<-${c.src0}`).join(' | '));
console.log('OK src/timing.json:', words.length, 'kata,', cuts.length, 'potongan, total', total, 'dtk');
