# edit-gibran-dprd (Remotion 4.0.250)

Video 9:16 (1080x1920, 30 fps, +/- 56 detik): footage audiensi DPRD DIY + narasi (mp3), jump cut mengikuti jeda narasi, caption per kata, dan ilustrasi paper-cut yang muncul saat kata kuncinya diucapkan.
Video TIDAK dirender di sini. Render lewat GitHub Actions (lihat di bawah).

## Struktur
- `public/footage.mp4` footage mentah (720p, 69,7 dtk). Suara aslinya dipelankan (volume 0,18) di bawah narasi.
- `public/narasi.mp3` narasi (55,2 dtk), jalan dari detik 0.
- `narasi.srt` teks narasi. Dasar caption dan waktu kata.
- `timing.cjs` -> `src/timing.json` (waktu kata, rencana potong footage).
- `data/silences.json` hasil deteksi jeda mp3 (dipakai bila ffmpeg tidak ada).
- `src/Video.tsx` komponen murni (semua animasi fungsi dari `t`), `src/Root.tsx` (Sequence + OffthreadVideo + Audio), `src/theme.ts`.

## Render di GitHub Actions
Job di workflow `render-remotion.yml` (`workflow_dispatch`), folder project `edit-gibran-dprd`:
1. `actions/checkout@v4`
2. `actions/setup-node@v4` (Node 20)
3. `npm install` (bukan `npm ci`, karena tidak ada lockfile)
4. `npm run render` (hasil: `out/video.mp4`)
5. `actions/upload-artifact@v4` dengan path `out/video.mp4`

Contoh file workflow ada di `.github/workflows/render-remotion.yml`. Sesuaikan `working-directory` kalau repo kamu menaruh project di folder lain.

## Membuat ulang timing
Edit `narasi.srt` atau ganti `public/narasi.mp3`, lalu `node timing.cjs` (butuh ffmpeg/ffprobe; tanpa ffmpeg dipakai `data/silences.json`). Variabel env: `FPS`, `W`, `H`.
Geser footage terhadap narasi lewat `OFFSETS` di bagian atas `timing.cjs` (waktu_sumber = waktu_hasil + offset, satu angka per kalimat).
Jumlah kalimat di SRT harus sama dengan panjang `OFFSETS` (sekarang 8).

## Opsi di `src/theme.ts`
- `text.title`, `text.channel` (kosong = chip disembunyikan), `text.sticker`, `text.attribution` (kosongkan untuk mematikan chip "Dugaan dalam narasi").
- `audio.narasi`, `audio.footage` volume.
- `zoom` (zoom bergantian per potongan dan dorongan pelan), `layout`, `waves.speed`, dan semua warna.

## Catatan
- Caption persis mengikuti teks SRT. Ilustrasi sengaja generik (siluet tanpa wajah), tidak menggambar tokoh nyata.
- Cue visual: `cue('kata', n)` di `Video.tsx` = kemunculan ke-n kata itu di transkrip. Kata tidak ditemukan -> error jelas.
