import React from "react";
import {AbsoluteFill, Easing, Loop, OffthreadVideo, interpolate, staticFile, useCurrentFrame} from "remotion";
import {scenes} from "./captions";
import {LOOP_FRAMES} from "./theme";

const ORIGINS = ["50% 0%", "30% 0%", "70% 0%", "40% 0%", "60% 0%"];

export const Footage: React.FC = () => {
  const frame = useCurrentFrame();
  let idx = scenes.findIndex((s) => frame >= s.from && frame < s.to);
  if (idx < 0) idx = scenes.length - 1;
  const s = scenes[idx];
  const local = frame - s.from;
  const p = local / Math.max(1, s.to - s.from);

  // push-in pelan + "punch" kecil tiap ganti adegan; zoom sengaja kecil
  // supaya label asli di klip tetap tertutup chip judul
  const punch = interpolate(local, [0, 5, 16], [idx === 0 ? 0 : 0.05, 0.02, 0], {extrapolateRight: "clamp"});
  const zoom = 1.04 + 0.06 * Easing.out(Easing.cubic)(p) + punch;
  const dx = Math.sin(frame / 11) * 4;
  const dy = Math.cos(frame / 13) * 3;

  return (
    <AbsoluteFill style={{overflow: "hidden", backgroundColor: "#000"}}>
      <AbsoluteFill
        style={{
          transformOrigin: ORIGINS[idx % ORIGINS.length],
          transform: `translate(${dx}px, ${dy}px) scale(${zoom})`,
          filter: "saturate(1.18) contrast(1.06) brightness(1.03)",
        }}
      >
        <Loop durationInFrames={LOOP_FRAMES}>
          <OffthreadVideo src={staticFile("klip.mp4")} muted style={{width: "100%", height: "100%", objectFit: "cover"}} />
        </Loop>
      </AbsoluteFill>
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(to bottom, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0) 18%, rgba(0,0,0,0) 52%, rgba(0,0,0,0.6) 100%)",
        }}
      />
      <AbsoluteFill
        style={{background: "radial-gradient(ellipse at center, rgba(0,0,0,0) 55%, rgba(0,0,0,0.35) 100%)"}}
      />
    </AbsoluteFill>
  );
};
