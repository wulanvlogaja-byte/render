import {DURATION, FPS} from "./theme";

const SRT = `1
00:00:00,000 --> 00:00:05,412
Subhanallah, ternyata di Cina mulai banyak
muslim Alhamdulillah..

2
00:00:05,412 --> 00:00:12,105
Pria asal Iran ini berkunjung ke Cina,
ia mengunjungi kawasan muslim Cina

3
00:00:12,105 --> 00:00:18,203
terlihat beberapa gadis remaja Cina sedang berjualan,
ia mengenakan hijab dan terlihat sangat cantik

4
00:00:18,203 --> 00:00:24,518
jika kalian muslim tolong tinggalkan like nya
agar video ini disebarkan youtube ke jangkauan
lebih luas agar banyak yang tau keindahan beragama Islam

5
00:00:24,518 --> 00:00:27,640
Terimakasih, semoga Allah membalas
kebaikan kalian dan kita semua.`;

export type Cue = {start: number; end: number; text: string};
export type Word = {raw: string; text: string; start: number; end: number; cue: number};
export type Chunk = {start: number; end: number; words: Word[]};

const toSec = (s: string): number => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) return 0;
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000;
};

const parse = (src: string): Cue[] =>
  src
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n");
      const t = lines[1].split("-->");
      return {start: toSec(t[0]), end: toSec(t[1]), text: lines.slice(2).join(" ")};
    });

export const cues: Cue[] = parse(SRT);

// SRT cuma punya waktu per baris, jadi waktu tiap kata dibagi sesuai panjang huruf
const wordsOf = (cue: Cue, idx: number): Word[] => {
  const toks = cue.text.replace(/\s+/g, " ").trim().split(" ");
  const weights = toks.map((t) => t.replace(/[^\p{L}\p{N}]/gu, "").length + 1 + (/[,.!?]$/.test(t) ? 1.5 : 0));
  const total = weights.reduce((a, b) => a + b, 0);
  const dur = cue.end - cue.start;
  let acc = 0;
  return toks.map((raw, i) => {
    const start = cue.start + (acc / total) * dur;
    acc += weights[i];
    const end = cue.start + (acc / total) * dur;
    return {raw, text: raw.replace(/[.,]+$/, "").toUpperCase(), start, end, cue: idx};
  });
};

export const words: Word[] = cues.flatMap(wordsOf);

const buildChunks = (all: Word[]): Chunk[] => {
  const out: Chunk[] = [];
  let cur: Word[] = [];
  const flush = () => {
    if (cur.length) {
      out.push({start: cur[0].start, end: cur[cur.length - 1].end, words: cur});
      cur = [];
    }
  };
  for (const w of all) {
    const len = [...cur, w].map((x) => x.text).join(" ").length;
    if (cur.length && (cur.length >= 3 || len > 18 || w.cue !== cur[0].cue)) flush();
    cur.push(w);
    if (/[,.!?]$/.test(w.raw)) flush();
  }
  flush();
  // chunk tampil sampai chunk berikutnya mulai (tanpa celah kosong)
  return out.map((c, i) => ({...c, end: i < out.length - 1 ? out[i + 1].start : c.end + 0.3}));
};

export const chunks: Chunk[] = buildChunks(words);

export const KEYWORDS = ["MUSLIM", "CINA", "ISLAM", "ALLAH", "ALHAMDULILLAH", "SUBHANALLAH", "LIKE", "HIJAB", "IRAN"];

export type Scene = {i: number; from: number; to: number};
export const scenes: Scene[] = cues.map((c, i) => ({
  i,
  from: Math.round(c.start * FPS),
  to: i < cues.length - 1 ? Math.round(cues[i + 1].start * FPS) : DURATION,
}));
