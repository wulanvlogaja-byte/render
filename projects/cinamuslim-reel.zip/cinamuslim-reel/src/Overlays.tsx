import React from "react";
import {AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {scenes} from "./captions";
import {C, DURATION, fontFamily} from "./theme";

const HEART = "M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z";
const THUMB = "M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z";
const SHARE = "M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z";

const stickerBase: React.CSSProperties = {
  position: "absolute",
  border: `8px solid ${C.ink}`,
  borderRadius: 36,
  boxShadow: `0 12px 0 ${C.ink}`,
  fontFamily,
  fontWeight: 800,
  color: C.ink,
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
};

// masuk dengan spring, keluar dengan fade di 8 frame terakhir sequence
const usePop = (dur: number, delay = 0) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - delay, fps, config: {damping: 12, stiffness: 170, mass: 0.7}});
  const out = interpolate(f, [dur - 8, dur], [1, 0], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return {s, out, f, fps};
};

const star = (cx: number, cy: number, R: number, r: number): string => {
  const pts: string[] = [];
  for (let i = 0; i < 10; i++) {
    const a = -Math.PI / 2 + (i * Math.PI) / 5;
    const rad = i % 2 === 0 ? R : r;
    pts.push(`${(cx + Math.cos(a) * rad).toFixed(2)},${(cy + Math.sin(a) * rad).toFixed(2)}`);
  }
  return pts.join(" ");
};

const Heart: React.FC<{size: number; color: string}> = ({size, color}) => (
  <svg width={size} height={size} viewBox="0 0 24 24">
    <path d={HEART} fill={color} stroke={C.ink} strokeWidth={1.2} strokeLinejoin="round" />
  </svg>
);

// ---------- elemen global ----------

export const TitleChip: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - 4, fps, config: {damping: 12, stiffness: 140, mass: 0.8}});
  const y = interpolate(s, [0, 1], [-280, 0]) + Math.sin(f / 14) * 4;
  return (
    <div
      style={{
        ...stickerBase,
        top: 205,
        left: 140,
        width: 800,
        height: 140,
        gap: 24,
        background: C.yellow,
        fontSize: 62,
        transform: `translateY(${y}px) rotate(${interpolate(s, [0, 1], [-6, 0])}deg)`,
      }}
    >
      <svg width={92} height={62} viewBox="0 0 92 62">
        <rect x={2} y={2} width={88} height={58} rx={8} fill={C.red} stroke={C.ink} strokeWidth={4} />
        <polygon points={star(22, 20, 12, 5)} fill={C.yellow} />
        <polygon points={star(42, 10, 4, 1.6)} fill={C.yellow} />
        <polygon points={star(48, 20, 4, 1.6)} fill={C.yellow} />
        <polygon points={star(48, 31, 4, 1.6)} fill={C.yellow} />
        <polygon points={star(42, 40, 4, 1.6)} fill={C.yellow} />
      </svg>
      <span>MUSLIM DI CINA</span>
    </div>
  );
};

export const ProgressBar: React.FC = () => {
  const f = useCurrentFrame();
  const p = Math.min(1, f / DURATION);
  return (
    <div style={{position: "absolute", top: 80, left: 90, width: 900, height: 16, borderRadius: 8, background: "rgba(255,255,255,0.35)"}}>
      <div
        style={{
          width: `${p * 100}%`,
          height: "100%",
          borderRadius: 8,
          background: `linear-gradient(90deg, ${C.yellow}, ${C.mint})`,
          boxShadow: "0 0 14px rgba(61,255,163,0.8)",
        }}
      />
    </div>
  );
};

export const Wipes: React.FC = () => {
  const f = useCurrentFrame();
  const hit = scenes.find((s) => s.i > 0 && f >= s.from && f < s.from + 18);
  if (!hit) return null;
  const local = f - hit.from;
  const band = (lag: number, color: string, w: number) => {
    const x = interpolate(local - lag, [0, 14], [-w - 200, 1300], {extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.inOut(Easing.cubic)});
    return (
      <div style={{position: "absolute", top: -200, left: 0, width: w, height: 2320, background: color, transform: `translateX(${x}px) skewX(-18deg)`}} />
    );
  };
  return (
    <AbsoluteFill style={{pointerEvents: "none"}}>
      {band(0, C.yellow, 560)}
      {band(3, C.mint, 380)}
    </AbsoluteFill>
  );
};

// ---------- adegan 1: tren naik ----------

export const TrendCard: React.FC<{dur: number}> = ({dur}) => {
  const {s, out, f} = usePop(dur, 6);
  const draw = interpolate(f, [16, 60], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.out(Easing.cubic)});
  const head = interpolate(f, [58, 70], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <div
      style={{
        ...stickerBase,
        top: 1470,
        left: 190,
        width: 700,
        height: 250,
        background: C.white,
        flexDirection: "column",
        opacity: out,
        transform: `translateY(${interpolate(s, [0, 1], [260, 0])}px) scale(${0.92 + 0.08 * out}) rotate(-2deg)`,
      }}
    >
      <div style={{fontSize: 44, marginTop: 8}}>MAKIN BANYAK!</div>
      <svg width={620} height={150} viewBox="0 0 660 170">
        <path d="M 20 150 L 120 125 L 220 135 L 320 85 L 420 95 L 520 40 L 620 20" fill="none" stroke={C.mint} strokeWidth={16} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
        <g opacity={head} transform={`translate(${620},${20}) scale(${0.6 + 0.4 * head})`}>
          <polygon points="-6,-30 34,-10 -10,22" fill={C.red} stroke={C.ink} strokeWidth={5} strokeLinejoin="round" transform="rotate(-8)" />
        </g>
      </svg>
    </div>
  );
};

// ---------- adegan 2: rute Iran -> Cina + lokasi ----------

export const RouteTag: React.FC<{dur: number}> = ({dur}) => {
  const {s, out, f} = usePop(dur, 4);
  const t = interpolate(f, [18, 80], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.inOut(Easing.cubic)});
  const bx = (1 - t) * (1 - t) * 240 + 2 * (1 - t) * t * 450 + t * t * 660;
  const by = (1 - t) * (1 - t) * 62 + 2 * (1 - t) * t * 2 + t * t * 62;
  const dash = -f * 1.2;
  return (
    <div style={{position: "absolute", top: 362, left: 90, width: 900, height: 110, opacity: out, transform: `scale(${interpolate(s, [0, 1], [0.6, 1])})`}}>
      <svg width={900} height={110} viewBox="0 0 900 110" style={{overflow: "visible"}}>
        <path d="M 240 62 Q 450 2 660 62" fill="none" stroke={C.white} strokeWidth={8} strokeLinecap="round" strokeDasharray="4 18" strokeDashoffset={dash} />
        <rect x={0} y={12} width={230} height={86} rx={28} fill={C.blue} stroke={C.ink} strokeWidth={8} />
        <text x={115} y={72} textAnchor="middle" fontFamily={fontFamily} fontWeight={800} fontSize={46} fill={C.white}>IRAN</text>
        <rect x={670} y={12} width={230} height={86} rx={28} fill={C.red} stroke={C.ink} strokeWidth={8} />
        <text x={785} y={72} textAnchor="middle" fontFamily={fontFamily} fontWeight={800} fontSize={46} fill={C.white}>CINA</text>
        <circle cx={bx} cy={by} r={16} fill={C.yellow} stroke={C.ink} strokeWidth={6} />
      </svg>
    </div>
  );
};

export const LocationCard: React.FC<{dur: number}> = ({dur}) => {
  const {s, out} = usePop(dur, 30);
  return (
    <div
      style={{
        ...stickerBase,
        top: 1470,
        left: 150,
        width: 780,
        height: 150,
        gap: 22,
        background: C.mint,
        fontSize: 44,
        opacity: out,
        transform: `translateY(${interpolate(s, [0, 1], [240, 0])}px) rotate(1.5deg)`,
      }}
    >
      <svg width={64} height={64} viewBox="0 0 24 24">
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z" fill={C.red} stroke={C.ink} strokeWidth={1.2} />
        <circle cx={12} cy={9} r={2.6} fill={C.white} />
      </svg>
      <span>KAWASAN MUSLIM CINA</span>
    </div>
  );
};

// ---------- adegan 3: berjualan + kilau ----------

const SPARKS = [
  {x: 70, y: 560, d: 0, s: 70},
  {x: 940, y: 520, d: 9, s: 90},
  {x: 90, y: 830, d: 17, s: 56},
  {x: 960, y: 800, d: 5, s: 64},
  {x: 520, y: 500, d: 22, s: 48},
];

export const Sparkles: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <>
      {SPARKS.map((p, i) => {
        const k = (Math.sin((f + p.d * 3) / 8) + 1) / 2;
        return (
          <svg key={i} width={p.s} height={p.s} viewBox="-12 -12 24 24" style={{position: "absolute", left: p.x, top: p.y, opacity: 0.35 + 0.65 * k, transform: `scale(${0.6 + 0.6 * k}) rotate(${f * 2}deg)`}}>
            <path d="M0 -11 Q1.5 -1.5 11 0 Q1.5 1.5 0 11 Q-1.5 1.5 -11 0 Q-1.5 -1.5 0 -11 Z" fill={C.yellow} stroke={C.ink} strokeWidth={1.4} strokeLinejoin="round" />
          </svg>
        );
      })}
    </>
  );
};

export const BagSticker: React.FC<{dur: number}> = ({dur}) => {
  const {s, out, f} = usePop(dur, 8);
  return (
    <div
      style={{
        ...stickerBase,
        top: 1480,
        left: 240,
        width: 600,
        height: 150,
        gap: 22,
        background: C.pink,
        fontSize: 52,
        opacity: out,
        transform: `scale(${interpolate(s, [0, 1], [0.3, 1])}) rotate(${-4 + Math.sin(f / 7) * 2}deg)`,
      }}
    >
      <svg width={70} height={70} viewBox="0 0 24 24">
        <path d="M18 6h-2c0-2.21-1.79-4-4-4S8 3.79 8 6H6c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm-6-2c1.1 0 2 .9 2 2h-4c0-1.1.9-2 2-2z" fill={C.white} stroke={C.ink} strokeWidth={1.2} strokeLinejoin="round" />
      </svg>
      <span>BERJUALAN</span>
    </div>
  );
};

// ---------- adegan 4 & 5: like / share / hati / konfeti ----------

const HEART_X = [-180, -60, 90, 200, -120, 30, 150, -20];

const Hearts: React.FC<{startFrame: number; originX: number; originY: number; count?: number}> = ({startFrame, originX, originY, count = 8}) => {
  const f = useCurrentFrame();
  return (
    <>
      {HEART_X.slice(0, count).map((hx, i) => {
        const lf = f - startFrame - i * 4;
        if (lf < 0 || lf > 50) return null;
        const p = lf / 50;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: originX + hx + Math.sin(lf / 5 + i) * 18,
              top: originY - p * 420,
              opacity: 1 - p * p,
              transform: `scale(${0.6 + 0.6 * Math.min(1, lf / 8)}) rotate(${Math.sin(lf / 6 + i) * 16}deg)`,
            }}
          >
            <Heart size={74} color={i % 2 ? C.pink : C.red} />
          </div>
        );
      })}
    </>
  );
};

const PressButton: React.FC<{left: number; label: string; pressedLabel: string; icon: string; pressAt: number; dur: number; delay: number; color: string}> = ({left, label, pressedLabel, icon, pressAt, dur, delay, color}) => {
  const {s, out, f} = usePop(dur, delay);
  const pressed = f >= pressAt;
  const dip = interpolate(f, [pressAt - 4, pressAt, pressAt + 6], [1, 0.86, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const ring = interpolate(f, [pressAt, pressAt + 18], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <>
      <div
        style={{
          position: "absolute",
          top: 1475,
          left,
          width: 440,
          height: 160,
          borderRadius: 44,
          border: `8px solid ${color}`,
          opacity: ring > 0 ? (1 - ring) * out : 0,
          transform: `scale(${1 + ring * 0.7})`,
        }}
      />
      <div
        style={{
          ...stickerBase,
          top: 1475,
          left,
          width: 440,
          height: 160,
          gap: 20,
          background: pressed ? color : C.white,
          color: pressed ? C.white : C.ink,
          fontSize: 54,
          opacity: out,
          transform: `translateY(${interpolate(s, [0, 1], [260, 0])}px) scale(${dip})`,
        }}
      >
        <svg width={72} height={72} viewBox="0 0 24 24">
          <path d={icon} fill={pressed ? C.white : color} stroke={C.ink} strokeWidth={0.9} strokeLinejoin="round" />
        </svg>
        <span>{pressed ? pressedLabel : label}</span>
      </div>
    </>
  );
};

export const LikeShare: React.FC<{dur: number}> = ({dur}) => (
  <>
    <PressButton left={70} label="LIKE" pressedLabel="LIKED!" icon={THUMB} pressAt={38} dur={dur} delay={6} color={C.blue} />
    <PressButton left={570} label="BAGIKAN" pressedLabel="DIBAGIKAN!" icon={SHARE} pressAt={86} dur={dur} delay={14} color={C.red} />
    <Hearts startFrame={38} originX={290} originY={1470} />
    <Hearts startFrame={86} originX={790} originY={1470} count={6} />
  </>
);

export const EndCard: React.FC<{dur: number}> = ({dur}) => {
  const {s, f} = usePop(dur + 100, 4);
  const sub = spring({frame: f - 22, fps: 30, config: {damping: 11, stiffness: 150, mass: 0.7}});
  const pressDip = interpolate(f, [46, 50, 56], [1, 0.88, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const done = f >= 50;
  const palette = [C.yellow, C.mint, C.pink, C.blue, C.red];
  return (
    <>
      {Array.from({length: 28}).map((_, i) => {
        const x = (i * 137) % 1080;
        const speed = 14 + (i % 5) * 4;
        const y = -80 + f * speed - (i % 7) * 60;
        if (y < -100 || y > 2000) return null;
        return <div key={i} style={{position: "absolute", left: x, top: y, width: 22, height: 36, background: palette[i % 5], border: `3px solid ${C.ink}`, borderRadius: 4, transform: `rotate(${f * (6 + (i % 4) * 3) + i * 30}deg)`}} />;
      })}
      <div
        style={{
          ...stickerBase,
          top: 1440,
          left: 130,
          width: 820,
          height: 150,
          background: C.yellow,
          fontSize: 78,
          transform: `scale(${interpolate(s, [0, 1], [0.3, 1])}) rotate(${-3 + Math.sin(f / 8) * 1.5}deg)`,
        }}
      >
        TERIMA KASIH!
      </div>
      <div
        style={{
          ...stickerBase,
          top: 1640,
          left: 290,
          width: 500,
          height: 120,
          gap: 16,
          background: done ? C.ink : C.red,
          color: C.white,
          fontSize: 46,
          transform: `scale(${interpolate(sub, [0, 1], [0.3, 1]) * pressDip})`,
        }}
      >
        <svg width={52} height={52} viewBox="0 0 24 24">
          <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.9 2 2 2zm6-6v-5c0-3.07-1.63-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.64 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z" fill={C.yellow} stroke={C.white} strokeWidth={0.8} />
        </svg>
        <span>{done ? "DIIKUTI" : "FOLLOW"}</span>
      </div>
      <Hearts startFrame={10} originX={540} originY={1430} />
      <Hearts startFrame={50} originX={380} originY={1430} count={6} />
    </>
  );
};
