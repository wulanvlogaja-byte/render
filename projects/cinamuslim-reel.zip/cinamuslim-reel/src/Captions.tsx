import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {KEYWORDS, chunks} from "./captions";
import {C, fontFamily, outline} from "./theme";

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const chunk = chunks.find((c) => t >= c.start && t < c.end);
  if (!chunk) return null;

  const local = frame - Math.round(chunk.start * fps);
  const pop = spring({frame: local, fps, config: {damping: 11, stiffness: 220, mass: 0.55}});
  const scale = interpolate(pop, [0, 1], [0.6, 1]);
  const y = interpolate(pop, [0, 1], [30, 0]);

  let active = 0;
  chunk.words.forEach((w, i) => {
    if (t >= w.start) active = i;
  });

  return (
    <AbsoluteFill style={{justifyContent: "flex-start", alignItems: "center"}}>
      <div
        style={{
          position: "absolute",
          top: 1050,
          left: 60,
          width: 960,
          height: 300,
          display: "flex",
          flexWrap: "wrap",
          alignContent: "center",
          justifyContent: "center",
          gap: "6px 4px",
          transform: `translateY(${y}px) scale(${scale})`,
          fontFamily,
          fontWeight: 800,
          fontSize: 92,
          lineHeight: 1.18,
          textAlign: "center",
        }}
      >
        {chunk.words.map((w, i) => {
          const isActive = i === active;
          const isKey = KEYWORDS.includes(w.text.replace(/[^A-Z]/g, ""));
          return (
            <span
              key={i}
              style={{
                display: "inline-block",
                padding: "0 20px",
                borderRadius: 26,
                background: isActive ? C.yellow : "transparent",
                color: isActive ? C.ink : isKey ? C.mint : C.white,
                textShadow: isActive ? "none" : `${outline(C.ink, 7)}, 0 12px 14px rgba(0,0,0,0.45)`,
                boxShadow: isActive ? `0 10px 0 #B8870B, 0 0 0 6px ${C.ink}` : "none",
                transform: isActive ? "scale(1.08) rotate(-2deg)" : "none",
              }}
            >
              {w.text}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
