import React from "react";
import {AbsoluteFill, Audio, Sequence, staticFile} from "remotion";
import {Captions} from "./Captions";
import {scenes} from "./captions";
import {Footage} from "./Footage";
import {BagSticker, EndCard, LikeShare, LocationCard, ProgressBar, RouteTag, Sparkles, TitleChip, TrendCard, Wipes} from "./Overlays";
import {fontFamily} from "./theme";

const seq = (i: number) => ({from: scenes[i].from, durationInFrames: scenes[i].to - scenes[i].from, dur: scenes[i].to - scenes[i].from});

export const Main: React.FC = () => {
  const s1 = seq(0);
  const s2 = seq(1);
  const s3 = seq(2);
  const s4 = seq(3);
  const s5 = seq(4);
  return (
    <AbsoluteFill style={{backgroundColor: "#000", fontFamily}}>
      <Audio src={staticFile("narasi.mp3")} />
      <Footage />

      <Sequence from={s1.from} durationInFrames={s1.durationInFrames}>
        <TrendCard dur={s1.dur} />
      </Sequence>
      <Sequence from={s2.from} durationInFrames={s2.durationInFrames}>
        <RouteTag dur={s2.dur} />
        <LocationCard dur={s2.dur} />
      </Sequence>
      <Sequence from={s3.from} durationInFrames={s3.durationInFrames}>
        <Sparkles />
        <BagSticker dur={s3.dur} />
      </Sequence>
      <Sequence from={s4.from} durationInFrames={s4.durationInFrames}>
        <LikeShare dur={s4.dur} />
      </Sequence>
      <Sequence from={s5.from} durationInFrames={s5.durationInFrames}>
        <EndCard dur={s5.dur} />
      </Sequence>

      <TitleChip />
      <ProgressBar />
      <Captions />
      <Wipes />
    </AbsoluteFill>
  );
};
