import {loadFont} from "@remotion/google-fonts/Poppins";

const loaded = loadFont("normal", {weights: ["700", "800"], subsets: ["latin"]});

export const fontFamily = `${loaded.fontFamily}, "Arial Black", Arial, sans-serif`;

export const FPS = 30;
export const W = 1080;
export const H = 1920;
// narasi 27.64 detik
export const DURATION = 830;
// klip sumber 8.8 detik, di-loop
export const LOOP_FRAMES = 264;

export const C = {
  yellow: "#FFD23F",
  mint: "#3DFFA3",
  red: "#FF3B4E",
  blue: "#2D7BFF",
  pink: "#FF5FA2",
  ink: "#141414",
  white: "#FFFFFF",
};

// outline tebal ala sticker lewat text-shadow (aman di semua Chromium)
export const outline = (color: string, r: number): string => {
  const parts: string[] = [];
  for (let i = 0; i < 16; i++) {
    const a = (i / 16) * Math.PI * 2;
    parts.push(`${(Math.cos(a) * r).toFixed(1)}px ${(Math.sin(a) * r).toFixed(1)}px 0 ${color}`);
  }
  return parts.join(",");
};
