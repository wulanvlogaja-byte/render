import { interpolate, spring, useCurrentFrame, useVideoConfig } from 'remotion';
import { FONT } from './Caption';

export type Stat = { text: string; from: number; to: number };

// Label angka kunci (30 cm, 12 km, 0,2%) — palet navy + tembaga dari avatar channel
export const StatChip: React.FC<{ stats: Stat[] }> = ({ stats }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const st = stats.find((x) => frame >= x.from && frame < x.to);
  if (!st) return null;

  const pop = spring({ frame: frame - st.from, fps, durationInFrames: 12, config: { damping: 12, stiffness: 200 } });
  const out = interpolate(frame, [st.to - 6, st.to], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });

  return (
    <div style={{ position: 'absolute', left: 0, right: 0, top: '15.5%', textAlign: 'center', opacity: out }}>
      <span
        style={{
          display: 'inline-block',
          fontFamily: FONT,
          fontWeight: 700,
          fontSize: 84,
          color: '#FFE2B8',
          background: 'rgba(1,19,41,0.86)',
          border: '5px solid #C97B3C',
          borderRadius: 44,
          padding: '12px 38px',
          transform: `scale(${0.8 + 0.2 * pop})`,
        }}
      >
        {st.text}
      </span>
    </div>
  );
};
