import { useCurrentFrame, useVideoConfig, spring } from 'remotion';
import { loadFont } from '@remotion/google-fonts/Fredoka';
import type { Word } from '../lib/srt';

const { fontFamily } = loadFont('normal', { weights: ['600', '700'] });
export const FONT = fontFamily;

export const Caption: React.FC<{ words: Word[] }> = ({ words }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const w = words.find((x) => frame >= x.from && frame < x.to);
  if (!w || !w.text) return null;

  const pop = spring({ frame: frame - w.from, fps, durationInFrames: 8, config: { damping: 12, stiffness: 220 } });
  const label = w.text.charAt(0).toUpperCase() + w.text.slice(1);

  return (
    <div style={{ position: 'absolute', left: 0, right: 0, top: '52%', transform: 'translateY(-50%)', textAlign: 'center' }}>
      <span
        style={{
          display: 'inline-block',
          fontFamily,
          fontWeight: 700,
          fontSize: 96,
          color: '#fff',
          transform: `scale(${0.85 + 0.15 * pop})`,
          WebkitTextStroke: '12px #0A1230',
          paintOrder: 'stroke fill',
          textShadow: '0 6px 0 rgba(1,19,41,0.55)',
          letterSpacing: 1,
        }}
      >
        {label}
      </span>
    </div>
  );
};
