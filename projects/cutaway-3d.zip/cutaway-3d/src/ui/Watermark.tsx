import { FONT } from './Caption';

// Watermark sudut kiri atas: ikon logo YouTube + teks "suzkadreamer"
export const Watermark: React.FC = () => (
  <div
    style={{
      position: 'absolute',
      top: 104,
      left: 80,
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      opacity: 0.92,
    }}
  >
    <svg width="56" height="40" viewBox="0 0 28 20">
      <rect width="28" height="20" rx="5.5" fill="#FF0000" />
      <path d="M11 5.8 L19 10 L11 14.2 Z" fill="#FFFFFF" />
    </svg>
    <span
      style={{
        fontFamily: FONT,
        fontWeight: 600,
        fontSize: 40,
        color: '#FFFFFF',
        letterSpacing: 0.5,
        textShadow: '0 2px 8px rgba(1,19,41,0.75)',
      }}
    >
      suzkadreamer
    </span>
  </div>
);
