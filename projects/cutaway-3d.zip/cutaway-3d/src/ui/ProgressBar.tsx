import { useCurrentFrame, useVideoConfig } from 'remotion';

export const ProgressBar: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const p = Math.min(1, frame / (durationInFrames - 1));
  return (
    <div style={{ position: 'absolute', top: 70, left: 80, right: 80, height: 8, borderRadius: 4, background: 'rgba(255,255,255,0.25)' }}>
      <div style={{ width: `${p * 100}%`, height: '100%', borderRadius: 4, background: '#fff' }} />
    </div>
  );
};
