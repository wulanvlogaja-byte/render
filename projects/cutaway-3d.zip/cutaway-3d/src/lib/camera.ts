import { useThree } from '@react-three/fiber';
import type { PerspectiveCamera } from 'three';
import { ease } from './anim';

export type V3 = [number, number, number];
export type CamKey = { f: number; pos: V3; look: V3; fov: number };

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

export const sampleCam = (keys: CamKey[], frame: number): CamKey => {
  if (frame <= keys[0].f) return keys[0];
  for (let i = 0; i < keys.length - 1; i++) {
    const a = keys[i];
    const b = keys[i + 1];
    if (frame <= b.f) {
      const t = ease((frame - a.f) / (b.f - a.f));
      const v3 = (x: V3, y: V3): V3 => [lerp(x[0], y[0], t), lerp(x[1], y[1], t), lerp(x[2], y[2], t)];
      return { f: frame, pos: v3(a.pos, b.pos), look: v3(a.look, b.look), fov: lerp(a.fov, b.fov, t) };
    }
  }
  return keys[keys.length - 1];
};

export const CameraRig: React.FC<{ keys: CamKey[]; frame: number }> = ({ keys, frame }) => {
  const camera = useThree((s) => s.camera) as PerspectiveCamera;
  const k = sampleCam(keys, frame);
  camera.position.set(k.pos[0], k.pos[1], k.pos[2]);
  camera.fov = k.fov;
  camera.lookAt(k.look[0], k.look[1], k.look[2]);
  camera.updateProjectionMatrix();
  return null;
};
