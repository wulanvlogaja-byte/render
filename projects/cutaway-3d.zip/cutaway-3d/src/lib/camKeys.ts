import type { CamKey, V3 } from './camera';
import type { S } from './timing';

// Semua keyframe dikunci ke cue SRT lewat s(cue, fraksi). Index cue 0-based:
// 0 gali halaman | 1 tanah pucuk 30cm | 2 lempung lengket | 3 pasir+kerikil+basah | 4 air tanah
// 5 batu, sekop pensiun | 6 manusia keras kepala | 7 bor Kola 20 tahun | 8 berhenti 12 km
// 9 panas 180C | 10 batu lembek | 11 12 km 20 tahun | 12 pusat bumi 6000 km | 13 0,2% | 14 tak pernah kita lihat | 15 subscribe
export const buildCamKeys = (s: S, endFrame: number): CamKey[] => {
  const K = (f: number, pos: V3, look: V3, fov: number): CamKey => ({ f, pos, look, fov });
  const raw: CamKey[] = [
    K(0, [-0.5, 6.5, 27], [0.5, 2.2, 0], 42), // dunia penuh: rumah + halaman + lubang
    K(s(0, 0.6), [1.5, 3.2, 17], [2.5, 0.4, 9], 36), // push-in ke lubang
    K(s(1, 0.1), [2.5, 0.2, 16], [2.5, -0.8, 9], 34), // tilt-down ke tanah pucuk
    K(s(2, 0), [2.5, -3.0, 16], [2.5, -3.8, 9], 34), // lempung
    K(s(3, 0), [2.5, -6.8, 16], [2.5, -7.4, 9], 34), // pasir
    K(s(3, 0.9), [2.5, -10.5, 15], [2.5, -11, 9], 33),
    K(s(4, 0.1), [2.5, -11.8, 13], [2.5, -12.2, 9], 30), // air tanah
    K(s(5, 0), [2.5, -14.2, 15], [2.5, -14.6, 9], 32), // batu
    K(s(5, 0.9), [2.5, -16.5, 14], [2.5, -16.8, 9], 30),
    K(s(7, 0), [2.5, 7.0, 23], [2.5, 2.6, 8], 42), // crane naik: menara bor Kola
    K(s(8, 0), [2.5, -57, 18], [2.5, -58, 9], 34), // ikut mata bor turun 12 km
    K(s(9, 0), [2.5, -57.8, 15], [2.5, -58.4, 9], 30),
    K(s(9, 0.55), [2.5, -56.5, 13], [2.5, -57, 9], 28), // panas
    K(s(10, 0.1), [2.5, -55.5, 12], [2.5, -57, 8.5], 26), // push-in ke dinding lembek
    K(s(11, 0), [2.5, -58, 16], [2.5, -58, 9], 34),
    K(s(12, 0), [2.5, -31, 80], [2.5, -31, 8], 45), // pull-back: seluruh lubang 12 km
    K(s(13, 0), [2.5, -165, 30], [2.5, -172, 10], 40), // tilt-down ke pusat bumi
    K(s(13, 0.5), [2.5, -90, 140], [2.5, -90, 8], 48), // naik cepat
    K(s(14, 0), [2.5, -25, 120], [2.5, -25, 8], 50), // lubang kecil dibanding bumi
    K(s(14, 0.3), [0.4, 2.6, 16], [0.4, 0.9, 8], 34), // orang berdiri di halaman
    K(s(14, 0.55), [0.4, 2.4, 15.5], [0.4, 0.6, 8], 34),
    K(s(15, 0), [0.4, -30, 24], [0.4, -36, 10], 36), // tilt-down ke gelap di bawah kaki
    K(s(15, 0.8), [-0.8, 5.5, 25], [0.5, 2, 0], 42), // kembali ke halaman senja
    K(endFrame, [-0.5, 5, 23], [0.5, 2, 0], 40),
  ];
  // pastikan frame naik ketat
  const out: CamKey[] = [];
  raw.forEach((k, i) => out.push(i === 0 ? k : { ...k, f: Math.max(k.f, out[i - 1].f + 1) }));
  return out;
};
