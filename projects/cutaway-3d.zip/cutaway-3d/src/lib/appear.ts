import { spring, useCurrentFrame, useVideoConfig } from 'remotion';

export const useAppear = (startFrame: number, endFrame = Infinity) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  if (frame < startFrame || frame >= endFrame) return 0;
  return spring({ frame: frame - startFrame, fps, durationInFrames: 14, config: { damping: 14 } });
};
