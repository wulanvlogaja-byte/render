import { Easing, interpolate } from 'remotion';

export const ease = Easing.inOut(Easing.cubic);

export const prog = (frame: number, a: number, b: number) =>
  Math.min(1, Math.max(0, (frame - a) / Math.max(1, b - a)));

// Keyframe nilai skalar; input otomatis dipaksa naik (aman bila dua key jatuh di frame sama)
export const kf = (
  frame: number,
  pts: [number, number][],
  easing: (t: number) => number = ease,
) => {
  const xs: number[] = [];
  pts.forEach((p, i) => xs.push(i === 0 ? p[0] : Math.max(p[0], xs[i - 1] + 1)));
  return interpolate(frame, xs, pts.map((p) => p[1]), {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing,
  });
};
