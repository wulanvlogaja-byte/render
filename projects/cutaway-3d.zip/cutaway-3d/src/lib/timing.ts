import type { Cue } from './srt';

// s(i, frac) = frame absolut pada fraksi `frac` di dalam cue ke-i (0-based)
export type S = (i: number, frac?: number) => number;

export const makeS =
  (cues: Cue[], fps: number): S =>
  (i, frac = 0) => {
    if (!cues.length) return 0;
    const c = cues[Math.min(Math.max(i, 0), cues.length - 1)];
    return Math.round((c.start + (c.end - c.start) * frac) * fps);
  };
