export type Cue = { index: number; start: number; end: number; text: string };
export type Word = { text: string; from: number; to: number }; // frame

const parseTime = (t: string) => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error('Format waktu SRT tidak valid: ' + t);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4] / 1000;
};

export const parseSrt = (raw: string): Cue[] =>
  raw
    .replace(/\r/g, '')
    .trim()
    .split(/\n\s*\n/)
    .map((block, i) => {
      const lines = block.split('\n');
      const timeLine = lines.find((l) => l.includes('-->'))!;
      const [a, b] = timeLine.split('-->');
      const text = lines.slice(lines.indexOf(timeLine) + 1).join(' ').trim();
      return { index: i, start: parseTime(a), end: parseTime(b), text };
    });

// Bagi durasi cue ke tiap kata sebanding panjang kata.
export const cuesToWords = (cues: Cue[], fps: number): Word[] => {
  const out: Word[] = [];
  for (const cue of cues) {
    const words = cue.text.split(/\s+/).filter(Boolean);
    if (!words.length) continue;
    const weights = words.map((w) => w.length + 2);
    const total = weights.reduce((a, b) => a + b, 0);
    let t = cue.start;
    words.forEach((w, i) => {
      const dur = ((cue.end - cue.start) * weights[i]) / total;
      out.push({
        text: w.replace(/^[^\p{L}\p{N}]+|[^\p{L}\p{N}'’-]+$/gu, ''),
        from: Math.round(t * fps),
        to: Math.max(Math.round((t + dur) * fps), Math.round(t * fps) + 1),
      });
      t += dur;
    });
  }
  return out;
};
