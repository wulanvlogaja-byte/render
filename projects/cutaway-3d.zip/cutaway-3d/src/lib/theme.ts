// Palet diambil dari banner + avatar channel Suzka Dreamer (dusk lavender, rumput striping, tanah gelap, jendela hangat, navy + tembaga)
export const C = {
  sky: '#CAC3E4',
  skyTop: '#9C8EC8',
  skyLow: '#EBDDEA',
  lawnA: '#4A6228',
  lawnB: '#6F8240',
  roof: '#8F4527',
  wall: '#E7CEA1',
  navy: '#1B2F57',
  night: '#011329',
  glow: '#FFC878',
  copper: '#C97B3C',
  red: '#E8453C',
  water: '#4FB6D6',
  steel: '#A9B0C6',
  wood: '#6B4A35',
  leaf: '#3E5A2B',
};

// Dunia (satuan 3D)
export const W = 90; // lebar tanah
export const FRONT = 10; // sisi depan = penampang
export const BACK = -30;
export const SX0 = 1.4; // lubang bor: x kiri
export const SX1 = 3.6; // x kanan
export const SXC = 2.5;
export const PZ = 5.5; // dinding belakang lubang
export const SZ = 8; // z pusat lubang
export const SHAFT_BOTTOM = -60;
