import { Composition, staticFile } from 'remotion';
import { getAudioDurationInSeconds } from '@remotion/media-utils';
import { Main } from './Main';

export const Root: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    width={1080}
    height={1920}
    fps={30}
    durationInFrames={2066}
    calculateMetadata={async () => {
      const sec = await getAudioDurationInSeconds(staticFile('voice.mp3'));
      return { durationInFrames: Math.ceil(sec * 30) + 15 };
    }}
  />
);
