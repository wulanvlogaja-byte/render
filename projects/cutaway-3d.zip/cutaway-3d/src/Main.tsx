import { AbsoluteFill, Audio, Sequence, cancelRender, continueRender, delayRender, staticFile, useCurrentFrame, useVideoConfig } from 'remotion';
import { ThreeCanvas } from '@remotion/three';
import { useEffect, useMemo, useState } from 'react';
import { parseSrt, cuesToWords } from './lib/srt';
import { makeS } from './lib/timing';
import { buildCamKeys } from './lib/camKeys';
import { World } from './scene/World';
import { Caption } from './ui/Caption';
import { ProgressBar } from './ui/ProgressBar';
import { StatChip, Stat } from './ui/StatChip';
import { Watermark } from './ui/Watermark';

export const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, width, height, durationInFrames } = useVideoConfig();
  const [srt, setSrt] = useState<string | null>(null);
  const [handle] = useState(() => delayRender('srt'));

  useEffect(() => {
    fetch(staticFile('voice.srt'))
      .then((r) => r.text())
      .then((t) => {
        setSrt(t);
        continueRender(handle);
      })
      .catch((e) => cancelRender(e));
  }, [handle]);

  const cues = useMemo(() => (srt ? parseSrt(srt) : []), [srt]);
  const words = useMemo(() => cuesToWords(cues, fps), [cues, fps]);
  const s = useMemo(() => makeS(cues, fps), [cues, fps]);
  const keys = useMemo(() => buildCamKeys(s, durationInFrames - 1), [s, durationInFrames]);

  if (!srt) return null;

  const stats: Stat[] = [
    { text: '30 cm', from: s(1, 0.1), to: s(1, 0.95) },
    { text: '20 tahun', from: s(7, 0.4), to: s(8, 0) },
    { text: '12 km', from: s(8, 0.05), to: s(9, 0) },
    { text: '180°C+', from: s(9, 0.3), to: s(10, 0) },
    { text: '12 km', from: s(11, 0), to: s(11, 0.5) },
    { text: '20 tahun', from: s(11, 0.5), to: s(12, 0) },
    { text: '6.000+ km lagi', from: s(12, 0.1), to: s(13, 0) },
    { text: '0,2%', from: s(13, 0.45), to: s(14, 0) },
  ];

  const sfx: [string, number, number][] = [
    ['tick', s(0, 0.5), 0.4],
    ['whoosh', s(0, 0.55), 0.45],
    ['pop', s(1, 0.05), 0.4],
    ['pop', s(2, 0.05), 0.4],
    ['whoosh', s(3, 0.9), 0.3],
    ['ding', s(4, 0.05), 0.5],
    ['thud', s(5, 0.3), 0.6],
    ['whoosh', s(6, 0), 0.5],
    ['pop', s(6, 0.3), 0.5],
    ['whoosh', s(7, 0), 0.4],
    ['thud', s(8, 0.02), 0.6],
    ['pop', s(9, 0.1), 0.4],
    ['whoosh', s(11, 0), 0.45],
    ['tick', s(11, 0.5), 0.4],
    ['whoosh', s(12, 0), 0.5],
    ['tick', s(12, 0.15), 0.4],
    ['whoosh', s(13, 0.35), 0.5],
    ['pop', s(13, 0.6), 0.4],
    ['pop', s(14, 0.15), 0.5],
    ['whoosh', s(14, 0.55), 0.4],
    ['whoosh', s(15, 0.05), 0.45],
    ['pop', s(15, 0.2), 0.5],
    ['ding', s(15, 0.6), 0.55],
  ];

  return (
    <AbsoluteFill style={{ background: 'linear-gradient(180deg, #9C8EC8 0%, #CAC3E4 50%, #EBDDEA 100%)' }}>
      <ThreeCanvas width={width} height={height} shadows camera={{ fov: 40, position: [0, 6, 22] }}>
        <World s={s} keys={keys} />
      </ThreeCanvas>

      {/* vignette senja bernuansa navy */}
      <AbsoluteFill
        style={{ pointerEvents: 'none', background: 'radial-gradient(ellipse at center, rgba(1,19,41,0) 55%, rgba(1,19,41,0.45) 100%)' }}
      />

      <StatChip stats={stats} />
      <Caption words={words} />
      <Watermark />
      <ProgressBar />

      <Audio src={staticFile('voice.mp3')} />
      <Audio src={staticFile('bgm.mp3')} volume={0.12} loop />
      {sfx.map(([name, from, vol], i) => (
        <Sequence key={i} from={from}>
          <Audio src={staticFile(`sfx/${name}.wav`)} volume={vol} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};
