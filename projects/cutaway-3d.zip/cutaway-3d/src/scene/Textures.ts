import * as THREE from 'three';
import { random } from 'remotion';
import { C } from '../lib/theme';

export type Kind = 'topsoil' | 'clay' | 'sand' | 'rock' | 'hot' | 'crust' | 'mantle' | 'core' | 'lawn' | 'glow';

const PAL: Record<string, string[]> = {
  topsoil: ['#3A2416', '#2E1B10', '#442A19', '#35200F'],
  clay: ['#9A5A32', '#8A4F2C', '#A8643A', '#7F4727'],
  sand: ['#C9A66B', '#BE9A5E', '#D4B27A', '#B58E55'],
  rock: ['#5E5A70', '#524E64', '#6A6680', '#47445A'],
  hot: ['#6B3A2E', '#7A3A22', '#8A4426', '#5C2F28'],
  crust: ['#3B2F3F', '#2F2535', '#463A4B'],
  mantle: ['#7A2E22', '#8C3524', '#6B271D', '#A0442A'],
  core: ['#E07A2E', '#F0A040', '#D8641F'],
};

const cache: Partial<Record<Kind, THREE.CanvasTexture>> = {};

// Semua tekstur prosedural + deterministik (random bersandi seed dari remotion).
export const getTex = (kind: Kind): THREE.CanvasTexture => {
  const hit = cache[kind];
  if (hit) return hit;

  const c = document.createElement('canvas');
  const g = c.getContext('2d')!;

  if (kind === 'lawn') {
    c.width = 256;
    c.height = 8;
    g.fillStyle = C.lawnA;
    g.fillRect(0, 0, 128, 8);
    g.fillStyle = C.lawnB;
    g.fillRect(128, 0, 128, 8);
  } else if (kind === 'glow') {
    c.width = 8;
    c.height = 256;
    const gr = g.createLinearGradient(0, 0, 0, 256);
    gr.addColorStop(0, 'rgba(255,120,40,0)');
    gr.addColorStop(0.55, 'rgba(255,130,50,0.45)');
    gr.addColorStop(1, 'rgba(255,170,70,0.95)');
    g.fillStyle = gr;
    g.fillRect(0, 0, 8, 256);
  } else {
    c.width = 512;
    c.height = 256;
    const bands = PAL[kind];
    let y = 0;
    let i = 0;
    while (y < c.height) {
      const h = 18 + random(kind + 'b' + i) * 46;
      g.fillStyle = bands[i % bands.length];
      g.fillRect(0, y, c.width, h);
      y += h;
      i++;
    }
    const n = kind === 'sand' ? 500 : 320;
    for (let k = 0; k < n; k++) {
      g.fillStyle = `rgba(0,0,0,${0.05 + random(kind + 'd' + k) * 0.12})`;
      g.beginPath();
      g.ellipse(
        random(kind + 'x' + k) * c.width,
        random(kind + 'y' + k) * c.height,
        3 + random(kind + 'rx' + k) * 14,
        2 + random(kind + 'ry' + k) * 6,
        0,
        0,
        Math.PI * 2,
      );
      g.fill();
    }
    if (kind === 'sand') {
      for (let k = 0; k < 45; k++) {
        g.fillStyle = k % 2 ? '#8E8A96' : '#B5AFA6';
        g.beginPath();
        g.ellipse(
          random('sp' + k) * c.width,
          random('spy' + k) * c.height,
          4 + random('spr' + k) * 8,
          3 + random('sps' + k) * 6,
          0,
          0,
          Math.PI * 2,
        );
        g.fill();
      }
    }
    if (kind === 'rock' || kind === 'crust' || kind === 'hot') {
      g.strokeStyle = 'rgba(0,0,0,0.35)';
      g.lineWidth = 2;
      for (let k = 0; k < 14; k++) {
        let x = random('cx' + k) * c.width;
        let y2 = random('cy' + k) * c.height;
        g.beginPath();
        g.moveTo(x, y2);
        for (let j = 0; j < 5; j++) {
          x += (random('cj' + k + '_' + j) - 0.5) * 60;
          y2 += random('ck' + k + '_' + j) * 24;
          g.lineTo(x, y2);
        }
        g.stroke();
      }
    }
    if (kind === 'topsoil') {
      for (let k = 0; k < 160; k++) {
        g.fillStyle = 'rgba(255,200,150,0.08)';
        g.fillRect(random('tf' + k) * c.width, random('tg' + k) * c.height, 3, 3);
      }
    }
  }

  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  cache[kind] = t;
  return t;
};
