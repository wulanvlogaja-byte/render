import React, { useMemo } from 'react';
import * as THREE from 'three';
import { BACK, FRONT, PZ, SX0, SX1, W } from '../lib/theme';
import { Kind, getTex } from './Textures';

type SlabProps = {
  x0: number; x1: number; y0: number; y1: number; z0: number; z1: number;
  kind: Kind; lawn?: boolean; tint?: string;
};

const Slab: React.FC<SlabProps> = ({ x0, x1, y0, y1, z0, z1, kind, lawn = false, tint = '#ffffff' }) => {
  const w = x1 - x0;
  const h = y0 - y1;
  const d = z1 - z0;
  const tex = useMemo(() => {
    const t = getTex(kind).clone();
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(Math.max(1, w / 8), Math.max(0.5, h / 5));
    t.needsUpdate = true;
    return t;
  }, [kind, w, h]);
  const top = useMemo(() => {
    const t = getTex(lawn ? 'lawn' : kind).clone();
    t.wrapS = t.wrapT = THREE.RepeatWrapping;
    t.repeat.set(lawn ? Math.max(1, w / 2.8) : 1, 1);
    t.needsUpdate = true;
    return t;
  }, [lawn, kind, w]);

  return (
    <mesh position={[(x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2]} receiveShadow={lawn}>
      <boxGeometry args={[w, h, d]} />
      {/* urutan: +x, -x, +y, -y, +z (penampang depan), -z */}
      <meshStandardMaterial attach="material-0" map={tex} color={tint} roughness={1} />
      <meshStandardMaterial attach="material-1" map={tex} color={tint} roughness={1} />
      <meshStandardMaterial attach="material-2" map={top} color={lawn ? '#ffffff' : tint} roughness={1} />
      <meshStandardMaterial attach="material-3" map={tex} color={tint} roughness={1} />
      <meshStandardMaterial attach="material-4" map={tex} color={tint} roughness={1} />
      <meshStandardMaterial attach="material-5" map={tex} color={tint} roughness={1} />
    </mesh>
  );
};

type Layer = { id: string; y0: number; y1: number; kind: Kind };

// Lapisan yang dipotong lubang bor (0 sampai -60)
const SHAFT_LAYERS: Layer[] = [
  { id: 'top', y0: 0, y1: -2, kind: 'topsoil' },
  { id: 'clay', y0: -2, y1: -7, kind: 'clay' },
  { id: 'sand', y0: -7, y1: -14, kind: 'sand' },
  { id: 'rock', y0: -14, y1: -44, kind: 'rock' },
  { id: 'hot', y0: -44, y1: -60, kind: 'hot' },
];
// Di bawah dasar lubang: kerak, mantel, inti luar (penuh, tanpa lubang)
const DEEP_LAYERS: Layer[] = [
  { id: 'crust', y0: -60, y1: -80, kind: 'crust' },
  { id: 'mantle', y0: -80, y1: -150, kind: 'mantle' },
  { id: 'core', y0: -150, y1: -200, kind: 'core' },
];

export const Ground: React.FC = () => {
  const L = -W / 2;
  const R = W / 2;
  return (
    <group>
      {SHAFT_LAYERS.map((l) => (
        <group key={l.id}>
          <Slab x0={L} x1={SX0} y0={l.y0} y1={l.y1} z0={BACK} z1={FRONT} kind={l.kind} lawn={l.id === 'top'} />
          <Slab x0={SX1} x1={R} y0={l.y0} y1={l.y1} z0={BACK} z1={FRONT} kind={l.kind} lawn={l.id === 'top'} />
          <Slab x0={SX0} x1={SX1} y0={l.y0} y1={l.y1} z0={BACK} z1={PZ} kind={l.kind} lawn={l.id === 'top'} tint="#9A8C94" />
        </group>
      ))}
      {DEEP_LAYERS.map((l) => (
        <Slab key={l.id} x0={L} x1={R} y0={l.y0} y1={l.y1} z0={BACK} z1={FRONT} kind={l.kind} />
      ))}
    </group>
  );
};
