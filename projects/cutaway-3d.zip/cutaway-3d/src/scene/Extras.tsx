import React from 'react';
import { useCurrentFrame } from 'remotion';
import { C, FRONT, SHAFT_BOTTOM, SX0, SX1, SXC } from '../lib/theme';
import { useAppear } from '../lib/appear';
import type { S } from '../lib/timing';
import { HandleTop, ShovelBlade } from './Digging';

type P3 = [number, number, number];

// Panah putih penjelas (menunjuk ke arah +y lokal, diputar dengan rot di sumbu z; PI = menunjuk ke bawah)
export const Arrow: React.FC<{ pos: P3; rot?: number; len?: number; from: number; to?: number }> = ({
  pos,
  rot = Math.PI,
  len = 1.6,
  from,
  to = Infinity,
}) => {
  const frame = useCurrentFrame();
  const a = useAppear(from, to);
  if (a <= 0.001) return null;
  const pulse = Math.sin(frame / 6) * 0.18;
  const mat = <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.7} />;
  return (
    <group position={pos} rotation={[0, 0, rot]} scale={a}>
      <group position={[0, pulse, 0]}>
        <mesh position={[0, len / 2, 0]}>
          <cylinderGeometry args={[0.09, 0.09, len, 12]} />
          {mat}
        </mesh>
        <mesh position={[0, len + 0.3, 0]}>
          <coneGeometry args={[0.26, 0.6, 16]} />
          {mat}
        </mesh>
      </group>
    </group>
  );
};

// Orang berdiri aman di halaman (payoff)
export const Person: React.FC<{ s: S }> = ({ s }) => {
  const frame = useCurrentFrame();
  const a = useAppear(s(14, 0.15));
  if (a <= 0.001) return null;
  const sway = Math.sin(frame / 15) * 0.03;
  return (
    <group position={[0.4, 0, 8.4]} scale={a} rotation={[0, sway, 0]}>
      {[-0.12, 0.12].map((x) => (
        <mesh key={x} position={[x, 0.45, 0]} castShadow>
          <cylinderGeometry args={[0.09, 0.09, 0.9, 10]} />
          <meshStandardMaterial color={C.navy} roughness={0.8} />
        </mesh>
      ))}
      <mesh position={[0, 1.25, 0]} castShadow>
        <cylinderGeometry args={[0.22, 0.2, 0.75, 12]} />
        <meshStandardMaterial color={C.copper} roughness={0.8} />
      </mesh>
      {[-0.3, 0.3].map((x) => (
        <mesh key={x} position={[x, 1.2, 0]} rotation={[0, 0, x > 0 ? -0.12 : 0.12]} castShadow>
          <cylinderGeometry args={[0.06, 0.06, 0.7, 8]} />
          <meshStandardMaterial color={C.copper} roughness={0.8} />
        </mesh>
      ))}
      <group position={[0, 1.7, 0]} rotation={[0.35, 0, 0]}>
        <mesh castShadow>
          <sphereGeometry args={[0.2, 16, 12]} />
          <meshStandardMaterial color="#E7B98F" roughness={0.8} />
        </mesh>
        <mesh position={[0, 0.07, -0.03]} scale={[1, 0.7, 1]}>
          <sphereGeometry args={[0.215, 16, 12]} />
          <meshStandardMaterial color="#2A1910" roughness={1} />
        </mesh>
      </group>
    </group>
  );
};

// Sekop merah menancap di halaman (callback ke adegan awal)
export const StuckShovel: React.FC<{ s: S }> = ({ s }) => {
  const a = useAppear(s(15, 0.2));
  if (a <= 0.001) return null;
  return (
    <group position={[-1.3, -0.1, 8.6]} rotation={[0, 0, 0.1]} scale={a}>
      <ShovelBlade stub={1.0} />
      <group position={[0, 1.9, 0]}>
        <HandleTop />
      </group>
    </group>
  );
};

// Kotak merah di sekeliling lubang saat "0,2 persen"
export const Highlight: React.FC<{ s: S }> = ({ s }) => {
  const a = useAppear(s(13, 0.6), s(14, 0.25));
  if (a <= 0.001) return null;
  const x0 = SX0 - 0.7;
  const x1 = SX1 + 0.7;
  const y0 = 0.4;
  const y1 = SHAFT_BOTTOM - 0.4;
  const t = 0.5;
  const w = x1 - x0;
  const h = y0 - y1;
  const bars: [number, number, number, number][] = [
    [0, h / 2, w + t, t],
    [0, -h / 2, w + t, t],
    [-w / 2, 0, t, h],
    [w / 2, 0, t, h],
  ];
  return (
    <group position={[(x0 + x1) / 2, (y0 + y1) / 2, FRONT + 0.15]} scale={a}>
      {bars.map((b, i) => (
        <mesh key={i} position={[b[0], b[1], 0]}>
          <boxGeometry args={[b[2], b[3], 0.2]} />
          <meshStandardMaterial color={C.red} emissive={C.red} emissiveIntensity={0.6} />
        </mesh>
      ))}
    </group>
  );
};

// Inti dalam bumi (merah, berdenyut)
export const Core: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <group>
      <mesh position={[SXC, -188, 8]}>
        <sphereGeometry args={[6, 32, 24]} />
        <meshStandardMaterial color={C.red} emissive={C.red} emissiveIntensity={0.7 + 0.2 * Math.sin(frame / 10)} />
      </mesh>
      <pointLight position={[SXC, -185, 22]} color="#FF8A3C" intensity={160} distance={70} decay={2} />
    </group>
  );
};

// Pagar kayu + pohon di belakang (sesuai banner channel)
export const Backdrop: React.FC = () => (
  <group>
    <group position={[0, 0, -8]}>
      {Array.from({ length: 15 }, (_, i) => (
        <mesh key={i} position={[-14 + i * 2, 0.75, 0]} castShadow>
          <boxGeometry args={[0.22, 1.5, 0.18]} />
          <meshStandardMaterial color={C.wood} roughness={1} />
        </mesh>
      ))}
      {[0.5, 1.15].map((y) => (
        <mesh key={y} position={[0, y, 0.12]}>
          <boxGeometry args={[30, 0.12, 0.08]} />
          <meshStandardMaterial color="#7A5840" roughness={1} />
        </mesh>
      ))}
    </group>
    {([[4.5, -13], [-9, -14]] as [number, number][]).map(([x, z], i) => (
      <group key={i} position={[x, 0, z]}>
        <mesh position={[0, 1.6, 0]} castShadow>
          <cylinderGeometry args={[0.28, 0.4, 3.2, 8]} />
          <meshStandardMaterial color="#5D3B1D" roughness={1} />
        </mesh>
        {[[0, 4.2, 0, 2.0], [-1.1, 3.6, 0.3, 1.5], [1.1, 3.7, -0.2, 1.5]].map((c, k) => (
          <mesh key={k} position={[c[0], c[1], c[2]]} castShadow>
            <sphereGeometry args={[c[3], 16, 12]} />
            <meshStandardMaterial color={C.leaf} roughness={1} />
          </mesh>
        ))}
      </group>
    ))}
  </group>
);
