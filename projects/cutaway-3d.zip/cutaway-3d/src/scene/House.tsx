import React, { useMemo } from 'react';
import * as THREE from 'three';
import { C } from '../lib/theme';

const HW = 5.4; // lebar (x)
const HD = 4.4; // dalam (z)
const HH = 4.4; // tinggi dinding

const Win: React.FC<{ x: number; y: number; z: number; glow: number }> = ({ x, y, z, glow }) => (
  <group position={[x, y, z]}>
    <mesh>
      <planeGeometry args={[1.05, 1.4]} />
      <meshStandardMaterial color={C.navy} roughness={0.8} />
    </mesh>
    <mesh position={[0, 0, 0.01]}>
      <planeGeometry args={[0.82, 1.14]} />
      <meshStandardMaterial color={C.glow} emissive={C.glow} emissiveIntensity={glow} />
    </mesh>
    <mesh position={[0, 0, 0.02]}>
      <planeGeometry args={[0.06, 1.14]} />
      <meshStandardMaterial color={C.navy} />
    </mesh>
    <mesh position={[0, 0, 0.02]}>
      <planeGeometry args={[0.82, 0.06]} />
      <meshStandardMaterial color={C.navy} />
    </mesh>
  </group>
);

export const House: React.FC<{ glow: number }> = ({ glow }) => {
  const gable = useMemo(() => {
    const sh = new THREE.Shape();
    sh.moveTo(-HD / 2, 0);
    sh.lineTo(HD / 2, 0);
    sh.lineTo(0, 1.35);
    sh.closePath();
    return sh;
  }, []);
  const zf = HD / 2 + 0.02;
  const pitch = 0.549;

  return (
    <group position={[-3.2, 0, -3]}>
      <mesh position={[0, HH / 2, 0]} castShadow receiveShadow>
        <boxGeometry args={[HW, HH, HD]} />
        <meshStandardMaterial color={C.wall} roughness={0.9} />
      </mesh>
      <mesh position={[0, 2.2, 0]}>
        <boxGeometry args={[HW + 0.1, 0.12, HD + 0.1]} />
        <meshStandardMaterial color="#CDB487" roughness={0.9} />
      </mesh>
      {/* atap pelana terakota */}
      <mesh position={[0, 5.09, 1.225]} rotation={[pitch, 0, 0]} castShadow>
        <boxGeometry args={[HW + 0.5, 0.18, 2.9]} />
        <meshStandardMaterial color={C.roof} roughness={0.8} />
      </mesh>
      <mesh position={[0, 5.09, -1.225]} rotation={[-pitch, 0, 0]} castShadow>
        <boxGeometry args={[HW + 0.5, 0.18, 2.9]} />
        <meshStandardMaterial color={C.roof} roughness={0.8} />
      </mesh>
      <mesh position={[HW / 2 + 0.01, HH, 0]} rotation={[0, Math.PI / 2, 0]}>
        <shapeGeometry args={[gable]} />
        <meshStandardMaterial color="#D8BE90" side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[-HW / 2 - 0.01, HH, 0]} rotation={[0, -Math.PI / 2, 0]}>
        <shapeGeometry args={[gable]} />
        <meshStandardMaterial color="#D8BE90" side={THREE.DoubleSide} />
      </mesh>
      <mesh position={[1.7, 5.7, -0.8]} castShadow>
        <boxGeometry args={[0.6, 1.5, 0.6]} />
        <meshStandardMaterial color="#7A4A38" roughness={0.9} />
      </mesh>
      {/* jendela + pintu */}
      <Win x={-1.7} y={1.5} z={zf} glow={glow} />
      <Win x={1.7} y={1.5} z={zf} glow={glow} />
      <Win x={-1.7} y={3.4} z={zf} glow={glow} />
      <Win x={0} y={3.4} z={zf} glow={glow} />
      <Win x={1.7} y={3.4} z={zf} glow={glow} />
      <mesh position={[0, 0.95, zf]}>
        <planeGeometry args={[0.95, 1.9]} />
        <meshStandardMaterial color={C.navy} roughness={0.8} />
      </mesh>
    </group>
  );
};
