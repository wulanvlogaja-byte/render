import React, { useMemo } from 'react';
import { random, useCurrentFrame } from 'remotion';
import { C, FRONT, PZ, SX0, SX1, SXC, SZ, W } from '../lib/theme';
import { useAppear } from '../lib/appear';
import { kf, prog } from '../lib/anim';
import type { S } from '../lib/timing';

// ---------- Sekop (komponen merah scene 0-5 dan 15) ----------
export const ShovelBlade: React.FC<{ bend?: number; stub?: number }> = ({ bend = 0, stub = 1.0 }) => (
  <group>
    <group rotation={[bend, 0, 0]}>
      <mesh position={[0, 0.45, 0]} castShadow>
        <boxGeometry args={[0.7, 0.9, 0.07]} />
        <meshStandardMaterial color={C.red} roughness={0.45} />
      </mesh>
    </group>
    <mesh position={[0, 0.9 + stub / 2, 0]} castShadow>
      <cylinderGeometry args={[0.07, 0.07, stub, 10]} />
      <meshStandardMaterial color={C.copper} roughness={0.7} />
    </mesh>
  </group>
);

export const HandleTop: React.FC = () => (
  <group>
    <mesh position={[0, 0.8, 0]} castShadow>
      <cylinderGeometry args={[0.07, 0.07, 1.6, 10]} />
      <meshStandardMaterial color={C.copper} roughness={0.7} />
    </mesh>
    <mesh position={[0, 1.6, 0]} castShadow>
      <boxGeometry args={[0.5, 0.1, 0.12]} />
      <meshStandardMaterial color={C.copper} roughness={0.7} />
    </mesh>
  </group>
);

const CLUMPS: [number, number, number][] = [[-0.2, 0.25, 0.08], [0.18, 0.55, 0.1], [0.05, 0.12, 0.1], [-0.12, 0.72, 0.1]];

export const Digger: React.FC<{ s: S }> = ({ s }) => {
  const frame = useCurrentFrame();
  const clump = useAppear(s(2, 0.05));
  const tipY = kf(frame, [
    [0, 0.5],
    [s(0, 0.55), 0.5],
    [s(1, 0.2), -0.1],
    [s(1, 0.95), -1.9],
    [s(2, 0.95), -6.6],
    [s(3, 0.95), -10.6],
    [s(4, 0.6), -13.3],
    [s(5, 0.2), -14.3],
  ]);
  const snapF = s(5, 0.3);
  const bend = kf(frame, [[s(5, 0.2), 0], [snapF, 1.15]]);
  const t = Math.max(0, (frame - snapF) / 30);
  const fall = 0.5 * 28 * t * t;
  const snapped = frame >= snapF;
  if (frame > s(6, 0.15)) return null;

  return (
    <group position={[SXC, tipY, SZ]}>
      <ShovelBlade bend={bend} stub={1.0} />
      {clump > 0.01 &&
        CLUMPS.map((p, i) => (
          <mesh key={i} position={p} scale={clump}>
            <sphereGeometry args={[0.17, 12, 10]} />
            <meshStandardMaterial color="#A8643A" roughness={1} />
          </mesh>
        ))}
      <group position={[0, 1.9 - (snapped ? fall : 0), 0]} rotation={[0, 0, snapped ? t * 3.5 : 0]}>
        <HandleTop />
      </group>
    </group>
  );
};

// ---------- Akar + cacing di tanah pucuk (30 cm) ----------
export const Roots: React.FC<{ s: S }> = ({ s }) => {
  const frame = useCurrentFrame();
  const a = useAppear(s(1, 0.03));
  const roots = useMemo(
    () =>
      Array.from({ length: 16 }, (_, i) => ({
        x: -5 + i * 0.85 + random('rx' + i) * 0.4,
        len: 0.7 + random('rl' + i) * 1.0,
        tilt: (random('rt' + i) - 0.5) * 0.5,
      })),
    [],
  );
  const worms = [{ x: 0.2, y: -1.0 }, { x: 4.9, y: -1.45 }, { x: -1.5, y: -0.7 }];
  if (a <= 0.001) return null;
  return (
    <group position={[0, 0, FRONT + 0.04]}>
      {roots
        .filter((r) => r.x < SX0 - 0.1 || r.x > SX1 + 0.1)
        .map((r, i) => (
          <mesh key={i} position={[r.x, -r.len / 2, 0]} rotation={[0, 0, r.tilt]} scale={[1, a, 1]}>
            <cylinderGeometry args={[0.035, 0.015, r.len, 6]} />
            <meshStandardMaterial color="#8A5E38" roughness={1} />
          </mesh>
        ))}
      {worms.map((w, wi) => (
        <group key={wi} position={[w.x, w.y, 0.02]} scale={a}>
          {Array.from({ length: 7 }, (_, k) => (
            <mesh key={k} position={[k * 0.15, Math.sin(frame / 5 + k * 0.9 + wi) * 0.07, 0]}>
              <sphereGeometry args={[0.085, 10, 8]} />
              <meshStandardMaterial color="#E58F86" roughness={0.6} />
            </mesh>
          ))}
        </group>
      ))}
    </group>
  );
};

// ---------- Kerikil di lapisan pasir ----------
export const Pebbles: React.FC<{ s: S }> = ({ s }) => {
  const frame = useCurrentFrame();
  const list = useMemo(
    () =>
      Array.from({ length: 28 }, (_, i) => {
        const u = random('pu' + i);
        return {
          x: u < 0.5 ? -2 + u * 2 * 3.2 : 3.9 + (u - 0.5) * 2 * 3.0,
          y: -7.5 - random('py' + i) * 6.0,
          r: 0.1 + random('pr' + i) * 0.2,
          c: ['#8E8A96', '#B5AFA6', '#6F6A7A'][i % 3],
        };
      }),
    [],
  );
  return (
    <group position={[0, 0, FRONT + 0.02]}>
      {list.map((p, i) => {
        const t = prog(frame, s(3, 0.02) + i * 2, s(3, 0.02) + i * 2 + 10);
        if (t <= 0) return null;
        return (
          <mesh key={i} position={[p.x, p.y, 0]} scale={[t, t, t * 0.6]}>
            <sphereGeometry args={[p.r, 12, 10]} />
            <meshStandardMaterial color={p.c} roughness={0.8} />
          </mesh>
        );
      })}
    </group>
  );
};

// ---------- Air tanah ----------
export const Water: React.FC<{ s: S }> = ({ s }) => {
  const frame = useCurrentFrame();
  const wet = prog(frame, s(3, 0.55), s(3, 0.85));
  const rise = prog(frame, s(4, 0), s(4, 0.45));
  const hW = 2.8;
  const ring = (frame / 24) % 1;
  return (
    <group>
      {wet > 0 && (
        <group position={[0, -12.25, FRONT + 0.03]}>
          <mesh position={[(-W / 2 + SX0) / 2, 0, 0]}>
            <planeGeometry args={[SX0 + W / 2, 3.5]} />
            <meshBasicMaterial color={C.water} transparent opacity={0.3 * wet} depthWrite={false} />
          </mesh>
          <mesh position={[(SX1 + W / 2) / 2, 0, 0]}>
            <planeGeometry args={[W / 2 - SX1, 3.5]} />
            <meshBasicMaterial color={C.water} transparent opacity={0.3 * wet} depthWrite={false} />
          </mesh>
        </group>
      )}
      {rise > 0.001 && (
        <group position={[SXC, -14, (PZ + FRONT) / 2]} scale={[1, rise, 1]}>
          <mesh position={[0, hW / 2, 0]}>
            <boxGeometry args={[SX1 - SX0 - 0.06, hW, FRONT - PZ - 0.06]} />
            <meshStandardMaterial color={C.water} transparent opacity={0.62} roughness={0.15} depthWrite={false} />
          </mesh>
        </group>
      )}
      {rise > 0.95 &&
        [0, 0.5].map((o) => {
          const t = (ring + o) % 1;
          return (
            <mesh key={o} position={[SXC, -14 + hW + 0.03, SZ]} rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[0.15 + t * 0.8, 0.025, 8, 32]} />
              <meshBasicMaterial color="#ffffff" transparent opacity={0.8 * (1 - t)} />
            </mesh>
          );
        })}
    </group>
  );
};
