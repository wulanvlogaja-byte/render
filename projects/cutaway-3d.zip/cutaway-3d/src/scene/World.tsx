import React from 'react';
import { useCurrentFrame } from 'remotion';
import { CameraRig, CamKey } from '../lib/camera';
import { prog } from '../lib/anim';
import { FRONT, SXC, SZ } from '../lib/theme';
import type { S } from '../lib/timing';
import { Ground } from './Ground';
import { House } from './House';
import { Digger, Pebbles, Roots, Water } from './Digging';
import { Blobs, Derrick, DepthMarks, Drill, Heat } from './Drilling';
import { Arrow, Backdrop, Core, Highlight, Person, StuckShovel } from './Extras';

export const World: React.FC<{ s: S; keys: CamKey[] }> = ({ s, keys }) => {
  const frame = useCurrentFrame();
  // jendela menyala makin terang menjelang akhir (banner: jendela hangat saat senja)
  const glow = 0.7 + 1.1 * prog(frame, s(14, 0.9), s(15, 0.5));

  return (
    <>
      <ambientLight intensity={0.9} color="#C9BBE6" />
      <directionalLight
        position={[10, 16, 14]}
        intensity={2.2}
        color="#FFD6A8"
        castShadow
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-16}
        shadow-camera-right={16}
        shadow-camera-top={16}
        shadow-camera-bottom={-16}
        shadow-camera-near={1}
        shadow-camera-far={60}
        shadow-bias={-0.0004}
      />
      <CameraRig keys={keys} frame={frame} />

      <Ground />
      <House glow={glow} />
      <Backdrop />
      <Core />

      <Roots s={s} />
      <Pebbles s={s} />
      <Water s={s} />
      <Digger s={s} />

      <Derrick s={s} />
      <Drill s={s} />
      <DepthMarks s={s} />
      <Heat s={s} />
      <Blobs s={s} />

      <Highlight s={s} />
      <Person s={s} />
      <StuckShovel s={s} />

      {/* panah putih penjelas */}
      <Arrow pos={[SXC, 3.6, SZ]} rot={Math.PI} len={1.4} from={s(0, 0.5)} to={s(1, 0.1)} />
      <Arrow pos={[4.7, -12.2, FRONT + 0.3]} rot={Math.PI / 2} len={1.0} from={s(4, 0.3)} to={s(5, 0)} />
      <Arrow pos={[5.3, -59, FRONT + 0.3]} rot={Math.PI / 2} len={1.0} from={s(8, 0.1)} to={s(9, 0)} />
      {[-72, -105, -140].map((y, i) => (
        <Arrow key={y} pos={[SXC, y, FRONT + 0.5]} rot={Math.PI} len={3} from={s(12, 0.15 + i * 0.2)} to={s(13, 0.3)} />
      ))}
      <Arrow pos={[-1.3, 4.7, 8.6]} rot={Math.PI} len={0.9} from={s(15, 0.3)} />
    </>
  );
};
