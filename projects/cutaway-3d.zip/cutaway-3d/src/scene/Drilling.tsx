import React, { useMemo } from 'react';
import * as THREE from 'three';
import { useCurrentFrame } from 'remotion';
import { C, FRONT, PZ, SHAFT_BOTTOM, SX0, SX1, SXC, SZ } from '../lib/theme';
import { useAppear } from '../lib/appear';
import { kf, prog } from '../lib/anim';
import type { S } from '../lib/timing';
import { getTex } from './Textures';

type P3 = [number, number, number];

const Beam: React.FC<{ a: P3; b: P3; r?: number; color?: string }> = ({ a, b, r = 0.08, color = C.steel }) => {
  const { pos, len, quat } = useMemo(() => {
    const A = new THREE.Vector3(a[0], a[1], a[2]);
    const B = new THREE.Vector3(b[0], b[1], b[2]);
    const d = B.clone().sub(A);
    const length = d.length();
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.clone().normalize());
    return { pos: A.clone().add(B).multiplyScalar(0.5), len: length, quat: q };
  }, [a.join(), b.join()]);
  return (
    <mesh position={pos} quaternion={quat} castShadow>
      <cylinderGeometry args={[r, r, len, 8]} />
      <meshStandardMaterial color={color} roughness={0.6} metalness={0.2} />
    </mesh>
  );
};

const TOP_Y = 7.4;
const BIT_TIP = SHAFT_BOTTOM + 0.35;

// ---------- Menara bor Kola ----------
export const Derrick: React.FC<{ s: S }> = ({ s }) => {
  const a = useAppear(s(6, 0.3));
  if (a <= 0.001) return null;
  const R = 1.5;
  const corners: [number, number][] = [[-R, -R], [R, -R], [R, R], [-R, R]];
  const pt = (c: [number, number], h: number): P3 => [SXC + c[0] * (1 - h / TOP_Y), h, SZ + c[1] * (1 - h / TOP_Y)];
  const levels = [2, 4, 5.8];
  return (
    <group scale={[1, a, 1]}>
      {corners.map((c, i) => (
        <Beam key={'l' + i} a={pt(c, 0)} b={pt(c, TOP_Y)} r={0.1} />
      ))}
      {levels.map((h) =>
        corners.map((c, i) => <Beam key={'h' + h + i} a={pt(c, h)} b={pt(corners[(i + 1) % 4], h)} r={0.06} color="#8890AC" />),
      )}
      <Beam a={pt(corners[3], 0)} b={pt(corners[2], 2)} r={0.05} color="#8890AC" />
      <Beam a={pt(corners[2], 0)} b={pt(corners[3], 2)} r={0.05} color="#8890AC" />
      <Beam a={pt(corners[3], 2)} b={pt(corners[2], 4)} r={0.05} color="#8890AC" />
      <Beam a={pt(corners[2], 2)} b={pt(corners[3], 4)} r={0.05} color="#8890AC" />
      <mesh position={[SXC, TOP_Y + 0.15, SZ]} castShadow>
        <boxGeometry args={[0.7, 0.35, 0.7]} />
        <meshStandardMaterial color={C.copper} roughness={0.6} />
      </mesh>
    </group>
  );
};

// ---------- Pipa + mata bor merah (komponen merah scene 7-8) ----------
export const Drill: React.FC<{ s: S }> = ({ s }) => {
  const frame = useCurrentFrame();
  const start = s(6, 0.55);
  if (frame < start) return null;
  const tip = kf(frame, [[s(7, 0), 0.9], [s(8, 0), BIT_TIP]]);
  const topY = TOP_Y - 0.2;
  const h = Math.max(0.1, topY - tip);
  const hot = prog(frame, s(9, 0), s(9, 0) + 25);
  const col = new THREE.Color(C.red).lerp(new THREE.Color(C.steel), hot);
  const grow = prog(frame, start, start + 12);
  return (
    <group>
      <mesh position={[SXC, (topY + tip) / 2, SZ]} castShadow>
        <cylinderGeometry args={[0.1, 0.1, h, 10]} />
        <meshStandardMaterial color="#7B84A0" metalness={0.3} roughness={0.5} />
      </mesh>
      <group position={[SXC, tip + 0.35, SZ]} rotation={[0, frame * 0.35, 0]} scale={grow}>
        <mesh rotation={[Math.PI, 0, 0]}>
          <coneGeometry args={[0.34, 0.7, 6]} />
          <meshStandardMaterial color={col} flatShading roughness={0.4} />
        </mesh>
        <mesh position={[0, 0.28, 0]}>
          <boxGeometry args={[0.75, 0.07, 0.07]} />
          <meshStandardMaterial color={C.copper} />
        </mesh>
      </group>
    </group>
  );
};

// ---------- Garis 12 km + penggaris kedalaman ----------
export const DepthMarks: React.FC<{ s: S }> = ({ s }) => {
  const frame = useCurrentFrame();
  const a = prog(frame, s(8, 0.05), s(8, 0.3));
  if (a <= 0) return null;
  const white = <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.7} />;
  return (
    <group position={[0, 0, FRONT + 0.04]}>
      <mesh position={[SXC, SHAFT_BOTTOM, 0]} scale={[a, 1, 1]}>
        <boxGeometry args={[16, 0.1, 0.05]} />
        {white}
      </mesh>
      <mesh position={[6.6, SHAFT_BOTTOM / 2, 0]} scale={[1, a, 1]}>
        <boxGeometry args={[0.06, 60, 0.05]} />
        {white}
      </mesh>
      {Array.from({ length: 7 }, (_, k) => (
        <mesh key={k} position={[6.9, -k * 10, 0]} scale={[a, 1, 1]}>
          <boxGeometry args={[0.7, 0.07, 0.05]} />
          {white}
        </mesh>
      ))}
    </group>
  );
};

// ---------- Panas: glow oranye, partikel naik, termometer merah ----------
export const Heat: React.FC<{ s: S }> = ({ s }) => {
  const frame = useCurrentFrame();
  const glowTex = useMemo(() => getTex('glow'), []);
  const th = useAppear(s(9, 0.1), s(11, 0));
  const g = prog(frame, s(9, 0.1), s(9, 0.5)) * (0.8 + 0.12 * Math.sin(frame / 7));
  const m = prog(frame, s(9, 0.15), s(9, 0.9));
  if (g <= 0.001) return null;
  return (
    <group>
      <mesh position={[SXC, -52.5, FRONT + 0.05]}>
        <planeGeometry args={[60, 16]} />
        <meshBasicMaterial map={glowTex} transparent opacity={g} depthWrite={false} blending={THREE.AdditiveBlending} />
      </mesh>
      {Array.from({ length: 8 }, (_, i) => (
        <mesh
          key={i}
          position={[SXC + Math.sin(frame / 12 + i * 1.7) * 0.5, SHAFT_BOTTOM + 0.6 + ((frame * 0.05 + i * 1.15) % 9), PZ + 0.8 + (i % 3) * 0.6]}
        >
          <sphereGeometry args={[0.07, 8, 8]} />
          <meshBasicMaterial color="#FFB066" />
        </mesh>
      ))}
      <pointLight position={[SXC, -57, 13]} color="#FF7A2E" intensity={120 * g} distance={30} decay={2} />
      {th > 0.001 && (
        <group position={[4.1, -57.5, FRONT + 0.3]} scale={th}>
          <mesh position={[0, 1.9, 0]}>
            <cylinderGeometry args={[0.13, 0.13, 3.8, 12]} />
            <meshStandardMaterial color="#ffffff" transparent opacity={0.35} />
          </mesh>
          <mesh>
            <sphereGeometry args={[0.28, 16, 12]} />
            <meshStandardMaterial color={C.red} emissive={C.red} emissiveIntensity={0.5} />
          </mesh>
          <mesh position={[0, (3.4 * m) / 2, 0]}>
            <cylinderGeometry args={[0.07, 0.07, Math.max(0.01, 3.4 * m), 10]} />
            <meshStandardMaterial color={C.red} emissive={C.red} emissiveIntensity={0.5} />
          </mesh>
        </group>
      )}
    </group>
  );
};

// ---------- Dinding batu lembek menonjol ke lubang ----------
export const Blobs: React.FC<{ s: S }> = ({ s }) => {
  const frame = useCurrentFrame();
  const list: [number, number][] = [[-1, -52.5], [1, -54], [-1, -55.5], [1, -57], [-1, -58.3], [1, -50.8]];
  return (
    <group>
      {list.map(([side, y], i) => {
        const t = prog(frame, s(10, 0.05) + i * 4, s(10, 0.05) + i * 4 + 14);
        if (t <= 0) return null;
        const sc = t * (1 + 0.12 * Math.sin(frame / 7 + i));
        return (
          <mesh key={i} position={[SXC + side * 0.95, y, SZ + (i % 2) * 0.5 - 0.2]} scale={sc}>
            <sphereGeometry args={[0.5, 16, 12]} />
            <meshStandardMaterial color="#9A4A2E" emissive="#FF7A2E" emissiveIntensity={0.45} roughness={0.35} />
          </mesh>
        );
      })}
    </group>
  );
};
