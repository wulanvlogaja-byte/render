# Gali Kola Borehole — video 9:16 Suzka Dreamer (Remotion 3D cutaway)

Narasi: `public/voice.mp3` (ElevenLabs Janu) + `public/voice.srt` (Gali Kola Borehole). 2066 frame, 30 fps, 1080x1920.
Branding: palet dari banner/avatar channel (senja lavender, rumput striping, tanah gelap, jendela hangat, navy + tembaga). Gambar channel tidak dimasukkan ke video.
Watermark kiri atas: ikon YouTube + `suzkadreamer` (`src/ui/Watermark.tsx`).

## Render lewat GitHub Actions
1. Buat repo GitHub, push isi folder ini (termasuk `.github/workflows`).
2. Tab **Actions** -> **render-remotion** -> **Run workflow** (chunk default 450 frame).
3. Setelah selesai, download artifact **final-video** (`final.mp4`).
Kalau satu chunk gagal: re-run job itu saja, lalu re-run job `merge`.
Kalau frame hitam / three.js gagal init: ganti `--gl=swangle` jadi `--gl=angle` di workflow.

## Preview lokal
```
npm install
npm run dev                                  # Remotion Studio
npx remotion still src/index.ts Main out/f.png --frame=0 --gl=swangle
```
Index cue SRT -> adegan ada di komentar `src/lib/camKeys.ts`. Ganti sfx/bgm: `python3 scripts/make_sfx.py`.
