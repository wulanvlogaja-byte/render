import numpy as np, wave, os
SR = 44100
os.makedirs('public/sfx', exist_ok=True)

def save(name, x):
    x = np.clip(x / max(1e-9, np.max(np.abs(x))), -1, 1) * 0.9
    with wave.open(f'public/sfx/{name}.wav', 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype('<i2').tobytes())

rng = np.random.default_rng(7)
def env(n, a=0.01, r=0.2):
    t = np.linspace(0, 1, n); return np.minimum(t / a, 1) * np.exp(-t / r)

# whoosh
n = int(SR * 0.7); noise = rng.standard_normal(n)
sweep = np.cumsum(noise); sweep -= np.convolve(sweep, np.ones(400) / 400, 'same')
save('whoosh', sweep * np.sin(np.linspace(0, np.pi, n)) ** 2)

# pop
n = int(SR * 0.18); t = np.arange(n) / SR
save('pop', np.sin(2 * np.pi * (700 - 2500 * t) * t) * env(n, 0.002, 0.08))

# thud
n = int(SR * 0.5); t = np.arange(n) / SR
save('thud', np.sin(2 * np.pi * 55 * t) * env(n, 0.003, 0.18))

# ding
n = int(SR * 0.9); t = np.arange(n) / SR
save('ding', (np.sin(2 * np.pi * 988 * t) + 0.4 * np.sin(2 * np.pi * 1976 * t)) * env(n, 0.002, 0.3))

# tick
n = int(SR * 0.05); save('tick', rng.standard_normal(n) * env(n, 0.001, 0.02))

# bgm: pad A minor lembut 70 detik
dur = 70; n = SR * dur; t = np.arange(n) / SR
chords = [(220, 261.6, 329.6), (196, 246.9, 293.7), (174.6, 220, 261.6), (196, 246.9, 293.7)]
bgm = np.zeros(n)
for i, ch in enumerate(chords * 6):
    a, b = int(i * 4 * SR), int((i + 1) * 4 * SR)
    if a >= n: break
    b = min(b, n); seg = t[a:b] - t[a]
    for f in ch:
        bgm[a:b] += np.sin(2 * np.pi * f * seg) * np.sin(np.pi * seg / 4) ** 2
save('bgm', bgm)
os.replace('public/sfx/bgm.wav', 'public/bgm.wav')
