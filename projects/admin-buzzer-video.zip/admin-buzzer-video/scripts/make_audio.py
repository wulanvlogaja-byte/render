#!/usr/bin/env python3
"""
Sintesis semua SFX + backsound (royalty-free, bikinan sendiri) -> public/sfx/*.mp3
Jalankan ulang kalau mau ngubah:  python3 scripts/make_audio.py
Butuh: numpy, scipy, ffmpeg.
"""
import os, json, subprocess, wave
import numpy as np
from scipy.signal import butter, lfilter

SR = 44100
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "public", "sfx")
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(7)


def T(d):
    return np.arange(int(SR * d)) / SR


def lp(x, f):
    b, a = butter(2, f / (SR / 2), "low")
    return lfilter(b, a, x)


def hp(x, f):
    b, a = butter(2, f / (SR / 2), "high")
    return lfilter(b, a, x)


def bp(x, lo, hi):
    b, a = butter(2, [lo / (SR / 2), hi / (SR / 2)], "band")
    return lfilter(b, a, x)


def noise(d):
    return rng.uniform(-1, 1, int(SR * d))


def sine_sweep(t, f0, f1, k=None):
    """sine dengan frekuensi meluncur f0 -> f1 (linear)."""
    f = f0 + (f1 - f0) * (t / t[-1])
    return np.sin(2 * np.pi * np.cumsum(f) / SR)


def phase_sine(f):
    return np.sin(2 * np.pi * np.cumsum(f) / SR)


def saw(f):
    ph = (np.cumsum(f) / SR) % 1.0
    return 2 * ph - 1


def fade(x, a=0.004, r=0.02):
    n = len(x)
    na, nr = int(SR * a), int(SR * r)
    e = np.ones(n)
    if na > 0:
        e[:na] = np.linspace(0, 1, na)
    if nr > 0:
        e[-nr:] = np.linspace(1, 0, nr)
    return x * e


def place(buf, x, at):
    i = int(SR * at)
    n = min(len(x), len(buf) - i)
    if n > 0:
        buf[i:i + n] += x[:n]
    return buf


def bell(f0, d, partials=(1, 2.76, 5.4, 8.9), amps=(1, .5, .25, .12), k=5):
    t = T(d)
    x = sum(a * np.sin(2 * np.pi * f0 * p * t) * np.exp(-t * k * (1 + i * .6))
            for i, (p, a) in enumerate(zip(partials, amps)))
    return x


def reverb(x, mix=.25, taps=((0.045, .5), (0.09, .35), (0.14, .25), (0.21, .15))):
    y = np.copy(x)
    pad = int(SR * 0.3)
    y = np.concatenate([y, np.zeros(pad)])
    for dly, g in taps:
        i = int(SR * dly)
        y[i:i + len(x)] += x * g * mix * 2
    return y


durations = {}


def save(name, x, peak=0.85):
    x = np.asarray(x, dtype=np.float64)
    m = np.max(np.abs(x)) or 1
    x = x / m * peak
    x = fade(x, 0.002, 0.015)
    wav_path = os.path.join(OUT, name + ".wav")
    mp3_path = os.path.join(OUT, name + ".mp3")
    with wave.open(wav_path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((x * 32767).astype(np.int16).tobytes())
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", wav_path, "-codec:a", "libmp3lame", "-b:a", "128k", mp3_path], check=True)
    os.remove(wav_path)
    durations[name] = round(len(x) / SR, 3)


# ---------------------------------------------------------------- SFX
def whoosh(d=0.6, rev=False):
    t = T(d)
    n = noise(d)
    lo, mid, hi = bp(n, 150, 500), bp(n, 500, 1800), bp(n, 1800, 6000)
    p = t / d
    x = lo * np.exp(-((p - .2) / .25) ** 2) + mid * np.exp(-((p - .5) / .22) ** 2) + hi * np.exp(-((p - .8) / .2) ** 2)
    x *= np.sin(np.pi * p) ** 1.2
    return x[::-1] if rev else x


save("whoosh", whoosh(0.55))
save("whoosh-rev", whoosh(0.7, rev=True))


def boom(d=0.9, f0=130, f1=32, k=4.5):
    t = T(d)
    x = phase_sine(f0 * (f1 / f0) ** (t / d)) * np.exp(-t * k)
    x += lp(noise(d), 600) * np.exp(-t * 18) * .8
    return np.tanh(x * 2.2)


save("boom", boom())
save("vine-boom", boom(1.2, 95, 28, 3.2))


def pop(f0=420, rise=3200, d=0.16, k=34):
    t = T(d)
    return np.sin(2 * np.pi * np.cumsum(f0 + rise * t) / SR) * np.exp(-t * k)


save("pop", pop())
save("pop-low", pop(260, 1500, 0.2, 28))

save("ding", bell(1318, 1.1, k=3.2))
save("bell", bell(1760, 1.8, k=2.2, partials=(1, 2.0, 3.01, 4.2), amps=(1, .6, .4, .2)) * (1 + .35 * np.sin(2 * np.pi * 9 * T(1.8))))


def cash():
    d = 1.1
    buf = np.zeros(int(SR * d))
    cha = hp(noise(.12), 2500) * np.exp(-T(.12) * 40)
    place(buf, cha, 0)
    place(buf, bell(2093, .9, k=4.5, partials=(1, 2.4, 4.1), amps=(1, .6, .35)), 0.1)
    place(buf, hp(noise(.08), 3000) * np.exp(-T(.08) * 60) * .6, 0.12)
    return buf


save("cash", cash())


def coin():
    buf = np.zeros(int(SR * .5))
    place(buf, np.sin(2 * np.pi * 1318 * T(.1)) * np.exp(-T(.1) * 25), 0)
    place(buf, np.sin(2 * np.pi * 1760 * T(.4)) * np.exp(-T(.4) * 9), 0.08)
    return buf


save("coin", coin())


def notif():
    buf = np.zeros(int(SR * .45))
    for at, f in ((0, 987), (0.09, 1480)):
        t = T(.3)
        place(buf, (np.sin(2 * np.pi * f * t) + .3 * np.sin(2 * np.pi * 2 * f * t)) * np.exp(-t * 14), at)
    return buf


save("notif", notif())


def sent():
    t = T(.3)
    x = sine_sweep(t, 500, 1900) * np.sin(np.pi * t / .3) * .7
    buf = np.zeros(int(SR * .45))
    place(buf, x, 0)
    place(buf, np.sin(2 * np.pi * 1900 * T(.1)) * np.exp(-T(.1) * 40) * .6, .28)
    return buf


save("sent", sent())


def scratch():
    d = .65
    t = T(d)
    f = 520 * np.exp(-t * 3) * (1 + .9 * np.sin(2 * np.pi * (5 + 14 * t) * t))
    f = np.abs(f) + 60
    x = saw(f) * .6 + bp(noise(d), 800, 5000) * .8
    x = bp(x, 300, 6000)
    e = np.where(t < .5, 1, np.exp(-(t - .5) * 40)) * np.minimum(1, t * 80)
    return x * e


save("scratch", scratch())


def slide_whistle(d=.9, f0=2000, f1=260):
    t = T(d)
    f = f0 + (f1 - f0) * (t / d) ** .8 + 25 * np.sin(2 * np.pi * 7 * t)
    return phase_sine(f) * np.sin(np.pi * t / d) ** .4 * .8


save("slide-down", slide_whistle())
save("slide-up", slide_whistle(.6, 300, 1800))


def tick(f=1800, k=120):
    t = T(.08)
    return (np.sin(2 * np.pi * f * t) * .6 + hp(noise(.08), 2000) * .8) * np.exp(-t * k)


save("tick", tick())
save("tock", tick(1100, 100))


def typing(d=3.0):
    buf = np.zeros(int(SR * d))
    at = 0.0
    while at < d - .1:
        f = rng.choice([1300, 1600, 1900, 2300])
        c = tick(f, rng.uniform(90, 160)) * rng.uniform(.5, 1)
        place(buf, c, at)
        at += rng.uniform(.055, .13)
    return buf


save("typing", typing())


def click():
    t = T(.06)
    return (np.sin(2 * np.pi * 1200 * t) * .8 + hp(noise(.06), 1500) * .5) * np.exp(-t * 90)


save("click", click())


def shutter():
    buf = np.zeros(int(SR * .5))
    place(buf, tick(2400, 70) * 1.2, 0)
    place(buf, tick(1700, 60) * 1.0, .045)
    place(buf, hp(noise(.25), 1500) * np.exp(-T(.25) * 18) * .3, .02)
    return buf


save("shutter", shutter())


def trombone():
    notes = [(233.1, .45), (220.0, .45), (207.7, .45), (196.0, 1.1)]
    total = sum(d for _, d in notes) + .3
    buf = np.zeros(int(SR * total))
    at = 0
    for i, (f, d) in enumerate(notes):
        t = T(d)
        last = i == len(notes) - 1
        fm = f * (1 + .012 * np.sin(2 * np.pi * 5.5 * t) * (t / d))
        if last:
            fm = fm * (1 - .05 * (t / d) ** 2)
        x = sum(saw(fm * (1 + .002 * j)) / (1 + j) for j in range(3))
        x = lp(x, 1500)
        wah = (.45 + .55 * np.sin(np.pi * np.minimum(1, t / (d * .85))) ** .6)
        x *= wah * np.minimum(1, t * 30) * (np.exp(-(t - d + .1) * 8) if last else 1)
        place(buf, x, at)
        at += d if not last else 0
    return reverb(buf, .15)


save("sad-trombone", trombone())


def stinger(n=3, gap=.38, f=78):
    total = gap * n + 1.4
    buf = np.zeros(int(SR * total))
    for i in range(n):
        d = 1.2 if i == n - 1 else .6
        t = T(d)
        x = lp(saw(np.full(len(t), f * (1 if i < n - 1 else .84))) * .8, 500) + .8 * np.sin(2 * np.pi * f * .5 * t)
        x += hp(noise(d), 1000) * np.exp(-t * 30) * .6
        place(buf, np.tanh(x * 1.8) * np.exp(-t * (3 if i == n - 1 else 6)), i * gap)
    return reverb(buf, .3)


save("stinger", stinger())
save("stinger-2", stinger(2, .45, 98))


def airhorn(d=1.1):
    t = T(d)
    f = 466 * (1 - .06 * np.clip((t - .85) / .25, 0, 1)) * (1 + .004 * np.sin(2 * np.pi * 6 * t))
    x = sum(saw(f * m) * a for m, a in ((1, 1), (1.005, .8), (.995, .8), (2, .45), (3, .3)))
    x = bp(x, 300, 5000)
    x = np.tanh(x * .9)
    e = np.minimum(1, t * 120) * np.where(t < d - .2, 1, np.exp(-(t - (d - .2)) * 18))
    return x * e


save("airhorn", airhorn())


def heartbeat():
    buf = np.zeros(int(SR * 1.3))
    for at in (0, .38, .95):
        t = T(.3)
        a = .9 if at != .38 else .6
        place(buf, np.sin(2 * np.pi * 62 * t) * np.exp(-t * 16) * a, at)
    return buf


save("heartbeat", heartbeat())


def shimmer():
    buf = np.zeros(int(SR * 1.0))
    for i, f in enumerate((1046, 1318, 1568, 2093, 2637, 3136)):
        t = T(.45)
        place(buf, np.sin(2 * np.pi * f * t) * np.exp(-t * 9) * .7, i * .06)
    return buf


save("shimmer", shimmer())


def boing(d=.6):
    t = T(d)
    f = 260 + 240 * np.exp(-t * 5) * np.sin(2 * np.pi * 11 * t)
    return phase_sine(f) * np.exp(-t * 5) + .2 * np.sin(2 * np.pi * 2 * np.cumsum(f) / SR) * np.exp(-t * 7)


save("boing", boing())


def bonk():
    t = T(.25)
    return (phase_sine(330 * np.exp(-t * 8)) + .5 * np.sin(2 * np.pi * 660 * t)) * np.exp(-t * 22)


save("bonk", bonk())


def thud():
    d = .45
    t = T(d)
    return np.tanh((phase_sine(90 * np.exp(-t * 9)) * np.exp(-t * 10) + lp(noise(d), 1500) * np.exp(-t * 40)) * 2)


save("thud", thud())


def plop():
    t = T(.2)
    return np.sin(2 * np.pi * np.cumsum(500 - 1800 * t) / SR) * np.exp(-t * 22)


save("plop", plop())


def shh():
    d = .6
    t = T(d)
    return bp(noise(d), 3000, 8000) * np.sin(np.pi * t / d) ** 2 * .6


save("shh", shh())


def squeak():
    t = T(.35)
    f = 1200 + 900 * np.sin(np.pi * t / .35) ** 2
    return phase_sine(f) * np.sin(np.pi * t / .35) * .6


save("squeak", squeak())


def drumroll(d=1.6):
    buf = np.zeros(int(SR * d))
    at = 0.0
    step = .12
    while at < d - .05:
        place(buf, tick(900, 55) * (.35 + .65 * at / d), at)
        step = max(.035, step * .93)
        at += step
    return buf


save("drumroll", drumroll())

# ---------------------------------------------------------------- BACKSOUND (loop 16 bar @ 120 bpm = 32 s)
BPM = 120
BEAT = 60 / BPM
BARS = 16
LOOP = BARS * 4 * BEAT
TAIL = 1.0
buf = np.zeros(int(SR * (LOOP + TAIL)))


def midi(m):
    return 440 * 2 ** ((m - 69) / 12)


def pluck(m, d, amp=1.0):
    t = T(d)
    f = np.full(len(t), midi(m))
    x = lp(saw(f) + .5 * saw(f * 1.005), 900) * np.exp(-t * 7)
    return x * amp


def marimba(m, d=.5, amp=1.0):
    t = T(d)
    f = midi(m)
    return (np.sin(2 * np.pi * f * t) + .35 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-t * 30)) * np.exp(-t * 9) * amp


def stab(ms, d=.22, amp=1.0):
    t = T(d)
    x = sum(lp(saw(np.full(len(t), midi(m))), 1800) for m in ms) / len(ms)
    return x * np.exp(-t * 14) * amp


def kick():
    t = T(.3)
    return phase_sine(110 * np.exp(-t * 18) + 42) * np.exp(-t * 11)


def clap():
    t = T(.2)
    return bp(noise(.2), 1200, 4500) * np.exp(-t * 22)


def hat():
    t = T(.07)
    return hp(noise(.07), 6500) * np.exp(-t * 70)


prog = [  # (bass midi, chord midi list)
    (45, [57, 60, 64]),  # Am
    (41, [57, 60, 65]),  # F
    (48, [55, 60, 64]),  # C
    (40, [56, 59, 64]),  # E
]
motifs = [
    [(0, 76, .4), (.5, 74, .4), (1, 72, .4), (2, 69, .8), (3.5, 72, .4)],
    [(0, 72, .4), (.5, 69, .4), (1, 65, .4), (2, 69, .8), (3, 72, .4)],
    [(0, 76, .4), (.5, 76, .4), (1, 79, .4), (2, 76, .8), (3.5, 72, .4)],
    [(0, 71, .4), (.5, 71, .4), (1, 68, .4), (2, 71, .5), (2.5, 76, .8)],
]
for bar in range(BARS):
    base = bar * 4 * BEAT
    bass, chord = prog[bar % 4]
    for b in (0, 1.5, 2, 3.5):
        place(buf, pluck(bass + (12 if b in (1.5, 3.5) else 0), .45, .9), base + b * BEAT)
    for b in (.5, 1.5, 2.5, 3.5):
        place(buf, stab(chord, .2, .35), base + b * BEAT)
    for b in (0, 2):
        place(buf, kick() * .8, base + b * BEAT)
    for b in (1, 3):
        place(buf, clap() * .45, base + b * BEAT)
    for b in np.arange(0, 4, .5):
        place(buf, hat() * (.28 if b % 1 == 0 else .16), base + b * BEAT)
    if bar >= 4:  # melodi masuk setelah 4 bar pertama
        mt = motifs[bar % 4]
        for b, m, d in mt:
            place(buf, marimba(m - (12 if bar >= 12 else 0), d * 1.2, .55), base + b * BEAT)

# bungkus tail ke awal supaya loop mulus
n = int(SR * LOOP)
loop = buf[:n].copy()
tail = buf[n:]
loop[:len(tail)] += tail
loop = np.tanh(loop * 1.1)
loop = loop / np.max(np.abs(loop)) * .8
w = os.path.join(OUT, "backsound.wav")
with wave.open(w, "wb") as f:
    f.setnchannels(1)
    f.setsampwidth(2)
    f.setframerate(SR)
    f.writeframes((loop * 32767).astype(np.int16).tobytes())
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", w, "-codec:a", "libmp3lame", "-b:a", "160k", os.path.join(OUT, "backsound.mp3")], check=True)
os.remove(w)
durations["backsound"] = round(LOOP, 3)

# versi panjang (78 dtk) sudah di-loop mulus + fade in/out, dipakai langsung oleh Video.tsx
FULL_SEC = 78
full = np.tile(loop, int(np.ceil(FULL_SEC * SR / len(loop))))[: FULL_SEC * SR].copy()
fi, fo = int(SR * 1.0), int(SR * 2.5)
full[:fi] *= np.linspace(0, 1, fi)
full[-fo:] *= np.linspace(1, 0, fo)
w = os.path.join(OUT, "backsound-full.wav")
with wave.open(w, "wb") as f:
    f.setnchannels(1)
    f.setsampwidth(2)
    f.setframerate(SR)
    f.writeframes((full * 32767).astype(np.int16).tobytes())
subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", w, "-codec:a", "libmp3lame", "-b:a", "128k", os.path.join(OUT, "backsound-full.mp3")], check=True)
os.remove(w)
os.remove(os.path.join(OUT, "backsound.mp3"))

# ---------------------------------------------------------------- manifest untuk TS
ts = "// AUTO-GENERATED oleh scripts/make_audio.py - jangan diedit manual\n"
ts += "export const SFX_DURATIONS: Record<string, number> = " + json.dumps(durations, indent=2) + ";\n"
with open(os.path.join(ROOT, "src", "sfxManifest.ts"), "w") as f:
    f.write(ts)
print("OK", len(durations), "file audio")
