# POV Admin Buzzer Salah Kirim Timestamp — Remotion 9:16

Video komedi 1080x1920 @30fps, durasi 78 detik (narasi 76 dtk + end card).

## Render
```bash
npm install
npx remotion render AdminBuzzer out/admin-buzzer.mp4
# preview interaktif: npm run dev
```
Workflow contoh ada di `.github/workflows/render.yml` (Node 20, `workflow_dispatch`).

## Struktur
- `public/audio/narasi.mp3` — narasi (adminbuzzer.mp3)
- `public/sfx/*.mp3` — SFX + backsound (dibikin sendiri lewat `scripts/make_audio.py`, bebas hak cipta)
- `public/img/*` — karakter (dipotong rapi), ikon medsos, avatar wajah
- `public/video/pasar.mp4` — klip yang dipakai di momen "rame kayak pasar" (di-mute)
- `src/timing.ts` — timing caption (hasil deteksi jeda audio, bukan dari .srt) + awal tiap scene
- `src/sfx.ts` — jadwal SFX (detik absolut)
- `src/scenes/Part1-3.tsx` — 17 scene motion graphic
- `src/constants.ts` — `CHANNEL` (nama di end card), warna, font

## Tweak cepat
- Volume: `SFX_MASTER` & `BACKSOUND_VOL` di `src/Video.tsx`
- Geser SFX/caption: ubah angka detik di `src/sfx.ts` / `src/timing.ts`
- Ganti klip pasar: timpa `public/video/pasar.mp4` (atur `startFrom` di `ScenePasar`)
- Font Poppins & Luckiest Guy diunduh dari Google Fonts saat render (butuh internet di runner).
