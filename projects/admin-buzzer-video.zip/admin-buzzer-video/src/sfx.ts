// Jadwal SFX (detik absolut). Nama = file di public/sfx/<nama>.mp3
export type Sfx = {t: number; n: string; v?: number; d?: number}; // d = potong maksimal d detik

const rep = (n: string, from: number, to: number, step: number, v = 0.5): Sfx[] => {
  const out: Sfx[] = [];
  for (let t = from; t <= to + 1e-6; t += step) out.push({t: +t.toFixed(2), n, v});
  return out;
};

// notifikasi beruntun (efek grup rame): interval makin rapat
const spam: Sfx[] = [];
{
  let t = 39.5;
  let step = 0.22;
  let i = 0;
  while (t < 42.1) {
    spam.push({t: +t.toFixed(2), n: i % 3 === 0 ? 'pop' : 'notif', v: 0.38});
    t += step;
    step = Math.max(0.07, step * 0.9);
    i++;
  }
}

export const SFX: Sfx[] = [
  // --- intro
  {t: 0.0, n: 'whoosh', v: 0.8},
  {t: 0.12, n: 'boom', v: 0.9},
  {t: 0.55, n: 'pop', v: 0.7},
  {t: 1.2, n: 'shimmer', v: 0.5},
  {t: 1.55, n: 'ding', v: 0.5},
  // --- gaji
  {t: 2.7, n: 'whoosh', v: 0.5},
  {t: 2.9, n: 'cash', v: 0.9},
  {t: 3.45, n: 'coin', v: 0.5},
  {t: 3.7, n: 'coin', v: 0.5},
  {t: 4.2, n: 'shimmer', v: 0.5},
  // --- 200 akun
  ...rep('pop', 5.35, 6.7, 0.09, 0.45),
  {t: 5.1, n: 'whoosh', v: 0.5},
  {t: 6.95, n: 'ding', v: 0.7},
  {t: 7.05, n: 'boing', v: 0.5},
  // --- jam 7 malam
  {t: 7.55, n: 'whoosh', v: 0.5},
  ...rep('tick', 7.8, 8.6, 0.4, 0.7),
  {t: 8.7, n: 'bell', v: 0.6},
  {t: 9.12, n: 'whoosh', v: 0.6},
  {t: 9.3, n: 'typing', v: 0.6, d: 1.9},
  {t: 10.0, n: 'pop-low', v: 0.5},
  {t: 10.3, n: 'pop-low', v: 0.5},
  {t: 10.6, n: 'pop-low', v: 0.5},
  {t: 10.9, n: 'pop-low', v: 0.5},
  {t: 11.2, n: 'thud', v: 0.5},
  // --- aman
  {t: 11.75, n: 'whoosh', v: 0.4},
  {t: 11.95, n: 'ding', v: 0.6},
  {t: 12.15, n: 'shimmer', v: 0.45},
  {t: 13.45, n: 'shh', v: 0.6},
  {t: 13.9, n: 'squeak', v: 0.4},
  // --- chat instruksi
  {t: 14.5, n: 'whoosh', v: 0.5},
  {t: 14.95, n: 'typing', v: 0.55, d: 2.4},
  {t: 17.95, n: 'pop', v: 0.5},
  {t: 18.55, n: 'typing', v: 0.55, d: 1.9},
  {t: 20.9, n: 'typing', v: 0.55, d: 2.0},
  {t: 21.1, n: 'pop', v: 0.5},
  {t: 23.4, n: 'typing', v: 0.5, d: 1.4},
  {t: 24.35, n: 'click', v: 0.7},
  // --- gorengan & kepencet
  {t: 25.1, n: 'whoosh', v: 0.4},
  {t: 25.55, n: 'plop', v: 0.6},
  {t: 26.0, n: 'plop', v: 0.6},
  {t: 26.6, n: 'slide-down', v: 0.6},
  {t: 27.55, n: 'boing', v: 0.5},
  {t: 27.75, n: 'scratch', v: 0.7},
  {t: 28.2, n: 'click', v: 0.8},
  {t: 28.3, n: 'sent', v: 0.8},
  {t: 29.1, n: 'stinger-2', v: 0.8},
  // --- centang biru
  {t: 30.05, n: 'tick', v: 0.8},
  {t: 30.5, n: 'tock', v: 0.8},
  {t: 30.9, n: 'heartbeat', v: 0.7},
  {t: 31.32, n: 'ding', v: 0.7},
  {t: 31.55, n: 'ding', v: 0.7},
  {t: 32.7, n: 'pop', v: 0.6},
  {t: 32.78, n: 'notif', v: 0.5},
  {t: 33.97, n: 'pop', v: 0.6},
  {t: 34.05, n: 'notif', v: 0.5},
  {t: 35.25, n: 'pop', v: 0.6},
  {t: 35.33, n: 'notif', v: 0.5},
  {t: 37.15, n: 'pop', v: 0.6},
  {t: 37.23, n: 'notif', v: 0.5},
  {t: 38.6, n: 'drumroll', v: 0.5},
  // --- pasar
  {t: 39.3, n: 'airhorn', v: 0.8},
  ...spam,
  // --- poll
  {t: 42.4, n: 'scratch', v: 0.8},
  {t: 42.75, n: 'bonk', v: 0.7},
  {t: 44.0, n: 'pop', v: 0.5},
  {t: 45.75, n: 'stinger-2', v: 0.5},
  {t: 48.4, n: 'pop', v: 0.6},
  {t: 49.1, n: 'pop', v: 0.6},
  {t: 49.8, n: 'ding', v: 0.6},
  // --- like subscribe
  {t: 50.25, n: 'whoosh', v: 0.6},
  {t: 50.55, n: 'pop', v: 0.7},
  {t: 51.35, n: 'pop', v: 0.6},
  {t: 51.95, n: 'click', v: 0.9},
  {t: 52.05, n: 'ding', v: 0.6},
  {t: 52.45, n: 'bell', v: 0.8},
  {t: 53.15, n: 'shimmer', v: 0.5},
  // --- emak chat
  {t: 53.9, n: 'whoosh', v: 0.6},
  {t: 54.95, n: 'notif', v: 0.8},
  {t: 56.8, n: 'notif', v: 0.8},
  {t: 57.4, n: 'notif', v: 0.8},
  {t: 58.4, n: 'bonk', v: 0.6},
  // --- bapak chat
  {t: 59.1, n: 'whoosh', v: 0.5},
  {t: 59.5, n: 'notif', v: 0.8},
  {t: 60.6, n: 'notif', v: 0.8},
  {t: 61.9, n: 'stinger', v: 0.75},
  {t: 62.15, n: 'cash', v: 0.7},
  // --- screenshot
  {t: 63.4, n: 'whoosh', v: 0.5},
  {t: 64.65, n: 'shutter', v: 1},
  {t: 65.0, n: 'pop', v: 0.5},
  // --- viral
  {t: 66.0, n: 'whoosh', v: 0.6},
  ...rep('pop', 66.4, 68.4, 0.25, 0.3),
  {t: 68.95, n: 'typing', v: 0.6, d: 2.3},
  {t: 70.55, n: 'vine-boom', v: 0.9},
  // --- dipecat
  {t: 71.6, n: 'whoosh', v: 0.5},
  {t: 72.15, n: 'thud', v: 0.9},
  {t: 73.05, n: 'whoosh-rev', v: 0.6},
  {t: 73.7, n: 'thud', v: 0.9},
  {t: 74.25, n: 'notif', v: 0.9},
  {t: 74.7, n: 'sad-trombone', v: 0.9},
  // --- end
  {t: 76.2, n: 'shimmer', v: 0.5},
  {t: 76.3, n: 'ding', v: 0.5},
];
