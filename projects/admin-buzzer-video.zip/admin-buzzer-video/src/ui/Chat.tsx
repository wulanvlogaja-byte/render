import React from 'react';
import {FONT_BODY, C} from '../constants';
import {ArrowBack, DoubleCheck, SendIcon, SingleCheck} from './Icons';
import {popS} from '../anim';

/** Frame HP dengan layar di dalam. */
export const PhoneFrame: React.FC<{
  w?: number;
  h?: number;
  rot?: number;
  scale?: number;
  children: React.ReactNode;
  style?: React.CSSProperties;
}> = ({w = 820, h = 1060, rot = 0, scale = 1, children, style}) => (
  <div
    style={{
      position: 'absolute',
      width: w,
      height: h,
      borderRadius: 78,
      background: '#0d0f14',
      border: '14px solid #1d212b',
      boxShadow: '0 40px 80px rgba(0,0,0,0.5), 0 0 0 4px #3a4052',
      overflow: 'hidden',
      transform: `rotate(${rot}deg) scale(${scale})`,
      transformOrigin: '50% 50%',
      ...style,
    }}
  >
    <div style={{position: 'absolute', left: '50%', top: 14, width: 150, height: 34, marginLeft: -75, borderRadius: 20, background: '#000', zIndex: 5}} />
    {children}
  </div>
);

export const ChatHeader: React.FC<{title: string; sub?: string; avatar: React.ReactNode; bg?: string}> = ({title, sub, avatar, bg = '#1f2c34'}) => (
  <div style={{height: 150, background: bg, display: 'flex', alignItems: 'flex-end', gap: 18, padding: '0 22px 16px', boxSizing: 'border-box'}}>
    <div style={{paddingBottom: 14}}>
      <ArrowBack size={44} color="#e9edef" />
    </div>
    {avatar}
    <div style={{paddingBottom: 2, minWidth: 0}}>
      <div style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 36, color: '#e9edef', whiteSpace: 'nowrap'}}>{title}</div>
      {sub && <div style={{fontFamily: FONT_BODY, fontWeight: 600, fontSize: 24, color: '#8696a0', whiteSpace: 'nowrap'}}>{sub}</div>}
    </div>
  </div>
);

export const ChatBody: React.FC<{children: React.ReactNode; style?: React.CSSProperties}> = ({children, style}) => (
  <div
    style={{
      position: 'absolute',
      left: 0,
      right: 0,
      top: 150,
      bottom: 110,
      background: '#0b141a',
      padding: '22px 22px 0',
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      overflow: 'hidden',
      ...style,
    }}
  >
    {children}
  </div>
);

export const InputBar: React.FC<{text?: string; caret?: boolean; hot?: boolean}> = ({text = '', caret = false, hot = false}) => (
  <div style={{position: 'absolute', left: 0, right: 0, bottom: 0, height: 110, background: '#0b141a', display: 'flex', alignItems: 'center', gap: 14, padding: '0 16px'}}>
    <div
      style={{
        flex: 1,
        height: 78,
        borderRadius: 40,
        background: '#2a3942',
        display: 'flex',
        alignItems: 'center',
        padding: '0 26px',
        fontFamily: FONT_BODY,
        fontWeight: 600,
        fontSize: 29,
        color: '#e9edef',
        overflow: 'hidden',
        whiteSpace: 'nowrap',
      }}
    >
      {text}
      {caret && <span style={{display: 'inline-block', width: 3, height: 36, background: '#00a884', marginLeft: 3}} />}
      {!text && !caret && <span style={{color: '#8696a0'}}>Ketik pesan</span>}
    </div>
    <div
      style={{
        width: 78,
        height: 78,
        borderRadius: 39,
        background: hot ? '#ff3b3b' : '#00a884',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transform: hot ? 'scale(1.18)' : 'none',
        boxShadow: hot ? '0 0 0 12px rgba(255,59,59,0.35)' : 'none',
      }}
    >
      <SendIcon size={40} color="#fff" />
    </div>
  </div>
);

export const Bubble: React.FC<{
  text: React.ReactNode;
  me?: boolean;
  name?: string;
  nameColor?: string;
  time?: string;
  ticks?: 'none' | 'sent' | 'read';
  rf?: number; // frame sejak muncul
  fs?: number;
  extra?: React.ReactNode;
  maxW?: number;
}> = ({text, me, name, nameColor = '#53bdeb', time = '19.00', ticks = 'none', rf = 99, fs = 32, extra, maxW = 640}) => {
  if (rf < 0) return null;
  const s = popS(rf, 30, {damping: 12, stiffness: 200});
  return (
    <div style={{display: 'flex', justifyContent: me ? 'flex-end' : 'flex-start', transform: `scale(${0.6 + 0.4 * s})`, opacity: Math.min(1, s * 2), transformOrigin: me ? '100% 100%' : '0% 100%'}}>
      <div
        style={{
          maxWidth: maxW,
          background: me ? '#005c4b' : '#202c33',
          borderRadius: me ? '26px 26px 6px 26px' : '26px 26px 26px 6px',
          padding: '14px 22px 12px',
          fontFamily: FONT_BODY,
          color: '#e9edef',
        }}
      >
        {name && <div style={{fontWeight: 800, fontSize: fs * 0.8, color: nameColor, marginBottom: 4}}>{name}</div>}
        <div style={{fontWeight: 600, fontSize: fs, lineHeight: 1.25}}>{text}</div>
        {extra}
        <div style={{display: 'flex', justifyContent: 'flex-end', alignItems: 'center', gap: 8, marginTop: 4, fontSize: 22, color: '#8696a0', fontWeight: 600}}>
          {time}
          {ticks === 'sent' && <SingleCheck size={24} />}
          {ticks === 'read' && <DoubleCheck size={24} color="#53bdeb" />}
        </div>
      </div>
    </div>
  );
};

export const TypingDots: React.FC<{frame: number}> = ({frame}) => (
  <div style={{display: 'inline-flex', gap: 10, background: '#202c33', borderRadius: 30, padding: '20px 28px'}}>
    {[0, 1, 2].map((i) => (
      <div key={i} style={{width: 18, height: 18, borderRadius: 9, background: '#8696a0', transform: `translateY(${Math.sin((frame + i * 4) / 4) * -7}px)`}} />
    ))}
  </div>
);

export const Wallpaper: React.FC = () => <></>;
export {C};
