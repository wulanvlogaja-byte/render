import React from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {FONT_BODY} from '../constants';
import {PHRASES} from '../timing';
import {popS} from '../anim';

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const p = PHRASES.find((x) => t >= x.start - 0.04 && t <= x.end + 0.28);
  if (!p) return null;

  const words = p.text.split(' ');
  const total = words.reduce((a, w) => a + w.length + 1, 0);
  const dur = Math.max(0.25, p.end - p.start);
  let acc = 0;
  const starts = words.map((w) => {
    const s = p.start + (acc / total) * dur;
    acc += w.length + 1;
    return s;
  });
  let active = 0;
  starts.forEach((s, i) => {
    if (t >= s) active = i;
  });
  const rf = frame - Math.round(p.start * fps);
  const s = popS(rf + 2, fps, {damping: 13, stiffness: 220});

  return (
    <div style={{position: 'absolute', left: 60, right: 60, top: 1300, height: 270, display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 50}}>
      <div style={{textAlign: 'center', transform: `scale(${0.85 + 0.15 * s})`, opacity: Math.min(1, s * 2.4)}}>
        {words.map((w, i) => {
          const hot = (p.hot ?? []).includes(w);
          const isAct = i === active && t <= p.end + 0.05;
          return (
            <span
              key={i}
              style={{
                display: 'inline-block',
                margin: '2px 17px',
                fontFamily: FONT_BODY,
                fontWeight: 900,
                fontSize: 66,
                lineHeight: 1.08,
                textTransform: 'uppercase',
                color: hot ? '#ffd23f' : '#fff',
                WebkitTextStroke: '11px #000',
                paintOrder: 'stroke fill',
                textShadow: '0 8px 0 rgba(0,0,0,0.9)',
                transform: `scale(${isAct ? 1.14 : 1}) translateY(${isAct ? -4 : 0}px)`,
                opacity: i <= active ? 1 : 0.55,
              }}
            >
              {w}
            </span>
          );
        })}
      </div>
    </div>
  );
};
