import React from 'react';
import {Img, staticFile} from 'remotion';
import {C, FONT_BODY, FONT_TITLE} from '../constants';

export const CHARS = {
  admin: {file: 'img/admin.png', ar: 537 / 1527},
  tante: {file: 'img/tante.png', ar: 550 / 1536},
  sepupu: {file: 'img/sepupu.png', ar: 585 / 1523},
  ortu: {file: 'img/ortu.png', ar: 1178 / 1220},
};
export type CharName = keyof typeof CHARS;

export const Char: React.FC<{
  name: CharName;
  h: number;
  cx: number;
  bottom: number;
  scale?: number;
  rot?: number;
  flip?: boolean;
  opacity?: number;
  ty?: number;
  tx?: number;
  filter?: string;
}> = ({name, h, cx, bottom, scale = 1, rot = 0, flip, opacity = 1, ty = 0, tx = 0, filter}) => {
  const c = CHARS[name];
  const w = h * c.ar;
  return (
    <div
      style={{
        position: 'absolute',
        left: cx - w / 2,
        bottom,
        width: w,
        height: h,
        opacity,
        transformOrigin: '50% 100%',
        transform: `translate(${tx}px, ${ty}px) rotate(${rot}deg) scale(${flip ? -scale : scale}, ${scale})`,
        filter: filter ?? 'drop-shadow(0 14px 18px rgba(0,0,0,0.38))',
      }}
    >
      <Img src={staticFile(c.file)} style={{width: '100%', height: '100%', display: 'block'}} />
    </div>
  );
};

export const Face: React.FC<{who: 'admin' | 'bapak' | 'emak' | 'tante' | 'sepupu'; size: number; ring?: string; bg?: string}> = ({
  who,
  size,
  ring = 'transparent',
  bg = '#cfd8dc',
}) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: '50%',
      overflow: 'hidden',
      background: bg,
      border: `${Math.max(3, size * 0.045)}px solid ${ring}`,
      boxSizing: 'border-box',
      flexShrink: 0,
    }}
  >
    <Img src={staticFile(`img/face-${who}.png`)} style={{width: '100%', height: '100%', objectFit: 'cover', display: 'block'}} />
  </div>
);

export const Txt: React.FC<{
  size: number;
  color?: string;
  stroke?: string;
  sw?: number;
  font?: 'title' | 'body';
  weight?: number;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({size, color = C.white, stroke, sw = 0, font = 'body', weight = 900, style, children}) => (
  <div
    style={{
      fontFamily: font === 'title' ? FONT_TITLE : FONT_BODY,
      fontWeight: weight,
      fontSize: size,
      color,
      lineHeight: 1.05,
      letterSpacing: font === 'title' ? 1 : 0,
      WebkitTextStroke: stroke ? `${sw * 2}px ${stroke}` : undefined,
      paintOrder: 'stroke fill',
      textShadow: stroke ? `0 ${Math.round(size * 0.07)}px 0 ${stroke}` : undefined,
      textAlign: 'center',
      ...style,
    }}
  >
    {children}
  </div>
);

export const Pill: React.FC<{
  bg: string;
  color?: string;
  size?: number;
  border?: string;
  style?: React.CSSProperties;
  children: React.ReactNode;
}> = ({bg, color = '#fff', size = 40, border, style, children}) => (
  <div
    style={{
      display: 'inline-flex',
      alignItems: 'center',
      gap: 12,
      background: bg,
      color,
      fontFamily: FONT_BODY,
      fontWeight: 800,
      fontSize: size,
      padding: `${size * 0.28}px ${size * 0.7}px`,
      borderRadius: 999,
      border: border ? `5px solid ${border}` : undefined,
      boxShadow: '0 10px 0 rgba(0,0,0,0.25)',
      ...style,
    }}
  >
    {children}
  </div>
);

export const Center: React.FC<{style?: React.CSSProperties; children: React.ReactNode}> = ({style, children}) => (
  <div style={{position: 'absolute', left: 0, right: 0, display: 'flex', justifyContent: 'center', ...style}}>{children}</div>
);
