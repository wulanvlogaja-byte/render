import React, {useId} from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {H, W} from '../constants';
import {rnd} from '../anim';

export type Pattern = 'dots' | 'rays' | 'grid' | 'stripes' | 'shapes' | 'none';

export const BG: React.FC<{
  a: string;
  b: string;
  pattern?: Pattern;
  accent?: string;
  speed?: number;
  cx?: number;
  cy?: number;
}> = ({a, b, pattern = 'dots', accent = 'rgba(255,255,255,0.10)', speed = 1, cx = W / 2, cy = H * 0.38}) => {
  const frame = useCurrentFrame();
  const id = useId().replace(/[^a-zA-Z0-9]/g, '');
  return (
    <AbsoluteFill style={{background: `linear-gradient(165deg, ${a} 0%, ${b} 100%)`}}>
      {pattern === 'dots' && (
        <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
          <defs>
            <pattern id={`d${id}`} width="64" height="64" patternUnits="userSpaceOnUse" patternTransform={`translate(${frame * 0.7 * speed} ${frame * 0.7 * speed})`}>
              <circle cx="32" cy="32" r="6" fill={accent} />
            </pattern>
          </defs>
          <rect width={W} height={H} fill={`url(#d${id})`} />
        </svg>
      )}
      {pattern === 'grid' && (
        <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
          <defs>
            <pattern id={`g${id}`} width="90" height="90" patternUnits="userSpaceOnUse" patternTransform={`translate(0 ${frame * 1.2 * speed})`}>
              <path d="M90 0 L0 0 L0 90" fill="none" stroke={accent} strokeWidth="3" />
            </pattern>
          </defs>
          <rect width={W} height={H} fill={`url(#g${id})`} />
        </svg>
      )}
      {pattern === 'stripes' && (
        <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
          <defs>
            <pattern id={`s${id}`} width="120" height="120" patternUnits="userSpaceOnUse" patternTransform={`rotate(35) translate(${frame * 1.4 * speed} 0)`}>
              <rect width="60" height="120" fill={accent} />
            </pattern>
          </defs>
          <rect width={W} height={H} fill={`url(#s${id})`} />
        </svg>
      )}
      {pattern === 'rays' && (
        <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
          <g transform={`rotate(${frame * 0.35 * speed} ${cx} ${cy})`}>
            {Array.from({length: 20}).map((_, i) => {
              const a0 = (i / 20) * Math.PI * 2;
              const a1 = a0 + Math.PI / 20;
              const R = 2600;
              return (
                <polygon
                  key={i}
                  points={`${cx},${cy} ${cx + Math.cos(a0) * R},${cy + Math.sin(a0) * R} ${cx + Math.cos(a1) * R},${cy + Math.sin(a1) * R}`}
                  fill={accent}
                />
              );
            })}
          </g>
        </svg>
      )}
      {pattern === 'shapes' && (
        <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
          {Array.from({length: 22}).map((_, i) => {
            const x = rnd(i + 1) * W;
            const sp = 0.6 + rnd(i + 40) * 1.4;
            const y = (((rnd(i + 90) * H - frame * sp * speed) % (H + 200)) + H + 200) % (H + 200) - 100;
            const s = 24 + rnd(i + 7) * 60;
            const rot = frame * (rnd(i + 3) - 0.5) * 3;
            const k = i % 3;
            return (
              <g key={i} transform={`translate(${x} ${y}) rotate(${rot})`} fill={accent}>
                {k === 0 && <circle r={s / 2} />}
                {k === 1 && <rect x={-s / 2} y={-s / 2} width={s} height={s} rx={s * 0.2} />}
                {k === 2 && <path d={`M0 ${-s / 2} L${s / 2} ${s / 2} L${-s / 2} ${s / 2} Z`} />}
              </g>
            );
          })}
        </svg>
      )}
    </AbsoluteFill>
  );
};

export const Vignette: React.FC<{strength?: number}> = ({strength = 0.45}) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 45%, rgba(0,0,0,${strength}) 100%)`,
      pointerEvents: 'none',
    }}
  />
);

/** Siluet Istana (SVG 2D). */
export const Palace: React.FC<{width?: number; fill?: string; light?: string}> = ({width = 980, fill = '#e9eefc', light = '#7a8fe0'}) => (
  <svg width={width} height={width * 0.52} viewBox="0 0 900 470">
    <g transform="translate(0 50)">
      <line x1="450" y1="-40" x2="450" y2="16" stroke={fill} strokeWidth="5" />
      <rect x="452" y="-38" width="52" height="14" fill="#ff3b3b" />
      <rect x="452" y="-24" width="52" height="14" fill="#ffffff" />
      <path d="M395 72 A55 58 0 0 1 505 72 Z" fill={fill} />
      <rect x="402" y="70" width="96" height="26" fill={fill} />
      <polygon points="100,190 450,96 800,190" fill={fill} />
      <polygon points="170,186 450,112 730,186" fill={light} opacity=".55" />
      <rect x="120" y="190" width="660" height="30" fill={fill} />
      <rect x="130" y="220" width="640" height="130" fill={light} opacity=".5" />
      {Array.from({length: 8}).map((_, i) => (
        <rect key={i} x={140 + i * 80} y="220" width="34" height="130" fill={fill} />
      ))}
      <rect x="70" y="350" width="760" height="26" fill={fill} />
      <rect x="40" y="376" width="820" height="34" fill={fill} />
      <rect x="10" y="410" width="880" height="30" fill={fill} opacity=".85" />
    </g>
  </svg>
);

/** Kota / gedung siluet buat dasar. */
export const Skyline: React.FC<{fill?: string; opacity?: number}> = ({fill = '#0a0f2b', opacity = 1}) => (
  <svg width={W} height={420} viewBox="0 0 1080 420" style={{opacity}}>
    {[[0, 200, 110], [100, 120, 90], [180, 260, 120], [290, 160, 100], [380, 300, 110], [480, 190, 120], [590, 250, 90], [670, 140, 110], [770, 280, 120], [880, 170, 90], [960, 230, 120]].map(
      ([x, h, w], i) => (
        <g key={i}>
          <rect x={x} y={420 - h} width={w} height={h} fill={fill} />
          {Array.from({length: Math.floor(h / 40)}).map((_, r) => (
            <rect key={r} x={x + 14 + (r % 2) * 30} y={420 - h + 16 + r * 36} width={14} height={16} fill="#ffd23f" opacity={rnd(i * 9 + r) > 0.5 ? 0.9 : 0.25} />
          ))}
        </g>
      )
    )}
  </svg>
);
