import React from 'react';

type P = {size?: number; color?: string; style?: React.CSSProperties};

const mat = (d: string) => {
  const I: React.FC<P> = ({size = 64, color = '#fff', style}) => (
    <svg width={size} height={size} viewBox="0 0 24 24" style={style}>
      <path d={d} fill={color} />
    </svg>
  );
  return I;
};

export const ThumbUp = mat(
  'M1 21h4V9H1v12zm22-11c0-1.1-.9-2-2-2h-6.31l.95-4.57.03-.32c0-.41-.17-.79-.44-1.06L14.17 1 7.59 7.59C7.22 7.95 7 8.45 7 9v10c0 1.1.9 2 2 2h9c.83 0 1.54-.5 1.84-1.22l3.02-7.05c.09-.23.14-.47.14-.73v-2z'
);
export const BellIcon = mat(
  'M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z'
);
export const HeartIcon = mat(
  'M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z'
);
export const RetweetIcon = mat('M7 7h10v3l4-4-4-4v3H5v6h2V7zm10 10H7v-3l-4 4 4 4v-3h12v-6h-2v4z');
export const CommentIcon = mat(
  'M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zm0 14H6l-2 2V4h16v12z'
);
export const XLogo = mat(
  'M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z'
);
export const ShieldCheck = mat(
  'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z'
);
export const SendIcon = mat('M2.01 21L23 12 2.01 3 2 10l15 2-15 2z');
export const ArrowBack = mat('M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z');
export const PersonIcon = mat(
  'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z'
);
export const CloseIcon = mat(
  'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z'
);
export const ImageIcon = mat(
  'M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z'
);

/** Centang dua (read receipt). */
export const DoubleCheck: React.FC<P> = ({size = 40, color = '#34b7f1', style}) => (
  <svg width={size * 1.5} height={size} viewBox="0 0 30 20" style={style}>
    <g fill="none" stroke={color} strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 11 L8 17 L20 4" />
      <path d="M10 15 L12 17 L24 4" />
    </g>
  </svg>
);
export const SingleCheck: React.FC<P> = ({size = 40, color = '#8696a0', style}) => (
  <svg width={size} height={size} viewBox="0 0 20 20" style={style}>
    <path d="M2 11 L8 17 L18 4" fill="none" stroke={color} strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

/** Jam analog. h = jam (0-12 pecahan), m = menit (0-60 pecahan). */
export const Clock: React.FC<{size?: number; h: number; m: number; face?: string; rim?: string}> = ({
  size = 420,
  h,
  m,
  face = '#fff',
  rim = '#ffd23f',
}) => {
  const ha = ((h % 12) + m / 60) * 30;
  const ma = m * 6;
  return (
    <svg width={size} height={size} viewBox="0 0 200 200">
      <circle cx="100" cy="100" r="94" fill={rim} />
      <circle cx="100" cy="100" r="82" fill={face} />
      {Array.from({length: 12}).map((_, i) => (
        <rect key={i} x="98" y="22" width="4" height={i % 3 === 0 ? 14 : 8} fill="#1b2a6b" transform={`rotate(${i * 30} 100 100)`} />
      ))}
      <g transform={`rotate(${ha} 100 100)`}>
        <rect x="95.5" y="48" width="9" height="55" rx="4.5" fill="#101322" />
      </g>
      <g transform={`rotate(${ma} 100 100)`}>
        <rect x="97.5" y="30" width="5" height="73" rx="2.5" fill="#ff3b3b" />
      </g>
      <circle cx="100" cy="100" r="8" fill="#101322" />
    </svg>
  );
};

/** Lembar uang Rp. */
export const Bill: React.FC<{w?: number; color?: string}> = ({w = 260, color = '#2fbf71'}) => (
  <svg width={w} height={w * 0.5} viewBox="0 0 260 130">
    <rect x="3" y="3" width="254" height="124" rx="14" fill={color} stroke="#14663a" strokeWidth="6" />
    <rect x="16" y="16" width="228" height="98" rx="8" fill="none" stroke="#b9f3d0" strokeWidth="3" strokeDasharray="8 6" />
    <circle cx="130" cy="65" r="34" fill="#b9f3d0" stroke="#14663a" strokeWidth="5" />
    <text x="130" y="78" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="38" fill="#14663a">
      Rp
    </text>
    <circle cx="40" cy="36" r="9" fill="#14663a" opacity=".6" />
    <circle cx="220" cy="94" r="9" fill="#14663a" opacity=".6" />
  </svg>
);

export const Coin: React.FC<{size?: number}> = ({size = 90}) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <circle cx="50" cy="50" r="46" fill="#ffd23f" stroke="#c98a00" strokeWidth="6" />
    <circle cx="50" cy="50" r="33" fill="none" stroke="#e5a900" strokeWidth="4" />
    <text x="50" y="64" textAnchor="middle" fontFamily="Arial, sans-serif" fontWeight="900" fontSize="40" fill="#c98a00">
      $
    </text>
  </svg>
);

/** Tahu goreng / gorengan berminyak. */
export const Gorengan: React.FC<{size?: number}> = ({size = 360}) => (
  <svg width={size} height={size * 0.8} viewBox="0 0 360 288">
    <ellipse cx="180" cy="262" rx="130" ry="18" fill="rgba(0,0,0,0.22)" />
    <path
      d="M40 120 C40 60 100 30 180 30 C260 30 322 62 322 124 C330 190 290 252 180 256 C72 254 30 190 40 120 Z"
      fill="#f0a93b"
      stroke="#9b5a0f"
      strokeWidth="9"
      strokeLinejoin="round"
    />
    <path d="M70 110 C78 70 120 52 180 52" fill="none" stroke="#ffd98a" strokeWidth="14" strokeLinecap="round" opacity=".8" />
    {[[100, 150, 9], [150, 120, 7], [220, 170, 10], [260, 120, 7], [190, 210, 8], [120, 210, 7], [270, 205, 6], [175, 90, 6]].map(
      ([x, y, r], i) => (
        <circle key={i} cx={x} cy={y} r={r} fill="#b66a14" opacity=".75" />
      )
    )}
    <ellipse cx="240" cy="90" rx="26" ry="11" fill="#fff" opacity=".55" transform="rotate(-20 240 90)" />
    <ellipse cx="110" cy="190" rx="18" ry="8" fill="#fff" opacity=".4" transform="rotate(-25 110 190)" />
  </svg>
);

export const Drop: React.FC<{size?: number; color?: string}> = ({size = 40, color = '#ffd23f'}) => (
  <svg width={size * 0.7} height={size} viewBox="0 0 28 40">
    <path d="M14 2 C14 2 2 18 2 27 A12 12 0 0 0 26 27 C26 18 14 2 14 2 Z" fill={color} stroke="#c98a00" strokeWidth="2.5" />
    <ellipse cx="9" cy="26" rx="3" ry="5" fill="#fff" opacity=".6" />
  </svg>
);

/** Jempol/jari. */
export const Finger: React.FC<{size?: number}> = ({size = 300}) => (
  <svg width={size * 0.5} height={size} viewBox="0 0 150 300">
    <path d="M30 300 L30 90 C30 40 120 40 120 90 L120 300 Z" fill="#f2b98f" stroke="#a9693d" strokeWidth="7" strokeLinejoin="round" />
    <path d="M48 82 C50 56 100 56 102 82 C102 98 96 106 75 106 C54 106 48 98 48 82 Z" fill="#ffe3cf" stroke="#a9693d" strokeWidth="4" />
    <ellipse cx="62" cy="150" rx="8" ry="26" fill="#fff" opacity=".35" />
    <path d="M30 200 L120 200" stroke="#a9693d" strokeWidth="4" opacity=".4" />
  </svg>
);

/** Kamera DSLR sederhana / frame screenshot. */
export const CornerFrame: React.FC<{w: number; h: number; color?: string; t?: number}> = ({w, h, color = '#fff', t = 10}) => {
  const L = 90;
  const c = (x: number, y: number, dx: number, dy: number) => (
    <path d={`M${x} ${y + dy * L} L${x} ${y} L${x + dx * L} ${y}`} fill="none" stroke={color} strokeWidth={t} strokeLinecap="round" />
  );
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} style={{position: 'absolute', left: 0, top: 0}}>
      {c(8, 8, 1, 1)}
      {c(w - 8, 8, -1, 1)}
      {c(8, h - 8, 1, -1)}
      {c(w - 8, h - 8, -1, -1)}
    </svg>
  );
};

/** Megafon. */
export const Megaphone: React.FC<{size?: number}> = ({size = 220}) => (
  <svg width={size} height={size} viewBox="0 0 200 200">
    <path d="M30 80 L120 40 L120 160 L30 120 Z" fill="#ff3b3b" stroke="#8c1212" strokeWidth="8" strokeLinejoin="round" />
    <rect x="14" y="78" width="28" height="44" rx="8" fill="#f1f1f1" stroke="#8c1212" strokeWidth="8" />
    <ellipse cx="124" cy="100" rx="16" ry="62" fill="#fff" stroke="#8c1212" strokeWidth="8" />
    <path d="M50 120 L62 168 L88 168 L80 128" fill="#f1f1f1" stroke="#8c1212" strokeWidth="8" strokeLinejoin="round" />
    <path d="M160 72 Q184 100 160 128" fill="none" stroke="#ffd23f" strokeWidth="9" strokeLinecap="round" />
    <path d="M176 52 Q214 100 176 148" fill="none" stroke="#ffd23f" strokeWidth="9" strokeLinecap="round" />
  </svg>
);

/** Avatar akun palsu (siluet warna-warni). */
export const FakeAvatar: React.FC<{size: number; hue: number}> = ({size, hue}) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <circle cx="50" cy="50" r="48" fill={`hsl(${hue} 70% 55%)`} stroke="#fff" strokeWidth="4" />
    <circle cx="50" cy="40" r="17" fill="rgba(255,255,255,0.9)" />
    <path d="M16 90 C20 66 80 66 84 90 A48 48 0 0 1 16 90 Z" fill="rgba(255,255,255,0.9)" />
    <rect x="30" y="34" width="40" height="8" rx="4" fill="#101322" opacity=".75" />
  </svg>
);
