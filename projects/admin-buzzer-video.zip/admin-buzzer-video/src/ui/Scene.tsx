import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';

/** Wrapper scene: fade+zoom masuk 7 frame, nimpa scene sebelumnya (yang durasinya sengaja diperpanjang). */
export const SceneWrap: React.FC<{children: React.ReactNode; zoom?: number; flash?: boolean}> = ({children, zoom = 0.04, flash}) => {
  const frame = useCurrentFrame();
  const o = interpolate(frame, [0, 7], [0, 1], {extrapolateRight: 'clamp'});
  const sc = interpolate(frame, [0, 9], [1 + zoom, 1], {extrapolateRight: 'clamp'});
  const fl = flash ? interpolate(frame, [0, 6], [0.9, 0], {extrapolateRight: 'clamp'}) : 0;
  return (
    <AbsoluteFill style={{opacity: o}}>
      <AbsoluteFill style={{transform: `scale(${sc})`, transformOrigin: '50% 50%'}}>{children}</AbsoluteFill>
      {fl > 0 && <AbsoluteFill style={{background: '#fff', opacity: fl}} />}
    </AbsoluteFill>
  );
};

export const Flash: React.FC<{rf: number; dur?: number}> = ({rf, dur = 8}) => {
  if (rf < 0 || rf > dur) return null;
  return <AbsoluteFill style={{background: '#fff', opacity: interpolate(rf, [0, dur], [1, 0]), zIndex: 40}} />;
};
