import React from 'react';
import {AbsoluteFill, Img, OffthreadVideo, staticFile, useCurrentFrame} from 'remotion';
import {C, CHANNEL, FONT_BODY, FPS, H, W} from '../constants';
import {SCENE_START} from '../timing';
import {bob, ease, lin, popS, rnd, shake, soft, useRel} from '../anim';
import {BG, Palace, Vignette} from '../ui/Backgrounds';
import {Bubble, ChatBody, ChatHeader, InputBar, PhoneFrame, TypingDots} from '../ui/Chat';
import {Center, Char, Face, Pill, Txt} from '../ui/common';
import {BellIcon, Coin, CommentIcon, CornerFrame, Drop, Finger, HeartIcon, RetweetIcon, ThumbUp, XLogo} from '../ui/Icons';
import {Flash, SceneWrap} from '../ui/Scene';

const CH_BOTTOM = 190;
const CH_H = 660;
const PHONE = {w: 820, h: 1060, left: (W - 820) / 2, top: 150};

const kfmt = (v: number) => (v >= 1000 ? (v / 1000).toFixed(1).replace('.', ',') + ' rb' : String(Math.round(v)));

/* ------------------------------------------------------------------ I. RAME KAYAK PASAR (39.1 - 42.4) */
export const ScenePasar: React.FC = () => {
  const rf = useRel(SCENE_START.pasar);
  const frame = useCurrentFrame();
  const vid = popS(rf(39.3), FPS, {damping: 10, stiffness: 140});
  const wa = popS(rf(39.2), FPS, {damping: 7, stiffness: 200});
  const count = Math.round(ease(rf(39.4), 80, 3, 999));
  const s = shake(frame, 5, 1.8);
  return (
    <SceneWrap flash>
      <BG a="#ff5b1f" b="#8a0f1c" pattern="stripes" accent="rgba(255,255,255,0.09)" speed={3} />
      <div style={{position: 'absolute', left: W / 2 - 150, top: 150, width: 300, height: 300, transform: `scale(${wa}) translate(${s.x}px, ${s.y}px)`}}>
        <Img src={staticFile('img/icon-whatsapp.png')} style={{width: 260, height: 260, margin: '20px 0 0 20px'}} />
        <div
          style={{
            position: 'absolute',
            right: -70,
            top: 0,
            background: '#ff1f1f',
            border: '8px solid #fff',
            borderRadius: 70,
            padding: '6px 28px',
            fontFamily: FONT_BODY,
            fontWeight: 900,
            fontSize: 74,
            color: '#fff',
            transform: `rotate(${s.r * 3}deg)`,
          }}
        >
          {count >= 999 ? '999+' : count}
        </div>
      </div>
      <div
        style={{
          position: 'absolute',
          left: 150,
          top: 470,
          width: 780,
          height: 790,
          borderRadius: 44,
          overflow: 'hidden',
          border: '12px solid #fff',
          boxShadow: '0 30px 60px rgba(0,0,0,0.5)',
          transform: `scale(${0.6 + 0.4 * vid}) rotate(${-3 + s.r}deg) translate(${s.x * 0.4}px, ${s.y * 0.4}px)`,
          opacity: Math.min(1, vid * 2),
          background: '#000',
        }}
      >
        <OffthreadVideo src={staticFile('video/pasar.mp4')} muted startFrom={0} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
        <div style={{position: 'absolute', left: 18, top: 18}}>
          <Pill bg="#ff1f1f" size={32} style={{boxShadow: 'none'}}>
            <span style={{width: 18, height: 18, borderRadius: 9, background: '#fff', display: 'inline-block', opacity: Math.floor(frame / 8) % 2 ? 1 : 0.3}} />
            LIVE: GRUP KELUARGA
          </Pill>
        </div>
      </div>
      <Vignette />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ J. POLL: NGELES ATAU RESIGN (42.4 - 50.2) */
export const ScenePoll: React.FC = () => {
  const rf = useRel(SCENE_START.poll);
  const frame = useCurrentFrame();
  const eh = popS(rf(42.45), FPS, {damping: 7, stiffness: 200});
  const card = popS(rf(43.94), FPS, {damping: 11});
  const q = popS(rf(45.69), FPS, {damping: 10});
  const a = popS(rf(48.4), FPS, {damping: 9});
  const b = popS(rf(49.1), FPS, {damping: 9});
  const ch = popS(rf(42.6), FPS, {damping: 11});
  const pulse = 1 + Math.sin(frame / 5) * 0.025;
  const sh = rf(42.45) >= 0 && rf(42.45) < 12 ? shake(frame, 10, 1.4) : {x: 0, y: 0, r: 0};
  return (
    <SceneWrap flash>
      <BG a="#ffd23f" b="#ff7a1a" pattern="shapes" accent="rgba(255,255,255,0.22)" />
      {rf(43.94) < 0 && (
        <Center style={{top: 280, transform: `translate(${sh.x}px,${sh.y}px) rotate(${-4 + sh.r}deg) scale(${0.3 + 0.7 * eh})`}}>
          <Txt size={190} font="title" color="#fff" stroke="#101322" sw={12}>
            EH BENTAR
            <br />
            BRO!
          </Txt>
        </Center>
      )}
      {rf(43.94) >= 0 && (
        <div
          style={{
            position: 'absolute',
            left: 70,
            top: 150,
            width: W - 140,
            height: 800,
            borderRadius: 50,
            background: '#fff',
            boxShadow: '0 16px 0 rgba(0,0,0,0.25)',
            transform: `scale(${0.7 + 0.3 * card})`,
            opacity: Math.min(1, card * 2),
            padding: 44,
            boxSizing: 'border-box',
          }}
        >
          <div style={{fontFamily: FONT_BODY, fontWeight: 800, fontSize: 36, color: '#6b7280', letterSpacing: 2}}>POLLING DADAKAN</div>
          <div style={{fontFamily: FONT_BODY, fontWeight: 900, fontSize: 72, color: '#101322', lineHeight: 1.08, marginTop: 12, opacity: 1, transform: `translateY(${(1 - Math.max(q, card)) * 30}px)`}}>
            {rf(45.69) >= 0 ? 'Kalo lo ketauan jadi buzzer sama keluarga, lo pilih...' : 'Kalo lo ada di posisi ini...'}
          </div>
          <div style={{marginTop: 40, display: 'flex', flexDirection: 'column', gap: 30}}>
            <div style={{transform: `scale(${a * pulse})`, opacity: Math.min(1, a * 2)}}>
              <div style={{background: C.red, borderRadius: 40, padding: '34px 44px', fontFamily: FONT_BODY, fontWeight: 900, fontSize: 70, color: '#fff', boxShadow: '0 12px 0 #8c1212', display: 'flex', justifyContent: 'space-between'}}>
                <span>A. NGELES</span>
                <span>{Math.round(ease(rf(49.5), 20, 0, 62))}%</span>
              </div>
            </div>
            <div style={{transform: `scale(${b * pulse})`, opacity: Math.min(1, b * 2)}}>
              <div style={{background: '#2f6bff', borderRadius: 40, padding: '34px 44px', fontFamily: FONT_BODY, fontWeight: 900, fontSize: 70, color: '#fff', boxShadow: '0 12px 0 #14339c', display: 'flex', justifyContent: 'space-between'}}>
                <span>B. RESIGN</span>
                <span>{Math.round(ease(rf(49.5), 20, 0, 38))}%</span>
              </div>
            </div>
          </div>
        </div>
      )}
      <Char name="admin" h={CH_H} cx={W / 2} bottom={CH_BOTTOM} ty={(1 - ch) * 700 + bob(frame, 6, 26)} />
      <Vignette strength={0.3} />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ K. LIKE DAN SUBSCRIBE (50.2 - 53.9) */
export const SceneSub: React.FC = () => {
  const rf = useRel(SCENE_START.sub);
  const frame = useCurrentFrame();
  const yt = popS(rf(50.3), FPS, {damping: 8});
  const like = popS(rf(50.55), FPS, {damping: 7, stiffness: 210});
  const sub = popS(rf(51.3), FPS, {damping: 9});
  const click = rf(51.95);
  const clicked = click >= 0;
  const finger = ease(rf(51.5), 14, 0, 1);
  const bell = popS(rf(52.4), FPS, {damping: 5, stiffness: 200});
  const ring = rf(52.45) >= 0 ? Math.sin(rf(52.45) * 1.3) * 22 * Math.max(0, 1 - rf(52.45) / 40) : 0;
  const likeBounce = rf(50.55) >= 0 ? 1 + Math.max(0, Math.sin(rf(50.55) / 3)) * 0.12 * Math.max(0, 1 - rf(50.55) / 36) : 1;
  return (
    <SceneWrap>
      <BG a="#d3161c" b="#4a070b" pattern="rays" accent="rgba(255,255,255,0.08)" cy={420} />
      <div style={{position: 'absolute', left: W / 2 - 160, top: 150, transform: `scale(${yt}) rotate(${(1 - yt) * 40}deg)`}}>
        <Img src={staticFile('img/icon-youtube.png')} style={{width: 320, height: 253}} />
      </div>
      <Center style={{top: 470, transform: `scale(${like * likeBounce})`}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 28, background: '#fff', borderRadius: 100, padding: '24px 64px 24px 44px', boxShadow: '0 14px 0 rgba(0,0,0,0.3)'}}>
          <div style={{transform: `rotate(${rf(50.55) >= 0 ? -12 + Math.sin(rf(50.55) / 2) * 10 : 0}deg)`}}>
            <ThumbUp size={150} color="#1a73e8" />
          </div>
          <div style={{fontFamily: FONT_BODY, fontWeight: 900, fontSize: 112, color: '#101322'}}>LIKE</div>
        </div>
      </Center>
      <Center style={{top: 760, transform: `scale(${sub})`}}>
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: 26,
            background: clicked ? '#3a3a3a' : '#ff0000',
            borderRadius: 100,
            padding: '28px 70px',
            border: '8px solid #fff',
            boxShadow: '0 14px 0 rgba(0,0,0,0.35)',
            transform: `scale(${clicked && click < 6 ? 0.93 : 1})`,
          }}
        >
          <div style={{fontFamily: FONT_BODY, fontWeight: 900, fontSize: 80, color: '#fff'}}>{clicked ? 'SUBSCRIBED' : 'SUBSCRIBE'}</div>
          {clicked && (
            <div style={{transform: `scale(${bell}) rotate(${ring}deg)`, transformOrigin: '50% 10%'}}>
              <BellIcon size={92} color={C.yellow} />
            </div>
          )}
        </div>
      </Center>
      {!clicked && sub > 0.5 && (
        <div style={{position: 'absolute', left: W / 2 + 180 + (1 - finger) * 260, top: 930 + (1 - finger) * 260, transform: 'rotate(-30deg)'}}>
          <Finger size={300} />
        </div>
      )}
      <Vignette strength={0.35} />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ L & M. CHAT PERSONAL (Emak / Bapak) */
type PB = {t: number; text: string};
const PersonalChat: React.FC<{
  sceneStart: number;
  who: 'emak' | 'bapak';
  name: string;
  bg: [string, string];
  header: string;
  typingFrom: number;
  typingTo: number;
  bubbles: PB[];
  extra?: (rf: (t: number) => number, frame: number) => React.ReactNode;
}> = ({sceneStart, who, name, bg, header, typingFrom, typingTo, bubbles, extra}) => {
  const rf = useRel(sceneStart);
  const frame = useCurrentFrame();
  const ph = soft(rf(sceneStart + 0.05), FPS);
  const showTyping = rf(typingFrom) >= 0 && rf(typingTo) < 0;
  return (
    <SceneWrap>
      <BG a={bg[0]} b={bg[1]} pattern="dots" accent="rgba(255,255,255,0.12)" />
      <PhoneFrame w={PHONE.w} h={PHONE.h} style={{left: PHONE.left, top: PHONE.top + (1 - ph) * -900}}>
        <ChatHeader title={name} sub={showTyping ? 'sedang mengetik...' : 'online'} avatar={<Face who={who} size={92} ring="#fff" />} bg={header} />
        <ChatBody style={{justifyContent: 'flex-start'}}>
          <div style={{alignSelf: 'center', background: '#182229', color: '#8696a0', fontFamily: FONT_BODY, fontWeight: 700, fontSize: 24, padding: '6px 22px', borderRadius: 16}}>HARI INI</div>
          {bubbles.map((b, i) => (
            <Bubble key={i} rf={rf(b.t)} text={b.text} fs={44} maxW={700} time="19.04" />
          ))}
          {showTyping && <TypingDots frame={frame} />}
        </ChatBody>
        <InputBar />
      </PhoneFrame>
      {extra && extra(rf, frame)}
      <Vignette />
    </SceneWrap>
  );
};

export const SceneEmak: React.FC = () => (
  <PersonalChat
    sceneStart={SCENE_START.emak}
    who="emak"
    name="Emak"
    bg={['#d6336c', '#4a0d2b']}
    header="#5a1d3a"
    typingFrom={54.7}
    typingTo={56.72}
    bubbles={[
      {t: 56.74, text: 'Nak,'},
      {t: 57.38, text: 'kamu dibayar berapa jadi buzzer?'},
    ]}
    extra={(rf, frame) => {
      const q = popS(rf(58.05), FPS, {damping: 6, stiffness: 220});
      const q2 = popS(rf(58.3), FPS, {damping: 6, stiffness: 220});
      return (
        <>
          <div style={{position: 'absolute', left: 30, top: 640 + bob(frame, 10, 20), transform: `scale(${q}) rotate(-14deg)`}}>
            <Txt size={300} font="title" color={C.yellow} stroke="#101322" sw={12}>?</Txt>
          </div>
          <div style={{position: 'absolute', right: 30, top: 380 + bob(frame + 8, 10, 22), transform: `scale(${q2}) rotate(16deg)`}}>
            <Txt size={240} font="title" color={C.red} stroke="#fff" sw={10}>?!</Txt>
          </div>
        </>
      );
    }}
  />
);

export const SceneBapak: React.FC = () => (
  <PersonalChat
    sceneStart={SCENE_START.bapak}
    who="bapak"
    name="Bapak"
    bg={['#1f4fd1', '#0a1233']}
    header="#14234f"
    typingFrom={59.25}
    typingTo={60.55}
    bubbles={[
      {t: 60.6, text: 'pantesan kamu bela terus,'},
      {t: 62.0, text: 'ternyata ada harga.'},
    ]}
    extra={(rf, frame) => {
      const tag = popS(rf(62.15), FPS, {damping: 7, stiffness: 140});
      const swing = Math.sin(rf(62.15) / 5) * 10 * Math.max(0.2, 1 - rf(62.15) / 60);
      return (
        <>
          <div style={{position: 'absolute', left: W / 2 - 200, top: 790, transform: `scale(${tag}) rotate(${swing}deg)`, transformOrigin: '50% 0%'}}>
            <svg width="400" height="320" viewBox="0 0 400 320">
              <line x1="200" y1="0" x2="200" y2="50" stroke="#fff" strokeWidth="6" />
              <path d="M70 70 L330 70 L370 130 L330 300 L70 300 L30 130 Z" fill="#ffd23f" stroke="#101322" strokeWidth="9" strokeLinejoin="round" />
              <circle cx="200" cy="105" r="18" fill="#1f4fd1" stroke="#101322" strokeWidth="6" />
              <text x="200" y="195" textAnchor="middle" fontFamily="Arial Black, Arial, sans-serif" fontWeight="900" fontSize="54" fill="#101322">HARGA</text>
              <text x="200" y="262" textAnchor="middle" fontFamily="Arial Black, Arial, sans-serif" fontWeight="900" fontSize="64" fill="#d3161c">Rp ???</text>
            </svg>
          </div>
          {[0, 1, 2, 3, 4].map((i) => {
            const r = rf(62.2 + i * 0.12);
            if (r < 0) return null;
            return (
              <div key={i} style={{position: 'absolute', left: 60 + i * 200, top: 700 - ease(r, 14, 0, 1) * 200 + Math.max(0, r - 14) * 7, opacity: 1 - Math.min(1, Math.max(0, r - 30) / 20)}}>
                <Coin size={100} />
              </div>
            );
          })}
        </>
      );
    }}
  />
);

/* ------------------------------------------------------------------ N. SEPUPU SCREENSHOT (63.4 - 66.0) */
export const SceneScreenshot: React.FC = () => {
  const rf = useRel(SCENE_START.ss);
  const frame = useCurrentFrame();
  const ch = popS(rf(63.5), FPS, {damping: 10});
  const card = popS(rf(63.7), FPS, {damping: 11});
  const fr = ease(rf(63.9), 28, 1.5, 1);
  const snap = rf(64.65);
  const toast = popS(rf(65.0), FPS, {damping: 9});
  const shrink = snap >= 0 ? ease(snap, 10, 1, 0.55) : 1;
  return (
    <SceneWrap>
      <BG a="#0c7c78" b="#04202b" pattern="grid" accent="rgba(120,255,235,0.12)" />
      <div style={{position: 'absolute', left: 60, top: 190, width: 960, height: 760, transform: `scale(${fr * shrink})`, transformOrigin: '50% 50%', opacity: Math.min(1, card * 2)}}>
        <CornerFrame w={960} h={760} color="#fff" t={12} />
        <div style={{position: 'absolute', left: 80, top: 130, width: 800, transform: `scale(${0.7 + 0.3 * card})`}}>
          <Bubble rf={99} me maxW={800} fs={42} time="19.00" ticks="read" text="tim, jam 7 serang hashtag oposisi, bikin trending #OposisiTenggelam, jangan lupa pake foto editan" />
        </div>
      </div>
      <Center style={{top: 1000, transform: `scale(${toast})`}}>
        <Pill bg="#101322" size={50} border="#fff">
          SCREENSHOT DISIMPAN
        </Pill>
      </Center>
      <Char name="sepupu" h={620} cx={W / 2} bottom={CH_BOTTOM} ty={(1 - ch) * 700} scale={0.95 + 0.05 * ch} />
      <Flash rf={snap} dur={9} />
      <Vignette />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ O. VIRAL DI TWITTER (66.0 - 71.6) */
const CAPTION = 'plot twist, admin buzzer ketauan keluarga.';
export const SceneViral: React.FC = () => {
  const rf = useRel(SCENE_START.viral);
  const frame = useCurrentFrame();
  const now = SCENE_START.viral + frame / FPS;
  const top = popS(rf(66.0), FPS, {damping: 9});
  const card = popS(rf(66.4), FPS, {damping: 10});
  const typedN = Math.max(0, Math.min(CAPTION.length, Math.floor(((now - 68.92) / (71.2 - 68.92)) * CAPTION.length)));
  const typed = CAPTION.slice(0, typedN);
  const k = ease(rf(66.5), 100, 0, 1);
  const stamp = popS(rf(70.55), FPS, {damping: 6, stiffness: 240});
  const sh = rf(70.55) >= 0 && rf(70.55) < 16 ? shake(frame, 14 - rf(70.55) * 0.7, 1.5) : {x: 0, y: 0, r: 0};
  return (
    <SceneWrap>
      <BG a="#0f1419" b="#1d2a38" pattern="grid" accent="rgba(29,155,240,0.10)" />
      <div style={{position: 'absolute', left: 0, right: 0, top: 130, display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 30, transform: `scale(${top})`}}>
        <div style={{width: 130, height: 130, borderRadius: 65, background: '#000', border: '5px solid #fff', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
          <XLogo size={78} color="#fff" />
        </div>
        <Pill bg={C.red} size={52} border="#fff">
          BESOKNYA...
        </Pill>
      </div>
      <div
        style={{
          position: 'absolute',
          left: 50,
          top: 330,
          width: W - 100,
          borderRadius: 40,
          background: '#fff',
          padding: '34px 38px 28px',
          boxSizing: 'border-box',
          boxShadow: '0 20px 50px rgba(0,0,0,0.5)',
          transform: `translate(${sh.x}px, ${sh.y}px) scale(${0.7 + 0.3 * card}) rotate(${sh.r}deg)`,
          opacity: Math.min(1, card * 2),
          fontFamily: FONT_BODY,
        }}
      >
        <div style={{display: 'flex', alignItems: 'center', gap: 22}}>
          <Face who="admin" size={118} bg="#e7e9ea" />
          <div style={{flex: 1}}>
            <div style={{fontWeight: 900, fontSize: 40, color: '#0f1419'}}>Admin Buzzer Istana</div>
            <div style={{fontWeight: 600, fontSize: 30, color: '#536471'}}>@adminbuzzer_01</div>
          </div>
          <XLogo size={64} color="#0f1419" />
        </div>
        <div style={{fontWeight: 800, fontSize: 52, color: '#0f1419', lineHeight: 1.18, marginTop: 24, minHeight: 130}}>
          {typed}
          {typedN < CAPTION.length && rf(68.9) >= 0 ? <span style={{color: '#1d9bf0'}}>|</span> : null}
        </div>
        <div style={{marginTop: 16, borderRadius: 28, overflow: 'hidden', border: '3px solid #cfd9de', background: '#0b141a', padding: 24}}>
          <Bubble rf={99} me maxW={820} fs={32} time="19.00" ticks="read" text="tim, jam 7 serang hashtag oposisi, bikin trending #OposisiTenggelam, jangan lupa pake foto editan" />
        </div>
        <div style={{display: 'flex', justifyContent: 'space-between', marginTop: 26, fontWeight: 700, fontSize: 38, color: '#536471', padding: '0 10px'}}>
          <span style={{display: 'flex', alignItems: 'center', gap: 12}}>
            <CommentIcon size={52} color="#536471" /> {kfmt(8400 * k)}
          </span>
          <span style={{display: 'flex', alignItems: 'center', gap: 12}}>
            <RetweetIcon size={52} color="#00ba7c" /> {kfmt(52000 * k)}
          </span>
          <span style={{display: 'flex', alignItems: 'center', gap: 12}}>
            <HeartIcon size={52} color="#f91880" /> {kfmt(187000 * k)}
          </span>
        </div>
      </div>
      <Center style={{top: 1090, transform: `scale(${0.3 + 0.7 * stamp}) rotate(-7deg)`, opacity: Math.min(1, stamp * 3)}}>
        <Txt size={110} font="title" color="#fff" stroke="#101322" sw={9} style={{background: C.red, padding: '4px 40px', borderRadius: 20, border: '8px solid #fff'}}>
          VIRAL!!
        </Txt>
      </Center>
      <Vignette />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ P. DIPECAT DARI GRUP KELUARGA (71.6 - 76.2) */
export const ScenePecat: React.FC = () => {
  const rf = useRel(SCENE_START.pecat);
  const frame = useCurrentFrame();
  const phase2 = rf(74.15) >= 0;
  const pal = soft(rf(71.7), FPS);
  const stamp = popS(rf(72.15), FPS, {damping: 7, stiffness: 230});
  const slash = ease(rf(73.0), 8, 0, 1);
  const no = popS(rf(73.1), FPS, {damping: 8});
  const ch = popS(rf(74.3), FPS, {damping: 9});
  const msg = popS(rf(74.25), FPS, {damping: 10});
  const stamp2 = popS(rf(74.9), FPS, {damping: 6, stiffness: 220});
  const sh = rf(74.9) >= 0 && rf(74.9) < 14 ? shake(frame, 10, 1.4) : {x: 0, y: 0, r: 0};
  return (
    <SceneWrap flash={phase2}>
      {!phase2 && (
        <>
          <BG a="#1f2a6b" b="#0a0e2a" pattern="rays" accent="rgba(255,255,255,0.05)" cy={620} />
          <div style={{position: 'absolute', left: 50, top: 330 + (1 - pal) * 200, opacity: pal}}>
            <Palace width={980} fill="#dfe6ff" light="#6f86e8" />
          </div>
          <Center style={{top: 190, transform: `scale(${0.3 + 0.7 * stamp}) rotate(-8deg)`, opacity: Math.min(1, stamp * 3)}}>
            <Txt size={150} font="title" color="#fff" stroke="#101322" sw={10} style={{background: C.red, padding: '4px 44px', borderRadius: 22, border: '9px solid #fff'}}>
              DIPECAT
            </Txt>
          </Center>
          <svg width={W} height={H} style={{position: 'absolute', left: 0, top: 0}}>
            <line x1={90} y1={190 + 200} x2={90 + 900 * slash} y2={190 + 200 - 120 * slash} stroke="#101322" strokeWidth="26" strokeLinecap="round" />
            <line x1={90} y1={190 + 200} x2={90 + 900 * slash} y2={190 + 200 - 120 * slash} stroke="#ffd23f" strokeWidth="14" strokeLinecap="round" />
          </svg>
          <Center style={{top: 880, transform: `scale(${no}) rotate(3deg)`}}>
            <Txt size={150} font="title" color={C.yellow} stroke="#101322" sw={12}>
              BUKAN!
            </Txt>
          </Center>
        </>
      )}
      {phase2 && (
        <>
          <BG a="#3b0a14" b="#0d0409" pattern="dots" accent="rgba(255,59,59,0.14)" />
          <div style={{position: 'absolute', left: 70, top: 210, width: W - 140, borderRadius: 40, background: '#0b141a', border: '6px solid #202c33', boxShadow: '0 20px 50px rgba(0,0,0,0.5)', overflow: 'hidden', transform: `scale(${0.7 + 0.3 * msg})`, opacity: Math.min(1, msg * 2)}}>
            <div style={{background: '#7a3a10', padding: '24px 34px', fontFamily: FONT_BODY, fontWeight: 900, fontSize: 44, color: '#fff'}}>KELUARGA BESAR</div>
            <div style={{padding: '36px 30px', display: 'flex', flexDirection: 'column', gap: 24, alignItems: 'center'}}>
              <div style={{background: '#182229', borderRadius: 22, padding: '18px 34px', fontFamily: FONT_BODY, fontWeight: 700, fontSize: 38, color: '#e9edef', textAlign: 'center', lineHeight: 1.25}}>
                Bapak mengeluarkan Anda
                <br />
                dari grup
              </div>
              <div style={{background: '#182229', borderRadius: 22, padding: '18px 34px', fontFamily: FONT_BODY, fontWeight: 700, fontSize: 34, color: '#8696a0', opacity: rf(74.6) >= 0 ? 1 : 0}}>
                Anda tidak dapat mengirim pesan ke grup ini
              </div>
            </div>
          </div>
          <Center style={{top: 700, transform: `translate(${sh.x}px,${sh.y}px) rotate(${-6 + sh.r}deg) scale(${0.3 + 0.7 * stamp2})`, opacity: Math.min(1, stamp2 * 3)}}>
            <Txt size={104} font="title" color="#fff" stroke="#101322" sw={9} style={{background: C.red, padding: '6px 34px', borderRadius: 20, border: '8px solid #fff'}}>
              DIKELUARIN!
            </Txt>
          </Center>
          <Char name="admin" h={CH_H} cx={W / 2} bottom={CH_BOTTOM} ty={(1 - ch) * 700 + Math.sin(frame / 3) * 3} rot={-3} filter="drop-shadow(0 14px 18px rgba(0,0,0,0.4)) grayscale(0.55) brightness(0.9)" />
          {[0, 1].map((i) => {
            const r = (frame - i * 12) % 32;
            return rf(74.5) >= 0 ? (
              <div key={i} style={{position: 'absolute', left: i === 0 ? 470 : 620, top: 1300 - 160 + r * 6, opacity: 1 - r / 32}}>
                <Drop size={46} color="#6ec6ff" />
              </div>
            ) : null;
          })}
        </>
      )}
      <Vignette />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ Q. END CARD (76.2 - 78) */
export const SceneEnd: React.FC = () => {
  const rf = useRel(SCENE_START.end);
  const frame = useCurrentFrame();
  const a = popS(rf(76.25), FPS, {damping: 9});
  const b = popS(rf(76.55), FPS, {damping: 10});
  return (
    <SceneWrap>
      <BG a="#ffd23f" b="#ff8a1a" pattern="rays" accent="rgba(255,255,255,0.18)" cy={900} />
      <Center style={{top: 700, transform: `scale(${a}) rotate(${-3 + Math.sin(frame / 6)}deg)`}}>
        <Txt size={250} font="title" color="#101322" stroke="#fff" sw={10}>
          TAMAT
        </Txt>
      </Center>
      <Center style={{top: 1000, transform: `scale(${b})`}}>
        <Pill bg="#101322" size={56} color="#fff" border="#fff">
          FOLLOW <span style={{color: C.yellow, marginLeft: 6}}>@{CHANNEL}</span>
        </Pill>
      </Center>
    </SceneWrap>
  );
};
