import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {C, FONT_BODY, FPS, H, W} from '../constants';
import {SCENE_START} from '../timing';
import {bob, ease, lin, popS, rnd, shake, soft, useRel} from '../anim';
import {BG, Vignette} from '../ui/Backgrounds';
import {Bubble, ChatBody, ChatHeader, InputBar, PhoneFrame} from '../ui/Chat';
import {Center, Char, Face, Pill, Txt} from '../ui/common';
import {DoubleCheck, Drop, Finger, Gorengan, ImageIcon, Megaphone, PersonIcon} from '../ui/Icons';
import {SceneWrap} from '../ui/Scene';

const PHONE = {w: 820, h: 1060, left: (W - 820) / 2, top: 150};
const CH_BOTTOM = 190;
const CH_H = 660;

const CHUNKS = [
  {t0: 17.95, t1: 18.2, s: 'tim,'},
  {t0: 18.56, t1: 20.4, s: ' jam 7 serang hashtag oposisi,'},
  {t0: 20.88, t1: 22.8, s: ' bikin trending #OposisiTenggelam,'},
  {t0: 23.36, t1: 24.7, s: ' jangan lupa pake foto editan'},
];
const FULL_MSG = CHUNKS.map((c) => c.s).join('');

const typedAt = (t: number) => {
  let out = '';
  for (const c of CHUNKS) {
    if (t >= c.t1) out += c.s;
    else if (t > c.t0) out += c.s.slice(0, Math.floor(((t - c.t0) / (c.t1 - c.t0)) * c.s.length));
  }
  return out;
};

const PhotoAttach: React.FC = () => (
  <div style={{marginTop: 10, width: 420, height: 210, borderRadius: 18, overflow: 'hidden', position: 'relative', background: 'linear-gradient(135deg,#ff9a3c,#ff3b7b 55%,#7b3fe4)'}}>
    <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <ImageIcon size={96} color="rgba(255,255,255,0.85)" />
    </div>
    <div style={{position: 'absolute', left: 12, bottom: 10, fontFamily: FONT_BODY, fontWeight: 800, fontSize: 24, color: '#fff', background: 'rgba(0,0,0,0.45)', padding: '2px 14px', borderRadius: 12}}>
      foto_editan_final2.jpg
    </div>
  </div>
);

const BuzzerAvatar: React.FC = () => (
  <div style={{width: 92, height: 92, borderRadius: 46, background: C.purple, display: 'flex', alignItems: 'center', justifyContent: 'center', border: '4px solid #fff'}}>
    <Megaphone size={64} />
  </div>
);
const FamilyAvatar: React.FC = () => (
  <div style={{width: 92, height: 92, borderRadius: 46, background: '#ff9a3c', display: 'flex', alignItems: 'center', justifyContent: 'center', border: '4px solid #fff'}}>
    <PersonIcon size={62} color="#fff" />
  </div>
);

/* ------------------------------------------------------------------ F. INSTRUKSI KE GRUP BUZZER (14.5 - 25.1) */
export const SceneChat: React.FC = () => {
  const rf = useRel(SCENE_START.chat);
  const frame = useCurrentFrame();
  const now = SCENE_START.chat + frame / FPS;
  const ph = soft(rf(14.55), FPS);
  const typed = typedAt(now);
  const typing = typed.length > 0 && typed.length < FULL_MSG.length;
  const caret = Math.floor(frame / 8) % 2 === 0;
  const showPhoto = rf(24.35) >= 0;
  return (
    <SceneWrap>
      <BG a="#1c1456" b="#0a0a24" pattern="dots" accent="rgba(140,120,255,0.16)" />
      <PhoneFrame w={PHONE.w} h={PHONE.h} style={{left: PHONE.left, top: PHONE.top + (1 - ph) * 900}}>
        <ChatHeader title="TIM BUZZER ISTANA" sub="200 anggota" avatar={<BuzzerAvatar />} bg="#2a1b5e" />
        <ChatBody>
          <Bubble rf={rf(15.2)} name="Akun_Fake_041" nameColor="#f6a609" text="Siap bang, standby" time="18.52" />
          <Bubble rf={rf(15.8)} name="Akun_Fake_117" nameColor="#53bdeb" text="Amunisi hashtag udah siap" time="18.55" />
          {typed.length > 0 && (
            <Bubble
              me
              rf={rf(17.95)}
              text={
                <>
                  {typed}
                  {(typing || caret) && !showPhoto ? <span style={{color: '#00a884'}}>|</span> : null}
                </>
              }
              time="19.00"
              fs={33}
              maxW={700}
              extra={showPhoto ? <PhotoAttach /> : null}
            />
          )}
        </ChatBody>
        <InputBar />
      </PhoneFrame>
      <Vignette />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ G. GORENGAN + KEPENCET (25.1 - 30.0) */
export const SceneGorengan: React.FC = () => {
  const rf = useRel(SCENE_START.gorengan);
  const frame = useCurrentFrame();
  const phase2 = rf(27.55) >= 0;
  const g = popS(rf(25.25), FPS, {damping: 9});
  const finger = soft(rf(25.9), FPS);
  const licin = popS(rf(26.45), FPS, {damping: 7, stiffness: 220});
  const slip = ease(rf(26.5), 14, 0, 1);
  const flashO = interpolate(rf(27.55), [0, 6], [0.95, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  // phase 2
  const ph = popS(rf(27.55), FPS, {damping: 12});
  const header = rf(27.75) >= 0 ? 'KELUARGA BESAR' : 'TIM BUZZER ISTANA';
  const press = rf(28.15);
  const pressed = press >= 0 && press < 10;
  const sent = rf(28.3) >= 0;
  const stamp = popS(rf(28.95), FPS, {damping: 7, stiffness: 220});
  const sh = rf(28.95) >= 0 && rf(28.95) < 18 ? shake(frame, 12 - rf(28.95) * 0.5, 1.3) : {x: 0, y: 0, r: 0};

  return (
    <SceneWrap>
      {!phase2 && (
        <>
          <BG a="#ff9a3c" b="#b8431a" pattern="rays" accent="rgba(255,255,255,0.10)" cy={620} />
          <div style={{position: 'absolute', left: W / 2 - 280, top: 300 + (1 - g) * -400, transform: `scale(${0.6 + 0.4 * g}) rotate(${-6 + slip * 12}deg)`, opacity: Math.min(1, g * 2)}}>
            <Gorengan size={560} />
          </div>
          {Array.from({length: 7}).map((_, i) => {
            const r = (frame - 14 - i * 9) % 40;
            if (frame < 14 + i * 9) return null;
            return (
              <div key={i} style={{position: 'absolute', left: 250 + rnd(i + 1) * 580, top: 640 + r * 11, opacity: 1 - r / 40}}>
                <Drop size={52} color="#ffd23f" />
              </div>
            );
          })}
          <div style={{position: 'absolute', right: 80 + slip * 150, top: 560 + (1 - finger) * 700 + slip * 260, transform: `rotate(${-28 + slip * 40}deg)`, transformOrigin: '50% 100%'}}>
            <Finger size={460} />
          </div>
          <Center style={{top: 160, transform: `scale(${licin}) rotate(${-4 + Math.sin(frame / 2) * 2}deg)`}}>
            <Txt size={150} font="title" color={C.yellow} stroke="#101322" sw={12}>
              LICIN!!
            </Txt>
          </Center>
        </>
      )}
      {phase2 && (
        <>
          <BG a="#3d1d0c" b="#14080a" pattern="dots" accent="rgba(255,154,60,0.15)" />
          <PhoneFrame w={PHONE.w} h={PHONE.h} style={{left: PHONE.left, top: PHONE.top, transform: `scale(${0.88 + 0.12 * ph})`}}>
            <ChatHeader title={header} sub={header === 'KELUARGA BESAR' ? 'Bapak, Emak, Tante, Sepupu, +9' : '200 anggota'} avatar={header === 'KELUARGA BESAR' ? <FamilyAvatar /> : <BuzzerAvatar />} bg={header === 'KELUARGA BESAR' ? '#7a3a10' : '#2a1b5e'} />
            <ChatBody>
              <Bubble rf={99} name="Emak" nameColor="#f6a609" text="Jangan lupa makan ya nak" time="17.40" />
              {sent ? <Bubble me rf={rf(28.3)} fs={30} maxW={720} text={FULL_MSG.trim()} time="19.00" ticks={rf(30) >= 0 ? 'read' : 'sent'} extra={<PhotoAttach />} /> : null}
            </ChatBody>
            <InputBar text={sent ? '' : 'jangan lupa pake foto editan'} hot={pressed} />
          </PhoneFrame>
          {!sent && (
            <div style={{position: 'absolute', left: PHONE.left + PHONE.w - 200, top: PHONE.top + PHONE.h - 130 - (pressed ? 0 : 60 * (1 - Math.min(1, press < 0 ? 0 : 1))), transform: 'rotate(-20deg)'}}>
              <Finger size={380} />
            </div>
          )}
          <Center style={{top: 520, transform: `translate(${sh.x}px, ${sh.y}px) rotate(${-10 + sh.r}deg) scale(${0.3 + 0.7 * stamp})`, opacity: Math.min(1, stamp * 3)}}>
            <Txt size={118} font="title" color="#fff" stroke="#101322" sw={9} style={{background: C.red, padding: '6px 38px', borderRadius: 20, border: '8px solid #fff'}}>
              SALAH GRUP!!
            </Txt>
          </Center>
        </>
      )}
      <AbsoluteFill style={{background: '#fff', opacity: phase2 ? flashO : 0, pointerEvents: 'none'}} />
      <Vignette />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ H. CENTANG BIRU, KELUARGA BACA (30.0 - 39.1) */
const READERS = [
  {who: 'bapak' as const, name: 'BAPAK', t: 32.73, time: '19.00'},
  {who: 'emak' as const, name: 'EMAK', t: 33.99, time: '19.00'},
  {who: 'tante' as const, name: 'TANTE PNS', t: 35.28, time: '19.01'},
  {who: 'sepupu' as const, name: 'SEPUPU AKTIVIS', t: 37.17, time: '19.01'},
];

export const SceneBaca: React.FC = () => {
  const rf = useRel(SCENE_START.baca);
  const frame = useCurrentFrame();
  const phase2 = rf(32.55) >= 0;
  const two = popS(rf(30.1), FPS, {damping: 9});
  const num = rf(30.62) >= 0 ? 1 : 2;
  const numPop = popS(rf(num === 2 ? 30.14 : 30.62), FPS, {damping: 7, stiffness: 220});
  const tick = popS(rf(31.3), FPS, {damping: 6, stiffness: 200});
  const tick2 = popS(rf(31.55), FPS, {damping: 6, stiffness: 200});
  const pulse = 0.5 + 0.5 * Math.sin(frame / 4);

  return (
    <SceneWrap>
      {!phase2 && (
        <>
          <BG a="#0a2a6b" b="#040b24" pattern="rays" accent="rgba(52,183,241,0.14)" cy={560} />
          {rf(31.25) < 0 && (
            <>
              <Center style={{top: 170, transform: `scale(${numPop}) rotate(${(1 - numPop) * 12}deg)`}}>
                <Txt size={640} font="title" color={C.yellow} stroke="#101322" sw={18}>
                  {num}
                </Txt>
              </Center>
              <Center style={{top: 900, transform: `scale(${two})`}}>
                <Pill bg="#101322" size={62} border={C.yellow} color="#fff">
                  DETIK KEMUDIAN...
                </Pill>
              </Center>
            </>
          )}
          {rf(31.25) >= 0 && (
            <>
              <Center style={{top: 250}}>
                <div style={{transform: `scale(${tick}) rotate(${(1 - tick) * -20}deg)`, filter: 'drop-shadow(0 0 40px rgba(52,183,241,0.8))'}}>
                  <DoubleCheck size={380} color="#34b7f1" />
                </div>
              </Center>
              <Center style={{top: 760, transform: `scale(${tick2})`}}>
                <Pill bg="#34b7f1" size={66} border="#fff">
                  CENTANG DUA BIRU
                </Pill>
              </Center>
            </>
          )}
        </>
      )}
      {phase2 && (
        <>
          <BG a={pulse > 0.5 ? '#14307a' : '#4a0e1c'} b="#080818" pattern="rays" accent="rgba(255,255,255,0.06)" cy={700} speed={2} />
          {READERS.map((r, i) => {
            const s = popS(rf(r.t), FPS, {damping: 11, stiffness: 190});
            if (rf(r.t) < 0) return null;
            return (
              <div
                key={r.who}
                style={{
                  position: 'absolute',
                  left: 70,
                  top: 150 + i * 178 + (1 - s) * -120,
                  width: W - 140,
                  height: 150,
                  borderRadius: 30,
                  background: '#202c33',
                  border: '5px solid #34b7f1',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 26,
                  padding: '0 30px',
                  boxSizing: 'border-box',
                  opacity: Math.min(1, s * 2),
                  transform: `scale(${0.85 + 0.15 * s})`,
                  boxShadow: '0 10px 0 rgba(0,0,0,0.35)',
                }}
              >
                <Face who={r.who} size={104} ring="#fff" />
                <div style={{flex: 1}}>
                  <div style={{fontFamily: FONT_BODY, fontWeight: 900, fontSize: 46, color: '#fff'}}>{r.name}</div>
                  <div style={{fontFamily: FONT_BODY, fontWeight: 600, fontSize: 28, color: '#8696a0'}}>membaca pesan - {r.time}</div>
                </div>
                <DoubleCheck size={60} color="#53bdeb" />
              </div>
            );
          })}
          {(() => {
            const o = popS(rf(32.7), FPS, {damping: 12, stiffness: 120});
            const tn = popS(rf(35.28), FPS, {damping: 10});
            const sp = popS(rf(37.17), FPS, {damping: 10});
            const a1 = rf(35.28) >= 0 ? shake(frame, 4, 1.4) : {x: 0, y: 0, r: 0};
            const a2 = rf(37.17) >= 0 ? shake(frame, 5, 1.6) : {x: 0, y: 0, r: 0};
            return (
              <>
                <Char name="ortu" h={520} cx={272} bottom={CH_BOTTOM} ty={(1 - o) * 700} scale={0.9 + 0.1 * o} />
                <Char name="tante" h={600} cx={644} bottom={CH_BOTTOM} ty={(1 - tn) * 700} tx={a1.x} rot={a1.r} />
                <Char name="sepupu" h={600} cx={885} bottom={CH_BOTTOM} ty={(1 - sp) * 700} tx={a2.x} rot={a2.r} />
              </>
            );
          })()}
        </>
      )}
      <Vignette />
    </SceneWrap>
  );
};
