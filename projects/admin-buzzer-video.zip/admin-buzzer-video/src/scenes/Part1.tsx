import React from 'react';
import {AbsoluteFill, Img, staticFile} from 'remotion';
import {C, FPS, H, W} from '../constants';
import {SCENE_START} from '../timing';
import {bob, ease, lin, popS, rnd, shake, soft, useRel} from '../anim';
import {BG, Palace, Skyline, Vignette} from '../ui/Backgrounds';
import {Char, Center, Pill, Txt} from '../ui/common';
import {Bill, Clock, Coin, FakeAvatar, Megaphone, ShieldCheck} from '../ui/Icons';
import {SceneWrap} from '../ui/Scene';

const money = (n: number) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, '.');
const CH_BOTTOM = 190; // kaki karakter di y=1730
const CH_H = 660;

/* ------------------------------------------------------------------ A. INTRO (0 - 2.7) */
export const SceneIntro: React.FC = () => {
  const rf = useRel(SCENE_START.intro);
  const f = rf(0);
  const slam = popS(rf(0.12), FPS, {damping: 8, stiffness: 140, mass: 0.7});
  const sh = rf(0.12) >= 0 && rf(0.12) < 14 ? shake(f, 14 - rf(0.12), 1.2) : {x: 0, y: 0, r: 0};
  const pal = soft(rf(0.1), FPS);
  const ch = popS(rf(0.55), FPS, {damping: 11, stiffness: 120, mass: 0.8});
  const badge = popS(rf(1.0), FPS);
  return (
    <SceneWrap zoom={0}>
      <BG a="#0b1230" b="#243a9c" pattern="rays" accent="rgba(255,255,255,0.05)" cy={620} />
      <div style={{position: 'absolute', left: 50, top: 330 + (1 - pal) * 260, opacity: pal}}>
        <Palace width={980} fill="#dfe6ff" light="#6f86e8" />
      </div>
      <Center style={{top: 90, transform: `translate(${sh.x}px, ${sh.y}px) rotate(${sh.r - 3}deg) scale(${0.4 + 0.6 * slam + (1 - slam) * 1.6})`, opacity: Math.min(1, slam * 3)}}>
        <Txt size={300} font="title" color={C.yellow} stroke="#101322" sw={14}>
          POV
        </Txt>
      </Center>
      <Center style={{top: 905, transform: `scale(${badge}) rotate(-2deg)`}}>
        <Pill bg={C.red} size={52} border="#fff">
          ADMIN BUZZER ISTANA
        </Pill>
      </Center>
      <Char name="admin" h={CH_H} cx={W / 2} bottom={CH_BOTTOM} ty={(1 - ch) * 700} scale={0.9 + 0.1 * ch} />
      <Vignette />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ B. GAJI (2.7 - 5.1) */
export const SceneGaji: React.FC = () => {
  const rf = useRel(SCENE_START.gaji);
  const f = rf(SCENE_START.gaji);
  const val = ease(rf(2.9), 26, 0, 15000000);
  const num = popS(rf(2.88), FPS, {damping: 9, stiffness: 150});
  const ch = popS(rf(2.85), FPS, {damping: 10, stiffness: 140});
  const per = popS(rf(3.9), FPS);
  return (
    <SceneWrap>
      <BG a="#0e8a4f" b="#04361f" pattern="rays" accent="rgba(255,255,255,0.07)" cy={520} />
      {Array.from({length: 16}).map((_, i) => {
        const st = 2.7 + rnd(i + 5) * 0.55;
        const r = rf(st);
        if (r < 0) return null;
        const x = rnd(i) * (W - 200);
        const y = -160 + r * (16 + rnd(i + 3) * 12);
        return (
          <div key={i} style={{position: 'absolute', left: x, top: y, transform: `rotate(${rnd(i + 8) * 60 - 30 + r * (rnd(i + 2) * 6 - 3)}deg)`}}>
            <Bill w={190 + rnd(i + 4) * 90} color={i % 3 === 0 ? '#e9c13b' : '#2fbf71'} />
          </div>
        );
      })}
      <Center style={{top: 250, transform: `scale(${0.5 + 0.5 * num})`, opacity: Math.min(1, num * 2)}}>
        <Txt size={148} font="title" color={C.yellow} stroke="#0a2a1a" sw={12}>
          {'Rp ' + money(val)}
        </Txt>
      </Center>
      <Center style={{top: 470, transform: `scale(${per}) rotate(2deg)`}}>
        <Pill bg="#101322" size={56} border={C.yellow}>
          PER BULAN
        </Pill>
      </Center>
      {[0, 1, 2, 3].map((i) => {
        const r = rf(3.4 + i * 0.28);
        const s = popS(r, FPS);
        return (
          <div key={i} style={{position: 'absolute', left: 140 + i * 235, top: 650 + Math.sin((f + i * 9) / 7) * 20 + (1 - s) * -300, opacity: s, transform: `rotate(${i * 25}deg) scale(${s})`}}>
            <Coin size={120} />
          </div>
        );
      })}
      <Char name="admin" h={CH_H} cx={W / 2} bottom={CH_BOTTOM} ty={(1 - ch) * 650 + bob(f, 6, 28)} scale={0.92 + 0.08 * ch} />
      <Vignette strength={0.35} />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ C. 200 AKUN FAKE (5.1 - 7.55) */
export const SceneAkun: React.FC = () => {
  const rf = useRel(SCENE_START.akun);
  const f = rf(SCENE_START.akun);
  const cnt = ease(rf(5.35), 50, 0, 200);
  const big = popS(rf(5.3), FPS, {damping: 9});
  const done = popS(rf(7.0), FPS, {damping: 7, stiffness: 200});
  const icons = ['facebook', 'tiktok', 'instagram', 'youtube', 'telegram'];
  const iconAR: Record<string, number> = {facebook: 365 / 367, tiktok: 365 / 374, instagram: 337 / 339, youtube: 292 / 371, telegram: 404 / 405};
  const COLS = 9;
  const ROWS = 5;
  return (
    <SceneWrap>
      <BG a="#2a0c5e" b="#0d0724" pattern="grid" accent="rgba(180,120,255,0.18)" />
      <Center style={{top: 130, transform: `scale(${0.4 + 0.6 * big})`, opacity: Math.min(1, big * 2)}}>
        <Txt size={330} font="title" color={C.yellow} stroke="#101322" sw={14} style={{transform: `scale(${1 + (1 - done) * 0 + (done > 0 ? Math.max(0, 1 - done) * 0.1 : 0)})`}}>
          {Math.round(cnt)}
        </Txt>
      </Center>
      <Center style={{top: 480, transform: `scale(${popS(rf(5.5), FPS)})`}}>
        <Pill bg={C.red} size={54} border="#fff">
          AKUN FAKE
        </Pill>
      </Center>
      {icons.map((n, i) => {
        const s = popS(rf(5.45 + i * 0.12), FPS, {damping: 8});
        const h = 118;
        const w = h * iconAR[n];
        return (
          <div key={n} style={{position: 'absolute', left: 90 + i * 190 + (118 - w) / 2, top: 600 + Math.sin((f + i * 8) / 8) * 10, width: w, height: h, transform: `scale(${s}) rotate(${(1 - s) * 90}deg)`, opacity: s}}>
            <Img src={staticFile(`img/icon-${n}.png`)} style={{width: '100%', height: '100%'}} />
          </div>
        );
      })}
      {Array.from({length: COLS * ROWS}).map((_, i) => {
        const col = i % COLS;
        const row = Math.floor(i / COLS);
        const s = popS(rf(5.5 + (i / (COLS * ROWS)) * 1.4), FPS, {damping: 9, stiffness: 220});
        const size = 94;
        return (
          <div key={i} style={{position: 'absolute', left: 52 + col * 109, top: 790 + row * 100, transform: `scale(${s})`, opacity: s}}>
            <FakeAvatar size={size} hue={(i * 47) % 360} />
          </div>
        );
      })}
      <Vignette strength={0.35} />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ D. JAM 7 MALAM, SERANG OPOSISI (7.55 - 11.6) */
export const SceneJam7: React.FC = () => {
  const rf = useRel(SCENE_START.jam7);
  const f = rf(SCENE_START.jam7);
  const clk = popS(rf(7.6), FPS, {damping: 10});
  const m = lin(rf(7.8), 24, 38, 60);
  const h = lin(rf(7.8), 24, 6.35, 7);
  const chime = rf(8.7);
  const wob = chime >= 0 && chime < 20 ? Math.sin(chime * 1.6) * (1 - chime / 20) * 8 : 0;
  const pill = popS(rf(8.72), FPS, {damping: 8, stiffness: 200});
  const mega = popS(rf(9.1), FPS, {damping: 9});
  const tweets = [9.6, 9.9, 10.2, 10.5];
  const stamp = popS(rf(10.65), FPS, {damping: 8, stiffness: 220});
  return (
    <SceneWrap>
      <BG a="#1b0836" b="#4b0a2e" pattern="rays" accent="rgba(255,59,59,0.10)" cy={440} />
      <div style={{position: 'absolute', left: 0, bottom: 0, opacity: 0.8}}>
        <Skyline fill="#0a0418" />
      </div>
      <div style={{position: 'absolute', left: W / 2 - 250, top: 120, transform: `scale(${clk}) rotate(${wob}deg)`}}>
        <Clock size={500} h={h} m={m} />
      </div>
      <Center style={{top: 660, transform: `scale(${pill})`}}>
        <Pill bg="#101322" size={80} border={C.yellow} color={C.yellow}>
          19.00 WIB
        </Pill>
      </Center>
      <div style={{position: 'absolute', left: 30, top: 840, transform: `scale(${mega}) rotate(${-8 + Math.sin(f / 3) * 3}deg)`}}>
        <Megaphone size={270} />
      </div>
      {tweets.map((t, i) => {
        const r = rf(t);
        const s = popS(r, FPS, {damping: 11, stiffness: 180});
        const slide = ease(r, 10, 260, 0);
        if (r < 0) return null;
        return (
          <div key={i} style={{position: 'absolute', left: 310 + slide, top: 830 + i * 98, opacity: Math.min(1, s * 2), transform: `scale(${0.8 + 0.2 * s})`, transformOrigin: '0% 50%'}}>
            <Pill bg={C.red} size={44} border="#fff" style={{boxShadow: '0 8px 0 rgba(0,0,0,0.35)'}}>
              #OposisiTenggelam
            </Pill>
          </div>
        );
      })}
      <Center style={{top: 1195, transform: `scale(${0.3 + 0.7 * stamp}) rotate(-6deg)`, opacity: Math.min(1, stamp * 3)}}>
        <Txt size={84} font="title" color="#fff" stroke="#101322" sw={8} style={{background: C.purple, padding: '8px 36px', borderRadius: 18, border: '6px solid #fff'}}>
          COPY - PASTE!
        </Txt>
      </Center>
      <Vignette />
    </SceneWrap>
  );
};

/* ------------------------------------------------------------------ E. KIRA AMAN / GAK ADA YANG TAU (11.6 - 14.5) */
const Eye: React.FC<{size: number; look: number}> = ({size, look}) => (
  <svg width={size} height={size * 0.7} viewBox="0 0 100 70">
    <ellipse cx="50" cy="35" rx="46" ry="30" fill="#fff" stroke="#101322" strokeWidth="5" />
    <circle cx={50 + look * 18} cy="36" r="15" fill="#101322" />
    <circle cx={45 + look * 18} cy="30" r="5" fill="#fff" />
  </svg>
);

export const SceneAman: React.FC = () => {
  const rf = useRel(SCENE_START.aman);
  const f = rf(SCENE_START.aman);
  const sh = popS(rf(11.9), FPS, {damping: 8, stiffness: 150});
  const secret = popS(rf(13.45), FPS, {damping: 8, stiffness: 230});
  const eyes = popS(rf(13.95), FPS, {damping: 9});
  const ch = popS(rf(11.7), FPS, {damping: 12});
  const wob = rf(13.45) >= 0 ? Math.sin(rf(13.45) * 1.8) * 4 * Math.max(0, 1 - rf(13.45) / 25) : 0;
  const shield = Math.round(0);
  return (
    <SceneWrap>
      <BG a="#0d6b78" b="#0a2c58" pattern="shapes" accent="rgba(255,255,255,0.08)" />
      <div style={{position: 'absolute', left: W / 2 - 240, top: 170, transform: `scale(${sh}) rotate(${wob}deg)`, filter: 'drop-shadow(0 20px 30px rgba(0,0,0,0.4))'}}>
        <ShieldCheck size={480} color="#7dffb0" />
      </div>
      <Center style={{top: 700, transform: `scale(${popS(rf(12.1), FPS)})`}}>
        <Pill bg="#1f9d55" size={68} border="#fff">
          AMAN JAYA
        </Pill>
      </Center>
      <Center style={{top: 560, transform: `scale(${0.3 + 0.7 * secret}) rotate(-12deg)`, opacity: Math.min(1, secret * 3)}}>
        <Txt size={110} font="title" color={C.red} stroke="#fff" sw={9} style={{border: '10px solid #ff3b3b', padding: '4px 28px', borderRadius: 14, background: 'rgba(255,255,255,0.92)', WebkitTextStroke: '0px'}}>
          RAHASIA
        </Txt>
      </Center>
      <div style={{position: 'absolute', left: 40, top: 900, transform: `scale(${eyes})`, opacity: eyes}}>
        <Eye size={190} look={Math.sin(f / 5)} />
      </div>
      <div style={{position: 'absolute', right: 40, top: 880, transform: `scale(${eyes})`, opacity: eyes}}>
        <Eye size={160} look={-Math.sin(f / 6)} />
      </div>
      <Char name="admin" h={CH_H} cx={W / 2} bottom={CH_BOTTOM} ty={(1 - ch) * 700 + bob(f, 5, 30)} />
      <Vignette strength={0.4} />
    </SceneWrap>
  );
};
