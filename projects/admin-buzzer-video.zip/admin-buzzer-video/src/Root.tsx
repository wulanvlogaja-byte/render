import React from 'react';
import {Composition} from 'remotion';
import {AdminBuzzerVideo} from './Video';
import {FPS, H, TOTAL_FRAMES, W} from './constants';

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="AdminBuzzer"
      component={AdminBuzzerVideo}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={W}
      height={H}
    />
  );
};
