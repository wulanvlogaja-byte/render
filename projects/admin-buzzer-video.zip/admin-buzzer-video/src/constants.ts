import {loadFont as loadPoppins} from '@remotion/google-fonts/Poppins';
import {loadFont as loadLuckiest} from '@remotion/google-fonts/LuckiestGuy';

export const W = 1080;
export const H = 1920;
export const FPS = 30;
// narasi = 76.12 detik, ditambah ~2 detik ekor buat end card
export const TOTAL_SEC = 78;
export const TOTAL_FRAMES = Math.round(TOTAL_SEC * FPS);

// Ganti kalau nama channel-nya beda
export const CHANNEL = 'BuzzerRp';

const pop = loadPoppins('normal', {weights: ['600', '800', '900'], subsets: ['latin']});
const lucky = loadLuckiest('normal', {weights: ['400'], subsets: ['latin']});
export const FONT_BODY = pop.fontFamily;
export const FONT_TITLE = lucky.fontFamily;

export const C = {
  navy: '#0b1230',
  navy2: '#1b2a6b',
  red: '#ff3b3b',
  yellow: '#ffd23f',
  green: '#25d366',
  blue: '#34b7f1',
  wa: '#075e54',
  waBg: '#0b141a',
  white: '#ffffff',
  ink: '#101322',
  pink: '#ff4f9a',
  purple: '#7b3fe4',
};

