import {spring, interpolate, Easing, useCurrentFrame, useVideoConfig} from 'remotion';

// Hook: kembalikan fungsi rf(absSec) = jumlah frame sejak detik absolut `absSec`
// (negatif kalau belum sampai). Dipakai di dalam <Sequence from=awal scene>.
export const useRel = (sceneStartSec: number) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const base = Math.round(sceneStartSec * fps);
  return (absSec: number) => frame - (Math.round(absSec * fps) - base);
};

export const popS = (rf: number, fps = 30, o: {damping?: number; stiffness?: number; mass?: number} = {}) =>
  rf < 0
    ? 0
    : spring({frame: rf, fps, config: {damping: o.damping ?? 10, stiffness: o.stiffness ?? 170, mass: o.mass ?? 0.6}});

export const soft = (rf: number, fps = 30) =>
  rf < 0 ? 0 : spring({frame: rf, fps, config: {damping: 18, stiffness: 120, mass: 0.7}});

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));

export const ease = (rf: number, dur: number, from = 0, to = 1) =>
  interpolate(rf, [0, dur], [from, to], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing: Easing.out(Easing.cubic),
  });

export const lin = (rf: number, dur: number, from = 0, to = 1) =>
  interpolate(rf, [0, dur], [from, to], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

// pseudo random deterministik (0..1)
export const rnd = (n: number) => {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
};

export const shake = (frame: number, amp = 8, speed = 1) => ({
  x: Math.sin(frame * 2.3 * speed) * amp + Math.sin(frame * 5.1 * speed) * amp * 0.5,
  y: Math.cos(frame * 2.9 * speed) * amp * 0.7,
  r: Math.sin(frame * 3.3 * speed) * amp * 0.12,
});

export const bob = (frame: number, amp = 10, period = 40) => Math.sin((frame / period) * Math.PI * 2) * amp;
