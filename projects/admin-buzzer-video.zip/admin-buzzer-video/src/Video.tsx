import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {FPS} from './constants';
import {SCENE_END, SCENE_START} from './timing';
import {SFX} from './sfx';
import {SFX_DURATIONS} from './sfxManifest';
import {Captions} from './ui/Captions';
import {SceneAman, SceneAkun, SceneGaji, SceneIntro, SceneJam7} from './scenes/Part1';
import {SceneBaca, SceneChat, SceneGorengan} from './scenes/Part2';
import {
  SceneBapak,
  SceneEmak,
  SceneEnd,
  ScenePasar,
  ScenePecat,
  ScenePoll,
  SceneScreenshot,
  SceneSub,
  SceneViral,
} from './scenes/Part3';

// Urutan scene + komponennya. Durasi tiap scene = sampai awal scene berikutnya (+8 frame overlap buat crossfade).
const SCENES: {start: number; C: React.FC}[] = [
  {start: SCENE_START.intro, C: SceneIntro},
  {start: SCENE_START.gaji, C: SceneGaji},
  {start: SCENE_START.akun, C: SceneAkun},
  {start: SCENE_START.jam7, C: SceneJam7},
  {start: SCENE_START.aman, C: SceneAman},
  {start: SCENE_START.chat, C: SceneChat},
  {start: SCENE_START.gorengan, C: SceneGorengan},
  {start: SCENE_START.baca, C: SceneBaca},
  {start: SCENE_START.pasar, C: ScenePasar},
  {start: SCENE_START.poll, C: ScenePoll},
  {start: SCENE_START.sub, C: SceneSub},
  {start: SCENE_START.emak, C: SceneEmak},
  {start: SCENE_START.bapak, C: SceneBapak},
  {start: SCENE_START.ss, C: SceneScreenshot},
  {start: SCENE_START.viral, C: SceneViral},
  {start: SCENE_START.pecat, C: ScenePecat},
  {start: SCENE_START.end, C: SceneEnd},
];

const SFX_MASTER = 0.7; // volume SFX relatif terhadap narasi
const BACKSOUND_VOL = 0.13;

export const AdminBuzzerVideo: React.FC = () => {
  return (
    <AbsoluteFill style={{backgroundColor: '#000'}}>
      {SCENES.map((s, i) => {
        const from = Math.round(s.start * FPS);
        const next = i + 1 < SCENES.length ? SCENES[i + 1].start : SCENE_END;
        const dur = Math.round((next - s.start) * FPS) + 8;
        return (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <s.C />
          </Sequence>
        );
      })}

      <Captions />

      {/* Narasi */}
      <Audio src={staticFile('audio/narasi.mp3')} volume={1} />

      {/* Backsound (sudah di-loop + fade in/out lewat scripts/make_audio.py) */}
      <Audio src={staticFile('sfx/backsound-full.mp3')} volume={BACKSOUND_VOL} />

      {/* SFX */}
      {SFX.map((x, i) => {
        const dur = Math.min(x.d ?? 99, SFX_DURATIONS[x.n] ?? 1);
        return (
          <Sequence key={i} from={Math.round(x.t * FPS)} durationInFrames={Math.ceil(dur * FPS) + 2}>
            <Audio src={staticFile(`sfx/${x.n}.mp3`)} volume={(x.v ?? 0.6) * SFX_MASTER} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};
