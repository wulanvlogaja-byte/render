export const theme = {
  duration: 65.724,
  fps: 30,
  width: 1080,
  height: 1920,
  colors: {
    bg: '#EAF6FF',
    bgWarm: '#FFF4DC',
    ink: '#1B2A3A',
    blue: '#2D9CDB',
    teal: '#00BFA6',
    yellow: '#FFC93C',
    orange: '#FF8A3D',
    red: '#FF5D5D',
    white: '#FFFFFF',
    grey: '#D8E5EE',
    navy: '#31577A'
  },
  shadow: { dx: 0, dy: 8, blur: 18, opacity: 0.18 },
  radius: 34,
  transition: 0.42,
  timeline: {
    intro: 0,
    tap: 4.417,
    secret: 7.897,
    ac: 10.307,
    panic: 16.932,
    gorengan: 19.476,
    sweat: 25.499,
    choice: 30.921,
    cable: 40.625,
    wifi: 43.503,
    palace: 49.594,
    prank: 53.074,
    punchline: 60.101
  }
} as const;
