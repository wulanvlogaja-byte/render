import React from 'react';
import { Img, staticFile } from 'remotion';
import { theme } from './theme';
import timing from './timing.json';

type Word = { w: string; start: number; end: number };
type Sentence = { text: string; start: number; end: number; words: Word[] };

const C = theme.colors;
const asset = (name: string) => staticFile(`assets/${name}`);
const clamp = (n: number, a = 0, b = 1) => Math.max(a, Math.min(b, n));
const ease = (n: number) => 1 - Math.pow(1 - clamp(n), 3);
const enter = (t: number, t0: number, d = 0.6) => ease((t - t0) / d);
const pulse = (t: number, speed = 1) => 1 + Math.sin(t * speed) * 0.025;

const scenes = [
  { from: 0, to: 4.417, title: 'AKSES SADAP PALING CANGGIH', body: 'POV lo jadi Kapolri', kind: 'police' },
  { from: 4.417, to: 7.897, title: 'TOMBOL RAHASIA', body: 'Iseng pencet sadap presiden', kind: 'tap' },
  { from: 7.897, to: 10.307, title: 'RAHASIA NEGARA?', body: 'Lo kira bakal dengar rahasia negara', kind: 'secret' },
  { from: 10.307, to: 16.932, title: 'KOK AC ISTANA ENGGA DINGIN?', body: 'Ternyata cuma cari remote AC', kind: 'ac' },
  { from: 16.932, to: 19.476, title: 'PANIK!', body: 'Matiin... eh kepencet lagi', kind: 'panic' },
  { from: 19.476, to: 25.499, title: 'PESAN GORENGAN', body: 'Yang pedas, jangan lupa sambal kacang', kind: 'food' },
  { from: 25.499, to: 30.921, title: 'NASIB LO DI UJUNG TANDUK', body: 'Bisa dimutasi jadi tukang parkir', kind: 'sweat' },
  { from: 30.921, to: 40.625, title: 'LANJUT ATAU CABUT?', body: 'Like dan subscribe dulu', kind: 'choice' },
  { from: 40.625, to: 43.503, title: 'SALAH CABUT KABEL', body: 'Bukan kabel sadap!', kind: 'cable' },
  { from: 43.503, to: 49.594, title: 'SATU ISTANA OFFLINE', body: 'Semua menteri enggak bisa Zoom', kind: 'wifi' },
  { from: 49.594, to: 53.074, title: 'BENERIN SENDIRI', body: 'Datang bawa tangga', kind: 'palace' },
  { from: 53.074, to: 60.101, title: 'PLOT TWIST', body: 'Yang disadap ternyata OB istana', kind: 'prank' },
  { from: 60.101, to: 65.724, title: 'MUTASI KE DEPAN MABES', body: 'Cuma boleh nyadap tukang bakso', kind: 'bakso' }
] as const;

function roundedRect(x: number, y: number, w: number, h: number, fill: string, stroke = C.ink, sw = 5) {
  return <rect x={x} y={y} width={w} height={h} rx={theme.radius} fill={fill} stroke={stroke} strokeWidth={sw} />;
}

function SceneArt({ kind, t }: { kind: string; t: number }) {
  const bob = Math.sin(t * 3.2) * 8;
  const s = pulse(t);
  const common = { style: { transformOrigin: '180px 360px', transform: `translateY(${bob}px) scale(${s})` } };
  if (kind === 'police' || kind === 'sweat' || kind === 'choice' || kind === 'palace' || kind === 'prank') return <g {...common}><Img src={asset('Polisi POLRI Bergaya 3D Kartun.png')} x="54" y="62" width="250" height="376" /></g>;
  if (kind === 'bakso' || kind === 'food') return <g {...common}><Img src={asset('Gerobak Bakso Ceria.png')} x="15" y="165" width="330" height="302" /></g>;
  if (kind === 'wifi') return <g {...common}><Img src={asset('IMG_20261104_121151.png')} x="64" y="90" width="232" height="232" /><path d="M80 420 C120 385 240 385 280 420" fill="none" stroke={C.red} strokeWidth="12" strokeLinecap="round" /><path d="M105 448 C140 420 220 420 255 448" fill="none" stroke={C.orange} strokeWidth="12" strokeLinecap="round" /></g>;
  if (kind === 'secret') return <g {...common}><Img src={asset('IMG_20261104_121138.png')} x="62" y="72" width="236" height="236" /><circle cx="180" cy="360" r="76" fill={C.yellow} stroke={C.ink} strokeWidth="8" /><text x="180" y="382" textAnchor="middle" fontSize="76" fontWeight="900" fill={C.ink}>?</text></g>;
  if (kind === 'tap' || kind === 'panic' || kind === 'cable') return <g {...common}>{roundedRect(65, 110, 230, 260, kind === 'panic' ? C.red : C.blue)}<circle cx="180" cy="205" r="58" fill={C.white} stroke={C.ink} strokeWidth="7" /><text x="180" y="225" textAnchor="middle" fontSize="62" fontWeight="900" fill={C.ink}>{kind === 'panic' ? '!' : '●'}</text><path d="M105 420 H255" stroke={C.ink} strokeWidth="12" strokeLinecap="round" /></g>;
  if (kind === 'ac') return <g {...common}>{roundedRect(55, 118, 250, 120, C.white)}<path d="M88 187 H272" stroke={C.blue} strokeWidth="10" strokeLinecap="round" /><path d="M100 235 q15 55 30 0 M150 235 q15 55 30 0 M200 235 q15 55 30 0" fill="none" stroke={C.blue} strokeWidth="8" /><circle cx="180" cy="395" r="56" fill={C.yellow} stroke={C.ink} strokeWidth="7" /><text x="180" y="417" textAnchor="middle" fontSize="60" fontWeight="900" fill={C.ink}>AC</text></g>;
  return <g {...common}><circle cx="180" cy="240" r="80" fill={C.orange} stroke={C.ink} strokeWidth="8" /><text x="180" y="262" textAnchor="middle" fontSize="74" fontWeight="900" fill={C.white}>!</text></g>;
}

function Caption({ sentence, t }: { sentence: Sentence; t: number }) {
  const active = sentence.words.findIndex(w => t >= w.start && t < w.end);
  return <div style={{ position: 'absolute', left: 70, right: 70, bottom: 90, padding: '22px 28px', background: C.white, border: `5px solid ${C.ink}`, borderRadius: 26, color: C.ink, fontSize: 34, fontWeight: 700, lineHeight: 1.18, boxShadow: `0 10px 0 ${C.grey}` }}>
    {sentence.words.map((w, i) => <span key={`${w.w}-${i}`} style={{ display: 'inline-block', marginRight: 9, padding: active === i ? '2px 9px' : '2px 0', borderRadius: 12, background: active === i ? C.yellow : 'transparent', opacity: i < active ? 0.52 : 1 }}>{w.w}</span>)}
  </div>;
}

export const Video: React.FC<{ t: number }> = ({ t }) => {
  const idx = Math.max(0, scenes.findIndex(s => t >= s.from && t < s.to));
  const scene = scenes[idx] || scenes[scenes.length - 1];
  const sentence = (timing.sentences[idx] || timing.sentences[timing.sentences.length - 1]) as Sentence;
  const p = enter(t, scene.from);
  return <div style={{ width: '100%', height: '100%', background: `linear-gradient(180deg, ${C.bg} 0%, ${C.bgWarm} 100%)`, fontFamily: 'Arial, sans-serif', overflow: 'hidden', position: 'relative' }}>
    <svg viewBox="0 0 360 640" width="100%" height="100%" style={{ position: 'absolute', inset: 0 }}>
      <circle cx="45" cy="70" r="12" fill={C.yellow} opacity={0.8} /><circle cx="315" cy="115" r="9" fill={C.orange} opacity={0.8} /><circle cx="300" cy="510" r="14" fill={C.teal} opacity={0.65} />
      <path d="M-20 510 Q70 470 150 510 T380 510 V680 H-20Z" fill={C.blue} opacity={0.16} />
      <path d="M-20 555 Q70 515 150 555 T380 555 V680 H-20Z" fill={C.teal} opacity={0.12} />
      <g opacity={p} transform={`translate(0 ${30 * (1 - p)})`}><SceneArt kind={scene.kind} t={t} /></g>
    </svg>
    <div style={{ position: 'absolute', top: 72, left: 56, right: 56, textAlign: 'center', color: C.ink }}>
      <div style={{ display: 'inline-block', padding: '10px 18px', background: C.yellow, border: `4px solid ${C.ink}`, borderRadius: 18, fontSize: 25, fontWeight: 900 }}>POV ABSURD</div>
      <div style={{ marginTop: 22, fontSize: 45, lineHeight: 1.05, fontWeight: 900, letterSpacing: -1 }}>{scene.title}</div>
      <div style={{ marginTop: 12, fontSize: 27, color: C.navy }}>{scene.body}</div>
    </div>
    <Caption sentence={sentence} t={t} />
  </div>;
};
