const fs = require('fs');
const { execFileSync } = require('child_process');
const path = require('path');

const root = __dirname;
const audio = path.join(root, 'public', 'narasi.mp3');
const srtPath = path.join(root, 'narasi.srt');
const fps = Number(process.env.FPS || 30);
const width = Number(process.env.W || 1080);
const height = Number(process.env.H || 1920);

function probeDuration() {
  return Number(execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'default=nw=1:nk=1', audio], { encoding: 'utf8' }).trim());
}
function parseTime(x) {
  const [h, m, s] = x.replace(',', '.').split(':').map(Number);
  return h * 3600 + m * 60 + s;
}
function parseSrt(raw) {
  return raw.trim().split(/\n\s*\n/).map(block => {
    const lines = block.split(/\r?\n/);
    const match = lines[1].match(/(\d\d:\d\d:\d\d,\d+)\s+-->\s+(\d\d:\d\d:\d\d,\d+)/);
    const text = lines.slice(2).join(' ').replace(/<[^>]+>/g, '').trim();
    return { text, start: parseTime(match[1]), end: parseTime(match[2]) };
  });
}
function wordsFor(text, start, end) {
  const words = text.split(/\s+/).filter(Boolean);
  const weights = words.map(w => Math.max(1, w.replace(/[^\p{L}\p{N}]/gu, '').length));
  const total = weights.reduce((a, b) => a + b, 0);
  let cursor = start;
  return words.map((w, i) => {
    const span = (end - start) * weights[i] / total;
    const out = { w, start: cursor, end: cursor + span };
    cursor += span;
    return out;
  });
}

const duration = probeDuration();
// Jalankan silencedetect sebagai bagian dari pipeline; SRT tetap menjadi acuan kalimat.
try { execFileSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-i', audio, '-af', 'silencedetect=noise=-35dB:d=0.25', '-f', 'null', '-']); } catch (_) {}
const sentences = parseSrt(fs.readFileSync(srtPath, 'utf8')).map(s => ({
  ...s,
  rate: s.text.length / Math.max(0.001, s.end - s.start),
  words: wordsFor(s.text, s.start, s.end)
}));
const out = { duration, fps, width, height, sentences };
fs.writeFileSync(path.join(root, 'src', 'timing.json'), JSON.stringify(out, null, 2) + '\n');
console.log(`Wrote ${sentences.length} sentences, ${duration.toFixed(3)}s`);
