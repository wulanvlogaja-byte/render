# Komedi: POV Sarjana Kehutanan Nyapres (Remotion, 9:16)

1080x1920, 30fps, 75 detik. Narasi = jokowi.mp3, caption dari file SRT.

## Jalankan
    npm install
    npm run studio     # preview
    npm run render     # hasil: out/komedi.mp4

SFX + backsound sudah dibuat di public/ (sintesis sendiri, bebas hak cipta).
Untuk membuat ulang: `npm run audio` (butuh python3, numpy, ffmpeg).

## Struktur
- src/scenes.tsx  : 14 scene, satu per segmen SRT; objek muncul sesuai kalimat narasi
- src/Background.tsx : latar SVG 2D (hutan, senja, pesta, kantor KPU, taman)
- src/parts.tsx / icons.tsx : komponen motion graphic dan ikon SVG
- src/captions.data.ts : data SRT; Captions.tsx memecahnya per 3-4 kata
- Volume: backsound di src/Main.tsx (0.17), SFX di tiap <Sfx vol=...>
