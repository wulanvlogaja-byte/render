import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Background} from './Background';
import {
  Big, Bubble, Character, Confetti, Drop, Pop, Reveal, Sfx, Stamp, Tag, ThoughtCloud, useSec,
} from './parts';
import * as I from './icons';
import {C, FPS, GROUND, H, W, bangers, lilita} from './theme';

const cl = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

const Card: React.FC<{w: number; h: number; bg?: string; children?: React.ReactNode}> = ({w, h, bg = '#fff', children}) => (
  <div
    style={{
      width: w, height: h, background: bg, border: `8px solid ${C.ink}`, borderRadius: 34,
      boxShadow: `0 10px 0 ${C.ink}`, boxSizing: 'border-box', display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center', fontFamily: lilita, color: C.ink, textAlign: 'center',
      overflow: 'hidden',
    }}
  >
    {children}
  </div>
);

/* ───────────── 1. HOOK ───────────── */
const S1: React.FC = () => (
  <AbsoluteFill>
    <Background kind="forest" />
    <Character src="grad" x={270} at={0.2} />
    <Character src="jkw" x={810} at={2.1} />
    <Pop at={0.1} x={260} y={300} rot={-6}><Big size={230} color={C.red}>POV</Big></Pop>
    <Pop at={0.7} x={760} y={320}><Tag bg={C.blue} size={58} w={470}>{'LO JADI\nSARJANA KEHUTANAN?'}</Tag></Pop>
    <Pop at={1.9} x={540} y={950}><Big size={210} color={C.yellow}>=</Big></Pop>
    <Pop at={2.5} x={540} y={560} rot={-3}><Tag bg={C.red} size={64} w={900}>SAMA PERSIS KAYAK JOKOWI?!</Tag></Pop>
    <Sfx at={0.1} f="pop" /><Sfx at={0.2} f="whoosh" /><Sfx at={0.7} f="pop" />
    <Sfx at={2.1} f="whoosh" /><Sfx at={2.5} f="ding" />
  </AbsoluteFill>
);

/* ───────────── 2. DATA ALUMNUS (kartu) ───────────── */
const LBL: React.CSSProperties = {fontFamily: lilita, fontSize: 28, color: '#6b705c', letterSpacing: 2, position: 'absolute', left: 310};
const VAL: React.CSSProperties = {fontFamily: lilita, fontSize: 58, color: C.ink, position: 'absolute', left: 310, whiteSpace: 'nowrap'};

const S2: React.FC = () => {
  const sec = useSec();
  const digits = '8034416';
  const n = Math.max(0, Math.min(digits.length, Math.floor((sec - 5.4) / 0.45) + 1));
  const row = (top: number) => ({top});
  return (
    <AbsoluteFill>
      <Background kind="forest" />
      <Character src="grad" x={270} h={560} at={0.6} />
      <Character src="jkw" x={810} h={560} at={0.2} />
      <Pop at={0.3} x={540} y={520} rot={-1.5}>
        <div style={{position: 'relative', width: 960, height: 580, background: C.cream, border: `10px solid ${C.ink}`, borderRadius: 36, boxShadow: `0 12px 0 ${C.ink}`, overflow: 'hidden', boxSizing: 'border-box'}}>
          <div style={{position: 'absolute', left: 0, top: 0, right: 0, height: 120, background: C.darkGreen, borderBottom: `8px solid ${C.ink}`}}>
            <div style={{position: 'absolute', left: 24, top: 14}}><I.TreeIcon s={84} /></div>
            <div style={{position: 'absolute', left: 130, top: 8, fontFamily: lilita, fontSize: 46, color: '#fff'}}>UNIVERSITAS GADJAH MADA</div>
            <div style={{position: 'absolute', left: 130, top: 62, fontFamily: lilita, fontSize: 34, color: C.yellow}}>FAKULTAS KEHUTANAN</div>
          </div>
          <div style={{position: 'absolute', left: 36, top: 150, width: 230, height: 300, background: '#d8f3dc', border: `6px solid ${C.ink}`, borderRadius: 20, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <I.TreeIcon s={190} />
          </div>
          <Reveal at={0.9} style={{position: 'absolute', left: 36, top: 470, width: 230, textAlign: 'center', fontFamily: lilita, fontSize: 38, color: C.darkGreen}}>ALUMNUS</Reveal>

          <Reveal at={2.2} origin="0% 50%" style={{...LBL, top: 140}}>ANGKATAN</Reveal>
          <Reveal at={3.9} origin="0% 50%" style={{...VAL, top: 168}}>1980</Reveal>

          <Reveal at={4.9} origin="0% 50%" style={{...LBL, top: 255}}>NIM</Reveal>
          {sec >= 5.4 && <div style={{...VAL, ...row(283)}}>{digits.slice(0, n)}{n < 7 && Math.floor(sec * 4) % 2 ? '|' : ''}</div>}

          <Reveal at={9.5} origin="0% 50%" style={{...LBL, top: 365}}>KT</Reveal>
          <Reveal at={10.3} origin="0% 50%" style={{...VAL, top: 393}}>1681</Reveal>

          <Reveal at={11.8} origin="0% 50%" style={{...LBL, top: 465}}>LULUS</Reveal>
          <Reveal at={12.8} origin="0% 50%" style={{...VAL, top: 493}}>5 NOV 1985</Reveal>
        </div>
      </Pop>
      <Stamp at={13.3} x={800} y={640} text="LULUS!" color={C.red} size={96} rot={-12} />
      <Sfx at={0.2} f="whoosh" /><Sfx at={0.3} f="pop" /><Sfx at={0.6} f="whoosh" /><Sfx at={2.2} f="pop" />
      <Sfx at={3.9} f="ding" /><Sfx at={4.9} f="pop" /><Sfx at={5.4} f="ticks" vol={0.5} /><Sfx at={7.0} f="ticks" vol={0.5} />
      <Sfx at={9.5} f="pop" /><Sfx at={10.3} f="ding" /><Sfx at={11.8} f="pop" /><Sfx at={12.8} f="ding" />
      <Sfx at={13.3} f="thud" vol={0.9} /><Sfx at={13.4} f="sparkle" />
    </AbsoluteFill>
  );
};

/* ───────────── 3. LO PIKIR BISA NYAPRES? ───────────── */
const Dot: React.FC<{at: number; x: number; y: number; r: number}> = ({at, x, y, r}) => (
  <Pop at={at} x={x} y={y}><div style={{width: r * 2, height: r * 2, borderRadius: '50%', background: '#fff', border: `6px solid ${C.ink}`}} /></Pop>
);
const S3: React.FC = () => (
  <AbsoluteFill>
    <Background kind="forest" />
    <Character src="grad" x={540} at={0.1} />
    <Dot at={0.4} x={610} y={660} r={12} />
    <Dot at={0.55} x={640} y={622} r={18} />
    <Pop at={0.8} x={540} y={400}>
      <ThoughtCloud w={780} h={400}>
        <div style={{display: 'flex', alignItems: 'center', gap: 16}}>
          <I.Podium s={200} label="LO" />
          <Big size={100} color={C.red} stroke={10} style={{textShadow: 'none'}}>{'VOTE\nLO!'}</Big>
        </div>
      </ThoughtCloud>
    </Pop>
    <Pop at={2.2} x={150} y={520} rot={-18}><Big size={190} color={C.yellow}>?</Big></Pop>
    <Pop at={2.7} x={940} y={560} rot={16}><Big size={190} color={C.orange}>?</Big></Pop>
    <Sfx at={0.1} f="whoosh" /><Sfx at={0.4} f="pop" /><Sfx at={0.55} f="pop" /><Sfx at={0.8} f="ding" />
    <Sfx at={2.2} f="pop" /><Sfx at={2.7} f="pop" />
  </AbsoluteFill>
);

/* ───────────── 4 & 5. KPU ───────────── */
const Desk: React.FC = () => (
  <>
    <div style={{position: 'absolute', left: 0, top: 1130, width: W, height: H - 1130, background: 'linear-gradient(#b5763a,#8d5524)', borderTop: '14px solid #6b3f1d'}} />
    <div style={{position: 'absolute', left: 60, top: 1185, width: W - 120, height: 12, background: 'rgba(0,0,0,0.15)', borderRadius: 6}} />
  </>
);
const KpuSign: React.FC<{scale?: number}> = ({scale = 1}) => (
  <div style={{transform: `scale(${scale})`}}>
    <Tag bg={C.blue} size={46} w={720}>
      <Big size={130} color="#fff">KPU</Big>
      <div>PENDAFTARAN CAPRES</div>
    </Tag>
  </div>
);

const S4: React.FC = () => (
  <AbsoluteFill>
    <Background kind="office" />
    <Pop at={0.1} x={540} y={300}><KpuSign /></Pop>
    <I.Officer x={830} />
    <Character src="grad" x={290} at={0.2} />
    <Desk />
    <Drop at={1.5} x={560} y={1130 - 72}><I.Ijazah s={200} /></Drop>
    <Drop at={2.7} x={730} y={1130 - 100}><I.Skripsi s={200} /></Drop>
    <Sfx at={0.1} f="pop" /><Sfx at={0.2} f="whoosh" /><Sfx at={1.5} f="whoosh" vol={0.4} /><Sfx at={1.85} f="thud" />
    <Sfx at={2.7} f="whoosh" vol={0.4} /><Sfx at={3.05} f="thud" />
  </AbsoluteFill>
);

const S5: React.FC = () => {
  const sec = useSec();
  const d1 = (sec * 260) % 140;
  const d2 = (sec * 260 + 70) % 140;
  return (
    <AbsoluteFill>
      <Background kind="office" />
      <Pop at={0} x={250} y={250}><KpuSign scale={0.5} /></Pop>
      <I.Officer x={830} angry />
      <Character src="grad" x={290} enter={false} shake={5} />
      <Desk />
      <div style={{position: 'absolute', left: 560 - 100, top: 1130 - 144}}><I.Ijazah s={200} /></div>
      <div style={{position: 'absolute', left: 730 - 80, top: 1130 - 200}}><I.Skripsi s={200} /></div>
      <div style={{position: 'absolute', left: 430, top: 760 + d1, opacity: 1 - d1 / 160}}><I.SweatDrop s={44} /></div>
      <div style={{position: 'absolute', left: 190, top: 800 + d2, opacity: 1 - d2 / 160}}><I.SweatDrop s={38} /></div>
      <Pop at={0.15} x={700} y={540}>
        <Bubble w={720} tailLeft="68%" fill="#fff">PARPOL PENDUKUNGNYA MANA?</Bubble>
      </Pop>
      <Pop at={0.7} x={120} y={560} rot={-14}><Big size={170} color={C.red}>?</Big></Pop>
      <Sfx at={0} f="scratch" /><Sfx at={0.15} f="pop" /><Sfx at={0.7} f="buzzer" vol={0.35} />
    </AbsoluteFill>
  );
};

/* ───────────── 6. SYARAT PARPOL ───────────── */
const SeatsCard: React.FC<{prog: number}> = ({prog}) => {
  const dots: {x: number; y: number; th: number; row: number}[] = [];
  [[45, 10], [72, 14], [99, 18]].forEach(([r, n], row) => {
    for (let k = 0; k < n; k++) {
      const th = Math.PI - (k * Math.PI) / (n - 1);
      dots.push({x: 200 + r * Math.cos(th), y: 130 - r * Math.sin(th), th, row});
    }
  });
  const ranked = [...dots].sort((a, b) => b.th - a.th || a.row - b.row);
  const filled = Math.round(dots.length * 0.2 * prog);
  return (
    <Card w={440} h={300}>
      <div style={{fontSize: 38}}>KURSI DPR</div>
      <svg width={400} height={150} viewBox="0 0 400 150">
        {ranked.map((d, i) => (
          <circle key={i} cx={d.x} cy={d.y} r={8} fill={i < filled ? C.darkGreen : '#ced4da'} stroke={C.ink} strokeWidth={2.5} />
        ))}
      </svg>
      <Big size={76} color={C.yellow} stroke={9} style={{textShadow: 'none'}}>MIN. 20%</Big>
    </Card>
  );
};
const PieCard: React.FC<{prog: number}> = ({prog}) => {
  const r = 56, c = 2 * Math.PI * r;
  return (
    <Card w={440} h={300}>
      <div style={{display: 'flex', alignItems: 'center', gap: 18}}>
        <svg width={170} height={170} viewBox="0 0 140 140">
          <circle cx={70} cy={70} r={r} fill="none" stroke="#ced4da" strokeWidth={26} />
          <circle cx={70} cy={70} r={r} fill="none" stroke={C.blue} strokeWidth={26} strokeDasharray={c} strokeDashoffset={c * (1 - 0.25 * prog)} transform="rotate(-90 70 70)" />
          <circle cx={70} cy={70} r={r + 13} fill="none" stroke={C.ink} strokeWidth={4} />
          <circle cx={70} cy={70} r={r - 13} fill="none" stroke={C.ink} strokeWidth={4} />
        </svg>
        <div>
          <Big size={84} color={C.yellow} stroke={9} style={{textShadow: 'none'}}>25%</Big>
          <div style={{fontSize: 34, lineHeight: 1.05}}>SUARA SAH{'\n'}NASIONAL</div>
        </div>
      </div>
    </Card>
  );
};
const S6: React.FC = () => {
  const sec = useSec();
  const p1 = interpolate(sec, [3.3, 4.6], [0, 1], cl);
  const p2 = interpolate(sec, [6.3, 7.6], [0, 1], cl);
  return (
    <AbsoluteFill>
      <Background kind="party" />
      <Character src="jkw" x={540} at={0.1} />
      <Pop at={0.5} x={540} y={250}>
        <div style={{display: 'flex', alignItems: 'center', gap: 18}}>
          <I.Building s={170} color={C.red} />
          <Tag bg={C.red} size={66}>PARPOL GEDE</Tag>
        </div>
      </Pop>
      <Pop at={3.0} x={285} y={545} rot={-2}><SeatsCard prog={p1} /></Pop>
      <Pop at={6.0} x={795} y={545} rot={2}><PieCard prog={p2} /></Pop>
      <Sfx at={0.1} f="whoosh" /><Sfx at={0.5} f="pop" /><Sfx at={3.0} f="pop" /><Sfx at={3.3} f="ticks" vol={0.45} />
      <Sfx at={6.0} f="pop" /><Sfx at={6.3} f="ticks" vol={0.45} /><Sfx at={8.3} f="ding" />
    </AbsoluteFill>
  );
};

/* ───────────── 7. OTOMATIS LOLOS ───────────── */
const S7: React.FC = () => (
  <AbsoluteFill>
    <Background kind="party" />
    <Character src="jkw" x={540} enter={false} jump={26} />
    <Stamp at={0.05} x={540} y={470} text={'OTOMATIS\nLOLOS!'} color={C.darkGreen} size={150} rot={-5} />
    <Confetti at={0.05} />
    <Sfx at={0.05} f="tada" /><Sfx at={0.1} f="thud" vol={0.6} />
  </AbsoluteFill>
);

/* ───────────── 8. GRUP WA & TETANGGA KOS ───────────── */
const Bub: React.FC<{at: number; top: number; children: React.ReactNode}> = ({at, top, children}) => (
  <Reveal at={at} origin="0% 50%" style={{position: 'absolute', left: 18, top, background: '#fff', border: `5px solid ${C.ink}`, borderRadius: '8px 26px 26px 26px', padding: '10px 20px', fontFamily: lilita, fontSize: 30, color: C.ink, maxWidth: 330}}>
    {children}
  </Reveal>
);
const S8: React.FC = () => (
  <AbsoluteFill>
    <Background kind="dusk" />
    <Character src="grad" x={250} at={0.1} />
    <Pop at={1.7} x={760} y={480}>
      <div style={{width: 430, height: 640, background: '#111', borderRadius: 56, padding: 16, border: `8px solid ${C.ink}`, boxSizing: 'border-box'}}>
        <div style={{background: '#e7ded3', borderRadius: 38, height: '100%', overflow: 'hidden', position: 'relative'}}>
          <div style={{background: '#075e54', height: 110, padding: '16px 20px', boxSizing: 'border-box', fontFamily: lilita, color: '#fff'}}>
            <div style={{fontSize: 30}}>Grup WA Alumni Kehutanan</div>
            <div style={{fontSize: 22, opacity: 0.8}}>3 online</div>
          </div>
          <Bub at={2.3} top={130}>semangat bro!</Bub>
          <Bub at={3.0} top={230}>kami doain dari jauh</Bub>
          <Bub at={3.6} top={330}>...</Bub>
        </div>
      </div>
    </Pop>
    <Pop at={4.3} x={265} y={530} rot={-4}><Tag bg={C.red} size={44}>PENDUKUNG: 3</Tag></Pop>
    <Pop at={3.9} x={800} y={1235}>
      <svg width={360} height={300} viewBox="0 0 360 300">
        <polygon points="180,6 350,110 10,110" fill={C.red} stroke={C.ink} strokeWidth={6} strokeLinejoin="round" />
        <rect x="30" y="110" width="300" height="180" fill={C.cream} stroke={C.ink} strokeWidth={6} />
        <rect x="130" y="30" width="100" height="44" rx="8" fill="#fff" stroke={C.ink} strokeWidth={5} />
        <text x="180" y="64" textAnchor="middle" fontFamily={bangers} fontSize="38" fill={C.ink}>KOS</text>
        <rect x="56" y="136" width="130" height="110" rx="10" fill="#9bd3f4" stroke={C.ink} strokeWidth={6} />
        <circle cx="121" cy="198" r="38" fill="#f4c08a" stroke={C.ink} strokeWidth={5} />
        <line x1="98" y1="180" x2="114" y2="174" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
        <line x1="144" y1="180" x2="128" y2="174" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
        <circle cx="108" cy="192" r="5" fill={C.ink} /><circle cx="134" cy="192" r="5" fill={C.ink} />
        <path d="M106 220 q15 -14 30 0" fill="none" stroke={C.ink} strokeWidth={5} strokeLinecap="round" />
        <path d="M104 202 c-4 10 -4 16 0 20 c4 -4 4 -10 0 -20z" fill="#74c0fc" />
        <rect x="220" y="150" width="80" height="140" fill="#8d5524" stroke={C.ink} strokeWidth={6} />
        <circle cx="288" cy="224" r="6" fill={C.yellow} />
      </svg>
    </Pop>
    <Pop at={4.4} x={780} y={1000}><Bubble w={340} tailLeft="30%">kasihan...</Bubble></Pop>
    <Sfx at={0.1} f="whoosh" /><Sfx at={1.7} f="pop" /><Sfx at={2.3} f="notify" /><Sfx at={3.0} f="notify" />
    <Sfx at={3.6} f="notify" vol={0.4} /><Sfx at={3.9} f="pop" /><Sfx at={4.3} f="buzzer" vol={0.25} /><Sfx at={4.4} f="pop" />
  </AbsoluteFill>
);

/* ───────────── 9. EH BENTAR BRO ───────────── */
const S9: React.FC = () => (
  <AbsoluteFill>
    <Background kind="forest" />
    <Character src="grad" x={540} enter={false} />
    <Pop at={0.05} x={540} y={330} until={2.9} rot={-4}><Big size={200} color={C.red}>{'EH BENTAR\nBRO!'}</Big></Pop>
    <Pop at={3.0} x={285} y={520} rot={-3}>
      <Card w={440} h={270} bg="#d3f9d8">
        <div style={{fontSize: 42}}>GELAR</div>
        <Big size={110} color={C.darkGreen}>SAMA</Big>
      </Card>
    </Pop>
    <Pop at={4.1} x={795} y={520} rot={3}>
      <Card w={440} h={270} bg="#ffe3e3">
        <div style={{fontSize: 42}}>DUKUNGAN</div>
        <Big size={140} color={C.red}>0</Big>
      </Card>
    </Pop>
    <Sfx at={0.05} f="scratch" /><Sfx at={3.0} f="pop" /><Sfx at={3.3} f="ding" vol={0.5} />
    <Sfx at={4.1} f="pop" /><Sfx at={4.2} f="buzzer" vol={0.35} /><Sfx at={4.6} f="crickets" vol={0.5} />
  </AbsoluteFill>
);

/* ───────────── 10. NYAPRES ATAU MANDOR KEBUN ───────────── */
const S10: React.FC = () => (
  <AbsoluteFill>
    <Background kind="forest" />
    <Character src="grad" x={540} enter={false} />
    <Pop at={0.3} x={250} y={440} rot={-5}>
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10}}>
        <Tag bg={C.darkGreen} size={58} w={440}>NYAPRES</Tag>
        <I.Podium s={130} label="LO" />
      </div>
    </Pop>
    <Pop at={1.6} x={830} y={440} rot={5}>
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10}}>
        <Tag bg={C.orange} size={58} w={440}>{'MANDOR\nKEBUN'}</Tag>
      </div>
    </Pop>
    <Drop at={2.5} x={535} y={650}><I.StrawHat s={280} /></Drop>
    <Sfx at={0.3} f="pop" /><Sfx at={1.6} f="pop" /><Sfx at={2.8} f="boing" />
  </AbsoluteFill>
);

/* ───────────── 11. LIKE & SUBSCRIBE ───────────── */
const S11: React.FC = () => {
  const sec = useSec();
  const f = useCurrentFrame();
  const done = sec >= 2.45;
  const cx = interpolate(sec, [1.7, 2.4], [1000, 800], cl);
  const cy = interpolate(sec, [1.7, 2.4], [760, 560], cl);
  const press = sec > 2.3 && sec < 2.55 ? 0.9 : 1;
  const bell = sec >= 2.5 ? Math.sin(f * 1.1) * 22 * Math.max(0, 1 - (sec - 2.5) / 1.6) : 0;
  return (
    <AbsoluteFill>
      <Background kind="forest" />
      <Character src="grad" x={540} at={0.1} jump={14} />
      <Pop at={0.4} x={250} y={500} rot={-8}>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <I.Thumb s={250} />
          <Big size={70} color="#fff" stroke={10}>LIKE</Big>
        </div>
      </Pop>
      <Pop at={1.2} x={740} y={500}>
        <div style={{transform: `scale(${press})`, display: 'flex', alignItems: 'center', gap: 16, background: done ? '#868e96' : '#ff0033', border: `8px solid ${C.ink}`, borderRadius: 30, padding: '20px 34px', boxShadow: `0 10px 0 ${C.ink}`, fontFamily: lilita, fontSize: 54, color: '#fff'}}>
          {!done && <svg width={54} height={54} viewBox="0 0 54 54"><polygon points="8,4 50,27 8,50" fill="#fff" stroke={C.ink} strokeWidth={4} strokeLinejoin="round" /></svg>}
          {done ? 'SUBSCRIBED' : 'SUBSCRIBE'}
        </div>
      </Pop>
      {sec >= 1.7 && <div style={{position: 'absolute', left: cx, top: cy}}><I.Cursor s={100} /></div>}
      <Pop at={2.5} x={940} y={640}><I.Bell s={150} rot={bell} /></Pop>
      <Pop at={3.4} x={540} y={250}><Tag bg={C.blue} size={52} w={940}>{'TIM SARJANA KEHUTANAN\nMANA YANG RELATE?'}</Tag></Pop>
      <Sfx at={0.4} f="pop" /><Sfx at={1.2} f="pop" /><Sfx at={1.7} f="whoosh" vol={0.35} /><Sfx at={2.45} f="click" />
      <Sfx at={2.5} f="ding" /><Sfx at={3.4} f="pop" /><Sfx at={3.6} f="sparkle" vol={0.5} />
    </AbsoluteFill>
  );
};

/* ───────────── 12. SADAR: JOKOWI ───────────── */
const S12: React.FC = () => {
  const sec = useSec();
  const f = useCurrentFrame();
  const sx = interpolate(sec, [3.9, 4.05, 4.2], [1, 0, 1], cl);
  const name = sec < 4.05 ? 'LO' : 'JOKOWI';
  return (
    <AbsoluteFill>
      <Background kind="forest" />
      <Character src="grad" x={540} at={0.1} until={4.25} />
      <Character src="jkw" x={540} at={4.25} />
      <Pop at={0.1} x={540} y={330} until={1.1} rot={-5}><Big size={210} color={C.yellow}>LANJUT.</Big></Pop>
      <Pop at={1.3} x={540} y={480}><I.Bulb s={200} f={f} /></Pop>
      <Pop at={2.4} x={540} y={225}><Tag bg={C.blue} size={50} w={940}>{'SARJANA KEHUTANAN\nBISA JADI PRESIDEN'}</Tag></Pop>
      <Reveal at={3.0} style={{position: 'absolute', left: 540 - 190, top: 990, width: 380}}>
        <div style={{transform: `scaleX(${sx})`}}>
          <div style={{background: C.red, color: '#fff', fontFamily: lilita, fontSize: 32, textAlign: 'center', padding: '8px', borderRadius: '18px 18px 0 0', border: `6px solid ${C.ink}`}}>HALO, NAMA SAYA</div>
          <div style={{background: '#fff', border: `6px solid ${C.ink}`, borderTop: 0, borderRadius: '0 0 18px 18px', textAlign: 'center', padding: '6px 0 4px'}}>
            <Big size={90} color={C.ink} stroke={0} style={{textShadow: 'none'}}>{name}</Big>
          </div>
        </div>
      </Reveal>
      <Pop at={4.25} x={540} y={1000} until={4.9} rot={-8}><Big size={150} color={C.yellow}>POOF!</Big></Pop>
      <Sfx at={0.1} f="whoosh" /><Sfx at={0.15} f="pop" /><Sfx at={1.3} f="ding" /><Sfx at={2.4} f="pop" />
      <Sfx at={3.0} f="pop" /><Sfx at={3.9} f="whoosh" vol={0.5} /><Sfx at={4.25} f="boing" /><Sfx at={4.3} f="sparkle" />
    </AbsoluteFill>
  );
};

/* ───────────── 13. RELAWAN, PARTAI, PAMAN MK ───────────── */
const S13: React.FC = () => (
  <AbsoluteFill>
    <Background kind="forest" />
    <Character src="jkw" x={540} enter={false} jump={10} />
    <Pop at={0.2} x={190} y={530} rot={-4}>
      <Card w={330} h={300} bg="#e7f5ff"><I.Crowd s={230} /><Big size={66} color={C.blue} stroke={8} style={{textShadow: 'none'}}>RELAWAN</Big></Card>
    </Pop>
    <Pop at={1.2} x={540} y={510} rot={2}>
      <Card w={330} h={300} bg="#fff5f5"><I.Building s={190} /><Big size={66} color={C.red} stroke={8} style={{textShadow: 'none'}}>PARTAI</Big></Card>
    </Pop>
    <Pop at={2.1} x={890} y={530} rot={4}>
      <Card w={330} h={300} bg="#fff9db"><I.Gavel s={170} /><Big size={62} color={C.orange} stroke={8} style={{textShadow: 'none'}}>PAMAN MK</Big></Card>
    </Pop>
    <Sfx at={0.2} f="pop" /><Sfx at={1.2} f="pop" /><Sfx at={2.1} f="pop" /><Sfx at={2.2} f="ding" vol={0.5} />
  </AbsoluteFill>
);

/* ───────────── 14. PUNCHLINE: TAMAN KOMPLEKS ───────────── */
const S14: React.FC = () => {
  const sec = useSec();
  const grow = interpolate(sec, [5.2, 6.2], [0.3, 1], cl);
  const water = sec > 4.8 ? (sec * 400) % 120 : 0;
  return (
    <AbsoluteFill>
      <Background kind="park" />
      <Character src="grad" x={300} at={0.1} />
      <Pop at={0.4} x={540} y={300} until={2.4} rot={-4}><Big size={150} color={C.red}>{'BUKAN\nJOKOWI'}</Big></Pop>
      <Pop at={2.5} x={300} y={500}><I.Ijazah s={240} /></Pop>
      <Stamp at={4.0} x={300} y={640} text="MENTOK!" color={C.red} size={80} rot={-8} />
      {/* papan taman kompleks */}
      <Pop at={4.5} x={790} y={1000}>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <Tag bg="#b5763a" size={50} w={440}>TAMAN KOMPLEKS</Tag>
          <div style={{width: 26, height: 280, background: '#8d5524', border: `6px solid ${C.ink}`}} />
        </div>
      </Pop>
      <Pop at={4.8} x={610} y={1180} rot={-8}><I.WateringCan s={230} /></Pop>
      {sec > 4.9 && [0, 1, 2].map((i) => (
        <div key={i} style={{position: 'absolute', left: 520 + i * 14, top: 1230 + ((water + i * 40) % 120), width: 10, height: 18, borderRadius: 6, background: '#4cc9f0', opacity: 0.9}} />
      ))}
      <Pop at={5.2} x={470} y={1300}><I.FlowerPot s={210} grow={grow} /></Pop>
      {/* negara dicoret */}
      <Pop at={6.0} x={780} y={470} rot={3}>
        <div style={{position: 'relative'}}>
          <Tag bg={C.navy} size={64} w={460}>NGURUS NEGARA</Tag>
          <Reveal at={6.4} style={{position: 'absolute', inset: 0}}>
            <svg width={460} height={130} viewBox="0 0 460 130" style={{position: 'absolute', left: 0, top: -4}}>
              <line x1="20" y1="14" x2="440" y2="116" stroke={C.red} strokeWidth={22} strokeLinecap="round" />
              <line x1="440" y1="14" x2="20" y2="116" stroke={C.red} strokeWidth={22} strokeLinecap="round" />
            </svg>
          </Reveal>
        </div>
      </Pop>
      <Pop at={7.5} x={540} y={240}><Tag bg={C.yellow} color={C.ink} size={60} w={940}>{'GELAR SAMA,\nNASIB BEDA.'}</Tag></Pop>
      <Sfx at={0.1} f="whoosh" /><Sfx at={0.4} f="pop" /><Sfx at={2.5} f="pop" /><Sfx at={4.0} f="thud" />
      <Sfx at={4.5} f="pop" /><Sfx at={4.8} f="pop" /><Sfx at={5.2} f="boing" vol={0.5} />
      <Sfx at={6.2} f="sadtrombone" vol={0.8} /><Sfx at={6.4} f="thud" vol={0.7} /><Sfx at={7.5} f="ding" />
    </AbsoluteFill>
  );
};

export const SCENES: {s: number; C: React.FC; wipe?: string}[] = [
  {s: 0, C: S1},
  {s: 3.794, C: S2, wipe: '#ffd23f'},
  {s: 17.822, C: S3, wipe: '#ef476f'},
  {s: 21.481, C: S4, wipe: '#118ab2'},
  {s: 25.75, C: S5, wipe: '#ef476f'},
  {s: 28.393, C: S6, wipe: '#ffd23f'},
  {s: 37.338, C: S7},
  {s: 38.693, C: S8, wipe: '#2b2d6e'},
  {s: 44.114, C: S9, wipe: '#ef476f'},
  {s: 49.603, C: S10, wipe: '#ff9f1c'},
  {s: 52.924, C: S11, wipe: '#06d6a0'},
  {s: 57.871, C: S12, wipe: '#ffd23f'},
  {s: 63.563, C: S13},
  {s: 66.545, C: S14, wipe: '#118ab2'},
];
