import React from 'react';
import {C, bangers, lilita} from './theme';

const st = {stroke: C.ink, strokeWidth: 5, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};

export const TreeIcon: React.FC<{s?: number}> = ({s = 100}) => (
  <svg width={s} height={s} viewBox="0 0 100 100">
    <rect x="43" y="66" width="14" height="28" fill="#7a4b2a" {...st} />
    <polygon points="50,6 82,46 18,46" fill="#37b24d" {...st} />
    <polygon points="50,28 88,74 12,74" fill="#2b8a3e" {...st} />
  </svg>
);

export const Ijazah: React.FC<{s?: number}> = ({s = 200}) => (
  <svg width={s} height={s * 0.72} viewBox="0 0 200 144">
    <rect x="8" y="8" width="184" height="118" rx="10" fill={C.cream} {...st} />
    <rect x="22" y="22" width="156" height="90" rx="6" fill="none" stroke="#c9a227" strokeWidth="4" />
    <text x="100" y="58" textAnchor="middle" fontFamily={lilita} fontSize="32" fill={C.ink}>IJAZAH</text>
    <line x1="48" y1="74" x2="152" y2="74" stroke={C.ink} strokeWidth="4" />
    <line x1="60" y1="90" x2="140" y2="90" stroke={C.ink} strokeWidth="4" />
    <polygon points="150,106 140,140 152,132 164,140 166,106" fill={C.red} {...st} />
    <circle cx="154" cy="100" r="18" fill={C.red} {...st} />
  </svg>
);

export const Skripsi: React.FC<{s?: number}> = ({s = 200}) => (
  <svg width={s * 0.8} height={s} viewBox="0 0 160 200">
    <rect x="10" y="8" width="140" height="184" rx="10" fill="#2a9d8f" {...st} />
    <rect x="10" y="8" width="22" height="184" rx="8" fill="#21867a" {...st} />
    <rect x="44" y="30" width="96" height="70" rx="6" fill={C.cream} {...st} />
    <text x="92" y="58" textAnchor="middle" fontFamily={lilita} fontSize="22" fill={C.ink}>SKRIPSI</text>
    <text x="92" y="84" textAnchor="middle" fontFamily={lilita} fontSize="17" fill={C.red}>KAYU LAPIS</text>
    <g>
      {[0, 1, 2, 3].map((i) => (
        <rect key={i} x="48" y={118 + i * 16} width="94" height="14" rx="3" fill={i % 2 ? '#b9803f' : '#e0a95f'} {...st} strokeWidth={3} />
      ))}
    </g>
  </svg>
);

export const Building: React.FC<{s?: number; color?: string}> = ({s = 200, color = C.red}) => (
  <svg width={s} height={s * 0.9} viewBox="0 0 200 180">
    <line x1="100" y1="4" x2="100" y2="30" {...st} />
    <polygon points="100,4 140,14 100,26" fill={C.yellow} {...st} strokeWidth={3} />
    <polygon points="100,28 192,70 8,70" fill={color} {...st} />
    {[0, 1, 2, 3].map((i) => (
      <rect key={i} x={24 + i * 40} y="76" width="22" height="70" fill="#fff" {...st} strokeWidth={4} />
    ))}
    <rect x="6" y="148" width="188" height="14" fill="#e9ecef" {...st} />
    <rect x="-2" y="164" width="204" height="14" fill="#ced4da" {...st} />
  </svg>
);

export const Podium: React.FC<{s?: number; label?: string}> = ({s = 200, label = 'LO'}) => (
  <svg width={s} height={s * 1.1} viewBox="0 0 200 220">
    <path d="M100 92 V44 q0 -14 14 -14" fill="none" stroke={C.ink} strokeWidth="8" strokeLinecap="round" />
    <ellipse cx="118" cy="30" rx="16" ry="12" fill="#495057" {...st} />
    <polygon points="38,92 162,92 178,212 22,212" fill="#b5763a" {...st} />
    <rect x="58" y="110" width="84" height="44" rx="6" fill={C.cream} {...st} strokeWidth={4} />
    <text x="100" y="142" textAnchor="middle" fontFamily={bangers} fontSize="34" fill={C.red}>{label}</text>
  </svg>
);

export const StrawHat: React.FC<{s?: number}> = ({s = 260}) => (
  <svg width={s} height={s * 0.5} viewBox="0 0 260 130">
    <polygon points="130,6 232,100 28,100" fill="#f1c453" {...st} />
    <path d="M70 70 L190 70 M52 86 L208 86" stroke="#c98f1b" strokeWidth="5" />
    <ellipse cx="130" cy="102" rx="124" ry="18" fill="#e0aa2e" {...st} />
  </svg>
);

export const Bulb: React.FC<{s?: number; f?: number}> = ({s = 200, f = 0}) => (
  <svg width={s} height={s} viewBox="0 0 200 200" style={{transform: `scale(${1 + Math.sin(f / 4) * 0.04})`}}>
    {[...Array(8)].map((_, i) => (
      <line key={i} x1="100" y1="100" x2={100 + Math.cos((i * Math.PI) / 4) * 96} y2={100 + Math.sin((i * Math.PI) / 4) * 96} stroke={C.yellow} strokeWidth="8" strokeLinecap="round" />
    ))}
    <circle cx="100" cy="92" r="52" fill={C.yellow} {...st} />
    <rect x="76" y="140" width="48" height="26" rx="6" fill="#adb5bd" {...st} />
    <rect x="82" y="166" width="36" height="12" rx="5" fill="#868e96" {...st} />
    <path d="M82 90 q18 22 36 0" fill="none" stroke={C.ink} strokeWidth="5" />
  </svg>
);

export const Gavel: React.FC<{s?: number}> = ({s = 200}) => (
  <svg width={s} height={s} viewBox="0 0 200 200">
    <g transform="rotate(-30 100 100)">
      <rect x="88" y="70" width="24" height="120" rx="8" fill="#b5763a" {...st} />
      <rect x="40" y="30" width="120" height="56" rx="12" fill="#8d5524" {...st} />
      <rect x="40" y="30" width="22" height="56" rx="8" fill="#6b3f1d" {...st} />
      <rect x="138" y="30" width="22" height="56" rx="8" fill="#6b3f1d" {...st} />
    </g>
    <rect x="30" y="176" width="140" height="18" rx="6" fill="#6b3f1d" {...st} />
  </svg>
);

export const Crowd: React.FC<{s?: number}> = ({s = 240}) => {
  const cols = [C.red, C.blue, C.green, C.orange, '#9b5de5'];
  return (
    <svg width={s} height={s * 0.6} viewBox="0 0 250 150">
      {cols.map((c, i) => (
        <g key={i} transform={`translate(${14 + i * 46} ${i % 2 ? 14 : 0})`}>
          <circle cx="22" cy="34" r="20" fill="#f4c08a" {...st} strokeWidth={4} />
          <path d="M0 110 q0 -50 22 -50 q22 0 22 50 z" fill={c} {...st} strokeWidth={4} />
          <line x1="40" y1="64" x2="46" y2="10" stroke={C.ink} strokeWidth="4" />
          <rect x="44" y="6" width="26" height="16" fill={c} {...st} strokeWidth={3} />
        </g>
      ))}
    </svg>
  );
};

export const Thumb: React.FC<{s?: number}> = ({s = 240}) => (
  <svg width={s} height={s} viewBox="0 0 200 200">
    <rect x="12" y="90" width="38" height="96" rx="8" fill={C.blue} {...st} />
    <path d="M62 94 L96 20 q14 -8 24 6 l-8 54 h58 q22 4 16 26 l-12 56 q-4 18 -22 18 H62 z" fill="#ffd8a8" {...st} />
  </svg>
);

export const Bell: React.FC<{s?: number; rot?: number}> = ({s = 150, rot = 0}) => (
  <svg width={s} height={s} viewBox="0 0 200 200" style={{transform: `rotate(${rot}deg)`, transformOrigin: '50% 10%'}}>
    <path d="M100 20 c-40 0 -56 32 -56 70 v28 l-18 24 h148 l-18 -24 v-28 c0 -38 -16 -70 -56 -70z" fill={C.yellow} {...st} />
    <circle cx="100" cy="162" r="16" fill={C.orange} {...st} />
  </svg>
);

export const Cursor: React.FC<{s?: number}> = ({s = 110}) => (
  <svg width={s} height={s} viewBox="0 0 80 120">
    <path d="M6 6 L6 100 L30 78 L48 116 L64 108 L46 72 L78 72 Z" fill="#fff" {...st} />
  </svg>
);

export const WateringCan: React.FC<{s?: number}> = ({s = 240}) => (
  <svg width={s} height={s * 0.8} viewBox="0 0 240 190">
    <path d="M60 60 q-40 0 -40 40 q0 30 40 30" fill="none" stroke={C.ink} strokeWidth="10" />
    <rect x="50" y="50" width="110" height="110" rx="14" fill={C.blue} {...st} />
    <polygon points="160,80 232,30 240,48 160,120" fill="#0c7a9c" {...st} />
    <ellipse cx="236" cy="38" rx="10" ry="20" fill="#0c7a9c" {...st} transform="rotate(30 236 38)" />
    <rect x="62" y="64" width="86" height="14" rx="6" fill="#4cc9f0" />
  </svg>
);

export const FlowerPot: React.FC<{s?: number; grow?: number}> = ({s = 200, grow = 1}) => (
  <svg width={s} height={s} viewBox="0 0 200 200">
    <g transform={`translate(100 140) scale(${grow}) translate(-100 -140)`}>
      <path d="M100 140 V60 M100 110 q-30 -10 -40 -40 M100 100 q30 -10 40 -40" stroke="#2b8a3e" strokeWidth="8" fill="none" strokeLinecap="round" />
      {[[100, 50], [58, 62], [142, 52]].map((p, i) => (
        <g key={i}>
          {[0, 1, 2, 3, 4].map((k) => (
            <circle key={k} cx={p[0] + Math.cos((k * 2 * Math.PI) / 5) * 16} cy={p[1] + Math.sin((k * 2 * Math.PI) / 5) * 16} r="12" fill={i === 1 ? C.red : '#ff8fab'} {...st} strokeWidth={3} />
          ))}
          <circle cx={p[0]} cy={p[1]} r="9" fill={C.yellow} {...st} strokeWidth={3} />
        </g>
      ))}
    </g>
    <polygon points="50,140 150,140 136,196 64,196" fill="#e76f51" {...st} />
    <rect x="44" y="130" width="112" height="20" rx="6" fill="#f4845f" {...st} />
  </svg>
);

export const SweatDrop: React.FC<{s?: number}> = ({s = 50}) => (
  <svg width={s} height={s * 1.4} viewBox="0 0 50 70">
    <path d="M25 4 C25 4 4 34 4 48 a21 21 0 0 0 42 0 C46 34 25 4 25 4z" fill="#74c0fc" {...st} strokeWidth={4} />
  </svg>
);

export const Officer: React.FC<{x: number; angry?: boolean}> = ({x, angry = false}) => (
  <svg width={360} height={560} viewBox="0 0 360 560" style={{position: 'absolute', left: x - 180, top: 1130 - 440}}>
    <path d="M30 560 q0 -250 150 -250 q150 0 150 250z" fill="#4dabf7" {...st} />
    <polygon points="150,310 180,370 210,310" fill="#fff" {...st} strokeWidth={4} />
    <rect x="156" y="372" width="50" height="62" rx="6" fill="#fff" {...st} strokeWidth={4} />
    <text x="181" y="412" textAnchor="middle" fontFamily={bangers} fontSize="26" fill={C.blue}>KPU</text>
    <rect x="164" y="268" width="32" height="50" fill="#e8a96b" {...st} strokeWidth={4} />
    <circle cx="180" cy="200" r="86" fill="#f4c08a" {...st} />
    <path d="M96 190 q4 -90 84 -90 q80 0 84 90 q-40 -40 -84 -40 q-44 0 -84 40z" fill="#1b1b2f" />
    <g stroke={C.ink} strokeWidth="6" fill="#fff">
      <circle cx="146" cy="206" r="24" />
      <circle cx="214" cy="206" r="24" />
      <line x1="170" y1="206" x2="190" y2="206" />
    </g>
    <circle cx="148" cy="208" r="8" fill={C.ink} />
    <circle cx="212" cy="208" r="8" fill={C.ink} />
    {angry ? (
      <>
        <line x1="120" y1="168" x2="168" y2="184" stroke={C.ink} strokeWidth="9" strokeLinecap="round" />
        <line x1="240" y1="168" x2="192" y2="184" stroke={C.ink} strokeWidth="9" strokeLinecap="round" />
        <path d="M150 256 q30 -22 60 0" fill="none" stroke={C.ink} strokeWidth="7" strokeLinecap="round" />
      </>
    ) : (
      <>
        <line x1="124" y1="176" x2="168" y2="176" stroke={C.ink} strokeWidth="9" strokeLinecap="round" />
        <line x1="192" y1="176" x2="236" y2="176" stroke={C.ink} strokeWidth="9" strokeLinecap="round" />
        <line x1="156" y1="252" x2="204" y2="252" stroke={C.ink} strokeWidth="7" strokeLinecap="round" />
      </>
    )}
  </svg>
);
