export const SEGMENTS: {s: number; e: number; text: string}[] = [
 {
  "s": 0.0,
  "e": 3.794,
  "text": "POV lo jadi sarjana kehutanan? Sama persis kayak Jokowi."
 },
 {
  "s": 3.794,
  "e": 17.822,
  "text": "Alumnus Fakultas Kehutanan UGM angkatan seribu sembilan ratus delapan puluh NIM delapan nol tiga empat empat satu enam. KT satu enam delapan satu lulus lima November seribu sembilan ratus delapan puluh lima."
 },
 {
  "s": 17.822,
  "e": 21.481,
  "text": "Lo pikir dengan ijazah yang sama lo bisa nyapres juga?"
 },
 {
  "s": 21.481,
  "e": 25.75,
  "text": "Lo daftar ke KPU, bawa ijazah, bawa skripsi tentang kayu lapis."
 },
 {
  "s": 25.75,
  "e": 28.393,
  "text": "Tapi ditanya, parpol pendukungnya mana?"
 },
 {
  "s": 28.393,
  "e": 37.338,
  "text": "Jokowi dulu nyapres diusung parpol gede yang punya minimal dua puluh persen kursi DPR atau dua puluh lima persen suara sah nasional."
 },
 {
  "s": 37.338,
  "e": 38.693,
  "text": "Jadi otomatis lolos."
 },
 {
  "s": 38.693,
  "e": 44.114,
  "text": "Lo nyapres cuma diusung grup WA alumni kehutanan sama tetangga kos yang kasihan."
 },
 {
  "s": 44.114,
  "e": 49.603,
  "text": "Eh bentar Bro, kalau lo ada di posisi ini gelar sama tapi enggak ada yang dukung."
 },
 {
  "s": 49.603,
  "e": 52.924,
  "text": "Bakal tetap nyapres atau balik jadi mandor kebun?"
 },
 {
  "s": 52.924,
  "e": 57.871,
  "text": "Like dan subscribe dulu biar tahu tim sarjana kehutanan mana yang relate."
 },
 {
  "s": 57.871,
  "e": 63.563,
  "text": "Lanjut. Akhirnya lo sadar sarjana kehutanan bisa jadi presiden kalau namanya Jokowi."
 },
 {
  "s": 63.563,
  "e": 66.545,
  "text": "Punya relawan, punya partai, punya paman MK."
 },
 {
  "s": 66.545,
  "e": 73.796,
  "text": "Kalau nama lo bukan Jokowi gelar kehutanan lo paling mentok buat ngurus taman kompleks bukan ngurus negara."
 }
];
