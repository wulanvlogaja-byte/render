import {loadFont as loadLilita} from '@remotion/google-fonts/LilitaOne';
import {loadFont as loadBangers} from '@remotion/google-fonts/Bangers';

export const FPS = 30;
export const W = 1080;
export const H = 1920;
export const GROUND = 1400; // garis tanah karakter
export const S = (sec: number) => Math.round(sec * FPS);
export const TOTAL = S(75); // narasi 73.8s + ekor 1.2s

export const lilita = loadLilita().fontFamily;
export const bangers = loadBangers().fontFamily;

export const C = {
  ink: '#1b1b2f',
  cream: '#fff6dc',
  yellow: '#ffd23f',
  red: '#ef476f',
  green: '#06d6a0',
  darkGreen: '#2f9e44',
  blue: '#118ab2',
  navy: '#073b4c',
  orange: '#ff9f1c',
  white: '#ffffff',
};
