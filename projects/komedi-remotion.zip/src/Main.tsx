import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {Captions} from './Captions';
import {SCENES} from './scenes';
import {S, TOTAL, W} from './theme';

/** Wipe warna singkat di awal tiap scene sebagai transisi */
const Wipe: React.FC<{color: string}> = ({color}) => {
  const f = useCurrentFrame();
  if (f > 9) return null;
  const x = interpolate(f, [0, 9], [0, W], {extrapolateRight: 'clamp'});
  return <AbsoluteFill style={{background: color, transform: `translateX(${x}px)`}} />;
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    <Audio src={staticFile('bgm.mp3')} volume={0.17} loop />
    <Audio src={staticFile('narasi.mp3')} volume={1} />
    {SCENES.map((sc, i) => {
      const from = S(sc.s);
      const end = i === SCENES.length - 1 ? TOTAL : S(SCENES[i + 1].s);
      const Comp = sc.C;
      return (
        <Sequence key={sc.s} from={from} durationInFrames={end - from}>
          <AbsoluteFill>
            <Comp />
            {sc.wipe ? <Wipe color={sc.wipe} /> : null}
          </AbsoluteFill>
        </Sequence>
      );
    })}
    <Captions />
  </AbsoluteFill>
);
